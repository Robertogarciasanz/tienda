(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const l of document.querySelectorAll('link[rel="modulepreload"]'))s(l);new MutationObserver(l=>{for(const c of l)if(c.type==="childList")for(const d of c.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&s(d)}).observe(document,{childList:!0,subtree:!0});function i(l){const c={};return l.integrity&&(c.integrity=l.integrity),l.referrerPolicy&&(c.referrerPolicy=l.referrerPolicy),l.crossOrigin==="use-credentials"?c.credentials="include":l.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function s(l){if(l.ep)return;l.ep=!0;const c=i(l);fetch(l.href,c)}})();var Ed={exports:{}},Xo={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var r_;function My(){if(r_)return Xo;r_=1;var r=Symbol.for("react.transitional.element"),e=Symbol.for("react.fragment");function i(s,l,c){var d=null;if(c!==void 0&&(d=""+c),l.key!==void 0&&(d=""+l.key),"key"in l){c={};for(var p in l)p!=="key"&&(c[p]=l[p])}else c=l;return l=c.ref,{$$typeof:r,type:s,key:d,ref:l!==void 0?l:null,props:c}}return Xo.Fragment=e,Xo.jsx=i,Xo.jsxs=i,Xo}var o_;function Ey(){return o_||(o_=1,Ed.exports=My()),Ed.exports}var R=Ey(),Td={exports:{}},ut={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var l_;function Ty(){if(l_)return ut;l_=1;var r=Symbol.for("react.transitional.element"),e=Symbol.for("react.portal"),i=Symbol.for("react.fragment"),s=Symbol.for("react.strict_mode"),l=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),d=Symbol.for("react.context"),p=Symbol.for("react.forward_ref"),m=Symbol.for("react.suspense"),h=Symbol.for("react.memo"),g=Symbol.for("react.lazy"),x=Symbol.for("react.activity"),_=Symbol.iterator;function y(B){return B===null||typeof B!="object"?null:(B=_&&B[_]||B["@@iterator"],typeof B=="function"?B:null)}var M={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},A=Object.assign,b={};function S(B,Q,ve){this.props=B,this.context=Q,this.refs=b,this.updater=ve||M}S.prototype.isReactComponent={},S.prototype.setState=function(B,Q){if(typeof B!="object"&&typeof B!="function"&&B!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,B,Q,"setState")},S.prototype.forceUpdate=function(B){this.updater.enqueueForceUpdate(this,B,"forceUpdate")};function N(){}N.prototype=S.prototype;function O(B,Q,ve){this.props=B,this.context=Q,this.refs=b,this.updater=ve||M}var z=O.prototype=new N;z.constructor=O,A(z,S.prototype),z.isPureReactComponent=!0;var k=Array.isArray;function L(){}var H={H:null,A:null,T:null,S:null},T=Object.prototype.hasOwnProperty;function I(B,Q,ve){var Ae=ve.ref;return{$$typeof:r,type:B,key:Q,ref:Ae!==void 0?Ae:null,props:ve}}function Z(B,Q){return I(B.type,Q,B.props)}function G(B){return typeof B=="object"&&B!==null&&B.$$typeof===r}function K(B){var Q={"=":"=0",":":"=2"};return"$"+B.replace(/[=:]/g,function(ve){return Q[ve]})}var ue=/\/+/g;function pe(B,Q){return typeof B=="object"&&B!==null&&B.key!=null?K(""+B.key):Q.toString(36)}function F(B){switch(B.status){case"fulfilled":return B.value;case"rejected":throw B.reason;default:switch(typeof B.status=="string"?B.then(L,L):(B.status="pending",B.then(function(Q){B.status==="pending"&&(B.status="fulfilled",B.value=Q)},function(Q){B.status==="pending"&&(B.status="rejected",B.reason=Q)})),B.status){case"fulfilled":return B.value;case"rejected":throw B.reason}}throw B}function D(B,Q,ve,Ae,Ce){var ae=typeof B;(ae==="undefined"||ae==="boolean")&&(B=null);var ye=!1;if(B===null)ye=!0;else switch(ae){case"bigint":case"string":case"number":ye=!0;break;case"object":switch(B.$$typeof){case r:case e:ye=!0;break;case g:return ye=B._init,D(ye(B._payload),Q,ve,Ae,Ce)}}if(ye)return Ce=Ce(B),ye=Ae===""?"."+pe(B,0):Ae,k(Ce)?(ve="",ye!=null&&(ve=ye.replace(ue,"$&/")+"/"),D(Ce,Q,ve,"",function(Ze){return Ze})):Ce!=null&&(G(Ce)&&(Ce=Z(Ce,ve+(Ce.key==null||B&&B.key===Ce.key?"":(""+Ce.key).replace(ue,"$&/")+"/")+ye)),Q.push(Ce)),1;ye=0;var Me=Ae===""?".":Ae+":";if(k(B))for(var Ie=0;Ie<B.length;Ie++)Ae=B[Ie],ae=Me+pe(Ae,Ie),ye+=D(Ae,Q,ve,ae,Ce);else if(Ie=y(B),typeof Ie=="function")for(B=Ie.call(B),Ie=0;!(Ae=B.next()).done;)Ae=Ae.value,ae=Me+pe(Ae,Ie++),ye+=D(Ae,Q,ve,ae,Ce);else if(ae==="object"){if(typeof B.then=="function")return D(F(B),Q,ve,Ae,Ce);throw Q=String(B),Error("Objects are not valid as a React child (found: "+(Q==="[object Object]"?"object with keys {"+Object.keys(B).join(", ")+"}":Q)+"). If you meant to render a collection of children, use an array instead.")}return ye}function P(B,Q,ve){if(B==null)return B;var Ae=[],Ce=0;return D(B,Ae,"","",function(ae){return Q.call(ve,ae,Ce++)}),Ae}function q(B){if(B._status===-1){var Q=B._result;Q=Q(),Q.then(function(ve){(B._status===0||B._status===-1)&&(B._status=1,B._result=ve)},function(ve){(B._status===0||B._status===-1)&&(B._status=2,B._result=ve)}),B._status===-1&&(B._status=0,B._result=Q)}if(B._status===1)return B._result.default;throw B._result}var he=typeof reportError=="function"?reportError:function(B){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var Q=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof B=="object"&&B!==null&&typeof B.message=="string"?String(B.message):String(B),error:B});if(!window.dispatchEvent(Q))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",B);return}console.error(B)},_e={map:P,forEach:function(B,Q,ve){P(B,function(){Q.apply(this,arguments)},ve)},count:function(B){var Q=0;return P(B,function(){Q++}),Q},toArray:function(B){return P(B,function(Q){return Q})||[]},only:function(B){if(!G(B))throw Error("React.Children.only expected to receive a single React element child.");return B}};return ut.Activity=x,ut.Children=_e,ut.Component=S,ut.Fragment=i,ut.Profiler=l,ut.PureComponent=O,ut.StrictMode=s,ut.Suspense=m,ut.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=H,ut.__COMPILER_RUNTIME={__proto__:null,c:function(B){return H.H.useMemoCache(B)}},ut.cache=function(B){return function(){return B.apply(null,arguments)}},ut.cacheSignal=function(){return null},ut.cloneElement=function(B,Q,ve){if(B==null)throw Error("The argument must be a React element, but you passed "+B+".");var Ae=A({},B.props),Ce=B.key;if(Q!=null)for(ae in Q.key!==void 0&&(Ce=""+Q.key),Q)!T.call(Q,ae)||ae==="key"||ae==="__self"||ae==="__source"||ae==="ref"&&Q.ref===void 0||(Ae[ae]=Q[ae]);var ae=arguments.length-2;if(ae===1)Ae.children=ve;else if(1<ae){for(var ye=Array(ae),Me=0;Me<ae;Me++)ye[Me]=arguments[Me+2];Ae.children=ye}return I(B.type,Ce,Ae)},ut.createContext=function(B){return B={$$typeof:d,_currentValue:B,_currentValue2:B,_threadCount:0,Provider:null,Consumer:null},B.Provider=B,B.Consumer={$$typeof:c,_context:B},B},ut.createElement=function(B,Q,ve){var Ae,Ce={},ae=null;if(Q!=null)for(Ae in Q.key!==void 0&&(ae=""+Q.key),Q)T.call(Q,Ae)&&Ae!=="key"&&Ae!=="__self"&&Ae!=="__source"&&(Ce[Ae]=Q[Ae]);var ye=arguments.length-2;if(ye===1)Ce.children=ve;else if(1<ye){for(var Me=Array(ye),Ie=0;Ie<ye;Ie++)Me[Ie]=arguments[Ie+2];Ce.children=Me}if(B&&B.defaultProps)for(Ae in ye=B.defaultProps,ye)Ce[Ae]===void 0&&(Ce[Ae]=ye[Ae]);return I(B,ae,Ce)},ut.createRef=function(){return{current:null}},ut.forwardRef=function(B){return{$$typeof:p,render:B}},ut.isValidElement=G,ut.lazy=function(B){return{$$typeof:g,_payload:{_status:-1,_result:B},_init:q}},ut.memo=function(B,Q){return{$$typeof:h,type:B,compare:Q===void 0?null:Q}},ut.startTransition=function(B){var Q=H.T,ve={};H.T=ve;try{var Ae=B(),Ce=H.S;Ce!==null&&Ce(ve,Ae),typeof Ae=="object"&&Ae!==null&&typeof Ae.then=="function"&&Ae.then(L,he)}catch(ae){he(ae)}finally{Q!==null&&ve.types!==null&&(Q.types=ve.types),H.T=Q}},ut.unstable_useCacheRefresh=function(){return H.H.useCacheRefresh()},ut.use=function(B){return H.H.use(B)},ut.useActionState=function(B,Q,ve){return H.H.useActionState(B,Q,ve)},ut.useCallback=function(B,Q){return H.H.useCallback(B,Q)},ut.useContext=function(B){return H.H.useContext(B)},ut.useDebugValue=function(){},ut.useDeferredValue=function(B,Q){return H.H.useDeferredValue(B,Q)},ut.useEffect=function(B,Q){return H.H.useEffect(B,Q)},ut.useEffectEvent=function(B){return H.H.useEffectEvent(B)},ut.useId=function(){return H.H.useId()},ut.useImperativeHandle=function(B,Q,ve){return H.H.useImperativeHandle(B,Q,ve)},ut.useInsertionEffect=function(B,Q){return H.H.useInsertionEffect(B,Q)},ut.useLayoutEffect=function(B,Q){return H.H.useLayoutEffect(B,Q)},ut.useMemo=function(B,Q){return H.H.useMemo(B,Q)},ut.useOptimistic=function(B,Q){return H.H.useOptimistic(B,Q)},ut.useReducer=function(B,Q,ve){return H.H.useReducer(B,Q,ve)},ut.useRef=function(B){return H.H.useRef(B)},ut.useState=function(B){return H.H.useState(B)},ut.useSyncExternalStore=function(B,Q,ve){return H.H.useSyncExternalStore(B,Q,ve)},ut.useTransition=function(){return H.H.useTransition()},ut.version="19.2.6",ut}var c_;function op(){return c_||(c_=1,Td.exports=Ty()),Td.exports}var tt=op(),Ad={exports:{}},Wo={},Rd={exports:{}},Cd={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var u_;function Ay(){return u_||(u_=1,(function(r){function e(D,P){var q=D.length;D.push(P);e:for(;0<q;){var he=q-1>>>1,_e=D[he];if(0<l(_e,P))D[he]=P,D[q]=_e,q=he;else break e}}function i(D){return D.length===0?null:D[0]}function s(D){if(D.length===0)return null;var P=D[0],q=D.pop();if(q!==P){D[0]=q;e:for(var he=0,_e=D.length,B=_e>>>1;he<B;){var Q=2*(he+1)-1,ve=D[Q],Ae=Q+1,Ce=D[Ae];if(0>l(ve,q))Ae<_e&&0>l(Ce,ve)?(D[he]=Ce,D[Ae]=q,he=Ae):(D[he]=ve,D[Q]=q,he=Q);else if(Ae<_e&&0>l(Ce,q))D[he]=Ce,D[Ae]=q,he=Ae;else break e}}return P}function l(D,P){var q=D.sortIndex-P.sortIndex;return q!==0?q:D.id-P.id}if(r.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var c=performance;r.unstable_now=function(){return c.now()}}else{var d=Date,p=d.now();r.unstable_now=function(){return d.now()-p}}var m=[],h=[],g=1,x=null,_=3,y=!1,M=!1,A=!1,b=!1,S=typeof setTimeout=="function"?setTimeout:null,N=typeof clearTimeout=="function"?clearTimeout:null,O=typeof setImmediate<"u"?setImmediate:null;function z(D){for(var P=i(h);P!==null;){if(P.callback===null)s(h);else if(P.startTime<=D)s(h),P.sortIndex=P.expirationTime,e(m,P);else break;P=i(h)}}function k(D){if(A=!1,z(D),!M)if(i(m)!==null)M=!0,L||(L=!0,K());else{var P=i(h);P!==null&&F(k,P.startTime-D)}}var L=!1,H=-1,T=5,I=-1;function Z(){return b?!0:!(r.unstable_now()-I<T)}function G(){if(b=!1,L){var D=r.unstable_now();I=D;var P=!0;try{e:{M=!1,A&&(A=!1,N(H),H=-1),y=!0;var q=_;try{t:{for(z(D),x=i(m);x!==null&&!(x.expirationTime>D&&Z());){var he=x.callback;if(typeof he=="function"){x.callback=null,_=x.priorityLevel;var _e=he(x.expirationTime<=D);if(D=r.unstable_now(),typeof _e=="function"){x.callback=_e,z(D),P=!0;break t}x===i(m)&&s(m),z(D)}else s(m);x=i(m)}if(x!==null)P=!0;else{var B=i(h);B!==null&&F(k,B.startTime-D),P=!1}}break e}finally{x=null,_=q,y=!1}P=void 0}}finally{P?K():L=!1}}}var K;if(typeof O=="function")K=function(){O(G)};else if(typeof MessageChannel<"u"){var ue=new MessageChannel,pe=ue.port2;ue.port1.onmessage=G,K=function(){pe.postMessage(null)}}else K=function(){S(G,0)};function F(D,P){H=S(function(){D(r.unstable_now())},P)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(D){D.callback=null},r.unstable_forceFrameRate=function(D){0>D||125<D?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):T=0<D?Math.floor(1e3/D):5},r.unstable_getCurrentPriorityLevel=function(){return _},r.unstable_next=function(D){switch(_){case 1:case 2:case 3:var P=3;break;default:P=_}var q=_;_=P;try{return D()}finally{_=q}},r.unstable_requestPaint=function(){b=!0},r.unstable_runWithPriority=function(D,P){switch(D){case 1:case 2:case 3:case 4:case 5:break;default:D=3}var q=_;_=D;try{return P()}finally{_=q}},r.unstable_scheduleCallback=function(D,P,q){var he=r.unstable_now();switch(typeof q=="object"&&q!==null?(q=q.delay,q=typeof q=="number"&&0<q?he+q:he):q=he,D){case 1:var _e=-1;break;case 2:_e=250;break;case 5:_e=1073741823;break;case 4:_e=1e4;break;default:_e=5e3}return _e=q+_e,D={id:g++,callback:P,priorityLevel:D,startTime:q,expirationTime:_e,sortIndex:-1},q>he?(D.sortIndex=q,e(h,D),i(m)===null&&D===i(h)&&(A?(N(H),H=-1):A=!0,F(k,q-he))):(D.sortIndex=_e,e(m,D),M||y||(M=!0,L||(L=!0,K()))),D},r.unstable_shouldYield=Z,r.unstable_wrapCallback=function(D){var P=_;return function(){var q=_;_=P;try{return D.apply(this,arguments)}finally{_=q}}}})(Cd)),Cd}var f_;function Ry(){return f_||(f_=1,Rd.exports=Ay()),Rd.exports}var wd={exports:{}},Bn={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var d_;function Cy(){if(d_)return Bn;d_=1;var r=op();function e(m){var h="https://react.dev/errors/"+m;if(1<arguments.length){h+="?args[]="+encodeURIComponent(arguments[1]);for(var g=2;g<arguments.length;g++)h+="&args[]="+encodeURIComponent(arguments[g])}return"Minified React error #"+m+"; visit "+h+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function i(){}var s={d:{f:i,r:function(){throw Error(e(522))},D:i,C:i,L:i,m:i,X:i,S:i,M:i},p:0,findDOMNode:null},l=Symbol.for("react.portal");function c(m,h,g){var x=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:l,key:x==null?null:""+x,children:m,containerInfo:h,implementation:g}}var d=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function p(m,h){if(m==="font")return"";if(typeof h=="string")return h==="use-credentials"?h:""}return Bn.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=s,Bn.createPortal=function(m,h){var g=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!h||h.nodeType!==1&&h.nodeType!==9&&h.nodeType!==11)throw Error(e(299));return c(m,h,null,g)},Bn.flushSync=function(m){var h=d.T,g=s.p;try{if(d.T=null,s.p=2,m)return m()}finally{d.T=h,s.p=g,s.d.f()}},Bn.preconnect=function(m,h){typeof m=="string"&&(h?(h=h.crossOrigin,h=typeof h=="string"?h==="use-credentials"?h:"":void 0):h=null,s.d.C(m,h))},Bn.prefetchDNS=function(m){typeof m=="string"&&s.d.D(m)},Bn.preinit=function(m,h){if(typeof m=="string"&&h&&typeof h.as=="string"){var g=h.as,x=p(g,h.crossOrigin),_=typeof h.integrity=="string"?h.integrity:void 0,y=typeof h.fetchPriority=="string"?h.fetchPriority:void 0;g==="style"?s.d.S(m,typeof h.precedence=="string"?h.precedence:void 0,{crossOrigin:x,integrity:_,fetchPriority:y}):g==="script"&&s.d.X(m,{crossOrigin:x,integrity:_,fetchPriority:y,nonce:typeof h.nonce=="string"?h.nonce:void 0})}},Bn.preinitModule=function(m,h){if(typeof m=="string")if(typeof h=="object"&&h!==null){if(h.as==null||h.as==="script"){var g=p(h.as,h.crossOrigin);s.d.M(m,{crossOrigin:g,integrity:typeof h.integrity=="string"?h.integrity:void 0,nonce:typeof h.nonce=="string"?h.nonce:void 0})}}else h==null&&s.d.M(m)},Bn.preload=function(m,h){if(typeof m=="string"&&typeof h=="object"&&h!==null&&typeof h.as=="string"){var g=h.as,x=p(g,h.crossOrigin);s.d.L(m,g,{crossOrigin:x,integrity:typeof h.integrity=="string"?h.integrity:void 0,nonce:typeof h.nonce=="string"?h.nonce:void 0,type:typeof h.type=="string"?h.type:void 0,fetchPriority:typeof h.fetchPriority=="string"?h.fetchPriority:void 0,referrerPolicy:typeof h.referrerPolicy=="string"?h.referrerPolicy:void 0,imageSrcSet:typeof h.imageSrcSet=="string"?h.imageSrcSet:void 0,imageSizes:typeof h.imageSizes=="string"?h.imageSizes:void 0,media:typeof h.media=="string"?h.media:void 0})}},Bn.preloadModule=function(m,h){if(typeof m=="string")if(h){var g=p(h.as,h.crossOrigin);s.d.m(m,{as:typeof h.as=="string"&&h.as!=="script"?h.as:void 0,crossOrigin:g,integrity:typeof h.integrity=="string"?h.integrity:void 0})}else s.d.m(m)},Bn.requestFormReset=function(m){s.d.r(m)},Bn.unstable_batchedUpdates=function(m,h){return m(h)},Bn.useFormState=function(m,h,g){return d.H.useFormState(m,h,g)},Bn.useFormStatus=function(){return d.H.useHostTransitionStatus()},Bn.version="19.2.6",Bn}var h_;function wy(){if(h_)return wd.exports;h_=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(e){console.error(e)}}return r(),wd.exports=Cy(),wd.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var p_;function Dy(){if(p_)return Wo;p_=1;var r=Ry(),e=op(),i=wy();function s(t){var n="https://react.dev/errors/"+t;if(1<arguments.length){n+="?args[]="+encodeURIComponent(arguments[1]);for(var a=2;a<arguments.length;a++)n+="&args[]="+encodeURIComponent(arguments[a])}return"Minified React error #"+t+"; visit "+n+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function l(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function c(t){var n=t,a=t;if(t.alternate)for(;n.return;)n=n.return;else{t=n;do n=t,(n.flags&4098)!==0&&(a=n.return),t=n.return;while(t)}return n.tag===3?a:null}function d(t){if(t.tag===13){var n=t.memoizedState;if(n===null&&(t=t.alternate,t!==null&&(n=t.memoizedState)),n!==null)return n.dehydrated}return null}function p(t){if(t.tag===31){var n=t.memoizedState;if(n===null&&(t=t.alternate,t!==null&&(n=t.memoizedState)),n!==null)return n.dehydrated}return null}function m(t){if(c(t)!==t)throw Error(s(188))}function h(t){var n=t.alternate;if(!n){if(n=c(t),n===null)throw Error(s(188));return n!==t?null:t}for(var a=t,o=n;;){var u=a.return;if(u===null)break;var f=u.alternate;if(f===null){if(o=u.return,o!==null){a=o;continue}break}if(u.child===f.child){for(f=u.child;f;){if(f===a)return m(u),t;if(f===o)return m(u),n;f=f.sibling}throw Error(s(188))}if(a.return!==o.return)a=u,o=f;else{for(var v=!1,w=u.child;w;){if(w===a){v=!0,a=u,o=f;break}if(w===o){v=!0,o=u,a=f;break}w=w.sibling}if(!v){for(w=f.child;w;){if(w===a){v=!0,a=f,o=u;break}if(w===o){v=!0,o=f,a=u;break}w=w.sibling}if(!v)throw Error(s(189))}}if(a.alternate!==o)throw Error(s(190))}if(a.tag!==3)throw Error(s(188));return a.stateNode.current===a?t:n}function g(t){var n=t.tag;if(n===5||n===26||n===27||n===6)return t;for(t=t.child;t!==null;){if(n=g(t),n!==null)return n;t=t.sibling}return null}var x=Object.assign,_=Symbol.for("react.element"),y=Symbol.for("react.transitional.element"),M=Symbol.for("react.portal"),A=Symbol.for("react.fragment"),b=Symbol.for("react.strict_mode"),S=Symbol.for("react.profiler"),N=Symbol.for("react.consumer"),O=Symbol.for("react.context"),z=Symbol.for("react.forward_ref"),k=Symbol.for("react.suspense"),L=Symbol.for("react.suspense_list"),H=Symbol.for("react.memo"),T=Symbol.for("react.lazy"),I=Symbol.for("react.activity"),Z=Symbol.for("react.memo_cache_sentinel"),G=Symbol.iterator;function K(t){return t===null||typeof t!="object"?null:(t=G&&t[G]||t["@@iterator"],typeof t=="function"?t:null)}var ue=Symbol.for("react.client.reference");function pe(t){if(t==null)return null;if(typeof t=="function")return t.$$typeof===ue?null:t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case A:return"Fragment";case S:return"Profiler";case b:return"StrictMode";case k:return"Suspense";case L:return"SuspenseList";case I:return"Activity"}if(typeof t=="object")switch(t.$$typeof){case M:return"Portal";case O:return t.displayName||"Context";case N:return(t._context.displayName||"Context")+".Consumer";case z:var n=t.render;return t=t.displayName,t||(t=n.displayName||n.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case H:return n=t.displayName||null,n!==null?n:pe(t.type)||"Memo";case T:n=t._payload,t=t._init;try{return pe(t(n))}catch{}}return null}var F=Array.isArray,D=e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,P=i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,q={pending:!1,data:null,method:null,action:null},he=[],_e=-1;function B(t){return{current:t}}function Q(t){0>_e||(t.current=he[_e],he[_e]=null,_e--)}function ve(t,n){_e++,he[_e]=t.current,t.current=n}var Ae=B(null),Ce=B(null),ae=B(null),ye=B(null);function Me(t,n){switch(ve(ae,n),ve(Ce,t),ve(Ae,null),n.nodeType){case 9:case 11:t=(t=n.documentElement)&&(t=t.namespaceURI)?w0(t):0;break;default:if(t=n.tagName,n=n.namespaceURI)n=w0(n),t=D0(n,t);else switch(t){case"svg":t=1;break;case"math":t=2;break;default:t=0}}Q(Ae),ve(Ae,t)}function Ie(){Q(Ae),Q(Ce),Q(ae)}function Ze(t){t.memoizedState!==null&&ve(ye,t);var n=Ae.current,a=D0(n,t.type);n!==a&&(ve(Ce,t),ve(Ae,a))}function Ke(t){Ce.current===t&&(Q(Ae),Q(Ce)),ye.current===t&&(Q(ye),Go._currentValue=q)}var Lt,nt;function dt(t){if(Lt===void 0)try{throw Error()}catch(a){var n=a.stack.trim().match(/\n( *(at )?)/);Lt=n&&n[1]||"",nt=-1<a.stack.indexOf(`
    at`)?" (<anonymous>)":-1<a.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Lt+t+nt}var St=!1;function ct(t,n){if(!t||St)return"";St=!0;var a=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(n){var be=function(){throw Error()};if(Object.defineProperty(be.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(be,[])}catch(fe){var ce=fe}Reflect.construct(t,[],be)}else{try{be.call()}catch(fe){ce=fe}t.call(be.prototype)}}else{try{throw Error()}catch(fe){ce=fe}(be=t())&&typeof be.catch=="function"&&be.catch(function(){})}}catch(fe){if(fe&&ce&&typeof fe.stack=="string")return[fe.stack,ce.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var u=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");u&&u.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var f=o.DetermineComponentFrameRoot(),v=f[0],w=f[1];if(v&&w){var V=v.split(`
`),se=w.split(`
`);for(u=o=0;o<V.length&&!V[o].includes("DetermineComponentFrameRoot");)o++;for(;u<se.length&&!se[u].includes("DetermineComponentFrameRoot");)u++;if(o===V.length||u===se.length)for(o=V.length-1,u=se.length-1;1<=o&&0<=u&&V[o]!==se[u];)u--;for(;1<=o&&0<=u;o--,u--)if(V[o]!==se[u]){if(o!==1||u!==1)do if(o--,u--,0>u||V[o]!==se[u]){var ge=`
`+V[o].replace(" at new "," at ");return t.displayName&&ge.includes("<anonymous>")&&(ge=ge.replace("<anonymous>",t.displayName)),ge}while(1<=o&&0<=u);break}}}finally{St=!1,Error.prepareStackTrace=a}return(a=t?t.displayName||t.name:"")?dt(a):""}function $t(t,n){switch(t.tag){case 26:case 27:case 5:return dt(t.type);case 16:return dt("Lazy");case 13:return t.child!==n&&n!==null?dt("Suspense Fallback"):dt("Suspense");case 19:return dt("SuspenseList");case 0:case 15:return ct(t.type,!1);case 11:return ct(t.type.render,!1);case 1:return ct(t.type,!0);case 31:return dt("Activity");default:return""}}function te(t){try{var n="",a=null;do n+=$t(t,a),a=t,t=t.return;while(t);return n}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var Fe=Object.prototype.hasOwnProperty,j=r.unstable_scheduleCallback,yt=r.unstable_cancelCallback,lt=r.unstable_shouldYield,Nt=r.unstable_requestPaint,we=r.unstable_now,Xt=r.unstable_getCurrentPriorityLevel,U=r.unstable_ImmediatePriority,E=r.unstable_UserBlockingPriority,$=r.unstable_NormalPriority,xe=r.unstable_LowPriority,Te=r.unstable_IdlePriority,Ne=r.log,Pe=r.unstable_setDisableYieldValue,ne=null,de=null;function Oe(t){if(typeof Ne=="function"&&Pe(t),de&&typeof de.setStrictMode=="function")try{de.setStrictMode(ne,t)}catch{}}var ze=Math.clz32?Math.clz32:rt,Ue=Math.log,De=Math.LN2;function rt(t){return t>>>=0,t===0?32:31-(Ue(t)/De|0)|0}var ot=256,_t=262144,X=4194304;function Re(t){var n=t&42;if(n!==0)return n;switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return t&261888;case 262144:case 524288:case 1048576:case 2097152:return t&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return t&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return t}}function me(t,n,a){var o=t.pendingLanes;if(o===0)return 0;var u=0,f=t.suspendedLanes,v=t.pingedLanes;t=t.warmLanes;var w=o&134217727;return w!==0?(o=w&~f,o!==0?u=Re(o):(v&=w,v!==0?u=Re(v):a||(a=w&~t,a!==0&&(u=Re(a))))):(w=o&~f,w!==0?u=Re(w):v!==0?u=Re(v):a||(a=o&~t,a!==0&&(u=Re(a)))),u===0?0:n!==0&&n!==u&&(n&f)===0&&(f=u&-u,a=n&-n,f>=a||f===32&&(a&4194048)!==0)?n:u}function He(t,n){return(t.pendingLanes&~(t.suspendedLanes&~t.pingedLanes)&n)===0}function Le(t,n){switch(t){case 1:case 2:case 4:case 8:case 64:return n+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Ee(){var t=X;return X<<=1,(X&62914560)===0&&(X=4194304),t}function We(t){for(var n=[],a=0;31>a;a++)n.push(t);return n}function it(t,n){t.pendingLanes|=n,n!==268435456&&(t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0)}function Jt(t,n,a,o,u,f){var v=t.pendingLanes;t.pendingLanes=a,t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0,t.expiredLanes&=a,t.entangledLanes&=a,t.errorRecoveryDisabledLanes&=a,t.shellSuspendCounter=0;var w=t.entanglements,V=t.expirationTimes,se=t.hiddenUpdates;for(a=v&~a;0<a;){var ge=31-ze(a),be=1<<ge;w[ge]=0,V[ge]=-1;var ce=se[ge];if(ce!==null)for(se[ge]=null,ge=0;ge<ce.length;ge++){var fe=ce[ge];fe!==null&&(fe.lane&=-536870913)}a&=~be}o!==0&&Dt(t,o,0),f!==0&&u===0&&t.tag!==0&&(t.suspendedLanes|=f&~(v&~n))}function Dt(t,n,a){t.pendingLanes|=n,t.suspendedLanes&=~n;var o=31-ze(n);t.entangledLanes|=n,t.entanglements[o]=t.entanglements[o]|1073741824|a&261930}function Vn(t,n){var a=t.entangledLanes|=n;for(t=t.entanglements;a;){var o=31-ze(a),u=1<<o;u&n|t[o]&n&&(t[o]|=n),a&=~u}}function kn(t,n){var a=n&-n;return a=(a&42)!==0?1:ms(a),(a&(t.suspendedLanes|n))!==0?0:a}function ms(t){switch(t){case 2:t=1;break;case 8:t=4;break;case 32:t=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:t=128;break;case 268435456:t=134217728;break;default:t=0}return t}function Jr(t){return t&=-t,2<t?8<t?(t&134217727)!==0?32:268435456:8:2}function $r(){var t=P.p;return t!==0?t:(t=window.event,t===void 0?32:$0(t.type))}function eo(t,n){var a=P.p;try{return P.p=t,n()}finally{P.p=a}}var zn=Math.random().toString(36).slice(2),un="__reactFiber$"+zn,wn="__reactProps$"+zn,Ji="__reactContainer$"+zn,Ra="__reactEvents$"+zn,dl="__reactListeners$"+zn,qs="__reactHandles$"+zn,to="__reactResources$"+zn,Ca="__reactMarker$"+zn;function no(t){delete t[un],delete t[wn],delete t[Ra],delete t[dl],delete t[qs]}function wa(t){var n=t[un];if(n)return n;for(var a=t.parentNode;a;){if(n=a[Ji]||a[un]){if(a=n.alternate,n.child!==null||a!==null&&a.child!==null)for(t=F0(t);t!==null;){if(a=t[un])return a;t=F0(t)}return n}t=a,a=t.parentNode}return null}function Da(t){if(t=t[un]||t[Ji]){var n=t.tag;if(n===5||n===6||n===13||n===31||n===26||n===27||n===3)return t}return null}function gs(t){var n=t.tag;if(n===5||n===26||n===27||n===6)return t.stateNode;throw Error(s(33))}function Na(t){var n=t[to];return n||(n=t[to]={hoistableStyles:new Map,hoistableScripts:new Map}),n}function pn(t){t[Ca]=!0}var hl=new Set,C={};function Y(t,n){le(t,n),le(t+"Capture",n)}function le(t,n){for(C[t]=n,t=0;t<n.length;t++)hl.add(n[t])}var re=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),oe={},Ge={};function je(t){return Fe.call(Ge,t)?!0:Fe.call(oe,t)?!1:re.test(t)?Ge[t]=!0:(oe[t]=!0,!1)}function Be(t,n,a){if(je(n))if(a===null)t.removeAttribute(n);else{switch(typeof a){case"undefined":case"function":case"symbol":t.removeAttribute(n);return;case"boolean":var o=n.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){t.removeAttribute(n);return}}t.setAttribute(n,""+a)}}function qe(t,n,a){if(a===null)t.removeAttribute(n);else{switch(typeof a){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(n);return}t.setAttribute(n,""+a)}}function Xe(t,n,a,o){if(o===null)t.removeAttribute(a);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(a);return}t.setAttributeNS(n,a,""+o)}}function $e(t){switch(typeof t){case"bigint":case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function pt(t){var n=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(n==="checkbox"||n==="radio")}function Je(t,n,a){var o=Object.getOwnPropertyDescriptor(t.constructor.prototype,n);if(!t.hasOwnProperty(n)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var u=o.get,f=o.set;return Object.defineProperty(t,n,{configurable:!0,get:function(){return u.call(this)},set:function(v){a=""+v,f.call(this,v)}}),Object.defineProperty(t,n,{enumerable:o.enumerable}),{getValue:function(){return a},setValue:function(v){a=""+v},stopTracking:function(){t._valueTracker=null,delete t[n]}}}}function Ot(t){if(!t._valueTracker){var n=pt(t)?"checked":"value";t._valueTracker=Je(t,n,""+t[n])}}function nn(t){if(!t)return!1;var n=t._valueTracker;if(!n)return!0;var a=n.getValue(),o="";return t&&(o=pt(t)?t.checked?"true":"false":t.value),t=o,t!==a?(n.setValue(t),!0):!1}function Kt(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}var It=/[\n"\\]/g;function Ht(t){return t.replace(It,function(n){return"\\"+n.charCodeAt(0).toString(16)+" "})}function ke(t,n,a,o,u,f,v,w){t.name="",v!=null&&typeof v!="function"&&typeof v!="symbol"&&typeof v!="boolean"?t.type=v:t.removeAttribute("type"),n!=null?v==="number"?(n===0&&t.value===""||t.value!=n)&&(t.value=""+$e(n)):t.value!==""+$e(n)&&(t.value=""+$e(n)):v!=="submit"&&v!=="reset"||t.removeAttribute("value"),n!=null?bt(t,v,$e(n)):a!=null?bt(t,v,$e(a)):o!=null&&t.removeAttribute("value"),u==null&&f!=null&&(t.defaultChecked=!!f),u!=null&&(t.checked=u&&typeof u!="function"&&typeof u!="symbol"),w!=null&&typeof w!="function"&&typeof w!="symbol"&&typeof w!="boolean"?t.name=""+$e(w):t.removeAttribute("name")}function Fn(t,n,a,o,u,f,v,w){if(f!=null&&typeof f!="function"&&typeof f!="symbol"&&typeof f!="boolean"&&(t.type=f),n!=null||a!=null){if(!(f!=="submit"&&f!=="reset"||n!=null)){Ot(t);return}a=a!=null?""+$e(a):"",n=n!=null?""+$e(n):a,w||n===t.value||(t.value=n),t.defaultValue=n}o=o??u,o=typeof o!="function"&&typeof o!="symbol"&&!!o,t.checked=w?t.checked:!!o,t.defaultChecked=!!o,v!=null&&typeof v!="function"&&typeof v!="symbol"&&typeof v!="boolean"&&(t.name=v),Ot(t)}function bt(t,n,a){n==="number"&&Kt(t.ownerDocument)===t||t.defaultValue===""+a||(t.defaultValue=""+a)}function Sn(t,n,a,o){if(t=t.options,n){n={};for(var u=0;u<a.length;u++)n["$"+a[u]]=!0;for(a=0;a<t.length;a++)u=n.hasOwnProperty("$"+t[a].value),t[a].selected!==u&&(t[a].selected=u),u&&o&&(t[a].defaultSelected=!0)}else{for(a=""+$e(a),n=null,u=0;u<t.length;u++){if(t[u].value===a){t[u].selected=!0,o&&(t[u].defaultSelected=!0);return}n!==null||t[u].disabled||(n=t[u])}n!==null&&(n.selected=!0)}}function ii(t,n,a){if(n!=null&&(n=""+$e(n),n!==t.value&&(t.value=n),a==null)){t.defaultValue!==n&&(t.defaultValue=n);return}t.defaultValue=a!=null?""+$e(a):""}function Ri(t,n,a,o){if(n==null){if(o!=null){if(a!=null)throw Error(s(92));if(F(o)){if(1<o.length)throw Error(s(93));o=o[0]}a=o}a==null&&(a=""),n=a}a=$e(n),t.defaultValue=a,o=t.textContent,o===a&&o!==""&&o!==null&&(t.value=o),Ot(t)}function ai(t,n){if(n){var a=t.firstChild;if(a&&a===t.lastChild&&a.nodeType===3){a.nodeValue=n;return}}t.textContent=n}var Gt=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function an(t,n,a){var o=n.indexOf("--")===0;a==null||typeof a=="boolean"||a===""?o?t.setProperty(n,""):n==="float"?t.cssFloat="":t[n]="":o?t.setProperty(n,a):typeof a!="number"||a===0||Gt.has(n)?n==="float"?t.cssFloat=a:t[n]=(""+a).trim():t[n]=a+"px"}function Ci(t,n,a){if(n!=null&&typeof n!="object")throw Error(s(62));if(t=t.style,a!=null){for(var o in a)!a.hasOwnProperty(o)||n!=null&&n.hasOwnProperty(o)||(o.indexOf("--")===0?t.setProperty(o,""):o==="float"?t.cssFloat="":t[o]="");for(var u in n)o=n[u],n.hasOwnProperty(u)&&a[u]!==o&&an(t,u,o)}else for(var f in n)n.hasOwnProperty(f)&&an(t,f,n[f])}function Bt(t){if(t.indexOf("-")===-1)return!1;switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Fi=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Ua=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function _s(t){return Ua.test(""+t)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":t}function $i(){}var Su=null;function yu(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var Ys=null,Zs=null;function Cp(t){var n=Da(t);if(n&&(t=n.stateNode)){var a=t[wn]||null;e:switch(t=n.stateNode,n.type){case"input":if(ke(t,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name),n=a.name,a.type==="radio"&&n!=null){for(a=t;a.parentNode;)a=a.parentNode;for(a=a.querySelectorAll('input[name="'+Ht(""+n)+'"][type="radio"]'),n=0;n<a.length;n++){var o=a[n];if(o!==t&&o.form===t.form){var u=o[wn]||null;if(!u)throw Error(s(90));ke(o,u.value,u.defaultValue,u.defaultValue,u.checked,u.defaultChecked,u.type,u.name)}}for(n=0;n<a.length;n++)o=a[n],o.form===t.form&&nn(o)}break e;case"textarea":ii(t,a.value,a.defaultValue);break e;case"select":n=a.value,n!=null&&Sn(t,!!a.multiple,n,!1)}}}var bu=!1;function wp(t,n,a){if(bu)return t(n,a);bu=!0;try{var o=t(n);return o}finally{if(bu=!1,(Ys!==null||Zs!==null)&&(ec(),Ys&&(n=Ys,t=Zs,Zs=Ys=null,Cp(n),t)))for(n=0;n<t.length;n++)Cp(t[n])}}function io(t,n){var a=t.stateNode;if(a===null)return null;var o=a[wn]||null;if(o===null)return null;a=o[n];e:switch(n){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(t=t.type,o=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!o;break e;default:t=!1}if(t)return null;if(a&&typeof a!="function")throw Error(s(231,n,typeof a));return a}var ea=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Mu=!1;if(ea)try{var ao={};Object.defineProperty(ao,"passive",{get:function(){Mu=!0}}),window.addEventListener("test",ao,ao),window.removeEventListener("test",ao,ao)}catch{Mu=!1}var La=null,Eu=null,pl=null;function Dp(){if(pl)return pl;var t,n=Eu,a=n.length,o,u="value"in La?La.value:La.textContent,f=u.length;for(t=0;t<a&&n[t]===u[t];t++);var v=a-t;for(o=1;o<=v&&n[a-o]===u[f-o];o++);return pl=u.slice(t,1<o?1-o:void 0)}function ml(t){var n=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&n===13&&(t=13)):t=n,t===10&&(t=13),32<=t||t===13?t:0}function gl(){return!0}function Np(){return!1}function Yn(t){function n(a,o,u,f,v){this._reactName=a,this._targetInst=u,this.type=o,this.nativeEvent=f,this.target=v,this.currentTarget=null;for(var w in t)t.hasOwnProperty(w)&&(a=t[w],this[w]=a?a(f):f[w]);return this.isDefaultPrevented=(f.defaultPrevented!=null?f.defaultPrevented:f.returnValue===!1)?gl:Np,this.isPropagationStopped=Np,this}return x(n.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():typeof a.returnValue!="unknown"&&(a.returnValue=!1),this.isDefaultPrevented=gl)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():typeof a.cancelBubble!="unknown"&&(a.cancelBubble=!0),this.isPropagationStopped=gl)},persist:function(){},isPersistent:gl}),n}var xs={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},_l=Yn(xs),so=x({},xs,{view:0,detail:0}),yv=Yn(so),Tu,Au,ro,xl=x({},so,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Cu,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==ro&&(ro&&t.type==="mousemove"?(Tu=t.screenX-ro.screenX,Au=t.screenY-ro.screenY):Au=Tu=0,ro=t),Tu)},movementY:function(t){return"movementY"in t?t.movementY:Au}}),Up=Yn(xl),bv=x({},xl,{dataTransfer:0}),Mv=Yn(bv),Ev=x({},so,{relatedTarget:0}),Ru=Yn(Ev),Tv=x({},xs,{animationName:0,elapsedTime:0,pseudoElement:0}),Av=Yn(Tv),Rv=x({},xs,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),Cv=Yn(Rv),wv=x({},xs,{data:0}),Lp=Yn(wv),Dv={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Nv={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Uv={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Lv(t){var n=this.nativeEvent;return n.getModifierState?n.getModifierState(t):(t=Uv[t])?!!n[t]:!1}function Cu(){return Lv}var Ov=x({},so,{key:function(t){if(t.key){var n=Dv[t.key]||t.key;if(n!=="Unidentified")return n}return t.type==="keypress"?(t=ml(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?Nv[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Cu,charCode:function(t){return t.type==="keypress"?ml(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?ml(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),Pv=Yn(Ov),zv=x({},xl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Op=Yn(zv),Fv=x({},so,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Cu}),Bv=Yn(Fv),Iv=x({},xs,{propertyName:0,elapsedTime:0,pseudoElement:0}),Hv=Yn(Iv),Gv=x({},xl,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),Vv=Yn(Gv),kv=x({},xs,{newState:0,oldState:0}),jv=Yn(kv),Xv=[9,13,27,32],wu=ea&&"CompositionEvent"in window,oo=null;ea&&"documentMode"in document&&(oo=document.documentMode);var Wv=ea&&"TextEvent"in window&&!oo,Pp=ea&&(!wu||oo&&8<oo&&11>=oo),zp=" ",Fp=!1;function Bp(t,n){switch(t){case"keyup":return Xv.indexOf(n.keyCode)!==-1;case"keydown":return n.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Ip(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var Ks=!1;function qv(t,n){switch(t){case"compositionend":return Ip(n);case"keypress":return n.which!==32?null:(Fp=!0,zp);case"textInput":return t=n.data,t===zp&&Fp?null:t;default:return null}}function Yv(t,n){if(Ks)return t==="compositionend"||!wu&&Bp(t,n)?(t=Dp(),pl=Eu=La=null,Ks=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(n.ctrlKey||n.altKey||n.metaKey)||n.ctrlKey&&n.altKey){if(n.char&&1<n.char.length)return n.char;if(n.which)return String.fromCharCode(n.which)}return null;case"compositionend":return Pp&&n.locale!=="ko"?null:n.data;default:return null}}var Zv={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Hp(t){var n=t&&t.nodeName&&t.nodeName.toLowerCase();return n==="input"?!!Zv[t.type]:n==="textarea"}function Gp(t,n,a,o){Ys?Zs?Zs.push(o):Zs=[o]:Ys=o,n=oc(n,"onChange"),0<n.length&&(a=new _l("onChange","change",null,a,o),t.push({event:a,listeners:n}))}var lo=null,co=null;function Kv(t){M0(t,0)}function vl(t){var n=gs(t);if(nn(n))return t}function Vp(t,n){if(t==="change")return n}var kp=!1;if(ea){var Du;if(ea){var Nu="oninput"in document;if(!Nu){var jp=document.createElement("div");jp.setAttribute("oninput","return;"),Nu=typeof jp.oninput=="function"}Du=Nu}else Du=!1;kp=Du&&(!document.documentMode||9<document.documentMode)}function Xp(){lo&&(lo.detachEvent("onpropertychange",Wp),co=lo=null)}function Wp(t){if(t.propertyName==="value"&&vl(co)){var n=[];Gp(n,co,t,yu(t)),wp(Kv,n)}}function Qv(t,n,a){t==="focusin"?(Xp(),lo=n,co=a,lo.attachEvent("onpropertychange",Wp)):t==="focusout"&&Xp()}function Jv(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return vl(co)}function $v(t,n){if(t==="click")return vl(n)}function eS(t,n){if(t==="input"||t==="change")return vl(n)}function tS(t,n){return t===n&&(t!==0||1/t===1/n)||t!==t&&n!==n}var si=typeof Object.is=="function"?Object.is:tS;function uo(t,n){if(si(t,n))return!0;if(typeof t!="object"||t===null||typeof n!="object"||n===null)return!1;var a=Object.keys(t),o=Object.keys(n);if(a.length!==o.length)return!1;for(o=0;o<a.length;o++){var u=a[o];if(!Fe.call(n,u)||!si(t[u],n[u]))return!1}return!0}function qp(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function Yp(t,n){var a=qp(t);t=0;for(var o;a;){if(a.nodeType===3){if(o=t+a.textContent.length,t<=n&&o>=n)return{node:a,offset:n-t};t=o}e:{for(;a;){if(a.nextSibling){a=a.nextSibling;break e}a=a.parentNode}a=void 0}a=qp(a)}}function Zp(t,n){return t&&n?t===n?!0:t&&t.nodeType===3?!1:n&&n.nodeType===3?Zp(t,n.parentNode):"contains"in t?t.contains(n):t.compareDocumentPosition?!!(t.compareDocumentPosition(n)&16):!1:!1}function Kp(t){t=t!=null&&t.ownerDocument!=null&&t.ownerDocument.defaultView!=null?t.ownerDocument.defaultView:window;for(var n=Kt(t.document);n instanceof t.HTMLIFrameElement;){try{var a=typeof n.contentWindow.location.href=="string"}catch{a=!1}if(a)t=n.contentWindow;else break;n=Kt(t.document)}return n}function Uu(t){var n=t&&t.nodeName&&t.nodeName.toLowerCase();return n&&(n==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||n==="textarea"||t.contentEditable==="true")}var nS=ea&&"documentMode"in document&&11>=document.documentMode,Qs=null,Lu=null,fo=null,Ou=!1;function Qp(t,n,a){var o=a.window===a?a.document:a.nodeType===9?a:a.ownerDocument;Ou||Qs==null||Qs!==Kt(o)||(o=Qs,"selectionStart"in o&&Uu(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),fo&&uo(fo,o)||(fo=o,o=oc(Lu,"onSelect"),0<o.length&&(n=new _l("onSelect","select",null,n,a),t.push({event:n,listeners:o}),n.target=Qs)))}function vs(t,n){var a={};return a[t.toLowerCase()]=n.toLowerCase(),a["Webkit"+t]="webkit"+n,a["Moz"+t]="moz"+n,a}var Js={animationend:vs("Animation","AnimationEnd"),animationiteration:vs("Animation","AnimationIteration"),animationstart:vs("Animation","AnimationStart"),transitionrun:vs("Transition","TransitionRun"),transitionstart:vs("Transition","TransitionStart"),transitioncancel:vs("Transition","TransitionCancel"),transitionend:vs("Transition","TransitionEnd")},Pu={},Jp={};ea&&(Jp=document.createElement("div").style,"AnimationEvent"in window||(delete Js.animationend.animation,delete Js.animationiteration.animation,delete Js.animationstart.animation),"TransitionEvent"in window||delete Js.transitionend.transition);function Ss(t){if(Pu[t])return Pu[t];if(!Js[t])return t;var n=Js[t],a;for(a in n)if(n.hasOwnProperty(a)&&a in Jp)return Pu[t]=n[a];return t}var $p=Ss("animationend"),em=Ss("animationiteration"),tm=Ss("animationstart"),iS=Ss("transitionrun"),aS=Ss("transitionstart"),sS=Ss("transitioncancel"),nm=Ss("transitionend"),im=new Map,zu="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");zu.push("scrollEnd");function wi(t,n){im.set(t,n),Y(n,[t])}var Sl=typeof reportError=="function"?reportError:function(t){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var n=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof t=="object"&&t!==null&&typeof t.message=="string"?String(t.message):String(t),error:t});if(!window.dispatchEvent(n))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",t);return}console.error(t)},_i=[],$s=0,Fu=0;function yl(){for(var t=$s,n=Fu=$s=0;n<t;){var a=_i[n];_i[n++]=null;var o=_i[n];_i[n++]=null;var u=_i[n];_i[n++]=null;var f=_i[n];if(_i[n++]=null,o!==null&&u!==null){var v=o.pending;v===null?u.next=u:(u.next=v.next,v.next=u),o.pending=u}f!==0&&am(a,u,f)}}function bl(t,n,a,o){_i[$s++]=t,_i[$s++]=n,_i[$s++]=a,_i[$s++]=o,Fu|=o,t.lanes|=o,t=t.alternate,t!==null&&(t.lanes|=o)}function Bu(t,n,a,o){return bl(t,n,a,o),Ml(t)}function ys(t,n){return bl(t,null,null,n),Ml(t)}function am(t,n,a){t.lanes|=a;var o=t.alternate;o!==null&&(o.lanes|=a);for(var u=!1,f=t.return;f!==null;)f.childLanes|=a,o=f.alternate,o!==null&&(o.childLanes|=a),f.tag===22&&(t=f.stateNode,t===null||t._visibility&1||(u=!0)),t=f,f=f.return;return t.tag===3?(f=t.stateNode,u&&n!==null&&(u=31-ze(a),t=f.hiddenUpdates,o=t[u],o===null?t[u]=[n]:o.push(n),n.lane=a|536870912),f):null}function Ml(t){if(50<Oo)throw Oo=0,Yf=null,Error(s(185));for(var n=t.return;n!==null;)t=n,n=t.return;return t.tag===3?t.stateNode:null}var er={};function rS(t,n,a,o){this.tag=t,this.key=a,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=n,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function ri(t,n,a,o){return new rS(t,n,a,o)}function Iu(t){return t=t.prototype,!(!t||!t.isReactComponent)}function ta(t,n){var a=t.alternate;return a===null?(a=ri(t.tag,n,t.key,t.mode),a.elementType=t.elementType,a.type=t.type,a.stateNode=t.stateNode,a.alternate=t,t.alternate=a):(a.pendingProps=n,a.type=t.type,a.flags=0,a.subtreeFlags=0,a.deletions=null),a.flags=t.flags&65011712,a.childLanes=t.childLanes,a.lanes=t.lanes,a.child=t.child,a.memoizedProps=t.memoizedProps,a.memoizedState=t.memoizedState,a.updateQueue=t.updateQueue,n=t.dependencies,a.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext},a.sibling=t.sibling,a.index=t.index,a.ref=t.ref,a.refCleanup=t.refCleanup,a}function sm(t,n){t.flags&=65011714;var a=t.alternate;return a===null?(t.childLanes=0,t.lanes=n,t.child=null,t.subtreeFlags=0,t.memoizedProps=null,t.memoizedState=null,t.updateQueue=null,t.dependencies=null,t.stateNode=null):(t.childLanes=a.childLanes,t.lanes=a.lanes,t.child=a.child,t.subtreeFlags=0,t.deletions=null,t.memoizedProps=a.memoizedProps,t.memoizedState=a.memoizedState,t.updateQueue=a.updateQueue,t.type=a.type,n=a.dependencies,t.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),t}function El(t,n,a,o,u,f){var v=0;if(o=t,typeof t=="function")Iu(t)&&(v=1);else if(typeof t=="string")v=fy(t,a,Ae.current)?26:t==="html"||t==="head"||t==="body"?27:5;else e:switch(t){case I:return t=ri(31,a,n,u),t.elementType=I,t.lanes=f,t;case A:return bs(a.children,u,f,n);case b:v=8,u|=24;break;case S:return t=ri(12,a,n,u|2),t.elementType=S,t.lanes=f,t;case k:return t=ri(13,a,n,u),t.elementType=k,t.lanes=f,t;case L:return t=ri(19,a,n,u),t.elementType=L,t.lanes=f,t;default:if(typeof t=="object"&&t!==null)switch(t.$$typeof){case O:v=10;break e;case N:v=9;break e;case z:v=11;break e;case H:v=14;break e;case T:v=16,o=null;break e}v=29,a=Error(s(130,t===null?"null":typeof t,"")),o=null}return n=ri(v,a,n,u),n.elementType=t,n.type=o,n.lanes=f,n}function bs(t,n,a,o){return t=ri(7,t,o,n),t.lanes=a,t}function Hu(t,n,a){return t=ri(6,t,null,n),t.lanes=a,t}function rm(t){var n=ri(18,null,null,0);return n.stateNode=t,n}function Gu(t,n,a){return n=ri(4,t.children!==null?t.children:[],t.key,n),n.lanes=a,n.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},n}var om=new WeakMap;function xi(t,n){if(typeof t=="object"&&t!==null){var a=om.get(t);return a!==void 0?a:(n={value:t,source:n,stack:te(n)},om.set(t,n),n)}return{value:t,source:n,stack:te(n)}}var tr=[],nr=0,Tl=null,ho=0,vi=[],Si=0,Oa=null,Bi=1,Ii="";function na(t,n){tr[nr++]=ho,tr[nr++]=Tl,Tl=t,ho=n}function lm(t,n,a){vi[Si++]=Bi,vi[Si++]=Ii,vi[Si++]=Oa,Oa=t;var o=Bi;t=Ii;var u=32-ze(o)-1;o&=~(1<<u),a+=1;var f=32-ze(n)+u;if(30<f){var v=u-u%5;f=(o&(1<<v)-1).toString(32),o>>=v,u-=v,Bi=1<<32-ze(n)+u|a<<u|o,Ii=f+t}else Bi=1<<f|a<<u|o,Ii=t}function Vu(t){t.return!==null&&(na(t,1),lm(t,1,0))}function ku(t){for(;t===Tl;)Tl=tr[--nr],tr[nr]=null,ho=tr[--nr],tr[nr]=null;for(;t===Oa;)Oa=vi[--Si],vi[Si]=null,Ii=vi[--Si],vi[Si]=null,Bi=vi[--Si],vi[Si]=null}function cm(t,n){vi[Si++]=Bi,vi[Si++]=Ii,vi[Si++]=Oa,Bi=n.id,Ii=n.overflow,Oa=t}var Dn=null,en=null,Ct=!1,Pa=null,yi=!1,ju=Error(s(519));function za(t){var n=Error(s(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw po(xi(n,t)),ju}function um(t){var n=t.stateNode,a=t.type,o=t.memoizedProps;switch(n[un]=t,n[wn]=o,a){case"dialog":Et("cancel",n),Et("close",n);break;case"iframe":case"object":case"embed":Et("load",n);break;case"video":case"audio":for(a=0;a<zo.length;a++)Et(zo[a],n);break;case"source":Et("error",n);break;case"img":case"image":case"link":Et("error",n),Et("load",n);break;case"details":Et("toggle",n);break;case"input":Et("invalid",n),Fn(n,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":Et("invalid",n);break;case"textarea":Et("invalid",n),Ri(n,o.value,o.defaultValue,o.children)}a=o.children,typeof a!="string"&&typeof a!="number"&&typeof a!="bigint"||n.textContent===""+a||o.suppressHydrationWarning===!0||R0(n.textContent,a)?(o.popover!=null&&(Et("beforetoggle",n),Et("toggle",n)),o.onScroll!=null&&Et("scroll",n),o.onScrollEnd!=null&&Et("scrollend",n),o.onClick!=null&&(n.onclick=$i),n=!0):n=!1,n||za(t,!0)}function fm(t){for(Dn=t.return;Dn;)switch(Dn.tag){case 5:case 31:case 13:yi=!1;return;case 27:case 3:yi=!0;return;default:Dn=Dn.return}}function ir(t){if(t!==Dn)return!1;if(!Ct)return fm(t),Ct=!0,!1;var n=t.tag,a;if((a=n!==3&&n!==27)&&((a=n===5)&&(a=t.type,a=!(a!=="form"&&a!=="button")||cd(t.type,t.memoizedProps)),a=!a),a&&en&&za(t),fm(t),n===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(s(317));en=z0(t)}else if(n===31){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(s(317));en=z0(t)}else n===27?(n=en,Ka(t.type)?(t=pd,pd=null,en=t):en=n):en=Dn?Mi(t.stateNode.nextSibling):null;return!0}function Ms(){en=Dn=null,Ct=!1}function Xu(){var t=Pa;return t!==null&&(Jn===null?Jn=t:Jn.push.apply(Jn,t),Pa=null),t}function po(t){Pa===null?Pa=[t]:Pa.push(t)}var Wu=B(null),Es=null,ia=null;function Fa(t,n,a){ve(Wu,n._currentValue),n._currentValue=a}function aa(t){t._currentValue=Wu.current,Q(Wu)}function qu(t,n,a){for(;t!==null;){var o=t.alternate;if((t.childLanes&n)!==n?(t.childLanes|=n,o!==null&&(o.childLanes|=n)):o!==null&&(o.childLanes&n)!==n&&(o.childLanes|=n),t===a)break;t=t.return}}function Yu(t,n,a,o){var u=t.child;for(u!==null&&(u.return=t);u!==null;){var f=u.dependencies;if(f!==null){var v=u.child;f=f.firstContext;e:for(;f!==null;){var w=f;f=u;for(var V=0;V<n.length;V++)if(w.context===n[V]){f.lanes|=a,w=f.alternate,w!==null&&(w.lanes|=a),qu(f.return,a,t),o||(v=null);break e}f=w.next}}else if(u.tag===18){if(v=u.return,v===null)throw Error(s(341));v.lanes|=a,f=v.alternate,f!==null&&(f.lanes|=a),qu(v,a,t),v=null}else v=u.child;if(v!==null)v.return=u;else for(v=u;v!==null;){if(v===t){v=null;break}if(u=v.sibling,u!==null){u.return=v.return,v=u;break}v=v.return}u=v}}function ar(t,n,a,o){t=null;for(var u=n,f=!1;u!==null;){if(!f){if((u.flags&524288)!==0)f=!0;else if((u.flags&262144)!==0)break}if(u.tag===10){var v=u.alternate;if(v===null)throw Error(s(387));if(v=v.memoizedProps,v!==null){var w=u.type;si(u.pendingProps.value,v.value)||(t!==null?t.push(w):t=[w])}}else if(u===ye.current){if(v=u.alternate,v===null)throw Error(s(387));v.memoizedState.memoizedState!==u.memoizedState.memoizedState&&(t!==null?t.push(Go):t=[Go])}u=u.return}t!==null&&Yu(n,t,a,o),n.flags|=262144}function Al(t){for(t=t.firstContext;t!==null;){if(!si(t.context._currentValue,t.memoizedValue))return!0;t=t.next}return!1}function Ts(t){Es=t,ia=null,t=t.dependencies,t!==null&&(t.firstContext=null)}function Nn(t){return dm(Es,t)}function Rl(t,n){return Es===null&&Ts(t),dm(t,n)}function dm(t,n){var a=n._currentValue;if(n={context:n,memoizedValue:a,next:null},ia===null){if(t===null)throw Error(s(308));ia=n,t.dependencies={lanes:0,firstContext:n},t.flags|=524288}else ia=ia.next=n;return a}var oS=typeof AbortController<"u"?AbortController:function(){var t=[],n=this.signal={aborted:!1,addEventListener:function(a,o){t.push(o)}};this.abort=function(){n.aborted=!0,t.forEach(function(a){return a()})}},lS=r.unstable_scheduleCallback,cS=r.unstable_NormalPriority,mn={$$typeof:O,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Zu(){return{controller:new oS,data:new Map,refCount:0}}function mo(t){t.refCount--,t.refCount===0&&lS(cS,function(){t.controller.abort()})}var go=null,Ku=0,sr=0,rr=null;function uS(t,n){if(go===null){var a=go=[];Ku=0,sr=ed(),rr={status:"pending",value:void 0,then:function(o){a.push(o)}}}return Ku++,n.then(hm,hm),n}function hm(){if(--Ku===0&&go!==null){rr!==null&&(rr.status="fulfilled");var t=go;go=null,sr=0,rr=null;for(var n=0;n<t.length;n++)(0,t[n])()}}function fS(t,n){var a=[],o={status:"pending",value:null,reason:null,then:function(u){a.push(u)}};return t.then(function(){o.status="fulfilled",o.value=n;for(var u=0;u<a.length;u++)(0,a[u])(n)},function(u){for(o.status="rejected",o.reason=u,u=0;u<a.length;u++)(0,a[u])(void 0)}),o}var pm=D.S;D.S=function(t,n){Qg=we(),typeof n=="object"&&n!==null&&typeof n.then=="function"&&uS(t,n),pm!==null&&pm(t,n)};var As=B(null);function Qu(){var t=As.current;return t!==null?t:Qt.pooledCache}function Cl(t,n){n===null?ve(As,As.current):ve(As,n.pool)}function mm(){var t=Qu();return t===null?null:{parent:mn._currentValue,pool:t}}var or=Error(s(460)),Ju=Error(s(474)),wl=Error(s(542)),Dl={then:function(){}};function gm(t){return t=t.status,t==="fulfilled"||t==="rejected"}function _m(t,n,a){switch(a=t[a],a===void 0?t.push(n):a!==n&&(n.then($i,$i),n=a),n.status){case"fulfilled":return n.value;case"rejected":throw t=n.reason,vm(t),t;default:if(typeof n.status=="string")n.then($i,$i);else{if(t=Qt,t!==null&&100<t.shellSuspendCounter)throw Error(s(482));t=n,t.status="pending",t.then(function(o){if(n.status==="pending"){var u=n;u.status="fulfilled",u.value=o}},function(o){if(n.status==="pending"){var u=n;u.status="rejected",u.reason=o}})}switch(n.status){case"fulfilled":return n.value;case"rejected":throw t=n.reason,vm(t),t}throw Cs=n,or}}function Rs(t){try{var n=t._init;return n(t._payload)}catch(a){throw a!==null&&typeof a=="object"&&typeof a.then=="function"?(Cs=a,or):a}}var Cs=null;function xm(){if(Cs===null)throw Error(s(459));var t=Cs;return Cs=null,t}function vm(t){if(t===or||t===wl)throw Error(s(483))}var lr=null,_o=0;function Nl(t){var n=_o;return _o+=1,lr===null&&(lr=[]),_m(lr,t,n)}function xo(t,n){n=n.props.ref,t.ref=n!==void 0?n:null}function Ul(t,n){throw n.$$typeof===_?Error(s(525)):(t=Object.prototype.toString.call(n),Error(s(31,t==="[object Object]"?"object with keys {"+Object.keys(n).join(", ")+"}":t)))}function Sm(t){function n(J,W){if(t){var ie=J.deletions;ie===null?(J.deletions=[W],J.flags|=16):ie.push(W)}}function a(J,W){if(!t)return null;for(;W!==null;)n(J,W),W=W.sibling;return null}function o(J){for(var W=new Map;J!==null;)J.key!==null?W.set(J.key,J):W.set(J.index,J),J=J.sibling;return W}function u(J,W){return J=ta(J,W),J.index=0,J.sibling=null,J}function f(J,W,ie){return J.index=ie,t?(ie=J.alternate,ie!==null?(ie=ie.index,ie<W?(J.flags|=67108866,W):ie):(J.flags|=67108866,W)):(J.flags|=1048576,W)}function v(J){return t&&J.alternate===null&&(J.flags|=67108866),J}function w(J,W,ie,Se){return W===null||W.tag!==6?(W=Hu(ie,J.mode,Se),W.return=J,W):(W=u(W,ie),W.return=J,W)}function V(J,W,ie,Se){var et=ie.type;return et===A?ge(J,W,ie.props.children,Se,ie.key):W!==null&&(W.elementType===et||typeof et=="object"&&et!==null&&et.$$typeof===T&&Rs(et)===W.type)?(W=u(W,ie.props),xo(W,ie),W.return=J,W):(W=El(ie.type,ie.key,ie.props,null,J.mode,Se),xo(W,ie),W.return=J,W)}function se(J,W,ie,Se){return W===null||W.tag!==4||W.stateNode.containerInfo!==ie.containerInfo||W.stateNode.implementation!==ie.implementation?(W=Gu(ie,J.mode,Se),W.return=J,W):(W=u(W,ie.children||[]),W.return=J,W)}function ge(J,W,ie,Se,et){return W===null||W.tag!==7?(W=bs(ie,J.mode,Se,et),W.return=J,W):(W=u(W,ie),W.return=J,W)}function be(J,W,ie){if(typeof W=="string"&&W!==""||typeof W=="number"||typeof W=="bigint")return W=Hu(""+W,J.mode,ie),W.return=J,W;if(typeof W=="object"&&W!==null){switch(W.$$typeof){case y:return ie=El(W.type,W.key,W.props,null,J.mode,ie),xo(ie,W),ie.return=J,ie;case M:return W=Gu(W,J.mode,ie),W.return=J,W;case T:return W=Rs(W),be(J,W,ie)}if(F(W)||K(W))return W=bs(W,J.mode,ie,null),W.return=J,W;if(typeof W.then=="function")return be(J,Nl(W),ie);if(W.$$typeof===O)return be(J,Rl(J,W),ie);Ul(J,W)}return null}function ce(J,W,ie,Se){var et=W!==null?W.key:null;if(typeof ie=="string"&&ie!==""||typeof ie=="number"||typeof ie=="bigint")return et!==null?null:w(J,W,""+ie,Se);if(typeof ie=="object"&&ie!==null){switch(ie.$$typeof){case y:return ie.key===et?V(J,W,ie,Se):null;case M:return ie.key===et?se(J,W,ie,Se):null;case T:return ie=Rs(ie),ce(J,W,ie,Se)}if(F(ie)||K(ie))return et!==null?null:ge(J,W,ie,Se,null);if(typeof ie.then=="function")return ce(J,W,Nl(ie),Se);if(ie.$$typeof===O)return ce(J,W,Rl(J,ie),Se);Ul(J,ie)}return null}function fe(J,W,ie,Se,et){if(typeof Se=="string"&&Se!==""||typeof Se=="number"||typeof Se=="bigint")return J=J.get(ie)||null,w(W,J,""+Se,et);if(typeof Se=="object"&&Se!==null){switch(Se.$$typeof){case y:return J=J.get(Se.key===null?ie:Se.key)||null,V(W,J,Se,et);case M:return J=J.get(Se.key===null?ie:Se.key)||null,se(W,J,Se,et);case T:return Se=Rs(Se),fe(J,W,ie,Se,et)}if(F(Se)||K(Se))return J=J.get(ie)||null,ge(W,J,Se,et,null);if(typeof Se.then=="function")return fe(J,W,ie,Nl(Se),et);if(Se.$$typeof===O)return fe(J,W,ie,Rl(W,Se),et);Ul(W,Se)}return null}function Ye(J,W,ie,Se){for(var et=null,Pt=null,Qe=W,xt=W=0,Rt=null;Qe!==null&&xt<ie.length;xt++){Qe.index>xt?(Rt=Qe,Qe=null):Rt=Qe.sibling;var zt=ce(J,Qe,ie[xt],Se);if(zt===null){Qe===null&&(Qe=Rt);break}t&&Qe&&zt.alternate===null&&n(J,Qe),W=f(zt,W,xt),Pt===null?et=zt:Pt.sibling=zt,Pt=zt,Qe=Rt}if(xt===ie.length)return a(J,Qe),Ct&&na(J,xt),et;if(Qe===null){for(;xt<ie.length;xt++)Qe=be(J,ie[xt],Se),Qe!==null&&(W=f(Qe,W,xt),Pt===null?et=Qe:Pt.sibling=Qe,Pt=Qe);return Ct&&na(J,xt),et}for(Qe=o(Qe);xt<ie.length;xt++)Rt=fe(Qe,J,xt,ie[xt],Se),Rt!==null&&(t&&Rt.alternate!==null&&Qe.delete(Rt.key===null?xt:Rt.key),W=f(Rt,W,xt),Pt===null?et=Rt:Pt.sibling=Rt,Pt=Rt);return t&&Qe.forEach(function(ts){return n(J,ts)}),Ct&&na(J,xt),et}function at(J,W,ie,Se){if(ie==null)throw Error(s(151));for(var et=null,Pt=null,Qe=W,xt=W=0,Rt=null,zt=ie.next();Qe!==null&&!zt.done;xt++,zt=ie.next()){Qe.index>xt?(Rt=Qe,Qe=null):Rt=Qe.sibling;var ts=ce(J,Qe,zt.value,Se);if(ts===null){Qe===null&&(Qe=Rt);break}t&&Qe&&ts.alternate===null&&n(J,Qe),W=f(ts,W,xt),Pt===null?et=ts:Pt.sibling=ts,Pt=ts,Qe=Rt}if(zt.done)return a(J,Qe),Ct&&na(J,xt),et;if(Qe===null){for(;!zt.done;xt++,zt=ie.next())zt=be(J,zt.value,Se),zt!==null&&(W=f(zt,W,xt),Pt===null?et=zt:Pt.sibling=zt,Pt=zt);return Ct&&na(J,xt),et}for(Qe=o(Qe);!zt.done;xt++,zt=ie.next())zt=fe(Qe,J,xt,zt.value,Se),zt!==null&&(t&&zt.alternate!==null&&Qe.delete(zt.key===null?xt:zt.key),W=f(zt,W,xt),Pt===null?et=zt:Pt.sibling=zt,Pt=zt);return t&&Qe.forEach(function(by){return n(J,by)}),Ct&&na(J,xt),et}function Yt(J,W,ie,Se){if(typeof ie=="object"&&ie!==null&&ie.type===A&&ie.key===null&&(ie=ie.props.children),typeof ie=="object"&&ie!==null){switch(ie.$$typeof){case y:e:{for(var et=ie.key;W!==null;){if(W.key===et){if(et=ie.type,et===A){if(W.tag===7){a(J,W.sibling),Se=u(W,ie.props.children),Se.return=J,J=Se;break e}}else if(W.elementType===et||typeof et=="object"&&et!==null&&et.$$typeof===T&&Rs(et)===W.type){a(J,W.sibling),Se=u(W,ie.props),xo(Se,ie),Se.return=J,J=Se;break e}a(J,W);break}else n(J,W);W=W.sibling}ie.type===A?(Se=bs(ie.props.children,J.mode,Se,ie.key),Se.return=J,J=Se):(Se=El(ie.type,ie.key,ie.props,null,J.mode,Se),xo(Se,ie),Se.return=J,J=Se)}return v(J);case M:e:{for(et=ie.key;W!==null;){if(W.key===et)if(W.tag===4&&W.stateNode.containerInfo===ie.containerInfo&&W.stateNode.implementation===ie.implementation){a(J,W.sibling),Se=u(W,ie.children||[]),Se.return=J,J=Se;break e}else{a(J,W);break}else n(J,W);W=W.sibling}Se=Gu(ie,J.mode,Se),Se.return=J,J=Se}return v(J);case T:return ie=Rs(ie),Yt(J,W,ie,Se)}if(F(ie))return Ye(J,W,ie,Se);if(K(ie)){if(et=K(ie),typeof et!="function")throw Error(s(150));return ie=et.call(ie),at(J,W,ie,Se)}if(typeof ie.then=="function")return Yt(J,W,Nl(ie),Se);if(ie.$$typeof===O)return Yt(J,W,Rl(J,ie),Se);Ul(J,ie)}return typeof ie=="string"&&ie!==""||typeof ie=="number"||typeof ie=="bigint"?(ie=""+ie,W!==null&&W.tag===6?(a(J,W.sibling),Se=u(W,ie),Se.return=J,J=Se):(a(J,W),Se=Hu(ie,J.mode,Se),Se.return=J,J=Se),v(J)):a(J,W)}return function(J,W,ie,Se){try{_o=0;var et=Yt(J,W,ie,Se);return lr=null,et}catch(Qe){if(Qe===or||Qe===wl)throw Qe;var Pt=ri(29,Qe,null,J.mode);return Pt.lanes=Se,Pt.return=J,Pt}finally{}}}var ws=Sm(!0),ym=Sm(!1),Ba=!1;function $u(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function ef(t,n){t=t.updateQueue,n.updateQueue===t&&(n.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,callbacks:null})}function Ia(t){return{lane:t,tag:0,payload:null,callback:null,next:null}}function Ha(t,n,a){var o=t.updateQueue;if(o===null)return null;if(o=o.shared,(Ft&2)!==0){var u=o.pending;return u===null?n.next=n:(n.next=u.next,u.next=n),o.pending=n,n=Ml(t),am(t,null,a),n}return bl(t,o,n,a),Ml(t)}function vo(t,n,a){if(n=n.updateQueue,n!==null&&(n=n.shared,(a&4194048)!==0)){var o=n.lanes;o&=t.pendingLanes,a|=o,n.lanes=a,Vn(t,a)}}function tf(t,n){var a=t.updateQueue,o=t.alternate;if(o!==null&&(o=o.updateQueue,a===o)){var u=null,f=null;if(a=a.firstBaseUpdate,a!==null){do{var v={lane:a.lane,tag:a.tag,payload:a.payload,callback:null,next:null};f===null?u=f=v:f=f.next=v,a=a.next}while(a!==null);f===null?u=f=n:f=f.next=n}else u=f=n;a={baseState:o.baseState,firstBaseUpdate:u,lastBaseUpdate:f,shared:o.shared,callbacks:o.callbacks},t.updateQueue=a;return}t=a.lastBaseUpdate,t===null?a.firstBaseUpdate=n:t.next=n,a.lastBaseUpdate=n}var nf=!1;function So(){if(nf){var t=rr;if(t!==null)throw t}}function yo(t,n,a,o){nf=!1;var u=t.updateQueue;Ba=!1;var f=u.firstBaseUpdate,v=u.lastBaseUpdate,w=u.shared.pending;if(w!==null){u.shared.pending=null;var V=w,se=V.next;V.next=null,v===null?f=se:v.next=se,v=V;var ge=t.alternate;ge!==null&&(ge=ge.updateQueue,w=ge.lastBaseUpdate,w!==v&&(w===null?ge.firstBaseUpdate=se:w.next=se,ge.lastBaseUpdate=V))}if(f!==null){var be=u.baseState;v=0,ge=se=V=null,w=f;do{var ce=w.lane&-536870913,fe=ce!==w.lane;if(fe?(At&ce)===ce:(o&ce)===ce){ce!==0&&ce===sr&&(nf=!0),ge!==null&&(ge=ge.next={lane:0,tag:w.tag,payload:w.payload,callback:null,next:null});e:{var Ye=t,at=w;ce=n;var Yt=a;switch(at.tag){case 1:if(Ye=at.payload,typeof Ye=="function"){be=Ye.call(Yt,be,ce);break e}be=Ye;break e;case 3:Ye.flags=Ye.flags&-65537|128;case 0:if(Ye=at.payload,ce=typeof Ye=="function"?Ye.call(Yt,be,ce):Ye,ce==null)break e;be=x({},be,ce);break e;case 2:Ba=!0}}ce=w.callback,ce!==null&&(t.flags|=64,fe&&(t.flags|=8192),fe=u.callbacks,fe===null?u.callbacks=[ce]:fe.push(ce))}else fe={lane:ce,tag:w.tag,payload:w.payload,callback:w.callback,next:null},ge===null?(se=ge=fe,V=be):ge=ge.next=fe,v|=ce;if(w=w.next,w===null){if(w=u.shared.pending,w===null)break;fe=w,w=fe.next,fe.next=null,u.lastBaseUpdate=fe,u.shared.pending=null}}while(!0);ge===null&&(V=be),u.baseState=V,u.firstBaseUpdate=se,u.lastBaseUpdate=ge,f===null&&(u.shared.lanes=0),Xa|=v,t.lanes=v,t.memoizedState=be}}function bm(t,n){if(typeof t!="function")throw Error(s(191,t));t.call(n)}function Mm(t,n){var a=t.callbacks;if(a!==null)for(t.callbacks=null,t=0;t<a.length;t++)bm(a[t],n)}var cr=B(null),Ll=B(0);function Em(t,n){t=ha,ve(Ll,t),ve(cr,n),ha=t|n.baseLanes}function af(){ve(Ll,ha),ve(cr,cr.current)}function sf(){ha=Ll.current,Q(cr),Q(Ll)}var oi=B(null),bi=null;function Ga(t){var n=t.alternate;ve(fn,fn.current&1),ve(oi,t),bi===null&&(n===null||cr.current!==null||n.memoizedState!==null)&&(bi=t)}function rf(t){ve(fn,fn.current),ve(oi,t),bi===null&&(bi=t)}function Tm(t){t.tag===22?(ve(fn,fn.current),ve(oi,t),bi===null&&(bi=t)):Va()}function Va(){ve(fn,fn.current),ve(oi,oi.current)}function li(t){Q(oi),bi===t&&(bi=null),Q(fn)}var fn=B(0);function Ol(t){for(var n=t;n!==null;){if(n.tag===13){var a=n.memoizedState;if(a!==null&&(a=a.dehydrated,a===null||dd(a)||hd(a)))return n}else if(n.tag===19&&(n.memoizedProps.revealOrder==="forwards"||n.memoizedProps.revealOrder==="backwards"||n.memoizedProps.revealOrder==="unstable_legacy-backwards"||n.memoizedProps.revealOrder==="together")){if((n.flags&128)!==0)return n}else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return null;n=n.return}n.sibling.return=n.return,n=n.sibling}return null}var sa=0,mt=null,Wt=null,gn=null,Pl=!1,ur=!1,Ds=!1,zl=0,bo=0,fr=null,dS=0;function on(){throw Error(s(321))}function of(t,n){if(n===null)return!1;for(var a=0;a<n.length&&a<t.length;a++)if(!si(t[a],n[a]))return!1;return!0}function lf(t,n,a,o,u,f){return sa=f,mt=n,n.memoizedState=null,n.updateQueue=null,n.lanes=0,D.H=t===null||t.memoizedState===null?lg:Mf,Ds=!1,f=a(o,u),Ds=!1,ur&&(f=Rm(n,a,o,u)),Am(t),f}function Am(t){D.H=To;var n=Wt!==null&&Wt.next!==null;if(sa=0,gn=Wt=mt=null,Pl=!1,bo=0,fr=null,n)throw Error(s(300));t===null||_n||(t=t.dependencies,t!==null&&Al(t)&&(_n=!0))}function Rm(t,n,a,o){mt=t;var u=0;do{if(ur&&(fr=null),bo=0,ur=!1,25<=u)throw Error(s(301));if(u+=1,gn=Wt=null,t.updateQueue!=null){var f=t.updateQueue;f.lastEffect=null,f.events=null,f.stores=null,f.memoCache!=null&&(f.memoCache.index=0)}D.H=cg,f=n(a,o)}while(ur);return f}function hS(){var t=D.H,n=t.useState()[0];return n=typeof n.then=="function"?Mo(n):n,t=t.useState()[0],(Wt!==null?Wt.memoizedState:null)!==t&&(mt.flags|=1024),n}function cf(){var t=zl!==0;return zl=0,t}function uf(t,n,a){n.updateQueue=t.updateQueue,n.flags&=-2053,t.lanes&=~a}function ff(t){if(Pl){for(t=t.memoizedState;t!==null;){var n=t.queue;n!==null&&(n.pending=null),t=t.next}Pl=!1}sa=0,gn=Wt=mt=null,ur=!1,bo=zl=0,fr=null}function jn(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return gn===null?mt.memoizedState=gn=t:gn=gn.next=t,gn}function dn(){if(Wt===null){var t=mt.alternate;t=t!==null?t.memoizedState:null}else t=Wt.next;var n=gn===null?mt.memoizedState:gn.next;if(n!==null)gn=n,Wt=t;else{if(t===null)throw mt.alternate===null?Error(s(467)):Error(s(310));Wt=t,t={memoizedState:Wt.memoizedState,baseState:Wt.baseState,baseQueue:Wt.baseQueue,queue:Wt.queue,next:null},gn===null?mt.memoizedState=gn=t:gn=gn.next=t}return gn}function Fl(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Mo(t){var n=bo;return bo+=1,fr===null&&(fr=[]),t=_m(fr,t,n),n=mt,(gn===null?n.memoizedState:gn.next)===null&&(n=n.alternate,D.H=n===null||n.memoizedState===null?lg:Mf),t}function Bl(t){if(t!==null&&typeof t=="object"){if(typeof t.then=="function")return Mo(t);if(t.$$typeof===O)return Nn(t)}throw Error(s(438,String(t)))}function df(t){var n=null,a=mt.updateQueue;if(a!==null&&(n=a.memoCache),n==null){var o=mt.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(n={data:o.data.map(function(u){return u.slice()}),index:0})))}if(n==null&&(n={data:[],index:0}),a===null&&(a=Fl(),mt.updateQueue=a),a.memoCache=n,a=n.data[n.index],a===void 0)for(a=n.data[n.index]=Array(t),o=0;o<t;o++)a[o]=Z;return n.index++,a}function ra(t,n){return typeof n=="function"?n(t):n}function Il(t){var n=dn();return hf(n,Wt,t)}function hf(t,n,a){var o=t.queue;if(o===null)throw Error(s(311));o.lastRenderedReducer=a;var u=t.baseQueue,f=o.pending;if(f!==null){if(u!==null){var v=u.next;u.next=f.next,f.next=v}n.baseQueue=u=f,o.pending=null}if(f=t.baseState,u===null)t.memoizedState=f;else{n=u.next;var w=v=null,V=null,se=n,ge=!1;do{var be=se.lane&-536870913;if(be!==se.lane?(At&be)===be:(sa&be)===be){var ce=se.revertLane;if(ce===0)V!==null&&(V=V.next={lane:0,revertLane:0,gesture:null,action:se.action,hasEagerState:se.hasEagerState,eagerState:se.eagerState,next:null}),be===sr&&(ge=!0);else if((sa&ce)===ce){se=se.next,ce===sr&&(ge=!0);continue}else be={lane:0,revertLane:se.revertLane,gesture:null,action:se.action,hasEagerState:se.hasEagerState,eagerState:se.eagerState,next:null},V===null?(w=V=be,v=f):V=V.next=be,mt.lanes|=ce,Xa|=ce;be=se.action,Ds&&a(f,be),f=se.hasEagerState?se.eagerState:a(f,be)}else ce={lane:be,revertLane:se.revertLane,gesture:se.gesture,action:se.action,hasEagerState:se.hasEagerState,eagerState:se.eagerState,next:null},V===null?(w=V=ce,v=f):V=V.next=ce,mt.lanes|=be,Xa|=be;se=se.next}while(se!==null&&se!==n);if(V===null?v=f:V.next=w,!si(f,t.memoizedState)&&(_n=!0,ge&&(a=rr,a!==null)))throw a;t.memoizedState=f,t.baseState=v,t.baseQueue=V,o.lastRenderedState=f}return u===null&&(o.lanes=0),[t.memoizedState,o.dispatch]}function pf(t){var n=dn(),a=n.queue;if(a===null)throw Error(s(311));a.lastRenderedReducer=t;var o=a.dispatch,u=a.pending,f=n.memoizedState;if(u!==null){a.pending=null;var v=u=u.next;do f=t(f,v.action),v=v.next;while(v!==u);si(f,n.memoizedState)||(_n=!0),n.memoizedState=f,n.baseQueue===null&&(n.baseState=f),a.lastRenderedState=f}return[f,o]}function Cm(t,n,a){var o=mt,u=dn(),f=Ct;if(f){if(a===void 0)throw Error(s(407));a=a()}else a=n();var v=!si((Wt||u).memoizedState,a);if(v&&(u.memoizedState=a,_n=!0),u=u.queue,_f(Nm.bind(null,o,u,t),[t]),u.getSnapshot!==n||v||gn!==null&&gn.memoizedState.tag&1){if(o.flags|=2048,dr(9,{destroy:void 0},Dm.bind(null,o,u,a,n),null),Qt===null)throw Error(s(349));f||(sa&127)!==0||wm(o,n,a)}return a}function wm(t,n,a){t.flags|=16384,t={getSnapshot:n,value:a},n=mt.updateQueue,n===null?(n=Fl(),mt.updateQueue=n,n.stores=[t]):(a=n.stores,a===null?n.stores=[t]:a.push(t))}function Dm(t,n,a,o){n.value=a,n.getSnapshot=o,Um(n)&&Lm(t)}function Nm(t,n,a){return a(function(){Um(n)&&Lm(t)})}function Um(t){var n=t.getSnapshot;t=t.value;try{var a=n();return!si(t,a)}catch{return!0}}function Lm(t){var n=ys(t,2);n!==null&&$n(n,t,2)}function mf(t){var n=jn();if(typeof t=="function"){var a=t;if(t=a(),Ds){Oe(!0);try{a()}finally{Oe(!1)}}}return n.memoizedState=n.baseState=t,n.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:ra,lastRenderedState:t},n}function Om(t,n,a,o){return t.baseState=a,hf(t,Wt,typeof o=="function"?o:ra)}function pS(t,n,a,o,u){if(Vl(t))throw Error(s(485));if(t=n.action,t!==null){var f={payload:u,action:t,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(v){f.listeners.push(v)}};D.T!==null?a(!0):f.isTransition=!1,o(f),a=n.pending,a===null?(f.next=n.pending=f,Pm(n,f)):(f.next=a.next,n.pending=a.next=f)}}function Pm(t,n){var a=n.action,o=n.payload,u=t.state;if(n.isTransition){var f=D.T,v={};D.T=v;try{var w=a(u,o),V=D.S;V!==null&&V(v,w),zm(t,n,w)}catch(se){gf(t,n,se)}finally{f!==null&&v.types!==null&&(f.types=v.types),D.T=f}}else try{f=a(u,o),zm(t,n,f)}catch(se){gf(t,n,se)}}function zm(t,n,a){a!==null&&typeof a=="object"&&typeof a.then=="function"?a.then(function(o){Fm(t,n,o)},function(o){return gf(t,n,o)}):Fm(t,n,a)}function Fm(t,n,a){n.status="fulfilled",n.value=a,Bm(n),t.state=a,n=t.pending,n!==null&&(a=n.next,a===n?t.pending=null:(a=a.next,n.next=a,Pm(t,a)))}function gf(t,n,a){var o=t.pending;if(t.pending=null,o!==null){o=o.next;do n.status="rejected",n.reason=a,Bm(n),n=n.next;while(n!==o)}t.action=null}function Bm(t){t=t.listeners;for(var n=0;n<t.length;n++)(0,t[n])()}function Im(t,n){return n}function Hm(t,n){if(Ct){var a=Qt.formState;if(a!==null){e:{var o=mt;if(Ct){if(en){t:{for(var u=en,f=yi;u.nodeType!==8;){if(!f){u=null;break t}if(u=Mi(u.nextSibling),u===null){u=null;break t}}f=u.data,u=f==="F!"||f==="F"?u:null}if(u){en=Mi(u.nextSibling),o=u.data==="F!";break e}}za(o)}o=!1}o&&(n=a[0])}}return a=jn(),a.memoizedState=a.baseState=n,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Im,lastRenderedState:n},a.queue=o,a=sg.bind(null,mt,o),o.dispatch=a,o=mf(!1),f=bf.bind(null,mt,!1,o.queue),o=jn(),u={state:n,dispatch:null,action:t,pending:null},o.queue=u,a=pS.bind(null,mt,u,f,a),u.dispatch=a,o.memoizedState=t,[n,a,!1]}function Gm(t){var n=dn();return Vm(n,Wt,t)}function Vm(t,n,a){if(n=hf(t,n,Im)[0],t=Il(ra)[0],typeof n=="object"&&n!==null&&typeof n.then=="function")try{var o=Mo(n)}catch(v){throw v===or?wl:v}else o=n;n=dn();var u=n.queue,f=u.dispatch;return a!==n.memoizedState&&(mt.flags|=2048,dr(9,{destroy:void 0},mS.bind(null,u,a),null)),[o,f,t]}function mS(t,n){t.action=n}function km(t){var n=dn(),a=Wt;if(a!==null)return Vm(n,a,t);dn(),n=n.memoizedState,a=dn();var o=a.queue.dispatch;return a.memoizedState=t,[n,o,!1]}function dr(t,n,a,o){return t={tag:t,create:a,deps:o,inst:n,next:null},n=mt.updateQueue,n===null&&(n=Fl(),mt.updateQueue=n),a=n.lastEffect,a===null?n.lastEffect=t.next=t:(o=a.next,a.next=t,t.next=o,n.lastEffect=t),t}function jm(){return dn().memoizedState}function Hl(t,n,a,o){var u=jn();mt.flags|=t,u.memoizedState=dr(1|n,{destroy:void 0},a,o===void 0?null:o)}function Gl(t,n,a,o){var u=dn();o=o===void 0?null:o;var f=u.memoizedState.inst;Wt!==null&&o!==null&&of(o,Wt.memoizedState.deps)?u.memoizedState=dr(n,f,a,o):(mt.flags|=t,u.memoizedState=dr(1|n,f,a,o))}function Xm(t,n){Hl(8390656,8,t,n)}function _f(t,n){Gl(2048,8,t,n)}function gS(t){mt.flags|=4;var n=mt.updateQueue;if(n===null)n=Fl(),mt.updateQueue=n,n.events=[t];else{var a=n.events;a===null?n.events=[t]:a.push(t)}}function Wm(t){var n=dn().memoizedState;return gS({ref:n,nextImpl:t}),function(){if((Ft&2)!==0)throw Error(s(440));return n.impl.apply(void 0,arguments)}}function qm(t,n){return Gl(4,2,t,n)}function Ym(t,n){return Gl(4,4,t,n)}function Zm(t,n){if(typeof n=="function"){t=t();var a=n(t);return function(){typeof a=="function"?a():n(null)}}if(n!=null)return t=t(),n.current=t,function(){n.current=null}}function Km(t,n,a){a=a!=null?a.concat([t]):null,Gl(4,4,Zm.bind(null,n,t),a)}function xf(){}function Qm(t,n){var a=dn();n=n===void 0?null:n;var o=a.memoizedState;return n!==null&&of(n,o[1])?o[0]:(a.memoizedState=[t,n],t)}function Jm(t,n){var a=dn();n=n===void 0?null:n;var o=a.memoizedState;if(n!==null&&of(n,o[1]))return o[0];if(o=t(),Ds){Oe(!0);try{t()}finally{Oe(!1)}}return a.memoizedState=[o,n],o}function vf(t,n,a){return a===void 0||(sa&1073741824)!==0&&(At&261930)===0?t.memoizedState=n:(t.memoizedState=a,t=$g(),mt.lanes|=t,Xa|=t,a)}function $m(t,n,a,o){return si(a,n)?a:cr.current!==null?(t=vf(t,a,o),si(t,n)||(_n=!0),t):(sa&42)===0||(sa&1073741824)!==0&&(At&261930)===0?(_n=!0,t.memoizedState=a):(t=$g(),mt.lanes|=t,Xa|=t,n)}function eg(t,n,a,o,u){var f=P.p;P.p=f!==0&&8>f?f:8;var v=D.T,w={};D.T=w,bf(t,!1,n,a);try{var V=u(),se=D.S;if(se!==null&&se(w,V),V!==null&&typeof V=="object"&&typeof V.then=="function"){var ge=fS(V,o);Eo(t,n,ge,fi(t))}else Eo(t,n,o,fi(t))}catch(be){Eo(t,n,{then:function(){},status:"rejected",reason:be},fi())}finally{P.p=f,v!==null&&w.types!==null&&(v.types=w.types),D.T=v}}function _S(){}function Sf(t,n,a,o){if(t.tag!==5)throw Error(s(476));var u=tg(t).queue;eg(t,u,n,q,a===null?_S:function(){return ng(t),a(o)})}function tg(t){var n=t.memoizedState;if(n!==null)return n;n={memoizedState:q,baseState:q,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ra,lastRenderedState:q},next:null};var a={};return n.next={memoizedState:a,baseState:a,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ra,lastRenderedState:a},next:null},t.memoizedState=n,t=t.alternate,t!==null&&(t.memoizedState=n),n}function ng(t){var n=tg(t);n.next===null&&(n=t.alternate.memoizedState),Eo(t,n.next.queue,{},fi())}function yf(){return Nn(Go)}function ig(){return dn().memoizedState}function ag(){return dn().memoizedState}function xS(t){for(var n=t.return;n!==null;){switch(n.tag){case 24:case 3:var a=fi();t=Ia(a);var o=Ha(n,t,a);o!==null&&($n(o,n,a),vo(o,n,a)),n={cache:Zu()},t.payload=n;return}n=n.return}}function vS(t,n,a){var o=fi();a={lane:o,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null},Vl(t)?rg(n,a):(a=Bu(t,n,a,o),a!==null&&($n(a,t,o),og(a,n,o)))}function sg(t,n,a){var o=fi();Eo(t,n,a,o)}function Eo(t,n,a,o){var u={lane:o,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null};if(Vl(t))rg(n,u);else{var f=t.alternate;if(t.lanes===0&&(f===null||f.lanes===0)&&(f=n.lastRenderedReducer,f!==null))try{var v=n.lastRenderedState,w=f(v,a);if(u.hasEagerState=!0,u.eagerState=w,si(w,v))return bl(t,n,u,0),Qt===null&&yl(),!1}catch{}finally{}if(a=Bu(t,n,u,o),a!==null)return $n(a,t,o),og(a,n,o),!0}return!1}function bf(t,n,a,o){if(o={lane:2,revertLane:ed(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},Vl(t)){if(n)throw Error(s(479))}else n=Bu(t,a,o,2),n!==null&&$n(n,t,2)}function Vl(t){var n=t.alternate;return t===mt||n!==null&&n===mt}function rg(t,n){ur=Pl=!0;var a=t.pending;a===null?n.next=n:(n.next=a.next,a.next=n),t.pending=n}function og(t,n,a){if((a&4194048)!==0){var o=n.lanes;o&=t.pendingLanes,a|=o,n.lanes=a,Vn(t,a)}}var To={readContext:Nn,use:Bl,useCallback:on,useContext:on,useEffect:on,useImperativeHandle:on,useLayoutEffect:on,useInsertionEffect:on,useMemo:on,useReducer:on,useRef:on,useState:on,useDebugValue:on,useDeferredValue:on,useTransition:on,useSyncExternalStore:on,useId:on,useHostTransitionStatus:on,useFormState:on,useActionState:on,useOptimistic:on,useMemoCache:on,useCacheRefresh:on};To.useEffectEvent=on;var lg={readContext:Nn,use:Bl,useCallback:function(t,n){return jn().memoizedState=[t,n===void 0?null:n],t},useContext:Nn,useEffect:Xm,useImperativeHandle:function(t,n,a){a=a!=null?a.concat([t]):null,Hl(4194308,4,Zm.bind(null,n,t),a)},useLayoutEffect:function(t,n){return Hl(4194308,4,t,n)},useInsertionEffect:function(t,n){Hl(4,2,t,n)},useMemo:function(t,n){var a=jn();n=n===void 0?null:n;var o=t();if(Ds){Oe(!0);try{t()}finally{Oe(!1)}}return a.memoizedState=[o,n],o},useReducer:function(t,n,a){var o=jn();if(a!==void 0){var u=a(n);if(Ds){Oe(!0);try{a(n)}finally{Oe(!1)}}}else u=n;return o.memoizedState=o.baseState=u,t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:u},o.queue=t,t=t.dispatch=vS.bind(null,mt,t),[o.memoizedState,t]},useRef:function(t){var n=jn();return t={current:t},n.memoizedState=t},useState:function(t){t=mf(t);var n=t.queue,a=sg.bind(null,mt,n);return n.dispatch=a,[t.memoizedState,a]},useDebugValue:xf,useDeferredValue:function(t,n){var a=jn();return vf(a,t,n)},useTransition:function(){var t=mf(!1);return t=eg.bind(null,mt,t.queue,!0,!1),jn().memoizedState=t,[!1,t]},useSyncExternalStore:function(t,n,a){var o=mt,u=jn();if(Ct){if(a===void 0)throw Error(s(407));a=a()}else{if(a=n(),Qt===null)throw Error(s(349));(At&127)!==0||wm(o,n,a)}u.memoizedState=a;var f={value:a,getSnapshot:n};return u.queue=f,Xm(Nm.bind(null,o,f,t),[t]),o.flags|=2048,dr(9,{destroy:void 0},Dm.bind(null,o,f,a,n),null),a},useId:function(){var t=jn(),n=Qt.identifierPrefix;if(Ct){var a=Ii,o=Bi;a=(o&~(1<<32-ze(o)-1)).toString(32)+a,n="_"+n+"R_"+a,a=zl++,0<a&&(n+="H"+a.toString(32)),n+="_"}else a=dS++,n="_"+n+"r_"+a.toString(32)+"_";return t.memoizedState=n},useHostTransitionStatus:yf,useFormState:Hm,useActionState:Hm,useOptimistic:function(t){var n=jn();n.memoizedState=n.baseState=t;var a={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return n.queue=a,n=bf.bind(null,mt,!0,a),a.dispatch=n,[t,n]},useMemoCache:df,useCacheRefresh:function(){return jn().memoizedState=xS.bind(null,mt)},useEffectEvent:function(t){var n=jn(),a={impl:t};return n.memoizedState=a,function(){if((Ft&2)!==0)throw Error(s(440));return a.impl.apply(void 0,arguments)}}},Mf={readContext:Nn,use:Bl,useCallback:Qm,useContext:Nn,useEffect:_f,useImperativeHandle:Km,useInsertionEffect:qm,useLayoutEffect:Ym,useMemo:Jm,useReducer:Il,useRef:jm,useState:function(){return Il(ra)},useDebugValue:xf,useDeferredValue:function(t,n){var a=dn();return $m(a,Wt.memoizedState,t,n)},useTransition:function(){var t=Il(ra)[0],n=dn().memoizedState;return[typeof t=="boolean"?t:Mo(t),n]},useSyncExternalStore:Cm,useId:ig,useHostTransitionStatus:yf,useFormState:Gm,useActionState:Gm,useOptimistic:function(t,n){var a=dn();return Om(a,Wt,t,n)},useMemoCache:df,useCacheRefresh:ag};Mf.useEffectEvent=Wm;var cg={readContext:Nn,use:Bl,useCallback:Qm,useContext:Nn,useEffect:_f,useImperativeHandle:Km,useInsertionEffect:qm,useLayoutEffect:Ym,useMemo:Jm,useReducer:pf,useRef:jm,useState:function(){return pf(ra)},useDebugValue:xf,useDeferredValue:function(t,n){var a=dn();return Wt===null?vf(a,t,n):$m(a,Wt.memoizedState,t,n)},useTransition:function(){var t=pf(ra)[0],n=dn().memoizedState;return[typeof t=="boolean"?t:Mo(t),n]},useSyncExternalStore:Cm,useId:ig,useHostTransitionStatus:yf,useFormState:km,useActionState:km,useOptimistic:function(t,n){var a=dn();return Wt!==null?Om(a,Wt,t,n):(a.baseState=t,[t,a.queue.dispatch])},useMemoCache:df,useCacheRefresh:ag};cg.useEffectEvent=Wm;function Ef(t,n,a,o){n=t.memoizedState,a=a(o,n),a=a==null?n:x({},n,a),t.memoizedState=a,t.lanes===0&&(t.updateQueue.baseState=a)}var Tf={enqueueSetState:function(t,n,a){t=t._reactInternals;var o=fi(),u=Ia(o);u.payload=n,a!=null&&(u.callback=a),n=Ha(t,u,o),n!==null&&($n(n,t,o),vo(n,t,o))},enqueueReplaceState:function(t,n,a){t=t._reactInternals;var o=fi(),u=Ia(o);u.tag=1,u.payload=n,a!=null&&(u.callback=a),n=Ha(t,u,o),n!==null&&($n(n,t,o),vo(n,t,o))},enqueueForceUpdate:function(t,n){t=t._reactInternals;var a=fi(),o=Ia(a);o.tag=2,n!=null&&(o.callback=n),n=Ha(t,o,a),n!==null&&($n(n,t,a),vo(n,t,a))}};function ug(t,n,a,o,u,f,v){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(o,f,v):n.prototype&&n.prototype.isPureReactComponent?!uo(a,o)||!uo(u,f):!0}function fg(t,n,a,o){t=n.state,typeof n.componentWillReceiveProps=="function"&&n.componentWillReceiveProps(a,o),typeof n.UNSAFE_componentWillReceiveProps=="function"&&n.UNSAFE_componentWillReceiveProps(a,o),n.state!==t&&Tf.enqueueReplaceState(n,n.state,null)}function Ns(t,n){var a=n;if("ref"in n){a={};for(var o in n)o!=="ref"&&(a[o]=n[o])}if(t=t.defaultProps){a===n&&(a=x({},a));for(var u in t)a[u]===void 0&&(a[u]=t[u])}return a}function dg(t){Sl(t)}function hg(t){console.error(t)}function pg(t){Sl(t)}function kl(t,n){try{var a=t.onUncaughtError;a(n.value,{componentStack:n.stack})}catch(o){setTimeout(function(){throw o})}}function mg(t,n,a){try{var o=t.onCaughtError;o(a.value,{componentStack:a.stack,errorBoundary:n.tag===1?n.stateNode:null})}catch(u){setTimeout(function(){throw u})}}function Af(t,n,a){return a=Ia(a),a.tag=3,a.payload={element:null},a.callback=function(){kl(t,n)},a}function gg(t){return t=Ia(t),t.tag=3,t}function _g(t,n,a,o){var u=a.type.getDerivedStateFromError;if(typeof u=="function"){var f=o.value;t.payload=function(){return u(f)},t.callback=function(){mg(n,a,o)}}var v=a.stateNode;v!==null&&typeof v.componentDidCatch=="function"&&(t.callback=function(){mg(n,a,o),typeof u!="function"&&(Wa===null?Wa=new Set([this]):Wa.add(this));var w=o.stack;this.componentDidCatch(o.value,{componentStack:w!==null?w:""})})}function SS(t,n,a,o,u){if(a.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(n=a.alternate,n!==null&&ar(n,a,u,!0),a=oi.current,a!==null){switch(a.tag){case 31:case 13:return bi===null?tc():a.alternate===null&&ln===0&&(ln=3),a.flags&=-257,a.flags|=65536,a.lanes=u,o===Dl?a.flags|=16384:(n=a.updateQueue,n===null?a.updateQueue=new Set([o]):n.add(o),Qf(t,o,u)),!1;case 22:return a.flags|=65536,o===Dl?a.flags|=16384:(n=a.updateQueue,n===null?(n={transitions:null,markerInstances:null,retryQueue:new Set([o])},a.updateQueue=n):(a=n.retryQueue,a===null?n.retryQueue=new Set([o]):a.add(o)),Qf(t,o,u)),!1}throw Error(s(435,a.tag))}return Qf(t,o,u),tc(),!1}if(Ct)return n=oi.current,n!==null?((n.flags&65536)===0&&(n.flags|=256),n.flags|=65536,n.lanes=u,o!==ju&&(t=Error(s(422),{cause:o}),po(xi(t,a)))):(o!==ju&&(n=Error(s(423),{cause:o}),po(xi(n,a))),t=t.current.alternate,t.flags|=65536,u&=-u,t.lanes|=u,o=xi(o,a),u=Af(t.stateNode,o,u),tf(t,u),ln!==4&&(ln=2)),!1;var f=Error(s(520),{cause:o});if(f=xi(f,a),Lo===null?Lo=[f]:Lo.push(f),ln!==4&&(ln=2),n===null)return!0;o=xi(o,a),a=n;do{switch(a.tag){case 3:return a.flags|=65536,t=u&-u,a.lanes|=t,t=Af(a.stateNode,o,t),tf(a,t),!1;case 1:if(n=a.type,f=a.stateNode,(a.flags&128)===0&&(typeof n.getDerivedStateFromError=="function"||f!==null&&typeof f.componentDidCatch=="function"&&(Wa===null||!Wa.has(f))))return a.flags|=65536,u&=-u,a.lanes|=u,u=gg(u),_g(u,t,a,o),tf(a,u),!1}a=a.return}while(a!==null);return!1}var Rf=Error(s(461)),_n=!1;function Un(t,n,a,o){n.child=t===null?ym(n,null,a,o):ws(n,t.child,a,o)}function xg(t,n,a,o,u){a=a.render;var f=n.ref;if("ref"in o){var v={};for(var w in o)w!=="ref"&&(v[w]=o[w])}else v=o;return Ts(n),o=lf(t,n,a,v,f,u),w=cf(),t!==null&&!_n?(uf(t,n,u),oa(t,n,u)):(Ct&&w&&Vu(n),n.flags|=1,Un(t,n,o,u),n.child)}function vg(t,n,a,o,u){if(t===null){var f=a.type;return typeof f=="function"&&!Iu(f)&&f.defaultProps===void 0&&a.compare===null?(n.tag=15,n.type=f,Sg(t,n,f,o,u)):(t=El(a.type,null,o,n,n.mode,u),t.ref=n.ref,t.return=n,n.child=t)}if(f=t.child,!Pf(t,u)){var v=f.memoizedProps;if(a=a.compare,a=a!==null?a:uo,a(v,o)&&t.ref===n.ref)return oa(t,n,u)}return n.flags|=1,t=ta(f,o),t.ref=n.ref,t.return=n,n.child=t}function Sg(t,n,a,o,u){if(t!==null){var f=t.memoizedProps;if(uo(f,o)&&t.ref===n.ref)if(_n=!1,n.pendingProps=o=f,Pf(t,u))(t.flags&131072)!==0&&(_n=!0);else return n.lanes=t.lanes,oa(t,n,u)}return Cf(t,n,a,o,u)}function yg(t,n,a,o){var u=o.children,f=t!==null?t.memoizedState:null;if(t===null&&n.stateNode===null&&(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((n.flags&128)!==0){if(f=f!==null?f.baseLanes|a:a,t!==null){for(o=n.child=t.child,u=0;o!==null;)u=u|o.lanes|o.childLanes,o=o.sibling;o=u&~f}else o=0,n.child=null;return bg(t,n,f,a,o)}if((a&536870912)!==0)n.memoizedState={baseLanes:0,cachePool:null},t!==null&&Cl(n,f!==null?f.cachePool:null),f!==null?Em(n,f):af(),Tm(n);else return o=n.lanes=536870912,bg(t,n,f!==null?f.baseLanes|a:a,a,o)}else f!==null?(Cl(n,f.cachePool),Em(n,f),Va(),n.memoizedState=null):(t!==null&&Cl(n,null),af(),Va());return Un(t,n,u,a),n.child}function Ao(t,n){return t!==null&&t.tag===22||n.stateNode!==null||(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),n.sibling}function bg(t,n,a,o,u){var f=Qu();return f=f===null?null:{parent:mn._currentValue,pool:f},n.memoizedState={baseLanes:a,cachePool:f},t!==null&&Cl(n,null),af(),Tm(n),t!==null&&ar(t,n,o,!0),n.childLanes=u,null}function jl(t,n){return n=Wl({mode:n.mode,children:n.children},t.mode),n.ref=t.ref,t.child=n,n.return=t,n}function Mg(t,n,a){return ws(n,t.child,null,a),t=jl(n,n.pendingProps),t.flags|=2,li(n),n.memoizedState=null,t}function yS(t,n,a){var o=n.pendingProps,u=(n.flags&128)!==0;if(n.flags&=-129,t===null){if(Ct){if(o.mode==="hidden")return t=jl(n,o),n.lanes=536870912,Ao(null,t);if(rf(n),(t=en)?(t=P0(t,yi),t=t!==null&&t.data==="&"?t:null,t!==null&&(n.memoizedState={dehydrated:t,treeContext:Oa!==null?{id:Bi,overflow:Ii}:null,retryLane:536870912,hydrationErrors:null},a=rm(t),a.return=n,n.child=a,Dn=n,en=null)):t=null,t===null)throw za(n);return n.lanes=536870912,null}return jl(n,o)}var f=t.memoizedState;if(f!==null){var v=f.dehydrated;if(rf(n),u)if(n.flags&256)n.flags&=-257,n=Mg(t,n,a);else if(n.memoizedState!==null)n.child=t.child,n.flags|=128,n=null;else throw Error(s(558));else if(_n||ar(t,n,a,!1),u=(a&t.childLanes)!==0,_n||u){if(o=Qt,o!==null&&(v=kn(o,a),v!==0&&v!==f.retryLane))throw f.retryLane=v,ys(t,v),$n(o,t,v),Rf;tc(),n=Mg(t,n,a)}else t=f.treeContext,en=Mi(v.nextSibling),Dn=n,Ct=!0,Pa=null,yi=!1,t!==null&&cm(n,t),n=jl(n,o),n.flags|=4096;return n}return t=ta(t.child,{mode:o.mode,children:o.children}),t.ref=n.ref,n.child=t,t.return=n,t}function Xl(t,n){var a=n.ref;if(a===null)t!==null&&t.ref!==null&&(n.flags|=4194816);else{if(typeof a!="function"&&typeof a!="object")throw Error(s(284));(t===null||t.ref!==a)&&(n.flags|=4194816)}}function Cf(t,n,a,o,u){return Ts(n),a=lf(t,n,a,o,void 0,u),o=cf(),t!==null&&!_n?(uf(t,n,u),oa(t,n,u)):(Ct&&o&&Vu(n),n.flags|=1,Un(t,n,a,u),n.child)}function Eg(t,n,a,o,u,f){return Ts(n),n.updateQueue=null,a=Rm(n,o,a,u),Am(t),o=cf(),t!==null&&!_n?(uf(t,n,f),oa(t,n,f)):(Ct&&o&&Vu(n),n.flags|=1,Un(t,n,a,f),n.child)}function Tg(t,n,a,o,u){if(Ts(n),n.stateNode===null){var f=er,v=a.contextType;typeof v=="object"&&v!==null&&(f=Nn(v)),f=new a(o,f),n.memoizedState=f.state!==null&&f.state!==void 0?f.state:null,f.updater=Tf,n.stateNode=f,f._reactInternals=n,f=n.stateNode,f.props=o,f.state=n.memoizedState,f.refs={},$u(n),v=a.contextType,f.context=typeof v=="object"&&v!==null?Nn(v):er,f.state=n.memoizedState,v=a.getDerivedStateFromProps,typeof v=="function"&&(Ef(n,a,v,o),f.state=n.memoizedState),typeof a.getDerivedStateFromProps=="function"||typeof f.getSnapshotBeforeUpdate=="function"||typeof f.UNSAFE_componentWillMount!="function"&&typeof f.componentWillMount!="function"||(v=f.state,typeof f.componentWillMount=="function"&&f.componentWillMount(),typeof f.UNSAFE_componentWillMount=="function"&&f.UNSAFE_componentWillMount(),v!==f.state&&Tf.enqueueReplaceState(f,f.state,null),yo(n,o,f,u),So(),f.state=n.memoizedState),typeof f.componentDidMount=="function"&&(n.flags|=4194308),o=!0}else if(t===null){f=n.stateNode;var w=n.memoizedProps,V=Ns(a,w);f.props=V;var se=f.context,ge=a.contextType;v=er,typeof ge=="object"&&ge!==null&&(v=Nn(ge));var be=a.getDerivedStateFromProps;ge=typeof be=="function"||typeof f.getSnapshotBeforeUpdate=="function",w=n.pendingProps!==w,ge||typeof f.UNSAFE_componentWillReceiveProps!="function"&&typeof f.componentWillReceiveProps!="function"||(w||se!==v)&&fg(n,f,o,v),Ba=!1;var ce=n.memoizedState;f.state=ce,yo(n,o,f,u),So(),se=n.memoizedState,w||ce!==se||Ba?(typeof be=="function"&&(Ef(n,a,be,o),se=n.memoizedState),(V=Ba||ug(n,a,V,o,ce,se,v))?(ge||typeof f.UNSAFE_componentWillMount!="function"&&typeof f.componentWillMount!="function"||(typeof f.componentWillMount=="function"&&f.componentWillMount(),typeof f.UNSAFE_componentWillMount=="function"&&f.UNSAFE_componentWillMount()),typeof f.componentDidMount=="function"&&(n.flags|=4194308)):(typeof f.componentDidMount=="function"&&(n.flags|=4194308),n.memoizedProps=o,n.memoizedState=se),f.props=o,f.state=se,f.context=v,o=V):(typeof f.componentDidMount=="function"&&(n.flags|=4194308),o=!1)}else{f=n.stateNode,ef(t,n),v=n.memoizedProps,ge=Ns(a,v),f.props=ge,be=n.pendingProps,ce=f.context,se=a.contextType,V=er,typeof se=="object"&&se!==null&&(V=Nn(se)),w=a.getDerivedStateFromProps,(se=typeof w=="function"||typeof f.getSnapshotBeforeUpdate=="function")||typeof f.UNSAFE_componentWillReceiveProps!="function"&&typeof f.componentWillReceiveProps!="function"||(v!==be||ce!==V)&&fg(n,f,o,V),Ba=!1,ce=n.memoizedState,f.state=ce,yo(n,o,f,u),So();var fe=n.memoizedState;v!==be||ce!==fe||Ba||t!==null&&t.dependencies!==null&&Al(t.dependencies)?(typeof w=="function"&&(Ef(n,a,w,o),fe=n.memoizedState),(ge=Ba||ug(n,a,ge,o,ce,fe,V)||t!==null&&t.dependencies!==null&&Al(t.dependencies))?(se||typeof f.UNSAFE_componentWillUpdate!="function"&&typeof f.componentWillUpdate!="function"||(typeof f.componentWillUpdate=="function"&&f.componentWillUpdate(o,fe,V),typeof f.UNSAFE_componentWillUpdate=="function"&&f.UNSAFE_componentWillUpdate(o,fe,V)),typeof f.componentDidUpdate=="function"&&(n.flags|=4),typeof f.getSnapshotBeforeUpdate=="function"&&(n.flags|=1024)):(typeof f.componentDidUpdate!="function"||v===t.memoizedProps&&ce===t.memoizedState||(n.flags|=4),typeof f.getSnapshotBeforeUpdate!="function"||v===t.memoizedProps&&ce===t.memoizedState||(n.flags|=1024),n.memoizedProps=o,n.memoizedState=fe),f.props=o,f.state=fe,f.context=V,o=ge):(typeof f.componentDidUpdate!="function"||v===t.memoizedProps&&ce===t.memoizedState||(n.flags|=4),typeof f.getSnapshotBeforeUpdate!="function"||v===t.memoizedProps&&ce===t.memoizedState||(n.flags|=1024),o=!1)}return f=o,Xl(t,n),o=(n.flags&128)!==0,f||o?(f=n.stateNode,a=o&&typeof a.getDerivedStateFromError!="function"?null:f.render(),n.flags|=1,t!==null&&o?(n.child=ws(n,t.child,null,u),n.child=ws(n,null,a,u)):Un(t,n,a,u),n.memoizedState=f.state,t=n.child):t=oa(t,n,u),t}function Ag(t,n,a,o){return Ms(),n.flags|=256,Un(t,n,a,o),n.child}var wf={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Df(t){return{baseLanes:t,cachePool:mm()}}function Nf(t,n,a){return t=t!==null?t.childLanes&~a:0,n&&(t|=ui),t}function Rg(t,n,a){var o=n.pendingProps,u=!1,f=(n.flags&128)!==0,v;if((v=f)||(v=t!==null&&t.memoizedState===null?!1:(fn.current&2)!==0),v&&(u=!0,n.flags&=-129),v=(n.flags&32)!==0,n.flags&=-33,t===null){if(Ct){if(u?Ga(n):Va(),(t=en)?(t=P0(t,yi),t=t!==null&&t.data!=="&"?t:null,t!==null&&(n.memoizedState={dehydrated:t,treeContext:Oa!==null?{id:Bi,overflow:Ii}:null,retryLane:536870912,hydrationErrors:null},a=rm(t),a.return=n,n.child=a,Dn=n,en=null)):t=null,t===null)throw za(n);return hd(t)?n.lanes=32:n.lanes=536870912,null}var w=o.children;return o=o.fallback,u?(Va(),u=n.mode,w=Wl({mode:"hidden",children:w},u),o=bs(o,u,a,null),w.return=n,o.return=n,w.sibling=o,n.child=w,o=n.child,o.memoizedState=Df(a),o.childLanes=Nf(t,v,a),n.memoizedState=wf,Ao(null,o)):(Ga(n),Uf(n,w))}var V=t.memoizedState;if(V!==null&&(w=V.dehydrated,w!==null)){if(f)n.flags&256?(Ga(n),n.flags&=-257,n=Lf(t,n,a)):n.memoizedState!==null?(Va(),n.child=t.child,n.flags|=128,n=null):(Va(),w=o.fallback,u=n.mode,o=Wl({mode:"visible",children:o.children},u),w=bs(w,u,a,null),w.flags|=2,o.return=n,w.return=n,o.sibling=w,n.child=o,ws(n,t.child,null,a),o=n.child,o.memoizedState=Df(a),o.childLanes=Nf(t,v,a),n.memoizedState=wf,n=Ao(null,o));else if(Ga(n),hd(w)){if(v=w.nextSibling&&w.nextSibling.dataset,v)var se=v.dgst;v=se,o=Error(s(419)),o.stack="",o.digest=v,po({value:o,source:null,stack:null}),n=Lf(t,n,a)}else if(_n||ar(t,n,a,!1),v=(a&t.childLanes)!==0,_n||v){if(v=Qt,v!==null&&(o=kn(v,a),o!==0&&o!==V.retryLane))throw V.retryLane=o,ys(t,o),$n(v,t,o),Rf;dd(w)||tc(),n=Lf(t,n,a)}else dd(w)?(n.flags|=192,n.child=t.child,n=null):(t=V.treeContext,en=Mi(w.nextSibling),Dn=n,Ct=!0,Pa=null,yi=!1,t!==null&&cm(n,t),n=Uf(n,o.children),n.flags|=4096);return n}return u?(Va(),w=o.fallback,u=n.mode,V=t.child,se=V.sibling,o=ta(V,{mode:"hidden",children:o.children}),o.subtreeFlags=V.subtreeFlags&65011712,se!==null?w=ta(se,w):(w=bs(w,u,a,null),w.flags|=2),w.return=n,o.return=n,o.sibling=w,n.child=o,Ao(null,o),o=n.child,w=t.child.memoizedState,w===null?w=Df(a):(u=w.cachePool,u!==null?(V=mn._currentValue,u=u.parent!==V?{parent:V,pool:V}:u):u=mm(),w={baseLanes:w.baseLanes|a,cachePool:u}),o.memoizedState=w,o.childLanes=Nf(t,v,a),n.memoizedState=wf,Ao(t.child,o)):(Ga(n),a=t.child,t=a.sibling,a=ta(a,{mode:"visible",children:o.children}),a.return=n,a.sibling=null,t!==null&&(v=n.deletions,v===null?(n.deletions=[t],n.flags|=16):v.push(t)),n.child=a,n.memoizedState=null,a)}function Uf(t,n){return n=Wl({mode:"visible",children:n},t.mode),n.return=t,t.child=n}function Wl(t,n){return t=ri(22,t,null,n),t.lanes=0,t}function Lf(t,n,a){return ws(n,t.child,null,a),t=Uf(n,n.pendingProps.children),t.flags|=2,n.memoizedState=null,t}function Cg(t,n,a){t.lanes|=n;var o=t.alternate;o!==null&&(o.lanes|=n),qu(t.return,n,a)}function Of(t,n,a,o,u,f){var v=t.memoizedState;v===null?t.memoizedState={isBackwards:n,rendering:null,renderingStartTime:0,last:o,tail:a,tailMode:u,treeForkCount:f}:(v.isBackwards=n,v.rendering=null,v.renderingStartTime=0,v.last=o,v.tail=a,v.tailMode=u,v.treeForkCount=f)}function wg(t,n,a){var o=n.pendingProps,u=o.revealOrder,f=o.tail;o=o.children;var v=fn.current,w=(v&2)!==0;if(w?(v=v&1|2,n.flags|=128):v&=1,ve(fn,v),Un(t,n,o,a),o=Ct?ho:0,!w&&t!==null&&(t.flags&128)!==0)e:for(t=n.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&Cg(t,a,n);else if(t.tag===19)Cg(t,a,n);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===n)break e;for(;t.sibling===null;){if(t.return===null||t.return===n)break e;t=t.return}t.sibling.return=t.return,t=t.sibling}switch(u){case"forwards":for(a=n.child,u=null;a!==null;)t=a.alternate,t!==null&&Ol(t)===null&&(u=a),a=a.sibling;a=u,a===null?(u=n.child,n.child=null):(u=a.sibling,a.sibling=null),Of(n,!1,u,a,f,o);break;case"backwards":case"unstable_legacy-backwards":for(a=null,u=n.child,n.child=null;u!==null;){if(t=u.alternate,t!==null&&Ol(t)===null){n.child=u;break}t=u.sibling,u.sibling=a,a=u,u=t}Of(n,!0,a,null,f,o);break;case"together":Of(n,!1,null,null,void 0,o);break;default:n.memoizedState=null}return n.child}function oa(t,n,a){if(t!==null&&(n.dependencies=t.dependencies),Xa|=n.lanes,(a&n.childLanes)===0)if(t!==null){if(ar(t,n,a,!1),(a&n.childLanes)===0)return null}else return null;if(t!==null&&n.child!==t.child)throw Error(s(153));if(n.child!==null){for(t=n.child,a=ta(t,t.pendingProps),n.child=a,a.return=n;t.sibling!==null;)t=t.sibling,a=a.sibling=ta(t,t.pendingProps),a.return=n;a.sibling=null}return n.child}function Pf(t,n){return(t.lanes&n)!==0?!0:(t=t.dependencies,!!(t!==null&&Al(t)))}function bS(t,n,a){switch(n.tag){case 3:Me(n,n.stateNode.containerInfo),Fa(n,mn,t.memoizedState.cache),Ms();break;case 27:case 5:Ze(n);break;case 4:Me(n,n.stateNode.containerInfo);break;case 10:Fa(n,n.type,n.memoizedProps.value);break;case 31:if(n.memoizedState!==null)return n.flags|=128,rf(n),null;break;case 13:var o=n.memoizedState;if(o!==null)return o.dehydrated!==null?(Ga(n),n.flags|=128,null):(a&n.child.childLanes)!==0?Rg(t,n,a):(Ga(n),t=oa(t,n,a),t!==null?t.sibling:null);Ga(n);break;case 19:var u=(t.flags&128)!==0;if(o=(a&n.childLanes)!==0,o||(ar(t,n,a,!1),o=(a&n.childLanes)!==0),u){if(o)return wg(t,n,a);n.flags|=128}if(u=n.memoizedState,u!==null&&(u.rendering=null,u.tail=null,u.lastEffect=null),ve(fn,fn.current),o)break;return null;case 22:return n.lanes=0,yg(t,n,a,n.pendingProps);case 24:Fa(n,mn,t.memoizedState.cache)}return oa(t,n,a)}function Dg(t,n,a){if(t!==null)if(t.memoizedProps!==n.pendingProps)_n=!0;else{if(!Pf(t,a)&&(n.flags&128)===0)return _n=!1,bS(t,n,a);_n=(t.flags&131072)!==0}else _n=!1,Ct&&(n.flags&1048576)!==0&&lm(n,ho,n.index);switch(n.lanes=0,n.tag){case 16:e:{var o=n.pendingProps;if(t=Rs(n.elementType),n.type=t,typeof t=="function")Iu(t)?(o=Ns(t,o),n.tag=1,n=Tg(null,n,t,o,a)):(n.tag=0,n=Cf(null,n,t,o,a));else{if(t!=null){var u=t.$$typeof;if(u===z){n.tag=11,n=xg(null,n,t,o,a);break e}else if(u===H){n.tag=14,n=vg(null,n,t,o,a);break e}}throw n=pe(t)||t,Error(s(306,n,""))}}return n;case 0:return Cf(t,n,n.type,n.pendingProps,a);case 1:return o=n.type,u=Ns(o,n.pendingProps),Tg(t,n,o,u,a);case 3:e:{if(Me(n,n.stateNode.containerInfo),t===null)throw Error(s(387));o=n.pendingProps;var f=n.memoizedState;u=f.element,ef(t,n),yo(n,o,null,a);var v=n.memoizedState;if(o=v.cache,Fa(n,mn,o),o!==f.cache&&Yu(n,[mn],a,!0),So(),o=v.element,f.isDehydrated)if(f={element:o,isDehydrated:!1,cache:v.cache},n.updateQueue.baseState=f,n.memoizedState=f,n.flags&256){n=Ag(t,n,o,a);break e}else if(o!==u){u=xi(Error(s(424)),n),po(u),n=Ag(t,n,o,a);break e}else{switch(t=n.stateNode.containerInfo,t.nodeType){case 9:t=t.body;break;default:t=t.nodeName==="HTML"?t.ownerDocument.body:t}for(en=Mi(t.firstChild),Dn=n,Ct=!0,Pa=null,yi=!0,a=ym(n,null,o,a),n.child=a;a;)a.flags=a.flags&-3|4096,a=a.sibling}else{if(Ms(),o===u){n=oa(t,n,a);break e}Un(t,n,o,a)}n=n.child}return n;case 26:return Xl(t,n),t===null?(a=G0(n.type,null,n.pendingProps,null))?n.memoizedState=a:Ct||(a=n.type,t=n.pendingProps,o=lc(ae.current).createElement(a),o[un]=n,o[wn]=t,Ln(o,a,t),pn(o),n.stateNode=o):n.memoizedState=G0(n.type,t.memoizedProps,n.pendingProps,t.memoizedState),null;case 27:return Ze(n),t===null&&Ct&&(o=n.stateNode=B0(n.type,n.pendingProps,ae.current),Dn=n,yi=!0,u=en,Ka(n.type)?(pd=u,en=Mi(o.firstChild)):en=u),Un(t,n,n.pendingProps.children,a),Xl(t,n),t===null&&(n.flags|=4194304),n.child;case 5:return t===null&&Ct&&((u=o=en)&&(o=JS(o,n.type,n.pendingProps,yi),o!==null?(n.stateNode=o,Dn=n,en=Mi(o.firstChild),yi=!1,u=!0):u=!1),u||za(n)),Ze(n),u=n.type,f=n.pendingProps,v=t!==null?t.memoizedProps:null,o=f.children,cd(u,f)?o=null:v!==null&&cd(u,v)&&(n.flags|=32),n.memoizedState!==null&&(u=lf(t,n,hS,null,null,a),Go._currentValue=u),Xl(t,n),Un(t,n,o,a),n.child;case 6:return t===null&&Ct&&((t=a=en)&&(a=$S(a,n.pendingProps,yi),a!==null?(n.stateNode=a,Dn=n,en=null,t=!0):t=!1),t||za(n)),null;case 13:return Rg(t,n,a);case 4:return Me(n,n.stateNode.containerInfo),o=n.pendingProps,t===null?n.child=ws(n,null,o,a):Un(t,n,o,a),n.child;case 11:return xg(t,n,n.type,n.pendingProps,a);case 7:return Un(t,n,n.pendingProps,a),n.child;case 8:return Un(t,n,n.pendingProps.children,a),n.child;case 12:return Un(t,n,n.pendingProps.children,a),n.child;case 10:return o=n.pendingProps,Fa(n,n.type,o.value),Un(t,n,o.children,a),n.child;case 9:return u=n.type._context,o=n.pendingProps.children,Ts(n),u=Nn(u),o=o(u),n.flags|=1,Un(t,n,o,a),n.child;case 14:return vg(t,n,n.type,n.pendingProps,a);case 15:return Sg(t,n,n.type,n.pendingProps,a);case 19:return wg(t,n,a);case 31:return yS(t,n,a);case 22:return yg(t,n,a,n.pendingProps);case 24:return Ts(n),o=Nn(mn),t===null?(u=Qu(),u===null&&(u=Qt,f=Zu(),u.pooledCache=f,f.refCount++,f!==null&&(u.pooledCacheLanes|=a),u=f),n.memoizedState={parent:o,cache:u},$u(n),Fa(n,mn,u)):((t.lanes&a)!==0&&(ef(t,n),yo(n,null,null,a),So()),u=t.memoizedState,f=n.memoizedState,u.parent!==o?(u={parent:o,cache:o},n.memoizedState=u,n.lanes===0&&(n.memoizedState=n.updateQueue.baseState=u),Fa(n,mn,o)):(o=f.cache,Fa(n,mn,o),o!==u.cache&&Yu(n,[mn],a,!0))),Un(t,n,n.pendingProps.children,a),n.child;case 29:throw n.pendingProps}throw Error(s(156,n.tag))}function la(t){t.flags|=4}function zf(t,n,a,o,u){if((n=(t.mode&32)!==0)&&(n=!1),n){if(t.flags|=16777216,(u&335544128)===u)if(t.stateNode.complete)t.flags|=8192;else if(i0())t.flags|=8192;else throw Cs=Dl,Ju}else t.flags&=-16777217}function Ng(t,n){if(n.type!=="stylesheet"||(n.state.loading&4)!==0)t.flags&=-16777217;else if(t.flags|=16777216,!W0(n))if(i0())t.flags|=8192;else throw Cs=Dl,Ju}function ql(t,n){n!==null&&(t.flags|=4),t.flags&16384&&(n=t.tag!==22?Ee():536870912,t.lanes|=n,gr|=n)}function Ro(t,n){if(!Ct)switch(t.tailMode){case"hidden":n=t.tail;for(var a=null;n!==null;)n.alternate!==null&&(a=n),n=n.sibling;a===null?t.tail=null:a.sibling=null;break;case"collapsed":a=t.tail;for(var o=null;a!==null;)a.alternate!==null&&(o=a),a=a.sibling;o===null?n||t.tail===null?t.tail=null:t.tail.sibling=null:o.sibling=null}}function tn(t){var n=t.alternate!==null&&t.alternate.child===t.child,a=0,o=0;if(n)for(var u=t.child;u!==null;)a|=u.lanes|u.childLanes,o|=u.subtreeFlags&65011712,o|=u.flags&65011712,u.return=t,u=u.sibling;else for(u=t.child;u!==null;)a|=u.lanes|u.childLanes,o|=u.subtreeFlags,o|=u.flags,u.return=t,u=u.sibling;return t.subtreeFlags|=o,t.childLanes=a,n}function MS(t,n,a){var o=n.pendingProps;switch(ku(n),n.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return tn(n),null;case 1:return tn(n),null;case 3:return a=n.stateNode,o=null,t!==null&&(o=t.memoizedState.cache),n.memoizedState.cache!==o&&(n.flags|=2048),aa(mn),Ie(),a.pendingContext&&(a.context=a.pendingContext,a.pendingContext=null),(t===null||t.child===null)&&(ir(n)?la(n):t===null||t.memoizedState.isDehydrated&&(n.flags&256)===0||(n.flags|=1024,Xu())),tn(n),null;case 26:var u=n.type,f=n.memoizedState;return t===null?(la(n),f!==null?(tn(n),Ng(n,f)):(tn(n),zf(n,u,null,o,a))):f?f!==t.memoizedState?(la(n),tn(n),Ng(n,f)):(tn(n),n.flags&=-16777217):(t=t.memoizedProps,t!==o&&la(n),tn(n),zf(n,u,t,o,a)),null;case 27:if(Ke(n),a=ae.current,u=n.type,t!==null&&n.stateNode!=null)t.memoizedProps!==o&&la(n);else{if(!o){if(n.stateNode===null)throw Error(s(166));return tn(n),null}t=Ae.current,ir(n)?um(n):(t=B0(u,o,a),n.stateNode=t,la(n))}return tn(n),null;case 5:if(Ke(n),u=n.type,t!==null&&n.stateNode!=null)t.memoizedProps!==o&&la(n);else{if(!o){if(n.stateNode===null)throw Error(s(166));return tn(n),null}if(f=Ae.current,ir(n))um(n);else{var v=lc(ae.current);switch(f){case 1:f=v.createElementNS("http://www.w3.org/2000/svg",u);break;case 2:f=v.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;default:switch(u){case"svg":f=v.createElementNS("http://www.w3.org/2000/svg",u);break;case"math":f=v.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;case"script":f=v.createElement("div"),f.innerHTML="<script><\/script>",f=f.removeChild(f.firstChild);break;case"select":f=typeof o.is=="string"?v.createElement("select",{is:o.is}):v.createElement("select"),o.multiple?f.multiple=!0:o.size&&(f.size=o.size);break;default:f=typeof o.is=="string"?v.createElement(u,{is:o.is}):v.createElement(u)}}f[un]=n,f[wn]=o;e:for(v=n.child;v!==null;){if(v.tag===5||v.tag===6)f.appendChild(v.stateNode);else if(v.tag!==4&&v.tag!==27&&v.child!==null){v.child.return=v,v=v.child;continue}if(v===n)break e;for(;v.sibling===null;){if(v.return===null||v.return===n)break e;v=v.return}v.sibling.return=v.return,v=v.sibling}n.stateNode=f;e:switch(Ln(f,u,o),u){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break e;case"img":o=!0;break e;default:o=!1}o&&la(n)}}return tn(n),zf(n,n.type,t===null?null:t.memoizedProps,n.pendingProps,a),null;case 6:if(t&&n.stateNode!=null)t.memoizedProps!==o&&la(n);else{if(typeof o!="string"&&n.stateNode===null)throw Error(s(166));if(t=ae.current,ir(n)){if(t=n.stateNode,a=n.memoizedProps,o=null,u=Dn,u!==null)switch(u.tag){case 27:case 5:o=u.memoizedProps}t[un]=n,t=!!(t.nodeValue===a||o!==null&&o.suppressHydrationWarning===!0||R0(t.nodeValue,a)),t||za(n,!0)}else t=lc(t).createTextNode(o),t[un]=n,n.stateNode=t}return tn(n),null;case 31:if(a=n.memoizedState,t===null||t.memoizedState!==null){if(o=ir(n),a!==null){if(t===null){if(!o)throw Error(s(318));if(t=n.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(s(557));t[un]=n}else Ms(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;tn(n),t=!1}else a=Xu(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=a),t=!0;if(!t)return n.flags&256?(li(n),n):(li(n),null);if((n.flags&128)!==0)throw Error(s(558))}return tn(n),null;case 13:if(o=n.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(u=ir(n),o!==null&&o.dehydrated!==null){if(t===null){if(!u)throw Error(s(318));if(u=n.memoizedState,u=u!==null?u.dehydrated:null,!u)throw Error(s(317));u[un]=n}else Ms(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;tn(n),u=!1}else u=Xu(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=u),u=!0;if(!u)return n.flags&256?(li(n),n):(li(n),null)}return li(n),(n.flags&128)!==0?(n.lanes=a,n):(a=o!==null,t=t!==null&&t.memoizedState!==null,a&&(o=n.child,u=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(u=o.alternate.memoizedState.cachePool.pool),f=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(f=o.memoizedState.cachePool.pool),f!==u&&(o.flags|=2048)),a!==t&&a&&(n.child.flags|=8192),ql(n,n.updateQueue),tn(n),null);case 4:return Ie(),t===null&&ad(n.stateNode.containerInfo),tn(n),null;case 10:return aa(n.type),tn(n),null;case 19:if(Q(fn),o=n.memoizedState,o===null)return tn(n),null;if(u=(n.flags&128)!==0,f=o.rendering,f===null)if(u)Ro(o,!1);else{if(ln!==0||t!==null&&(t.flags&128)!==0)for(t=n.child;t!==null;){if(f=Ol(t),f!==null){for(n.flags|=128,Ro(o,!1),t=f.updateQueue,n.updateQueue=t,ql(n,t),n.subtreeFlags=0,t=a,a=n.child;a!==null;)sm(a,t),a=a.sibling;return ve(fn,fn.current&1|2),Ct&&na(n,o.treeForkCount),n.child}t=t.sibling}o.tail!==null&&we()>Jl&&(n.flags|=128,u=!0,Ro(o,!1),n.lanes=4194304)}else{if(!u)if(t=Ol(f),t!==null){if(n.flags|=128,u=!0,t=t.updateQueue,n.updateQueue=t,ql(n,t),Ro(o,!0),o.tail===null&&o.tailMode==="hidden"&&!f.alternate&&!Ct)return tn(n),null}else 2*we()-o.renderingStartTime>Jl&&a!==536870912&&(n.flags|=128,u=!0,Ro(o,!1),n.lanes=4194304);o.isBackwards?(f.sibling=n.child,n.child=f):(t=o.last,t!==null?t.sibling=f:n.child=f,o.last=f)}return o.tail!==null?(t=o.tail,o.rendering=t,o.tail=t.sibling,o.renderingStartTime=we(),t.sibling=null,a=fn.current,ve(fn,u?a&1|2:a&1),Ct&&na(n,o.treeForkCount),t):(tn(n),null);case 22:case 23:return li(n),sf(),o=n.memoizedState!==null,t!==null?t.memoizedState!==null!==o&&(n.flags|=8192):o&&(n.flags|=8192),o?(a&536870912)!==0&&(n.flags&128)===0&&(tn(n),n.subtreeFlags&6&&(n.flags|=8192)):tn(n),a=n.updateQueue,a!==null&&ql(n,a.retryQueue),a=null,t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(a=t.memoizedState.cachePool.pool),o=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(o=n.memoizedState.cachePool.pool),o!==a&&(n.flags|=2048),t!==null&&Q(As),null;case 24:return a=null,t!==null&&(a=t.memoizedState.cache),n.memoizedState.cache!==a&&(n.flags|=2048),aa(mn),tn(n),null;case 25:return null;case 30:return null}throw Error(s(156,n.tag))}function ES(t,n){switch(ku(n),n.tag){case 1:return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 3:return aa(mn),Ie(),t=n.flags,(t&65536)!==0&&(t&128)===0?(n.flags=t&-65537|128,n):null;case 26:case 27:case 5:return Ke(n),null;case 31:if(n.memoizedState!==null){if(li(n),n.alternate===null)throw Error(s(340));Ms()}return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 13:if(li(n),t=n.memoizedState,t!==null&&t.dehydrated!==null){if(n.alternate===null)throw Error(s(340));Ms()}return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 19:return Q(fn),null;case 4:return Ie(),null;case 10:return aa(n.type),null;case 22:case 23:return li(n),sf(),t!==null&&Q(As),t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 24:return aa(mn),null;case 25:return null;default:return null}}function Ug(t,n){switch(ku(n),n.tag){case 3:aa(mn),Ie();break;case 26:case 27:case 5:Ke(n);break;case 4:Ie();break;case 31:n.memoizedState!==null&&li(n);break;case 13:li(n);break;case 19:Q(fn);break;case 10:aa(n.type);break;case 22:case 23:li(n),sf(),t!==null&&Q(As);break;case 24:aa(mn)}}function Co(t,n){try{var a=n.updateQueue,o=a!==null?a.lastEffect:null;if(o!==null){var u=o.next;a=u;do{if((a.tag&t)===t){o=void 0;var f=a.create,v=a.inst;o=f(),v.destroy=o}a=a.next}while(a!==u)}}catch(w){kt(n,n.return,w)}}function ka(t,n,a){try{var o=n.updateQueue,u=o!==null?o.lastEffect:null;if(u!==null){var f=u.next;o=f;do{if((o.tag&t)===t){var v=o.inst,w=v.destroy;if(w!==void 0){v.destroy=void 0,u=n;var V=a,se=w;try{se()}catch(ge){kt(u,V,ge)}}}o=o.next}while(o!==f)}}catch(ge){kt(n,n.return,ge)}}function Lg(t){var n=t.updateQueue;if(n!==null){var a=t.stateNode;try{Mm(n,a)}catch(o){kt(t,t.return,o)}}}function Og(t,n,a){a.props=Ns(t.type,t.memoizedProps),a.state=t.memoizedState;try{a.componentWillUnmount()}catch(o){kt(t,n,o)}}function wo(t,n){try{var a=t.ref;if(a!==null){switch(t.tag){case 26:case 27:case 5:var o=t.stateNode;break;case 30:o=t.stateNode;break;default:o=t.stateNode}typeof a=="function"?t.refCleanup=a(o):a.current=o}}catch(u){kt(t,n,u)}}function Hi(t,n){var a=t.ref,o=t.refCleanup;if(a!==null)if(typeof o=="function")try{o()}catch(u){kt(t,n,u)}finally{t.refCleanup=null,t=t.alternate,t!=null&&(t.refCleanup=null)}else if(typeof a=="function")try{a(null)}catch(u){kt(t,n,u)}else a.current=null}function Pg(t){var n=t.type,a=t.memoizedProps,o=t.stateNode;try{e:switch(n){case"button":case"input":case"select":case"textarea":a.autoFocus&&o.focus();break e;case"img":a.src?o.src=a.src:a.srcSet&&(o.srcset=a.srcSet)}}catch(u){kt(t,t.return,u)}}function Ff(t,n,a){try{var o=t.stateNode;WS(o,t.type,a,n),o[wn]=n}catch(u){kt(t,t.return,u)}}function zg(t){return t.tag===5||t.tag===3||t.tag===26||t.tag===27&&Ka(t.type)||t.tag===4}function Bf(t){e:for(;;){for(;t.sibling===null;){if(t.return===null||zg(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.tag===27&&Ka(t.type)||t.flags&2||t.child===null||t.tag===4)continue e;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function If(t,n,a){var o=t.tag;if(o===5||o===6)t=t.stateNode,n?(a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a).insertBefore(t,n):(n=a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a,n.appendChild(t),a=a._reactRootContainer,a!=null||n.onclick!==null||(n.onclick=$i));else if(o!==4&&(o===27&&Ka(t.type)&&(a=t.stateNode,n=null),t=t.child,t!==null))for(If(t,n,a),t=t.sibling;t!==null;)If(t,n,a),t=t.sibling}function Yl(t,n,a){var o=t.tag;if(o===5||o===6)t=t.stateNode,n?a.insertBefore(t,n):a.appendChild(t);else if(o!==4&&(o===27&&Ka(t.type)&&(a=t.stateNode),t=t.child,t!==null))for(Yl(t,n,a),t=t.sibling;t!==null;)Yl(t,n,a),t=t.sibling}function Fg(t){var n=t.stateNode,a=t.memoizedProps;try{for(var o=t.type,u=n.attributes;u.length;)n.removeAttributeNode(u[0]);Ln(n,o,a),n[un]=t,n[wn]=a}catch(f){kt(t,t.return,f)}}var ca=!1,xn=!1,Hf=!1,Bg=typeof WeakSet=="function"?WeakSet:Set,Tn=null;function TS(t,n){if(t=t.containerInfo,od=mc,t=Kp(t),Uu(t)){if("selectionStart"in t)var a={start:t.selectionStart,end:t.selectionEnd};else e:{a=(a=t.ownerDocument)&&a.defaultView||window;var o=a.getSelection&&a.getSelection();if(o&&o.rangeCount!==0){a=o.anchorNode;var u=o.anchorOffset,f=o.focusNode;o=o.focusOffset;try{a.nodeType,f.nodeType}catch{a=null;break e}var v=0,w=-1,V=-1,se=0,ge=0,be=t,ce=null;t:for(;;){for(var fe;be!==a||u!==0&&be.nodeType!==3||(w=v+u),be!==f||o!==0&&be.nodeType!==3||(V=v+o),be.nodeType===3&&(v+=be.nodeValue.length),(fe=be.firstChild)!==null;)ce=be,be=fe;for(;;){if(be===t)break t;if(ce===a&&++se===u&&(w=v),ce===f&&++ge===o&&(V=v),(fe=be.nextSibling)!==null)break;be=ce,ce=be.parentNode}be=fe}a=w===-1||V===-1?null:{start:w,end:V}}else a=null}a=a||{start:0,end:0}}else a=null;for(ld={focusedElem:t,selectionRange:a},mc=!1,Tn=n;Tn!==null;)if(n=Tn,t=n.child,(n.subtreeFlags&1028)!==0&&t!==null)t.return=n,Tn=t;else for(;Tn!==null;){switch(n=Tn,f=n.alternate,t=n.flags,n.tag){case 0:if((t&4)!==0&&(t=n.updateQueue,t=t!==null?t.events:null,t!==null))for(a=0;a<t.length;a++)u=t[a],u.ref.impl=u.nextImpl;break;case 11:case 15:break;case 1:if((t&1024)!==0&&f!==null){t=void 0,a=n,u=f.memoizedProps,f=f.memoizedState,o=a.stateNode;try{var Ye=Ns(a.type,u);t=o.getSnapshotBeforeUpdate(Ye,f),o.__reactInternalSnapshotBeforeUpdate=t}catch(at){kt(a,a.return,at)}}break;case 3:if((t&1024)!==0){if(t=n.stateNode.containerInfo,a=t.nodeType,a===9)fd(t);else if(a===1)switch(t.nodeName){case"HEAD":case"HTML":case"BODY":fd(t);break;default:t.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((t&1024)!==0)throw Error(s(163))}if(t=n.sibling,t!==null){t.return=n.return,Tn=t;break}Tn=n.return}}function Ig(t,n,a){var o=a.flags;switch(a.tag){case 0:case 11:case 15:fa(t,a),o&4&&Co(5,a);break;case 1:if(fa(t,a),o&4)if(t=a.stateNode,n===null)try{t.componentDidMount()}catch(v){kt(a,a.return,v)}else{var u=Ns(a.type,n.memoizedProps);n=n.memoizedState;try{t.componentDidUpdate(u,n,t.__reactInternalSnapshotBeforeUpdate)}catch(v){kt(a,a.return,v)}}o&64&&Lg(a),o&512&&wo(a,a.return);break;case 3:if(fa(t,a),o&64&&(t=a.updateQueue,t!==null)){if(n=null,a.child!==null)switch(a.child.tag){case 27:case 5:n=a.child.stateNode;break;case 1:n=a.child.stateNode}try{Mm(t,n)}catch(v){kt(a,a.return,v)}}break;case 27:n===null&&o&4&&Fg(a);case 26:case 5:fa(t,a),n===null&&o&4&&Pg(a),o&512&&wo(a,a.return);break;case 12:fa(t,a);break;case 31:fa(t,a),o&4&&Vg(t,a);break;case 13:fa(t,a),o&4&&kg(t,a),o&64&&(t=a.memoizedState,t!==null&&(t=t.dehydrated,t!==null&&(a=OS.bind(null,a),ey(t,a))));break;case 22:if(o=a.memoizedState!==null||ca,!o){n=n!==null&&n.memoizedState!==null||xn,u=ca;var f=xn;ca=o,(xn=n)&&!f?da(t,a,(a.subtreeFlags&8772)!==0):fa(t,a),ca=u,xn=f}break;case 30:break;default:fa(t,a)}}function Hg(t){var n=t.alternate;n!==null&&(t.alternate=null,Hg(n)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(n=t.stateNode,n!==null&&no(n)),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}var sn=null,Zn=!1;function ua(t,n,a){for(a=a.child;a!==null;)Gg(t,n,a),a=a.sibling}function Gg(t,n,a){if(de&&typeof de.onCommitFiberUnmount=="function")try{de.onCommitFiberUnmount(ne,a)}catch{}switch(a.tag){case 26:xn||Hi(a,n),ua(t,n,a),a.memoizedState?a.memoizedState.count--:a.stateNode&&(a=a.stateNode,a.parentNode.removeChild(a));break;case 27:xn||Hi(a,n);var o=sn,u=Zn;Ka(a.type)&&(sn=a.stateNode,Zn=!1),ua(t,n,a),Bo(a.stateNode),sn=o,Zn=u;break;case 5:xn||Hi(a,n);case 6:if(o=sn,u=Zn,sn=null,ua(t,n,a),sn=o,Zn=u,sn!==null)if(Zn)try{(sn.nodeType===9?sn.body:sn.nodeName==="HTML"?sn.ownerDocument.body:sn).removeChild(a.stateNode)}catch(f){kt(a,n,f)}else try{sn.removeChild(a.stateNode)}catch(f){kt(a,n,f)}break;case 18:sn!==null&&(Zn?(t=sn,L0(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,a.stateNode),Er(t)):L0(sn,a.stateNode));break;case 4:o=sn,u=Zn,sn=a.stateNode.containerInfo,Zn=!0,ua(t,n,a),sn=o,Zn=u;break;case 0:case 11:case 14:case 15:ka(2,a,n),xn||ka(4,a,n),ua(t,n,a);break;case 1:xn||(Hi(a,n),o=a.stateNode,typeof o.componentWillUnmount=="function"&&Og(a,n,o)),ua(t,n,a);break;case 21:ua(t,n,a);break;case 22:xn=(o=xn)||a.memoizedState!==null,ua(t,n,a),xn=o;break;default:ua(t,n,a)}}function Vg(t,n){if(n.memoizedState===null&&(t=n.alternate,t!==null&&(t=t.memoizedState,t!==null))){t=t.dehydrated;try{Er(t)}catch(a){kt(n,n.return,a)}}}function kg(t,n){if(n.memoizedState===null&&(t=n.alternate,t!==null&&(t=t.memoizedState,t!==null&&(t=t.dehydrated,t!==null))))try{Er(t)}catch(a){kt(n,n.return,a)}}function AS(t){switch(t.tag){case 31:case 13:case 19:var n=t.stateNode;return n===null&&(n=t.stateNode=new Bg),n;case 22:return t=t.stateNode,n=t._retryCache,n===null&&(n=t._retryCache=new Bg),n;default:throw Error(s(435,t.tag))}}function Zl(t,n){var a=AS(t);n.forEach(function(o){if(!a.has(o)){a.add(o);var u=PS.bind(null,t,o);o.then(u,u)}})}function Kn(t,n){var a=n.deletions;if(a!==null)for(var o=0;o<a.length;o++){var u=a[o],f=t,v=n,w=v;e:for(;w!==null;){switch(w.tag){case 27:if(Ka(w.type)){sn=w.stateNode,Zn=!1;break e}break;case 5:sn=w.stateNode,Zn=!1;break e;case 3:case 4:sn=w.stateNode.containerInfo,Zn=!0;break e}w=w.return}if(sn===null)throw Error(s(160));Gg(f,v,u),sn=null,Zn=!1,f=u.alternate,f!==null&&(f.return=null),u.return=null}if(n.subtreeFlags&13886)for(n=n.child;n!==null;)jg(n,t),n=n.sibling}var Di=null;function jg(t,n){var a=t.alternate,o=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:Kn(n,t),Qn(t),o&4&&(ka(3,t,t.return),Co(3,t),ka(5,t,t.return));break;case 1:Kn(n,t),Qn(t),o&512&&(xn||a===null||Hi(a,a.return)),o&64&&ca&&(t=t.updateQueue,t!==null&&(o=t.callbacks,o!==null&&(a=t.shared.hiddenCallbacks,t.shared.hiddenCallbacks=a===null?o:a.concat(o))));break;case 26:var u=Di;if(Kn(n,t),Qn(t),o&512&&(xn||a===null||Hi(a,a.return)),o&4){var f=a!==null?a.memoizedState:null;if(o=t.memoizedState,a===null)if(o===null)if(t.stateNode===null){e:{o=t.type,a=t.memoizedProps,u=u.ownerDocument||u;t:switch(o){case"title":f=u.getElementsByTagName("title")[0],(!f||f[Ca]||f[un]||f.namespaceURI==="http://www.w3.org/2000/svg"||f.hasAttribute("itemprop"))&&(f=u.createElement(o),u.head.insertBefore(f,u.querySelector("head > title"))),Ln(f,o,a),f[un]=t,pn(f),o=f;break e;case"link":var v=j0("link","href",u).get(o+(a.href||""));if(v){for(var w=0;w<v.length;w++)if(f=v[w],f.getAttribute("href")===(a.href==null||a.href===""?null:a.href)&&f.getAttribute("rel")===(a.rel==null?null:a.rel)&&f.getAttribute("title")===(a.title==null?null:a.title)&&f.getAttribute("crossorigin")===(a.crossOrigin==null?null:a.crossOrigin)){v.splice(w,1);break t}}f=u.createElement(o),Ln(f,o,a),u.head.appendChild(f);break;case"meta":if(v=j0("meta","content",u).get(o+(a.content||""))){for(w=0;w<v.length;w++)if(f=v[w],f.getAttribute("content")===(a.content==null?null:""+a.content)&&f.getAttribute("name")===(a.name==null?null:a.name)&&f.getAttribute("property")===(a.property==null?null:a.property)&&f.getAttribute("http-equiv")===(a.httpEquiv==null?null:a.httpEquiv)&&f.getAttribute("charset")===(a.charSet==null?null:a.charSet)){v.splice(w,1);break t}}f=u.createElement(o),Ln(f,o,a),u.head.appendChild(f);break;default:throw Error(s(468,o))}f[un]=t,pn(f),o=f}t.stateNode=o}else X0(u,t.type,t.stateNode);else t.stateNode=k0(u,o,t.memoizedProps);else f!==o?(f===null?a.stateNode!==null&&(a=a.stateNode,a.parentNode.removeChild(a)):f.count--,o===null?X0(u,t.type,t.stateNode):k0(u,o,t.memoizedProps)):o===null&&t.stateNode!==null&&Ff(t,t.memoizedProps,a.memoizedProps)}break;case 27:Kn(n,t),Qn(t),o&512&&(xn||a===null||Hi(a,a.return)),a!==null&&o&4&&Ff(t,t.memoizedProps,a.memoizedProps);break;case 5:if(Kn(n,t),Qn(t),o&512&&(xn||a===null||Hi(a,a.return)),t.flags&32){u=t.stateNode;try{ai(u,"")}catch(Ye){kt(t,t.return,Ye)}}o&4&&t.stateNode!=null&&(u=t.memoizedProps,Ff(t,u,a!==null?a.memoizedProps:u)),o&1024&&(Hf=!0);break;case 6:if(Kn(n,t),Qn(t),o&4){if(t.stateNode===null)throw Error(s(162));o=t.memoizedProps,a=t.stateNode;try{a.nodeValue=o}catch(Ye){kt(t,t.return,Ye)}}break;case 3:if(fc=null,u=Di,Di=cc(n.containerInfo),Kn(n,t),Di=u,Qn(t),o&4&&a!==null&&a.memoizedState.isDehydrated)try{Er(n.containerInfo)}catch(Ye){kt(t,t.return,Ye)}Hf&&(Hf=!1,Xg(t));break;case 4:o=Di,Di=cc(t.stateNode.containerInfo),Kn(n,t),Qn(t),Di=o;break;case 12:Kn(n,t),Qn(t);break;case 31:Kn(n,t),Qn(t),o&4&&(o=t.updateQueue,o!==null&&(t.updateQueue=null,Zl(t,o)));break;case 13:Kn(n,t),Qn(t),t.child.flags&8192&&t.memoizedState!==null!=(a!==null&&a.memoizedState!==null)&&(Ql=we()),o&4&&(o=t.updateQueue,o!==null&&(t.updateQueue=null,Zl(t,o)));break;case 22:u=t.memoizedState!==null;var V=a!==null&&a.memoizedState!==null,se=ca,ge=xn;if(ca=se||u,xn=ge||V,Kn(n,t),xn=ge,ca=se,Qn(t),o&8192)e:for(n=t.stateNode,n._visibility=u?n._visibility&-2:n._visibility|1,u&&(a===null||V||ca||xn||Us(t)),a=null,n=t;;){if(n.tag===5||n.tag===26){if(a===null){V=a=n;try{if(f=V.stateNode,u)v=f.style,typeof v.setProperty=="function"?v.setProperty("display","none","important"):v.display="none";else{w=V.stateNode;var be=V.memoizedProps.style,ce=be!=null&&be.hasOwnProperty("display")?be.display:null;w.style.display=ce==null||typeof ce=="boolean"?"":(""+ce).trim()}}catch(Ye){kt(V,V.return,Ye)}}}else if(n.tag===6){if(a===null){V=n;try{V.stateNode.nodeValue=u?"":V.memoizedProps}catch(Ye){kt(V,V.return,Ye)}}}else if(n.tag===18){if(a===null){V=n;try{var fe=V.stateNode;u?O0(fe,!0):O0(V.stateNode,!1)}catch(Ye){kt(V,V.return,Ye)}}}else if((n.tag!==22&&n.tag!==23||n.memoizedState===null||n===t)&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break e;for(;n.sibling===null;){if(n.return===null||n.return===t)break e;a===n&&(a=null),n=n.return}a===n&&(a=null),n.sibling.return=n.return,n=n.sibling}o&4&&(o=t.updateQueue,o!==null&&(a=o.retryQueue,a!==null&&(o.retryQueue=null,Zl(t,a))));break;case 19:Kn(n,t),Qn(t),o&4&&(o=t.updateQueue,o!==null&&(t.updateQueue=null,Zl(t,o)));break;case 30:break;case 21:break;default:Kn(n,t),Qn(t)}}function Qn(t){var n=t.flags;if(n&2){try{for(var a,o=t.return;o!==null;){if(zg(o)){a=o;break}o=o.return}if(a==null)throw Error(s(160));switch(a.tag){case 27:var u=a.stateNode,f=Bf(t);Yl(t,f,u);break;case 5:var v=a.stateNode;a.flags&32&&(ai(v,""),a.flags&=-33);var w=Bf(t);Yl(t,w,v);break;case 3:case 4:var V=a.stateNode.containerInfo,se=Bf(t);If(t,se,V);break;default:throw Error(s(161))}}catch(ge){kt(t,t.return,ge)}t.flags&=-3}n&4096&&(t.flags&=-4097)}function Xg(t){if(t.subtreeFlags&1024)for(t=t.child;t!==null;){var n=t;Xg(n),n.tag===5&&n.flags&1024&&n.stateNode.reset(),t=t.sibling}}function fa(t,n){if(n.subtreeFlags&8772)for(n=n.child;n!==null;)Ig(t,n.alternate,n),n=n.sibling}function Us(t){for(t=t.child;t!==null;){var n=t;switch(n.tag){case 0:case 11:case 14:case 15:ka(4,n,n.return),Us(n);break;case 1:Hi(n,n.return);var a=n.stateNode;typeof a.componentWillUnmount=="function"&&Og(n,n.return,a),Us(n);break;case 27:Bo(n.stateNode);case 26:case 5:Hi(n,n.return),Us(n);break;case 22:n.memoizedState===null&&Us(n);break;case 30:Us(n);break;default:Us(n)}t=t.sibling}}function da(t,n,a){for(a=a&&(n.subtreeFlags&8772)!==0,n=n.child;n!==null;){var o=n.alternate,u=t,f=n,v=f.flags;switch(f.tag){case 0:case 11:case 15:da(u,f,a),Co(4,f);break;case 1:if(da(u,f,a),o=f,u=o.stateNode,typeof u.componentDidMount=="function")try{u.componentDidMount()}catch(se){kt(o,o.return,se)}if(o=f,u=o.updateQueue,u!==null){var w=o.stateNode;try{var V=u.shared.hiddenCallbacks;if(V!==null)for(u.shared.hiddenCallbacks=null,u=0;u<V.length;u++)bm(V[u],w)}catch(se){kt(o,o.return,se)}}a&&v&64&&Lg(f),wo(f,f.return);break;case 27:Fg(f);case 26:case 5:da(u,f,a),a&&o===null&&v&4&&Pg(f),wo(f,f.return);break;case 12:da(u,f,a);break;case 31:da(u,f,a),a&&v&4&&Vg(u,f);break;case 13:da(u,f,a),a&&v&4&&kg(u,f);break;case 22:f.memoizedState===null&&da(u,f,a),wo(f,f.return);break;case 30:break;default:da(u,f,a)}n=n.sibling}}function Gf(t,n){var a=null;t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(a=t.memoizedState.cachePool.pool),t=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(t=n.memoizedState.cachePool.pool),t!==a&&(t!=null&&t.refCount++,a!=null&&mo(a))}function Vf(t,n){t=null,n.alternate!==null&&(t=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==t&&(n.refCount++,t!=null&&mo(t))}function Ni(t,n,a,o){if(n.subtreeFlags&10256)for(n=n.child;n!==null;)Wg(t,n,a,o),n=n.sibling}function Wg(t,n,a,o){var u=n.flags;switch(n.tag){case 0:case 11:case 15:Ni(t,n,a,o),u&2048&&Co(9,n);break;case 1:Ni(t,n,a,o);break;case 3:Ni(t,n,a,o),u&2048&&(t=null,n.alternate!==null&&(t=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==t&&(n.refCount++,t!=null&&mo(t)));break;case 12:if(u&2048){Ni(t,n,a,o),t=n.stateNode;try{var f=n.memoizedProps,v=f.id,w=f.onPostCommit;typeof w=="function"&&w(v,n.alternate===null?"mount":"update",t.passiveEffectDuration,-0)}catch(V){kt(n,n.return,V)}}else Ni(t,n,a,o);break;case 31:Ni(t,n,a,o);break;case 13:Ni(t,n,a,o);break;case 23:break;case 22:f=n.stateNode,v=n.alternate,n.memoizedState!==null?f._visibility&2?Ni(t,n,a,o):Do(t,n):f._visibility&2?Ni(t,n,a,o):(f._visibility|=2,hr(t,n,a,o,(n.subtreeFlags&10256)!==0||!1)),u&2048&&Gf(v,n);break;case 24:Ni(t,n,a,o),u&2048&&Vf(n.alternate,n);break;default:Ni(t,n,a,o)}}function hr(t,n,a,o,u){for(u=u&&((n.subtreeFlags&10256)!==0||!1),n=n.child;n!==null;){var f=t,v=n,w=a,V=o,se=v.flags;switch(v.tag){case 0:case 11:case 15:hr(f,v,w,V,u),Co(8,v);break;case 23:break;case 22:var ge=v.stateNode;v.memoizedState!==null?ge._visibility&2?hr(f,v,w,V,u):Do(f,v):(ge._visibility|=2,hr(f,v,w,V,u)),u&&se&2048&&Gf(v.alternate,v);break;case 24:hr(f,v,w,V,u),u&&se&2048&&Vf(v.alternate,v);break;default:hr(f,v,w,V,u)}n=n.sibling}}function Do(t,n){if(n.subtreeFlags&10256)for(n=n.child;n!==null;){var a=t,o=n,u=o.flags;switch(o.tag){case 22:Do(a,o),u&2048&&Gf(o.alternate,o);break;case 24:Do(a,o),u&2048&&Vf(o.alternate,o);break;default:Do(a,o)}n=n.sibling}}var No=8192;function pr(t,n,a){if(t.subtreeFlags&No)for(t=t.child;t!==null;)qg(t,n,a),t=t.sibling}function qg(t,n,a){switch(t.tag){case 26:pr(t,n,a),t.flags&No&&t.memoizedState!==null&&dy(a,Di,t.memoizedState,t.memoizedProps);break;case 5:pr(t,n,a);break;case 3:case 4:var o=Di;Di=cc(t.stateNode.containerInfo),pr(t,n,a),Di=o;break;case 22:t.memoizedState===null&&(o=t.alternate,o!==null&&o.memoizedState!==null?(o=No,No=16777216,pr(t,n,a),No=o):pr(t,n,a));break;default:pr(t,n,a)}}function Yg(t){var n=t.alternate;if(n!==null&&(t=n.child,t!==null)){n.child=null;do n=t.sibling,t.sibling=null,t=n;while(t!==null)}}function Uo(t){var n=t.deletions;if((t.flags&16)!==0){if(n!==null)for(var a=0;a<n.length;a++){var o=n[a];Tn=o,Kg(o,t)}Yg(t)}if(t.subtreeFlags&10256)for(t=t.child;t!==null;)Zg(t),t=t.sibling}function Zg(t){switch(t.tag){case 0:case 11:case 15:Uo(t),t.flags&2048&&ka(9,t,t.return);break;case 3:Uo(t);break;case 12:Uo(t);break;case 22:var n=t.stateNode;t.memoizedState!==null&&n._visibility&2&&(t.return===null||t.return.tag!==13)?(n._visibility&=-3,Kl(t)):Uo(t);break;default:Uo(t)}}function Kl(t){var n=t.deletions;if((t.flags&16)!==0){if(n!==null)for(var a=0;a<n.length;a++){var o=n[a];Tn=o,Kg(o,t)}Yg(t)}for(t=t.child;t!==null;){switch(n=t,n.tag){case 0:case 11:case 15:ka(8,n,n.return),Kl(n);break;case 22:a=n.stateNode,a._visibility&2&&(a._visibility&=-3,Kl(n));break;default:Kl(n)}t=t.sibling}}function Kg(t,n){for(;Tn!==null;){var a=Tn;switch(a.tag){case 0:case 11:case 15:ka(8,a,n);break;case 23:case 22:if(a.memoizedState!==null&&a.memoizedState.cachePool!==null){var o=a.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:mo(a.memoizedState.cache)}if(o=a.child,o!==null)o.return=a,Tn=o;else e:for(a=t;Tn!==null;){o=Tn;var u=o.sibling,f=o.return;if(Hg(o),o===a){Tn=null;break e}if(u!==null){u.return=f,Tn=u;break e}Tn=f}}}var RS={getCacheForType:function(t){var n=Nn(mn),a=n.data.get(t);return a===void 0&&(a=t(),n.data.set(t,a)),a},cacheSignal:function(){return Nn(mn).controller.signal}},CS=typeof WeakMap=="function"?WeakMap:Map,Ft=0,Qt=null,Mt=null,At=0,Vt=0,ci=null,ja=!1,mr=!1,kf=!1,ha=0,ln=0,Xa=0,Ls=0,jf=0,ui=0,gr=0,Lo=null,Jn=null,Xf=!1,Ql=0,Qg=0,Jl=1/0,$l=null,Wa=null,yn=0,qa=null,_r=null,pa=0,Wf=0,qf=null,Jg=null,Oo=0,Yf=null;function fi(){return(Ft&2)!==0&&At!==0?At&-At:D.T!==null?ed():$r()}function $g(){if(ui===0)if((At&536870912)===0||Ct){var t=_t;_t<<=1,(_t&3932160)===0&&(_t=262144),ui=t}else ui=536870912;return t=oi.current,t!==null&&(t.flags|=32),ui}function $n(t,n,a){(t===Qt&&(Vt===2||Vt===9)||t.cancelPendingCommit!==null)&&(xr(t,0),Ya(t,At,ui,!1)),it(t,a),((Ft&2)===0||t!==Qt)&&(t===Qt&&((Ft&2)===0&&(Ls|=a),ln===4&&Ya(t,At,ui,!1)),Gi(t))}function e0(t,n,a){if((Ft&6)!==0)throw Error(s(327));var o=!a&&(n&127)===0&&(n&t.expiredLanes)===0||He(t,n),u=o?NS(t,n):Kf(t,n,!0),f=o;do{if(u===0){mr&&!o&&Ya(t,n,0,!1);break}else{if(a=t.current.alternate,f&&!wS(a)){u=Kf(t,n,!1),f=!1;continue}if(u===2){if(f=n,t.errorRecoveryDisabledLanes&f)var v=0;else v=t.pendingLanes&-536870913,v=v!==0?v:v&536870912?536870912:0;if(v!==0){n=v;e:{var w=t;u=Lo;var V=w.current.memoizedState.isDehydrated;if(V&&(xr(w,v).flags|=256),v=Kf(w,v,!1),v!==2){if(kf&&!V){w.errorRecoveryDisabledLanes|=f,Ls|=f,u=4;break e}f=Jn,Jn=u,f!==null&&(Jn===null?Jn=f:Jn.push.apply(Jn,f))}u=v}if(f=!1,u!==2)continue}}if(u===1){xr(t,0),Ya(t,n,0,!0);break}e:{switch(o=t,f=u,f){case 0:case 1:throw Error(s(345));case 4:if((n&4194048)!==n)break;case 6:Ya(o,n,ui,!ja);break e;case 2:Jn=null;break;case 3:case 5:break;default:throw Error(s(329))}if((n&62914560)===n&&(u=Ql+300-we(),10<u)){if(Ya(o,n,ui,!ja),me(o,0,!0)!==0)break e;pa=n,o.timeoutHandle=N0(t0.bind(null,o,a,Jn,$l,Xf,n,ui,Ls,gr,ja,f,"Throttled",-0,0),u);break e}t0(o,a,Jn,$l,Xf,n,ui,Ls,gr,ja,f,null,-0,0)}}break}while(!0);Gi(t)}function t0(t,n,a,o,u,f,v,w,V,se,ge,be,ce,fe){if(t.timeoutHandle=-1,be=n.subtreeFlags,be&8192||(be&16785408)===16785408){be={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:$i},qg(n,f,be);var Ye=(f&62914560)===f?Ql-we():(f&4194048)===f?Qg-we():0;if(Ye=hy(be,Ye),Ye!==null){pa=f,t.cancelPendingCommit=Ye(c0.bind(null,t,n,f,a,o,u,v,w,V,ge,be,null,ce,fe)),Ya(t,f,v,!se);return}}c0(t,n,f,a,o,u,v,w,V)}function wS(t){for(var n=t;;){var a=n.tag;if((a===0||a===11||a===15)&&n.flags&16384&&(a=n.updateQueue,a!==null&&(a=a.stores,a!==null)))for(var o=0;o<a.length;o++){var u=a[o],f=u.getSnapshot;u=u.value;try{if(!si(f(),u))return!1}catch{return!1}}if(a=n.child,n.subtreeFlags&16384&&a!==null)a.return=n,n=a;else{if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return!0;n=n.return}n.sibling.return=n.return,n=n.sibling}}return!0}function Ya(t,n,a,o){n&=~jf,n&=~Ls,t.suspendedLanes|=n,t.pingedLanes&=~n,o&&(t.warmLanes|=n),o=t.expirationTimes;for(var u=n;0<u;){var f=31-ze(u),v=1<<f;o[f]=-1,u&=~v}a!==0&&Dt(t,a,n)}function ec(){return(Ft&6)===0?(Po(0),!1):!0}function Zf(){if(Mt!==null){if(Vt===0)var t=Mt.return;else t=Mt,ia=Es=null,ff(t),lr=null,_o=0,t=Mt;for(;t!==null;)Ug(t.alternate,t),t=t.return;Mt=null}}function xr(t,n){var a=t.timeoutHandle;a!==-1&&(t.timeoutHandle=-1,ZS(a)),a=t.cancelPendingCommit,a!==null&&(t.cancelPendingCommit=null,a()),pa=0,Zf(),Qt=t,Mt=a=ta(t.current,null),At=n,Vt=0,ci=null,ja=!1,mr=He(t,n),kf=!1,gr=ui=jf=Ls=Xa=ln=0,Jn=Lo=null,Xf=!1,(n&8)!==0&&(n|=n&32);var o=t.entangledLanes;if(o!==0)for(t=t.entanglements,o&=n;0<o;){var u=31-ze(o),f=1<<u;n|=t[u],o&=~f}return ha=n,yl(),a}function n0(t,n){mt=null,D.H=To,n===or||n===wl?(n=xm(),Vt=3):n===Ju?(n=xm(),Vt=4):Vt=n===Rf?8:n!==null&&typeof n=="object"&&typeof n.then=="function"?6:1,ci=n,Mt===null&&(ln=1,kl(t,xi(n,t.current)))}function i0(){var t=oi.current;return t===null?!0:(At&4194048)===At?bi===null:(At&62914560)===At||(At&536870912)!==0?t===bi:!1}function a0(){var t=D.H;return D.H=To,t===null?To:t}function s0(){var t=D.A;return D.A=RS,t}function tc(){ln=4,ja||(At&4194048)!==At&&oi.current!==null||(mr=!0),(Xa&134217727)===0&&(Ls&134217727)===0||Qt===null||Ya(Qt,At,ui,!1)}function Kf(t,n,a){var o=Ft;Ft|=2;var u=a0(),f=s0();(Qt!==t||At!==n)&&($l=null,xr(t,n)),n=!1;var v=ln;e:do try{if(Vt!==0&&Mt!==null){var w=Mt,V=ci;switch(Vt){case 8:Zf(),v=6;break e;case 3:case 2:case 9:case 6:oi.current===null&&(n=!0);var se=Vt;if(Vt=0,ci=null,vr(t,w,V,se),a&&mr){v=0;break e}break;default:se=Vt,Vt=0,ci=null,vr(t,w,V,se)}}DS(),v=ln;break}catch(ge){n0(t,ge)}while(!0);return n&&t.shellSuspendCounter++,ia=Es=null,Ft=o,D.H=u,D.A=f,Mt===null&&(Qt=null,At=0,yl()),v}function DS(){for(;Mt!==null;)r0(Mt)}function NS(t,n){var a=Ft;Ft|=2;var o=a0(),u=s0();Qt!==t||At!==n?($l=null,Jl=we()+500,xr(t,n)):mr=He(t,n);e:do try{if(Vt!==0&&Mt!==null){n=Mt;var f=ci;t:switch(Vt){case 1:Vt=0,ci=null,vr(t,n,f,1);break;case 2:case 9:if(gm(f)){Vt=0,ci=null,o0(n);break}n=function(){Vt!==2&&Vt!==9||Qt!==t||(Vt=7),Gi(t)},f.then(n,n);break e;case 3:Vt=7;break e;case 4:Vt=5;break e;case 7:gm(f)?(Vt=0,ci=null,o0(n)):(Vt=0,ci=null,vr(t,n,f,7));break;case 5:var v=null;switch(Mt.tag){case 26:v=Mt.memoizedState;case 5:case 27:var w=Mt;if(v?W0(v):w.stateNode.complete){Vt=0,ci=null;var V=w.sibling;if(V!==null)Mt=V;else{var se=w.return;se!==null?(Mt=se,nc(se)):Mt=null}break t}}Vt=0,ci=null,vr(t,n,f,5);break;case 6:Vt=0,ci=null,vr(t,n,f,6);break;case 8:Zf(),ln=6;break e;default:throw Error(s(462))}}US();break}catch(ge){n0(t,ge)}while(!0);return ia=Es=null,D.H=o,D.A=u,Ft=a,Mt!==null?0:(Qt=null,At=0,yl(),ln)}function US(){for(;Mt!==null&&!lt();)r0(Mt)}function r0(t){var n=Dg(t.alternate,t,ha);t.memoizedProps=t.pendingProps,n===null?nc(t):Mt=n}function o0(t){var n=t,a=n.alternate;switch(n.tag){case 15:case 0:n=Eg(a,n,n.pendingProps,n.type,void 0,At);break;case 11:n=Eg(a,n,n.pendingProps,n.type.render,n.ref,At);break;case 5:ff(n);default:Ug(a,n),n=Mt=sm(n,ha),n=Dg(a,n,ha)}t.memoizedProps=t.pendingProps,n===null?nc(t):Mt=n}function vr(t,n,a,o){ia=Es=null,ff(n),lr=null,_o=0;var u=n.return;try{if(SS(t,u,n,a,At)){ln=1,kl(t,xi(a,t.current)),Mt=null;return}}catch(f){if(u!==null)throw Mt=u,f;ln=1,kl(t,xi(a,t.current)),Mt=null;return}n.flags&32768?(Ct||o===1?t=!0:mr||(At&536870912)!==0?t=!1:(ja=t=!0,(o===2||o===9||o===3||o===6)&&(o=oi.current,o!==null&&o.tag===13&&(o.flags|=16384))),l0(n,t)):nc(n)}function nc(t){var n=t;do{if((n.flags&32768)!==0){l0(n,ja);return}t=n.return;var a=MS(n.alternate,n,ha);if(a!==null){Mt=a;return}if(n=n.sibling,n!==null){Mt=n;return}Mt=n=t}while(n!==null);ln===0&&(ln=5)}function l0(t,n){do{var a=ES(t.alternate,t);if(a!==null){a.flags&=32767,Mt=a;return}if(a=t.return,a!==null&&(a.flags|=32768,a.subtreeFlags=0,a.deletions=null),!n&&(t=t.sibling,t!==null)){Mt=t;return}Mt=t=a}while(t!==null);ln=6,Mt=null}function c0(t,n,a,o,u,f,v,w,V){t.cancelPendingCommit=null;do ic();while(yn!==0);if((Ft&6)!==0)throw Error(s(327));if(n!==null){if(n===t.current)throw Error(s(177));if(f=n.lanes|n.childLanes,f|=Fu,Jt(t,a,f,v,w,V),t===Qt&&(Mt=Qt=null,At=0),_r=n,qa=t,pa=a,Wf=f,qf=u,Jg=o,(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?(t.callbackNode=null,t.callbackPriority=0,zS($,function(){return p0(),null})):(t.callbackNode=null,t.callbackPriority=0),o=(n.flags&13878)!==0,(n.subtreeFlags&13878)!==0||o){o=D.T,D.T=null,u=P.p,P.p=2,v=Ft,Ft|=4;try{TS(t,n,a)}finally{Ft=v,P.p=u,D.T=o}}yn=1,u0(),f0(),d0()}}function u0(){if(yn===1){yn=0;var t=qa,n=_r,a=(n.flags&13878)!==0;if((n.subtreeFlags&13878)!==0||a){a=D.T,D.T=null;var o=P.p;P.p=2;var u=Ft;Ft|=4;try{jg(n,t);var f=ld,v=Kp(t.containerInfo),w=f.focusedElem,V=f.selectionRange;if(v!==w&&w&&w.ownerDocument&&Zp(w.ownerDocument.documentElement,w)){if(V!==null&&Uu(w)){var se=V.start,ge=V.end;if(ge===void 0&&(ge=se),"selectionStart"in w)w.selectionStart=se,w.selectionEnd=Math.min(ge,w.value.length);else{var be=w.ownerDocument||document,ce=be&&be.defaultView||window;if(ce.getSelection){var fe=ce.getSelection(),Ye=w.textContent.length,at=Math.min(V.start,Ye),Yt=V.end===void 0?at:Math.min(V.end,Ye);!fe.extend&&at>Yt&&(v=Yt,Yt=at,at=v);var J=Yp(w,at),W=Yp(w,Yt);if(J&&W&&(fe.rangeCount!==1||fe.anchorNode!==J.node||fe.anchorOffset!==J.offset||fe.focusNode!==W.node||fe.focusOffset!==W.offset)){var ie=be.createRange();ie.setStart(J.node,J.offset),fe.removeAllRanges(),at>Yt?(fe.addRange(ie),fe.extend(W.node,W.offset)):(ie.setEnd(W.node,W.offset),fe.addRange(ie))}}}}for(be=[],fe=w;fe=fe.parentNode;)fe.nodeType===1&&be.push({element:fe,left:fe.scrollLeft,top:fe.scrollTop});for(typeof w.focus=="function"&&w.focus(),w=0;w<be.length;w++){var Se=be[w];Se.element.scrollLeft=Se.left,Se.element.scrollTop=Se.top}}mc=!!od,ld=od=null}finally{Ft=u,P.p=o,D.T=a}}t.current=n,yn=2}}function f0(){if(yn===2){yn=0;var t=qa,n=_r,a=(n.flags&8772)!==0;if((n.subtreeFlags&8772)!==0||a){a=D.T,D.T=null;var o=P.p;P.p=2;var u=Ft;Ft|=4;try{Ig(t,n.alternate,n)}finally{Ft=u,P.p=o,D.T=a}}yn=3}}function d0(){if(yn===4||yn===3){yn=0,Nt();var t=qa,n=_r,a=pa,o=Jg;(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?yn=5:(yn=0,_r=qa=null,h0(t,t.pendingLanes));var u=t.pendingLanes;if(u===0&&(Wa=null),Jr(a),n=n.stateNode,de&&typeof de.onCommitFiberRoot=="function")try{de.onCommitFiberRoot(ne,n,void 0,(n.current.flags&128)===128)}catch{}if(o!==null){n=D.T,u=P.p,P.p=2,D.T=null;try{for(var f=t.onRecoverableError,v=0;v<o.length;v++){var w=o[v];f(w.value,{componentStack:w.stack})}}finally{D.T=n,P.p=u}}(pa&3)!==0&&ic(),Gi(t),u=t.pendingLanes,(a&261930)!==0&&(u&42)!==0?t===Yf?Oo++:(Oo=0,Yf=t):Oo=0,Po(0)}}function h0(t,n){(t.pooledCacheLanes&=n)===0&&(n=t.pooledCache,n!=null&&(t.pooledCache=null,mo(n)))}function ic(){return u0(),f0(),d0(),p0()}function p0(){if(yn!==5)return!1;var t=qa,n=Wf;Wf=0;var a=Jr(pa),o=D.T,u=P.p;try{P.p=32>a?32:a,D.T=null,a=qf,qf=null;var f=qa,v=pa;if(yn=0,_r=qa=null,pa=0,(Ft&6)!==0)throw Error(s(331));var w=Ft;if(Ft|=4,Zg(f.current),Wg(f,f.current,v,a),Ft=w,Po(0,!1),de&&typeof de.onPostCommitFiberRoot=="function")try{de.onPostCommitFiberRoot(ne,f)}catch{}return!0}finally{P.p=u,D.T=o,h0(t,n)}}function m0(t,n,a){n=xi(a,n),n=Af(t.stateNode,n,2),t=Ha(t,n,2),t!==null&&(it(t,2),Gi(t))}function kt(t,n,a){if(t.tag===3)m0(t,t,a);else for(;n!==null;){if(n.tag===3){m0(n,t,a);break}else if(n.tag===1){var o=n.stateNode;if(typeof n.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(Wa===null||!Wa.has(o))){t=xi(a,t),a=gg(2),o=Ha(n,a,2),o!==null&&(_g(a,o,n,t),it(o,2),Gi(o));break}}n=n.return}}function Qf(t,n,a){var o=t.pingCache;if(o===null){o=t.pingCache=new CS;var u=new Set;o.set(n,u)}else u=o.get(n),u===void 0&&(u=new Set,o.set(n,u));u.has(a)||(kf=!0,u.add(a),t=LS.bind(null,t,n,a),n.then(t,t))}function LS(t,n,a){var o=t.pingCache;o!==null&&o.delete(n),t.pingedLanes|=t.suspendedLanes&a,t.warmLanes&=~a,Qt===t&&(At&a)===a&&(ln===4||ln===3&&(At&62914560)===At&&300>we()-Ql?(Ft&2)===0&&xr(t,0):jf|=a,gr===At&&(gr=0)),Gi(t)}function g0(t,n){n===0&&(n=Ee()),t=ys(t,n),t!==null&&(it(t,n),Gi(t))}function OS(t){var n=t.memoizedState,a=0;n!==null&&(a=n.retryLane),g0(t,a)}function PS(t,n){var a=0;switch(t.tag){case 31:case 13:var o=t.stateNode,u=t.memoizedState;u!==null&&(a=u.retryLane);break;case 19:o=t.stateNode;break;case 22:o=t.stateNode._retryCache;break;default:throw Error(s(314))}o!==null&&o.delete(n),g0(t,a)}function zS(t,n){return j(t,n)}var ac=null,Sr=null,Jf=!1,sc=!1,$f=!1,Za=0;function Gi(t){t!==Sr&&t.next===null&&(Sr===null?ac=Sr=t:Sr=Sr.next=t),sc=!0,Jf||(Jf=!0,BS())}function Po(t,n){if(!$f&&sc){$f=!0;do for(var a=!1,o=ac;o!==null;){if(t!==0){var u=o.pendingLanes;if(u===0)var f=0;else{var v=o.suspendedLanes,w=o.pingedLanes;f=(1<<31-ze(42|t)+1)-1,f&=u&~(v&~w),f=f&201326741?f&201326741|1:f?f|2:0}f!==0&&(a=!0,S0(o,f))}else f=At,f=me(o,o===Qt?f:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(f&3)===0||He(o,f)||(a=!0,S0(o,f));o=o.next}while(a);$f=!1}}function FS(){_0()}function _0(){sc=Jf=!1;var t=0;Za!==0&&YS()&&(t=Za);for(var n=we(),a=null,o=ac;o!==null;){var u=o.next,f=x0(o,n);f===0?(o.next=null,a===null?ac=u:a.next=u,u===null&&(Sr=a)):(a=o,(t!==0||(f&3)!==0)&&(sc=!0)),o=u}yn!==0&&yn!==5||Po(t),Za!==0&&(Za=0)}function x0(t,n){for(var a=t.suspendedLanes,o=t.pingedLanes,u=t.expirationTimes,f=t.pendingLanes&-62914561;0<f;){var v=31-ze(f),w=1<<v,V=u[v];V===-1?((w&a)===0||(w&o)!==0)&&(u[v]=Le(w,n)):V<=n&&(t.expiredLanes|=w),f&=~w}if(n=Qt,a=At,a=me(t,t===n?a:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),o=t.callbackNode,a===0||t===n&&(Vt===2||Vt===9)||t.cancelPendingCommit!==null)return o!==null&&o!==null&&yt(o),t.callbackNode=null,t.callbackPriority=0;if((a&3)===0||He(t,a)){if(n=a&-a,n===t.callbackPriority)return n;switch(o!==null&&yt(o),Jr(a)){case 2:case 8:a=E;break;case 32:a=$;break;case 268435456:a=Te;break;default:a=$}return o=v0.bind(null,t),a=j(a,o),t.callbackPriority=n,t.callbackNode=a,n}return o!==null&&o!==null&&yt(o),t.callbackPriority=2,t.callbackNode=null,2}function v0(t,n){if(yn!==0&&yn!==5)return t.callbackNode=null,t.callbackPriority=0,null;var a=t.callbackNode;if(ic()&&t.callbackNode!==a)return null;var o=At;return o=me(t,t===Qt?o:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),o===0?null:(e0(t,o,n),x0(t,we()),t.callbackNode!=null&&t.callbackNode===a?v0.bind(null,t):null)}function S0(t,n){if(ic())return null;e0(t,n,!0)}function BS(){KS(function(){(Ft&6)!==0?j(U,FS):_0()})}function ed(){if(Za===0){var t=sr;t===0&&(t=ot,ot<<=1,(ot&261888)===0&&(ot=256)),Za=t}return Za}function y0(t){return t==null||typeof t=="symbol"||typeof t=="boolean"?null:typeof t=="function"?t:_s(""+t)}function b0(t,n){var a=n.ownerDocument.createElement("input");return a.name=n.name,a.value=n.value,t.id&&a.setAttribute("form",t.id),n.parentNode.insertBefore(a,n),t=new FormData(t),a.parentNode.removeChild(a),t}function IS(t,n,a,o,u){if(n==="submit"&&a&&a.stateNode===u){var f=y0((u[wn]||null).action),v=o.submitter;v&&(n=(n=v[wn]||null)?y0(n.formAction):v.getAttribute("formAction"),n!==null&&(f=n,v=null));var w=new _l("action","action",null,o,u);t.push({event:w,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(Za!==0){var V=v?b0(u,v):new FormData(u);Sf(a,{pending:!0,data:V,method:u.method,action:f},null,V)}}else typeof f=="function"&&(w.preventDefault(),V=v?b0(u,v):new FormData(u),Sf(a,{pending:!0,data:V,method:u.method,action:f},f,V))},currentTarget:u}]})}}for(var td=0;td<zu.length;td++){var nd=zu[td],HS=nd.toLowerCase(),GS=nd[0].toUpperCase()+nd.slice(1);wi(HS,"on"+GS)}wi($p,"onAnimationEnd"),wi(em,"onAnimationIteration"),wi(tm,"onAnimationStart"),wi("dblclick","onDoubleClick"),wi("focusin","onFocus"),wi("focusout","onBlur"),wi(iS,"onTransitionRun"),wi(aS,"onTransitionStart"),wi(sS,"onTransitionCancel"),wi(nm,"onTransitionEnd"),le("onMouseEnter",["mouseout","mouseover"]),le("onMouseLeave",["mouseout","mouseover"]),le("onPointerEnter",["pointerout","pointerover"]),le("onPointerLeave",["pointerout","pointerover"]),Y("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),Y("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),Y("onBeforeInput",["compositionend","keypress","textInput","paste"]),Y("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),Y("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),Y("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var zo="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),VS=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(zo));function M0(t,n){n=(n&4)!==0;for(var a=0;a<t.length;a++){var o=t[a],u=o.event;o=o.listeners;e:{var f=void 0;if(n)for(var v=o.length-1;0<=v;v--){var w=o[v],V=w.instance,se=w.currentTarget;if(w=w.listener,V!==f&&u.isPropagationStopped())break e;f=w,u.currentTarget=se;try{f(u)}catch(ge){Sl(ge)}u.currentTarget=null,f=V}else for(v=0;v<o.length;v++){if(w=o[v],V=w.instance,se=w.currentTarget,w=w.listener,V!==f&&u.isPropagationStopped())break e;f=w,u.currentTarget=se;try{f(u)}catch(ge){Sl(ge)}u.currentTarget=null,f=V}}}}function Et(t,n){var a=n[Ra];a===void 0&&(a=n[Ra]=new Set);var o=t+"__bubble";a.has(o)||(E0(n,t,2,!1),a.add(o))}function id(t,n,a){var o=0;n&&(o|=4),E0(a,t,o,n)}var rc="_reactListening"+Math.random().toString(36).slice(2);function ad(t){if(!t[rc]){t[rc]=!0,hl.forEach(function(a){a!=="selectionchange"&&(VS.has(a)||id(a,!1,t),id(a,!0,t))});var n=t.nodeType===9?t:t.ownerDocument;n===null||n[rc]||(n[rc]=!0,id("selectionchange",!1,n))}}function E0(t,n,a,o){switch($0(n)){case 2:var u=gy;break;case 8:u=_y;break;default:u=vd}a=u.bind(null,n,a,t),u=void 0,!Mu||n!=="touchstart"&&n!=="touchmove"&&n!=="wheel"||(u=!0),o?u!==void 0?t.addEventListener(n,a,{capture:!0,passive:u}):t.addEventListener(n,a,!0):u!==void 0?t.addEventListener(n,a,{passive:u}):t.addEventListener(n,a,!1)}function sd(t,n,a,o,u){var f=o;if((n&1)===0&&(n&2)===0&&o!==null)e:for(;;){if(o===null)return;var v=o.tag;if(v===3||v===4){var w=o.stateNode.containerInfo;if(w===u)break;if(v===4)for(v=o.return;v!==null;){var V=v.tag;if((V===3||V===4)&&v.stateNode.containerInfo===u)return;v=v.return}for(;w!==null;){if(v=wa(w),v===null)return;if(V=v.tag,V===5||V===6||V===26||V===27){o=f=v;continue e}w=w.parentNode}}o=o.return}wp(function(){var se=f,ge=yu(a),be=[];e:{var ce=im.get(t);if(ce!==void 0){var fe=_l,Ye=t;switch(t){case"keypress":if(ml(a)===0)break e;case"keydown":case"keyup":fe=Pv;break;case"focusin":Ye="focus",fe=Ru;break;case"focusout":Ye="blur",fe=Ru;break;case"beforeblur":case"afterblur":fe=Ru;break;case"click":if(a.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":fe=Up;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":fe=Mv;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":fe=Bv;break;case $p:case em:case tm:fe=Av;break;case nm:fe=Hv;break;case"scroll":case"scrollend":fe=yv;break;case"wheel":fe=Vv;break;case"copy":case"cut":case"paste":fe=Cv;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":fe=Op;break;case"toggle":case"beforetoggle":fe=jv}var at=(n&4)!==0,Yt=!at&&(t==="scroll"||t==="scrollend"),J=at?ce!==null?ce+"Capture":null:ce;at=[];for(var W=se,ie;W!==null;){var Se=W;if(ie=Se.stateNode,Se=Se.tag,Se!==5&&Se!==26&&Se!==27||ie===null||J===null||(Se=io(W,J),Se!=null&&at.push(Fo(W,Se,ie))),Yt)break;W=W.return}0<at.length&&(ce=new fe(ce,Ye,null,a,ge),be.push({event:ce,listeners:at}))}}if((n&7)===0){e:{if(ce=t==="mouseover"||t==="pointerover",fe=t==="mouseout"||t==="pointerout",ce&&a!==Su&&(Ye=a.relatedTarget||a.fromElement)&&(wa(Ye)||Ye[Ji]))break e;if((fe||ce)&&(ce=ge.window===ge?ge:(ce=ge.ownerDocument)?ce.defaultView||ce.parentWindow:window,fe?(Ye=a.relatedTarget||a.toElement,fe=se,Ye=Ye?wa(Ye):null,Ye!==null&&(Yt=c(Ye),at=Ye.tag,Ye!==Yt||at!==5&&at!==27&&at!==6)&&(Ye=null)):(fe=null,Ye=se),fe!==Ye)){if(at=Up,Se="onMouseLeave",J="onMouseEnter",W="mouse",(t==="pointerout"||t==="pointerover")&&(at=Op,Se="onPointerLeave",J="onPointerEnter",W="pointer"),Yt=fe==null?ce:gs(fe),ie=Ye==null?ce:gs(Ye),ce=new at(Se,W+"leave",fe,a,ge),ce.target=Yt,ce.relatedTarget=ie,Se=null,wa(ge)===se&&(at=new at(J,W+"enter",Ye,a,ge),at.target=ie,at.relatedTarget=Yt,Se=at),Yt=Se,fe&&Ye)t:{for(at=kS,J=fe,W=Ye,ie=0,Se=J;Se;Se=at(Se))ie++;Se=0;for(var et=W;et;et=at(et))Se++;for(;0<ie-Se;)J=at(J),ie--;for(;0<Se-ie;)W=at(W),Se--;for(;ie--;){if(J===W||W!==null&&J===W.alternate){at=J;break t}J=at(J),W=at(W)}at=null}else at=null;fe!==null&&T0(be,ce,fe,at,!1),Ye!==null&&Yt!==null&&T0(be,Yt,Ye,at,!0)}}e:{if(ce=se?gs(se):window,fe=ce.nodeName&&ce.nodeName.toLowerCase(),fe==="select"||fe==="input"&&ce.type==="file")var Pt=Vp;else if(Hp(ce))if(kp)Pt=eS;else{Pt=Jv;var Qe=Qv}else fe=ce.nodeName,!fe||fe.toLowerCase()!=="input"||ce.type!=="checkbox"&&ce.type!=="radio"?se&&Bt(se.elementType)&&(Pt=Vp):Pt=$v;if(Pt&&(Pt=Pt(t,se))){Gp(be,Pt,a,ge);break e}Qe&&Qe(t,ce,se),t==="focusout"&&se&&ce.type==="number"&&se.memoizedProps.value!=null&&bt(ce,"number",ce.value)}switch(Qe=se?gs(se):window,t){case"focusin":(Hp(Qe)||Qe.contentEditable==="true")&&(Qs=Qe,Lu=se,fo=null);break;case"focusout":fo=Lu=Qs=null;break;case"mousedown":Ou=!0;break;case"contextmenu":case"mouseup":case"dragend":Ou=!1,Qp(be,a,ge);break;case"selectionchange":if(nS)break;case"keydown":case"keyup":Qp(be,a,ge)}var xt;if(wu)e:{switch(t){case"compositionstart":var Rt="onCompositionStart";break e;case"compositionend":Rt="onCompositionEnd";break e;case"compositionupdate":Rt="onCompositionUpdate";break e}Rt=void 0}else Ks?Bp(t,a)&&(Rt="onCompositionEnd"):t==="keydown"&&a.keyCode===229&&(Rt="onCompositionStart");Rt&&(Pp&&a.locale!=="ko"&&(Ks||Rt!=="onCompositionStart"?Rt==="onCompositionEnd"&&Ks&&(xt=Dp()):(La=ge,Eu="value"in La?La.value:La.textContent,Ks=!0)),Qe=oc(se,Rt),0<Qe.length&&(Rt=new Lp(Rt,t,null,a,ge),be.push({event:Rt,listeners:Qe}),xt?Rt.data=xt:(xt=Ip(a),xt!==null&&(Rt.data=xt)))),(xt=Wv?qv(t,a):Yv(t,a))&&(Rt=oc(se,"onBeforeInput"),0<Rt.length&&(Qe=new Lp("onBeforeInput","beforeinput",null,a,ge),be.push({event:Qe,listeners:Rt}),Qe.data=xt)),IS(be,t,se,a,ge)}M0(be,n)})}function Fo(t,n,a){return{instance:t,listener:n,currentTarget:a}}function oc(t,n){for(var a=n+"Capture",o=[];t!==null;){var u=t,f=u.stateNode;if(u=u.tag,u!==5&&u!==26&&u!==27||f===null||(u=io(t,a),u!=null&&o.unshift(Fo(t,u,f)),u=io(t,n),u!=null&&o.push(Fo(t,u,f))),t.tag===3)return o;t=t.return}return[]}function kS(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5&&t.tag!==27);return t||null}function T0(t,n,a,o,u){for(var f=n._reactName,v=[];a!==null&&a!==o;){var w=a,V=w.alternate,se=w.stateNode;if(w=w.tag,V!==null&&V===o)break;w!==5&&w!==26&&w!==27||se===null||(V=se,u?(se=io(a,f),se!=null&&v.unshift(Fo(a,se,V))):u||(se=io(a,f),se!=null&&v.push(Fo(a,se,V)))),a=a.return}v.length!==0&&t.push({event:n,listeners:v})}var jS=/\r\n?/g,XS=/\u0000|\uFFFD/g;function A0(t){return(typeof t=="string"?t:""+t).replace(jS,`
`).replace(XS,"")}function R0(t,n){return n=A0(n),A0(t)===n}function qt(t,n,a,o,u,f){switch(a){case"children":typeof o=="string"?n==="body"||n==="textarea"&&o===""||ai(t,o):(typeof o=="number"||typeof o=="bigint")&&n!=="body"&&ai(t,""+o);break;case"className":qe(t,"class",o);break;case"tabIndex":qe(t,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":qe(t,a,o);break;case"style":Ci(t,o,f);break;case"data":if(n!=="object"){qe(t,"data",o);break}case"src":case"href":if(o===""&&(n!=="a"||a!=="href")){t.removeAttribute(a);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){t.removeAttribute(a);break}o=_s(""+o),t.setAttribute(a,o);break;case"action":case"formAction":if(typeof o=="function"){t.setAttribute(a,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof f=="function"&&(a==="formAction"?(n!=="input"&&qt(t,n,"name",u.name,u,null),qt(t,n,"formEncType",u.formEncType,u,null),qt(t,n,"formMethod",u.formMethod,u,null),qt(t,n,"formTarget",u.formTarget,u,null)):(qt(t,n,"encType",u.encType,u,null),qt(t,n,"method",u.method,u,null),qt(t,n,"target",u.target,u,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){t.removeAttribute(a);break}o=_s(""+o),t.setAttribute(a,o);break;case"onClick":o!=null&&(t.onclick=$i);break;case"onScroll":o!=null&&Et("scroll",t);break;case"onScrollEnd":o!=null&&Et("scrollend",t);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(s(61));if(a=o.__html,a!=null){if(u.children!=null)throw Error(s(60));t.innerHTML=a}}break;case"multiple":t.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":t.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){t.removeAttribute("xlink:href");break}a=_s(""+o),t.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",a);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?t.setAttribute(a,""+o):t.removeAttribute(a);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?t.setAttribute(a,""):t.removeAttribute(a);break;case"capture":case"download":o===!0?t.setAttribute(a,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?t.setAttribute(a,o):t.removeAttribute(a);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?t.setAttribute(a,o):t.removeAttribute(a);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?t.removeAttribute(a):t.setAttribute(a,o);break;case"popover":Et("beforetoggle",t),Et("toggle",t),Be(t,"popover",o);break;case"xlinkActuate":Xe(t,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":Xe(t,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":Xe(t,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":Xe(t,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":Xe(t,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":Xe(t,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":Xe(t,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":Xe(t,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":Xe(t,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":Be(t,"is",o);break;case"innerText":case"textContent":break;default:(!(2<a.length)||a[0]!=="o"&&a[0]!=="O"||a[1]!=="n"&&a[1]!=="N")&&(a=Fi.get(a)||a,Be(t,a,o))}}function rd(t,n,a,o,u,f){switch(a){case"style":Ci(t,o,f);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(s(61));if(a=o.__html,a!=null){if(u.children!=null)throw Error(s(60));t.innerHTML=a}}break;case"children":typeof o=="string"?ai(t,o):(typeof o=="number"||typeof o=="bigint")&&ai(t,""+o);break;case"onScroll":o!=null&&Et("scroll",t);break;case"onScrollEnd":o!=null&&Et("scrollend",t);break;case"onClick":o!=null&&(t.onclick=$i);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!C.hasOwnProperty(a))e:{if(a[0]==="o"&&a[1]==="n"&&(u=a.endsWith("Capture"),n=a.slice(2,u?a.length-7:void 0),f=t[wn]||null,f=f!=null?f[a]:null,typeof f=="function"&&t.removeEventListener(n,f,u),typeof o=="function")){typeof f!="function"&&f!==null&&(a in t?t[a]=null:t.hasAttribute(a)&&t.removeAttribute(a)),t.addEventListener(n,o,u);break e}a in t?t[a]=o:o===!0?t.setAttribute(a,""):Be(t,a,o)}}}function Ln(t,n,a){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Et("error",t),Et("load",t);var o=!1,u=!1,f;for(f in a)if(a.hasOwnProperty(f)){var v=a[f];if(v!=null)switch(f){case"src":o=!0;break;case"srcSet":u=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(s(137,n));default:qt(t,n,f,v,a,null)}}u&&qt(t,n,"srcSet",a.srcSet,a,null),o&&qt(t,n,"src",a.src,a,null);return;case"input":Et("invalid",t);var w=f=v=u=null,V=null,se=null;for(o in a)if(a.hasOwnProperty(o)){var ge=a[o];if(ge!=null)switch(o){case"name":u=ge;break;case"type":v=ge;break;case"checked":V=ge;break;case"defaultChecked":se=ge;break;case"value":f=ge;break;case"defaultValue":w=ge;break;case"children":case"dangerouslySetInnerHTML":if(ge!=null)throw Error(s(137,n));break;default:qt(t,n,o,ge,a,null)}}Fn(t,f,w,V,se,v,u,!1);return;case"select":Et("invalid",t),o=v=f=null;for(u in a)if(a.hasOwnProperty(u)&&(w=a[u],w!=null))switch(u){case"value":f=w;break;case"defaultValue":v=w;break;case"multiple":o=w;default:qt(t,n,u,w,a,null)}n=f,a=v,t.multiple=!!o,n!=null?Sn(t,!!o,n,!1):a!=null&&Sn(t,!!o,a,!0);return;case"textarea":Et("invalid",t),f=u=o=null;for(v in a)if(a.hasOwnProperty(v)&&(w=a[v],w!=null))switch(v){case"value":o=w;break;case"defaultValue":u=w;break;case"children":f=w;break;case"dangerouslySetInnerHTML":if(w!=null)throw Error(s(91));break;default:qt(t,n,v,w,a,null)}Ri(t,o,u,f);return;case"option":for(V in a)if(a.hasOwnProperty(V)&&(o=a[V],o!=null))switch(V){case"selected":t.selected=o&&typeof o!="function"&&typeof o!="symbol";break;default:qt(t,n,V,o,a,null)}return;case"dialog":Et("beforetoggle",t),Et("toggle",t),Et("cancel",t),Et("close",t);break;case"iframe":case"object":Et("load",t);break;case"video":case"audio":for(o=0;o<zo.length;o++)Et(zo[o],t);break;case"image":Et("error",t),Et("load",t);break;case"details":Et("toggle",t);break;case"embed":case"source":case"link":Et("error",t),Et("load",t);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(se in a)if(a.hasOwnProperty(se)&&(o=a[se],o!=null))switch(se){case"children":case"dangerouslySetInnerHTML":throw Error(s(137,n));default:qt(t,n,se,o,a,null)}return;default:if(Bt(n)){for(ge in a)a.hasOwnProperty(ge)&&(o=a[ge],o!==void 0&&rd(t,n,ge,o,a,void 0));return}}for(w in a)a.hasOwnProperty(w)&&(o=a[w],o!=null&&qt(t,n,w,o,a,null))}function WS(t,n,a,o){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var u=null,f=null,v=null,w=null,V=null,se=null,ge=null;for(fe in a){var be=a[fe];if(a.hasOwnProperty(fe)&&be!=null)switch(fe){case"checked":break;case"value":break;case"defaultValue":V=be;default:o.hasOwnProperty(fe)||qt(t,n,fe,null,o,be)}}for(var ce in o){var fe=o[ce];if(be=a[ce],o.hasOwnProperty(ce)&&(fe!=null||be!=null))switch(ce){case"type":f=fe;break;case"name":u=fe;break;case"checked":se=fe;break;case"defaultChecked":ge=fe;break;case"value":v=fe;break;case"defaultValue":w=fe;break;case"children":case"dangerouslySetInnerHTML":if(fe!=null)throw Error(s(137,n));break;default:fe!==be&&qt(t,n,ce,fe,o,be)}}ke(t,v,w,V,se,ge,f,u);return;case"select":fe=v=w=ce=null;for(f in a)if(V=a[f],a.hasOwnProperty(f)&&V!=null)switch(f){case"value":break;case"multiple":fe=V;default:o.hasOwnProperty(f)||qt(t,n,f,null,o,V)}for(u in o)if(f=o[u],V=a[u],o.hasOwnProperty(u)&&(f!=null||V!=null))switch(u){case"value":ce=f;break;case"defaultValue":w=f;break;case"multiple":v=f;default:f!==V&&qt(t,n,u,f,o,V)}n=w,a=v,o=fe,ce!=null?Sn(t,!!a,ce,!1):!!o!=!!a&&(n!=null?Sn(t,!!a,n,!0):Sn(t,!!a,a?[]:"",!1));return;case"textarea":fe=ce=null;for(w in a)if(u=a[w],a.hasOwnProperty(w)&&u!=null&&!o.hasOwnProperty(w))switch(w){case"value":break;case"children":break;default:qt(t,n,w,null,o,u)}for(v in o)if(u=o[v],f=a[v],o.hasOwnProperty(v)&&(u!=null||f!=null))switch(v){case"value":ce=u;break;case"defaultValue":fe=u;break;case"children":break;case"dangerouslySetInnerHTML":if(u!=null)throw Error(s(91));break;default:u!==f&&qt(t,n,v,u,o,f)}ii(t,ce,fe);return;case"option":for(var Ye in a)if(ce=a[Ye],a.hasOwnProperty(Ye)&&ce!=null&&!o.hasOwnProperty(Ye))switch(Ye){case"selected":t.selected=!1;break;default:qt(t,n,Ye,null,o,ce)}for(V in o)if(ce=o[V],fe=a[V],o.hasOwnProperty(V)&&ce!==fe&&(ce!=null||fe!=null))switch(V){case"selected":t.selected=ce&&typeof ce!="function"&&typeof ce!="symbol";break;default:qt(t,n,V,ce,o,fe)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var at in a)ce=a[at],a.hasOwnProperty(at)&&ce!=null&&!o.hasOwnProperty(at)&&qt(t,n,at,null,o,ce);for(se in o)if(ce=o[se],fe=a[se],o.hasOwnProperty(se)&&ce!==fe&&(ce!=null||fe!=null))switch(se){case"children":case"dangerouslySetInnerHTML":if(ce!=null)throw Error(s(137,n));break;default:qt(t,n,se,ce,o,fe)}return;default:if(Bt(n)){for(var Yt in a)ce=a[Yt],a.hasOwnProperty(Yt)&&ce!==void 0&&!o.hasOwnProperty(Yt)&&rd(t,n,Yt,void 0,o,ce);for(ge in o)ce=o[ge],fe=a[ge],!o.hasOwnProperty(ge)||ce===fe||ce===void 0&&fe===void 0||rd(t,n,ge,ce,o,fe);return}}for(var J in a)ce=a[J],a.hasOwnProperty(J)&&ce!=null&&!o.hasOwnProperty(J)&&qt(t,n,J,null,o,ce);for(be in o)ce=o[be],fe=a[be],!o.hasOwnProperty(be)||ce===fe||ce==null&&fe==null||qt(t,n,be,ce,o,fe)}function C0(t){switch(t){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function qS(){if(typeof performance.getEntriesByType=="function"){for(var t=0,n=0,a=performance.getEntriesByType("resource"),o=0;o<a.length;o++){var u=a[o],f=u.transferSize,v=u.initiatorType,w=u.duration;if(f&&w&&C0(v)){for(v=0,w=u.responseEnd,o+=1;o<a.length;o++){var V=a[o],se=V.startTime;if(se>w)break;var ge=V.transferSize,be=V.initiatorType;ge&&C0(be)&&(V=V.responseEnd,v+=ge*(V<w?1:(w-se)/(V-se)))}if(--o,n+=8*(f+v)/(u.duration/1e3),t++,10<t)break}}if(0<t)return n/t/1e6}return navigator.connection&&(t=navigator.connection.downlink,typeof t=="number")?t:5}var od=null,ld=null;function lc(t){return t.nodeType===9?t:t.ownerDocument}function w0(t){switch(t){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function D0(t,n){if(t===0)switch(n){case"svg":return 1;case"math":return 2;default:return 0}return t===1&&n==="foreignObject"?0:t}function cd(t,n){return t==="textarea"||t==="noscript"||typeof n.children=="string"||typeof n.children=="number"||typeof n.children=="bigint"||typeof n.dangerouslySetInnerHTML=="object"&&n.dangerouslySetInnerHTML!==null&&n.dangerouslySetInnerHTML.__html!=null}var ud=null;function YS(){var t=window.event;return t&&t.type==="popstate"?t===ud?!1:(ud=t,!0):(ud=null,!1)}var N0=typeof setTimeout=="function"?setTimeout:void 0,ZS=typeof clearTimeout=="function"?clearTimeout:void 0,U0=typeof Promise=="function"?Promise:void 0,KS=typeof queueMicrotask=="function"?queueMicrotask:typeof U0<"u"?function(t){return U0.resolve(null).then(t).catch(QS)}:N0;function QS(t){setTimeout(function(){throw t})}function Ka(t){return t==="head"}function L0(t,n){var a=n,o=0;do{var u=a.nextSibling;if(t.removeChild(a),u&&u.nodeType===8)if(a=u.data,a==="/$"||a==="/&"){if(o===0){t.removeChild(u),Er(n);return}o--}else if(a==="$"||a==="$?"||a==="$~"||a==="$!"||a==="&")o++;else if(a==="html")Bo(t.ownerDocument.documentElement);else if(a==="head"){a=t.ownerDocument.head,Bo(a);for(var f=a.firstChild;f;){var v=f.nextSibling,w=f.nodeName;f[Ca]||w==="SCRIPT"||w==="STYLE"||w==="LINK"&&f.rel.toLowerCase()==="stylesheet"||a.removeChild(f),f=v}}else a==="body"&&Bo(t.ownerDocument.body);a=u}while(a);Er(n)}function O0(t,n){var a=t;t=0;do{var o=a.nextSibling;if(a.nodeType===1?n?(a._stashedDisplay=a.style.display,a.style.display="none"):(a.style.display=a._stashedDisplay||"",a.getAttribute("style")===""&&a.removeAttribute("style")):a.nodeType===3&&(n?(a._stashedText=a.nodeValue,a.nodeValue=""):a.nodeValue=a._stashedText||""),o&&o.nodeType===8)if(a=o.data,a==="/$"){if(t===0)break;t--}else a!=="$"&&a!=="$?"&&a!=="$~"&&a!=="$!"||t++;a=o}while(a)}function fd(t){var n=t.firstChild;for(n&&n.nodeType===10&&(n=n.nextSibling);n;){var a=n;switch(n=n.nextSibling,a.nodeName){case"HTML":case"HEAD":case"BODY":fd(a),no(a);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(a.rel.toLowerCase()==="stylesheet")continue}t.removeChild(a)}}function JS(t,n,a,o){for(;t.nodeType===1;){var u=a;if(t.nodeName.toLowerCase()!==n.toLowerCase()){if(!o&&(t.nodeName!=="INPUT"||t.type!=="hidden"))break}else if(o){if(!t[Ca])switch(n){case"meta":if(!t.hasAttribute("itemprop"))break;return t;case"link":if(f=t.getAttribute("rel"),f==="stylesheet"&&t.hasAttribute("data-precedence"))break;if(f!==u.rel||t.getAttribute("href")!==(u.href==null||u.href===""?null:u.href)||t.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin)||t.getAttribute("title")!==(u.title==null?null:u.title))break;return t;case"style":if(t.hasAttribute("data-precedence"))break;return t;case"script":if(f=t.getAttribute("src"),(f!==(u.src==null?null:u.src)||t.getAttribute("type")!==(u.type==null?null:u.type)||t.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin))&&f&&t.hasAttribute("async")&&!t.hasAttribute("itemprop"))break;return t;default:return t}}else if(n==="input"&&t.type==="hidden"){var f=u.name==null?null:""+u.name;if(u.type==="hidden"&&t.getAttribute("name")===f)return t}else return t;if(t=Mi(t.nextSibling),t===null)break}return null}function $S(t,n,a){if(n==="")return null;for(;t.nodeType!==3;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!a||(t=Mi(t.nextSibling),t===null))return null;return t}function P0(t,n){for(;t.nodeType!==8;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!n||(t=Mi(t.nextSibling),t===null))return null;return t}function dd(t){return t.data==="$?"||t.data==="$~"}function hd(t){return t.data==="$!"||t.data==="$?"&&t.ownerDocument.readyState!=="loading"}function ey(t,n){var a=t.ownerDocument;if(t.data==="$~")t._reactRetry=n;else if(t.data!=="$?"||a.readyState!=="loading")n();else{var o=function(){n(),a.removeEventListener("DOMContentLoaded",o)};a.addEventListener("DOMContentLoaded",o),t._reactRetry=o}}function Mi(t){for(;t!=null;t=t.nextSibling){var n=t.nodeType;if(n===1||n===3)break;if(n===8){if(n=t.data,n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"||n==="F!"||n==="F")break;if(n==="/$"||n==="/&")return null}}return t}var pd=null;function z0(t){t=t.nextSibling;for(var n=0;t;){if(t.nodeType===8){var a=t.data;if(a==="/$"||a==="/&"){if(n===0)return Mi(t.nextSibling);n--}else a!=="$"&&a!=="$!"&&a!=="$?"&&a!=="$~"&&a!=="&"||n++}t=t.nextSibling}return null}function F0(t){t=t.previousSibling;for(var n=0;t;){if(t.nodeType===8){var a=t.data;if(a==="$"||a==="$!"||a==="$?"||a==="$~"||a==="&"){if(n===0)return t;n--}else a!=="/$"&&a!=="/&"||n++}t=t.previousSibling}return null}function B0(t,n,a){switch(n=lc(a),t){case"html":if(t=n.documentElement,!t)throw Error(s(452));return t;case"head":if(t=n.head,!t)throw Error(s(453));return t;case"body":if(t=n.body,!t)throw Error(s(454));return t;default:throw Error(s(451))}}function Bo(t){for(var n=t.attributes;n.length;)t.removeAttributeNode(n[0]);no(t)}var Ei=new Map,I0=new Set;function cc(t){return typeof t.getRootNode=="function"?t.getRootNode():t.nodeType===9?t:t.ownerDocument}var ma=P.d;P.d={f:ty,r:ny,D:iy,C:ay,L:sy,m:ry,X:ly,S:oy,M:cy};function ty(){var t=ma.f(),n=ec();return t||n}function ny(t){var n=Da(t);n!==null&&n.tag===5&&n.type==="form"?ng(n):ma.r(t)}var yr=typeof document>"u"?null:document;function H0(t,n,a){var o=yr;if(o&&typeof n=="string"&&n){var u=Ht(n);u='link[rel="'+t+'"][href="'+u+'"]',typeof a=="string"&&(u+='[crossorigin="'+a+'"]'),I0.has(u)||(I0.add(u),t={rel:t,crossOrigin:a,href:n},o.querySelector(u)===null&&(n=o.createElement("link"),Ln(n,"link",t),pn(n),o.head.appendChild(n)))}}function iy(t){ma.D(t),H0("dns-prefetch",t,null)}function ay(t,n){ma.C(t,n),H0("preconnect",t,n)}function sy(t,n,a){ma.L(t,n,a);var o=yr;if(o&&t&&n){var u='link[rel="preload"][as="'+Ht(n)+'"]';n==="image"&&a&&a.imageSrcSet?(u+='[imagesrcset="'+Ht(a.imageSrcSet)+'"]',typeof a.imageSizes=="string"&&(u+='[imagesizes="'+Ht(a.imageSizes)+'"]')):u+='[href="'+Ht(t)+'"]';var f=u;switch(n){case"style":f=br(t);break;case"script":f=Mr(t)}Ei.has(f)||(t=x({rel:"preload",href:n==="image"&&a&&a.imageSrcSet?void 0:t,as:n},a),Ei.set(f,t),o.querySelector(u)!==null||n==="style"&&o.querySelector(Io(f))||n==="script"&&o.querySelector(Ho(f))||(n=o.createElement("link"),Ln(n,"link",t),pn(n),o.head.appendChild(n)))}}function ry(t,n){ma.m(t,n);var a=yr;if(a&&t){var o=n&&typeof n.as=="string"?n.as:"script",u='link[rel="modulepreload"][as="'+Ht(o)+'"][href="'+Ht(t)+'"]',f=u;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":f=Mr(t)}if(!Ei.has(f)&&(t=x({rel:"modulepreload",href:t},n),Ei.set(f,t),a.querySelector(u)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(a.querySelector(Ho(f)))return}o=a.createElement("link"),Ln(o,"link",t),pn(o),a.head.appendChild(o)}}}function oy(t,n,a){ma.S(t,n,a);var o=yr;if(o&&t){var u=Na(o).hoistableStyles,f=br(t);n=n||"default";var v=u.get(f);if(!v){var w={loading:0,preload:null};if(v=o.querySelector(Io(f)))w.loading=5;else{t=x({rel:"stylesheet",href:t,"data-precedence":n},a),(a=Ei.get(f))&&md(t,a);var V=v=o.createElement("link");pn(V),Ln(V,"link",t),V._p=new Promise(function(se,ge){V.onload=se,V.onerror=ge}),V.addEventListener("load",function(){w.loading|=1}),V.addEventListener("error",function(){w.loading|=2}),w.loading|=4,uc(v,n,o)}v={type:"stylesheet",instance:v,count:1,state:w},u.set(f,v)}}}function ly(t,n){ma.X(t,n);var a=yr;if(a&&t){var o=Na(a).hoistableScripts,u=Mr(t),f=o.get(u);f||(f=a.querySelector(Ho(u)),f||(t=x({src:t,async:!0},n),(n=Ei.get(u))&&gd(t,n),f=a.createElement("script"),pn(f),Ln(f,"link",t),a.head.appendChild(f)),f={type:"script",instance:f,count:1,state:null},o.set(u,f))}}function cy(t,n){ma.M(t,n);var a=yr;if(a&&t){var o=Na(a).hoistableScripts,u=Mr(t),f=o.get(u);f||(f=a.querySelector(Ho(u)),f||(t=x({src:t,async:!0,type:"module"},n),(n=Ei.get(u))&&gd(t,n),f=a.createElement("script"),pn(f),Ln(f,"link",t),a.head.appendChild(f)),f={type:"script",instance:f,count:1,state:null},o.set(u,f))}}function G0(t,n,a,o){var u=(u=ae.current)?cc(u):null;if(!u)throw Error(s(446));switch(t){case"meta":case"title":return null;case"style":return typeof a.precedence=="string"&&typeof a.href=="string"?(n=br(a.href),a=Na(u).hoistableStyles,o=a.get(n),o||(o={type:"style",instance:null,count:0,state:null},a.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(a.rel==="stylesheet"&&typeof a.href=="string"&&typeof a.precedence=="string"){t=br(a.href);var f=Na(u).hoistableStyles,v=f.get(t);if(v||(u=u.ownerDocument||u,v={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},f.set(t,v),(f=u.querySelector(Io(t)))&&!f._p&&(v.instance=f,v.state.loading=5),Ei.has(t)||(a={rel:"preload",as:"style",href:a.href,crossOrigin:a.crossOrigin,integrity:a.integrity,media:a.media,hrefLang:a.hrefLang,referrerPolicy:a.referrerPolicy},Ei.set(t,a),f||uy(u,t,a,v.state))),n&&o===null)throw Error(s(528,""));return v}if(n&&o!==null)throw Error(s(529,""));return null;case"script":return n=a.async,a=a.src,typeof a=="string"&&n&&typeof n!="function"&&typeof n!="symbol"?(n=Mr(a),a=Na(u).hoistableScripts,o=a.get(n),o||(o={type:"script",instance:null,count:0,state:null},a.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(s(444,t))}}function br(t){return'href="'+Ht(t)+'"'}function Io(t){return'link[rel="stylesheet"]['+t+"]"}function V0(t){return x({},t,{"data-precedence":t.precedence,precedence:null})}function uy(t,n,a,o){t.querySelector('link[rel="preload"][as="style"]['+n+"]")?o.loading=1:(n=t.createElement("link"),o.preload=n,n.addEventListener("load",function(){return o.loading|=1}),n.addEventListener("error",function(){return o.loading|=2}),Ln(n,"link",a),pn(n),t.head.appendChild(n))}function Mr(t){return'[src="'+Ht(t)+'"]'}function Ho(t){return"script[async]"+t}function k0(t,n,a){if(n.count++,n.instance===null)switch(n.type){case"style":var o=t.querySelector('style[data-href~="'+Ht(a.href)+'"]');if(o)return n.instance=o,pn(o),o;var u=x({},a,{"data-href":a.href,"data-precedence":a.precedence,href:null,precedence:null});return o=(t.ownerDocument||t).createElement("style"),pn(o),Ln(o,"style",u),uc(o,a.precedence,t),n.instance=o;case"stylesheet":u=br(a.href);var f=t.querySelector(Io(u));if(f)return n.state.loading|=4,n.instance=f,pn(f),f;o=V0(a),(u=Ei.get(u))&&md(o,u),f=(t.ownerDocument||t).createElement("link"),pn(f);var v=f;return v._p=new Promise(function(w,V){v.onload=w,v.onerror=V}),Ln(f,"link",o),n.state.loading|=4,uc(f,a.precedence,t),n.instance=f;case"script":return f=Mr(a.src),(u=t.querySelector(Ho(f)))?(n.instance=u,pn(u),u):(o=a,(u=Ei.get(f))&&(o=x({},a),gd(o,u)),t=t.ownerDocument||t,u=t.createElement("script"),pn(u),Ln(u,"link",o),t.head.appendChild(u),n.instance=u);case"void":return null;default:throw Error(s(443,n.type))}else n.type==="stylesheet"&&(n.state.loading&4)===0&&(o=n.instance,n.state.loading|=4,uc(o,a.precedence,t));return n.instance}function uc(t,n,a){for(var o=a.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),u=o.length?o[o.length-1]:null,f=u,v=0;v<o.length;v++){var w=o[v];if(w.dataset.precedence===n)f=w;else if(f!==u)break}f?f.parentNode.insertBefore(t,f.nextSibling):(n=a.nodeType===9?a.head:a,n.insertBefore(t,n.firstChild))}function md(t,n){t.crossOrigin==null&&(t.crossOrigin=n.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=n.referrerPolicy),t.title==null&&(t.title=n.title)}function gd(t,n){t.crossOrigin==null&&(t.crossOrigin=n.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=n.referrerPolicy),t.integrity==null&&(t.integrity=n.integrity)}var fc=null;function j0(t,n,a){if(fc===null){var o=new Map,u=fc=new Map;u.set(a,o)}else u=fc,o=u.get(a),o||(o=new Map,u.set(a,o));if(o.has(t))return o;for(o.set(t,null),a=a.getElementsByTagName(t),u=0;u<a.length;u++){var f=a[u];if(!(f[Ca]||f[un]||t==="link"&&f.getAttribute("rel")==="stylesheet")&&f.namespaceURI!=="http://www.w3.org/2000/svg"){var v=f.getAttribute(n)||"";v=t+v;var w=o.get(v);w?w.push(f):o.set(v,[f])}}return o}function X0(t,n,a){t=t.ownerDocument||t,t.head.insertBefore(a,n==="title"?t.querySelector("head > title"):null)}function fy(t,n,a){if(a===1||n.itemProp!=null)return!1;switch(t){case"meta":case"title":return!0;case"style":if(typeof n.precedence!="string"||typeof n.href!="string"||n.href==="")break;return!0;case"link":if(typeof n.rel!="string"||typeof n.href!="string"||n.href===""||n.onLoad||n.onError)break;switch(n.rel){case"stylesheet":return t=n.disabled,typeof n.precedence=="string"&&t==null;default:return!0}case"script":if(n.async&&typeof n.async!="function"&&typeof n.async!="symbol"&&!n.onLoad&&!n.onError&&n.src&&typeof n.src=="string")return!0}return!1}function W0(t){return!(t.type==="stylesheet"&&(t.state.loading&3)===0)}function dy(t,n,a,o){if(a.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(a.state.loading&4)===0){if(a.instance===null){var u=br(o.href),f=n.querySelector(Io(u));if(f){n=f._p,n!==null&&typeof n=="object"&&typeof n.then=="function"&&(t.count++,t=dc.bind(t),n.then(t,t)),a.state.loading|=4,a.instance=f,pn(f);return}f=n.ownerDocument||n,o=V0(o),(u=Ei.get(u))&&md(o,u),f=f.createElement("link"),pn(f);var v=f;v._p=new Promise(function(w,V){v.onload=w,v.onerror=V}),Ln(f,"link",o),a.instance=f}t.stylesheets===null&&(t.stylesheets=new Map),t.stylesheets.set(a,n),(n=a.state.preload)&&(a.state.loading&3)===0&&(t.count++,a=dc.bind(t),n.addEventListener("load",a),n.addEventListener("error",a))}}var _d=0;function hy(t,n){return t.stylesheets&&t.count===0&&pc(t,t.stylesheets),0<t.count||0<t.imgCount?function(a){var o=setTimeout(function(){if(t.stylesheets&&pc(t,t.stylesheets),t.unsuspend){var f=t.unsuspend;t.unsuspend=null,f()}},6e4+n);0<t.imgBytes&&_d===0&&(_d=62500*qS());var u=setTimeout(function(){if(t.waitingForImages=!1,t.count===0&&(t.stylesheets&&pc(t,t.stylesheets),t.unsuspend)){var f=t.unsuspend;t.unsuspend=null,f()}},(t.imgBytes>_d?50:800)+n);return t.unsuspend=a,function(){t.unsuspend=null,clearTimeout(o),clearTimeout(u)}}:null}function dc(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)pc(this,this.stylesheets);else if(this.unsuspend){var t=this.unsuspend;this.unsuspend=null,t()}}}var hc=null;function pc(t,n){t.stylesheets=null,t.unsuspend!==null&&(t.count++,hc=new Map,n.forEach(py,t),hc=null,dc.call(t))}function py(t,n){if(!(n.state.loading&4)){var a=hc.get(t);if(a)var o=a.get(null);else{a=new Map,hc.set(t,a);for(var u=t.querySelectorAll("link[data-precedence],style[data-precedence]"),f=0;f<u.length;f++){var v=u[f];(v.nodeName==="LINK"||v.getAttribute("media")!=="not all")&&(a.set(v.dataset.precedence,v),o=v)}o&&a.set(null,o)}u=n.instance,v=u.getAttribute("data-precedence"),f=a.get(v)||o,f===o&&a.set(null,u),a.set(v,u),this.count++,o=dc.bind(this),u.addEventListener("load",o),u.addEventListener("error",o),f?f.parentNode.insertBefore(u,f.nextSibling):(t=t.nodeType===9?t.head:t,t.insertBefore(u,t.firstChild)),n.state.loading|=4}}var Go={$$typeof:O,Provider:null,Consumer:null,_currentValue:q,_currentValue2:q,_threadCount:0};function my(t,n,a,o,u,f,v,w,V){this.tag=1,this.containerInfo=t,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=We(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=We(0),this.hiddenUpdates=We(null),this.identifierPrefix=o,this.onUncaughtError=u,this.onCaughtError=f,this.onRecoverableError=v,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=V,this.incompleteTransitions=new Map}function q0(t,n,a,o,u,f,v,w,V,se,ge,be){return t=new my(t,n,a,v,V,se,ge,be,w),n=1,f===!0&&(n|=24),f=ri(3,null,null,n),t.current=f,f.stateNode=t,n=Zu(),n.refCount++,t.pooledCache=n,n.refCount++,f.memoizedState={element:o,isDehydrated:a,cache:n},$u(f),t}function Y0(t){return t?(t=er,t):er}function Z0(t,n,a,o,u,f){u=Y0(u),o.context===null?o.context=u:o.pendingContext=u,o=Ia(n),o.payload={element:a},f=f===void 0?null:f,f!==null&&(o.callback=f),a=Ha(t,o,n),a!==null&&($n(a,t,n),vo(a,t,n))}function K0(t,n){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var a=t.retryLane;t.retryLane=a!==0&&a<n?a:n}}function xd(t,n){K0(t,n),(t=t.alternate)&&K0(t,n)}function Q0(t){if(t.tag===13||t.tag===31){var n=ys(t,67108864);n!==null&&$n(n,t,67108864),xd(t,67108864)}}function J0(t){if(t.tag===13||t.tag===31){var n=fi();n=ms(n);var a=ys(t,n);a!==null&&$n(a,t,n),xd(t,n)}}var mc=!0;function gy(t,n,a,o){var u=D.T;D.T=null;var f=P.p;try{P.p=2,vd(t,n,a,o)}finally{P.p=f,D.T=u}}function _y(t,n,a,o){var u=D.T;D.T=null;var f=P.p;try{P.p=8,vd(t,n,a,o)}finally{P.p=f,D.T=u}}function vd(t,n,a,o){if(mc){var u=Sd(o);if(u===null)sd(t,n,o,gc,a),e_(t,o);else if(vy(u,t,n,a,o))o.stopPropagation();else if(e_(t,o),n&4&&-1<xy.indexOf(t)){for(;u!==null;){var f=Da(u);if(f!==null)switch(f.tag){case 3:if(f=f.stateNode,f.current.memoizedState.isDehydrated){var v=Re(f.pendingLanes);if(v!==0){var w=f;for(w.pendingLanes|=2,w.entangledLanes|=2;v;){var V=1<<31-ze(v);w.entanglements[1]|=V,v&=~V}Gi(f),(Ft&6)===0&&(Jl=we()+500,Po(0))}}break;case 31:case 13:w=ys(f,2),w!==null&&$n(w,f,2),ec(),xd(f,2)}if(f=Sd(o),f===null&&sd(t,n,o,gc,a),f===u)break;u=f}u!==null&&o.stopPropagation()}else sd(t,n,o,null,a)}}function Sd(t){return t=yu(t),yd(t)}var gc=null;function yd(t){if(gc=null,t=wa(t),t!==null){var n=c(t);if(n===null)t=null;else{var a=n.tag;if(a===13){if(t=d(n),t!==null)return t;t=null}else if(a===31){if(t=p(n),t!==null)return t;t=null}else if(a===3){if(n.stateNode.current.memoizedState.isDehydrated)return n.tag===3?n.stateNode.containerInfo:null;t=null}else n!==t&&(t=null)}}return gc=t,null}function $0(t){switch(t){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Xt()){case U:return 2;case E:return 8;case $:case xe:return 32;case Te:return 268435456;default:return 32}default:return 32}}var bd=!1,Qa=null,Ja=null,$a=null,Vo=new Map,ko=new Map,es=[],xy="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function e_(t,n){switch(t){case"focusin":case"focusout":Qa=null;break;case"dragenter":case"dragleave":Ja=null;break;case"mouseover":case"mouseout":$a=null;break;case"pointerover":case"pointerout":Vo.delete(n.pointerId);break;case"gotpointercapture":case"lostpointercapture":ko.delete(n.pointerId)}}function jo(t,n,a,o,u,f){return t===null||t.nativeEvent!==f?(t={blockedOn:n,domEventName:a,eventSystemFlags:o,nativeEvent:f,targetContainers:[u]},n!==null&&(n=Da(n),n!==null&&Q0(n)),t):(t.eventSystemFlags|=o,n=t.targetContainers,u!==null&&n.indexOf(u)===-1&&n.push(u),t)}function vy(t,n,a,o,u){switch(n){case"focusin":return Qa=jo(Qa,t,n,a,o,u),!0;case"dragenter":return Ja=jo(Ja,t,n,a,o,u),!0;case"mouseover":return $a=jo($a,t,n,a,o,u),!0;case"pointerover":var f=u.pointerId;return Vo.set(f,jo(Vo.get(f)||null,t,n,a,o,u)),!0;case"gotpointercapture":return f=u.pointerId,ko.set(f,jo(ko.get(f)||null,t,n,a,o,u)),!0}return!1}function t_(t){var n=wa(t.target);if(n!==null){var a=c(n);if(a!==null){if(n=a.tag,n===13){if(n=d(a),n!==null){t.blockedOn=n,eo(t.priority,function(){J0(a)});return}}else if(n===31){if(n=p(a),n!==null){t.blockedOn=n,eo(t.priority,function(){J0(a)});return}}else if(n===3&&a.stateNode.current.memoizedState.isDehydrated){t.blockedOn=a.tag===3?a.stateNode.containerInfo:null;return}}}t.blockedOn=null}function _c(t){if(t.blockedOn!==null)return!1;for(var n=t.targetContainers;0<n.length;){var a=Sd(t.nativeEvent);if(a===null){a=t.nativeEvent;var o=new a.constructor(a.type,a);Su=o,a.target.dispatchEvent(o),Su=null}else return n=Da(a),n!==null&&Q0(n),t.blockedOn=a,!1;n.shift()}return!0}function n_(t,n,a){_c(t)&&a.delete(n)}function Sy(){bd=!1,Qa!==null&&_c(Qa)&&(Qa=null),Ja!==null&&_c(Ja)&&(Ja=null),$a!==null&&_c($a)&&($a=null),Vo.forEach(n_),ko.forEach(n_)}function xc(t,n){t.blockedOn===n&&(t.blockedOn=null,bd||(bd=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,Sy)))}var vc=null;function i_(t){vc!==t&&(vc=t,r.unstable_scheduleCallback(r.unstable_NormalPriority,function(){vc===t&&(vc=null);for(var n=0;n<t.length;n+=3){var a=t[n],o=t[n+1],u=t[n+2];if(typeof o!="function"){if(yd(o||a)===null)continue;break}var f=Da(a);f!==null&&(t.splice(n,3),n-=3,Sf(f,{pending:!0,data:u,method:a.method,action:o},o,u))}}))}function Er(t){function n(V){return xc(V,t)}Qa!==null&&xc(Qa,t),Ja!==null&&xc(Ja,t),$a!==null&&xc($a,t),Vo.forEach(n),ko.forEach(n);for(var a=0;a<es.length;a++){var o=es[a];o.blockedOn===t&&(o.blockedOn=null)}for(;0<es.length&&(a=es[0],a.blockedOn===null);)t_(a),a.blockedOn===null&&es.shift();if(a=(t.ownerDocument||t).$$reactFormReplay,a!=null)for(o=0;o<a.length;o+=3){var u=a[o],f=a[o+1],v=u[wn]||null;if(typeof f=="function")v||i_(a);else if(v){var w=null;if(f&&f.hasAttribute("formAction")){if(u=f,v=f[wn]||null)w=v.formAction;else if(yd(u)!==null)continue}else w=v.action;typeof w=="function"?a[o+1]=w:(a.splice(o,3),o-=3),i_(a)}}}function a_(){function t(f){f.canIntercept&&f.info==="react-transition"&&f.intercept({handler:function(){return new Promise(function(v){return u=v})},focusReset:"manual",scroll:"manual"})}function n(){u!==null&&(u(),u=null),o||setTimeout(a,20)}function a(){if(!o&&!navigation.transition){var f=navigation.currentEntry;f&&f.url!=null&&navigation.navigate(f.url,{state:f.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,u=null;return navigation.addEventListener("navigate",t),navigation.addEventListener("navigatesuccess",n),navigation.addEventListener("navigateerror",n),setTimeout(a,100),function(){o=!0,navigation.removeEventListener("navigate",t),navigation.removeEventListener("navigatesuccess",n),navigation.removeEventListener("navigateerror",n),u!==null&&(u(),u=null)}}}function Md(t){this._internalRoot=t}Sc.prototype.render=Md.prototype.render=function(t){var n=this._internalRoot;if(n===null)throw Error(s(409));var a=n.current,o=fi();Z0(a,o,t,n,null,null)},Sc.prototype.unmount=Md.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var n=t.containerInfo;Z0(t.current,2,null,t,null,null),ec(),n[Ji]=null}};function Sc(t){this._internalRoot=t}Sc.prototype.unstable_scheduleHydration=function(t){if(t){var n=$r();t={blockedOn:null,target:t,priority:n};for(var a=0;a<es.length&&n!==0&&n<es[a].priority;a++);es.splice(a,0,t),a===0&&t_(t)}};var s_=e.version;if(s_!=="19.2.6")throw Error(s(527,s_,"19.2.6"));P.findDOMNode=function(t){var n=t._reactInternals;if(n===void 0)throw typeof t.render=="function"?Error(s(188)):(t=Object.keys(t).join(","),Error(s(268,t)));return t=h(n),t=t!==null?g(t):null,t=t===null?null:t.stateNode,t};var yy={bundleType:0,version:"19.2.6",rendererPackageName:"react-dom",currentDispatcherRef:D,reconcilerVersion:"19.2.6"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var yc=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!yc.isDisabled&&yc.supportsFiber)try{ne=yc.inject(yy),de=yc}catch{}}return Wo.createRoot=function(t,n){if(!l(t))throw Error(s(299));var a=!1,o="",u=dg,f=hg,v=pg;return n!=null&&(n.unstable_strictMode===!0&&(a=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onUncaughtError!==void 0&&(u=n.onUncaughtError),n.onCaughtError!==void 0&&(f=n.onCaughtError),n.onRecoverableError!==void 0&&(v=n.onRecoverableError)),n=q0(t,1,!1,null,null,a,o,null,u,f,v,a_),t[Ji]=n.current,ad(t),new Md(n)},Wo.hydrateRoot=function(t,n,a){if(!l(t))throw Error(s(299));var o=!1,u="",f=dg,v=hg,w=pg,V=null;return a!=null&&(a.unstable_strictMode===!0&&(o=!0),a.identifierPrefix!==void 0&&(u=a.identifierPrefix),a.onUncaughtError!==void 0&&(f=a.onUncaughtError),a.onCaughtError!==void 0&&(v=a.onCaughtError),a.onRecoverableError!==void 0&&(w=a.onRecoverableError),a.formState!==void 0&&(V=a.formState)),n=q0(t,1,!0,n,a??null,o,u,V,f,v,w,a_),n.context=Y0(null),a=n.current,o=fi(),o=ms(o),u=Ia(o),u.callback=null,Ha(a,u,o),a=o,n.current.lanes=a,it(n,a),Gi(n),t[Ji]=n.current,ad(t),new Sc(n)},Wo.version="19.2.6",Wo}var m_;function Ny(){if(m_)return Ad.exports;m_=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(e){console.error(e)}}return r(),Ad.exports=Dy(),Ad.exports}var Uy=Ny();/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const lp="184",Gr={ROTATE:0,DOLLY:1,PAN:2},Hr={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},Ly=0,g_=1,Oy=2,eu=1,Px=2,nl=3,fs=0,ni=1,Xi=2,Ma=0,Vr=1,__=2,x_=3,v_=4,Py=5,Bs=100,zy=101,Fy=102,By=103,Iy=104,Hy=200,Gy=201,Vy=202,ky=203,hh=204,ph=205,jy=206,Xy=207,Wy=208,qy=209,Yy=210,Zy=211,Ky=212,Qy=213,Jy=214,mh=0,gh=1,_h=2,jr=3,xh=4,vh=5,Sh=6,yh=7,zx=0,$y=1,eb=2,Yi=0,Fx=1,Bx=2,Ix=3,Hx=4,Gx=5,Vx=6,kx=7,jx=300,ks=301,Xr=302,Dd=303,Nd=304,pu=306,bh=1e3,ba=1001,Mh=1002,On=1003,tb=1004,bc=1005,Gn=1006,Ud=1007,Hs=1008,gi=1009,Xx=1010,Wx=1011,rl=1012,cp=1013,Ki=1014,Wi=1015,Ta=1016,up=1017,fp=1018,ol=1020,qx=35902,Yx=35899,Zx=1021,Kx=1022,Pi=1023,Aa=1026,Gs=1027,Qx=1028,dp=1029,js=1030,hp=1031,pp=1033,tu=33776,nu=33777,iu=33778,au=33779,Eh=35840,Th=35841,Ah=35842,Rh=35843,Ch=36196,wh=37492,Dh=37496,Nh=37488,Uh=37489,ru=37490,Lh=37491,Oh=37808,Ph=37809,zh=37810,Fh=37811,Bh=37812,Ih=37813,Hh=37814,Gh=37815,Vh=37816,kh=37817,jh=37818,Xh=37819,Wh=37820,qh=37821,Yh=36492,Zh=36494,Kh=36495,Qh=36283,Jh=36284,ou=36285,$h=36286,nb=3200,ep=0,ib=1,cs="",pi="srgb",lu="srgb-linear",cu="linear",jt="srgb",Tr=7680,S_=519,ab=512,sb=513,rb=514,mp=515,ob=516,lb=517,gp=518,cb=519,y_=35044,b_="300 es",qi=2e3,ll=2001;function ub(r){for(let e=r.length-1;e>=0;--e)if(r[e]>=65535)return!0;return!1}function uu(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function fb(){const r=uu("canvas");return r.style.display="block",r}const M_={};function E_(...r){const e="THREE."+r.shift();console.log(e,...r)}function Jx(r){const e=r[0];if(typeof e=="string"&&e.startsWith("TSL:")){const i=r[1];i&&i.isStackTrace?r[0]+=" "+i.getLocation():r[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return r}function st(...r){r=Jx(r);const e="THREE."+r.shift();{const i=r[0];i&&i.isStackTrace?console.warn(i.getError(e)):console.warn(e,...r)}}function Ut(...r){r=Jx(r);const e="THREE."+r.shift();{const i=r[0];i&&i.isStackTrace?console.error(i.getError(e)):console.error(e,...r)}}function tp(...r){const e=r.join(" ");e in M_||(M_[e]=!0,st(...r))}function db(r,e,i){return new Promise(function(s,l){function c(){switch(r.clientWaitSync(e,r.SYNC_FLUSH_COMMANDS_BIT,0)){case r.WAIT_FAILED:l();break;case r.TIMEOUT_EXPIRED:setTimeout(c,i);break;default:s()}}setTimeout(c,i)})}const hb={[mh]:gh,[_h]:Sh,[xh]:yh,[jr]:vh,[gh]:mh,[Sh]:_h,[yh]:xh,[vh]:jr};class ps{addEventListener(e,i){this._listeners===void 0&&(this._listeners={});const s=this._listeners;s[e]===void 0&&(s[e]=[]),s[e].indexOf(i)===-1&&s[e].push(i)}hasEventListener(e,i){const s=this._listeners;return s===void 0?!1:s[e]!==void 0&&s[e].indexOf(i)!==-1}removeEventListener(e,i){const s=this._listeners;if(s===void 0)return;const l=s[e];if(l!==void 0){const c=l.indexOf(i);c!==-1&&l.splice(c,1)}}dispatchEvent(e){const i=this._listeners;if(i===void 0)return;const s=i[e.type];if(s!==void 0){e.target=this;const l=s.slice(0);for(let c=0,d=l.length;c<d;c++)l[c].call(this,e);e.target=null}}}const In=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],sl=Math.PI/180,np=180/Math.PI;function ul(){const r=Math.random()*4294967295|0,e=Math.random()*4294967295|0,i=Math.random()*4294967295|0,s=Math.random()*4294967295|0;return(In[r&255]+In[r>>8&255]+In[r>>16&255]+In[r>>24&255]+"-"+In[e&255]+In[e>>8&255]+"-"+In[e>>16&15|64]+In[e>>24&255]+"-"+In[i&63|128]+In[i>>8&255]+"-"+In[i>>16&255]+In[i>>24&255]+In[s&255]+In[s>>8&255]+In[s>>16&255]+In[s>>24&255]).toLowerCase()}function Tt(r,e,i){return Math.max(e,Math.min(i,r))}function pb(r,e){return(r%e+e)%e}function Ld(r,e,i){return(1-i)*r+i*e}function qo(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("Invalid component type.")}}function ei(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return Math.round(r*4294967295);case Uint16Array:return Math.round(r*65535);case Uint8Array:return Math.round(r*255);case Int32Array:return Math.round(r*2147483647);case Int16Array:return Math.round(r*32767);case Int8Array:return Math.round(r*127);default:throw new Error("Invalid component type.")}}const mb={DEG2RAD:sl},Mp=class Mp{constructor(e=0,i=0){this.x=e,this.y=i}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,i){return this.x=e,this.y=i,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,i){switch(e){case 0:this.x=i;break;case 1:this.y=i;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,i){return this.x=e.x+i.x,this.y=e.y+i.y,this}addScaledVector(e,i){return this.x+=e.x*i,this.y+=e.y*i,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,i){return this.x=e.x-i.x,this.y=e.y-i.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const i=this.x,s=this.y,l=e.elements;return this.x=l[0]*i+l[3]*s+l[6],this.y=l[1]*i+l[4]*s+l[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,i){return this.x=Tt(this.x,e.x,i.x),this.y=Tt(this.y,e.y,i.y),this}clampScalar(e,i){return this.x=Tt(this.x,e,i),this.y=Tt(this.y,e,i),this}clampLength(e,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(Tt(s,e,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const i=Math.sqrt(this.lengthSq()*e.lengthSq());if(i===0)return Math.PI/2;const s=this.dot(e)/i;return Math.acos(Tt(s,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const i=this.x-e.x,s=this.y-e.y;return i*i+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,i){return this.x+=(e.x-this.x)*i,this.y+=(e.y-this.y)*i,this}lerpVectors(e,i,s){return this.x=e.x+(i.x-e.x)*s,this.y=e.y+(i.y-e.y)*s,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,i=0){return this.x=e[i],this.y=e[i+1],this}toArray(e=[],i=0){return e[i]=this.x,e[i+1]=this.y,e}fromBufferAttribute(e,i){return this.x=e.getX(i),this.y=e.getY(i),this}rotateAround(e,i){const s=Math.cos(i),l=Math.sin(i),c=this.x-e.x,d=this.y-e.y;return this.x=c*s-d*l+e.x,this.y=c*l+d*s+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Mp.prototype.isVector2=!0;let gt=Mp;class ds{constructor(e=0,i=0,s=0,l=1){this.isQuaternion=!0,this._x=e,this._y=i,this._z=s,this._w=l}static slerpFlat(e,i,s,l,c,d,p){let m=s[l+0],h=s[l+1],g=s[l+2],x=s[l+3],_=c[d+0],y=c[d+1],M=c[d+2],A=c[d+3];if(x!==A||m!==_||h!==y||g!==M){let b=m*_+h*y+g*M+x*A;b<0&&(_=-_,y=-y,M=-M,A=-A,b=-b);let S=1-p;if(b<.9995){const N=Math.acos(b),O=Math.sin(N);S=Math.sin(S*N)/O,p=Math.sin(p*N)/O,m=m*S+_*p,h=h*S+y*p,g=g*S+M*p,x=x*S+A*p}else{m=m*S+_*p,h=h*S+y*p,g=g*S+M*p,x=x*S+A*p;const N=1/Math.sqrt(m*m+h*h+g*g+x*x);m*=N,h*=N,g*=N,x*=N}}e[i]=m,e[i+1]=h,e[i+2]=g,e[i+3]=x}static multiplyQuaternionsFlat(e,i,s,l,c,d){const p=s[l],m=s[l+1],h=s[l+2],g=s[l+3],x=c[d],_=c[d+1],y=c[d+2],M=c[d+3];return e[i]=p*M+g*x+m*y-h*_,e[i+1]=m*M+g*_+h*x-p*y,e[i+2]=h*M+g*y+p*_-m*x,e[i+3]=g*M-p*x-m*_-h*y,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,i,s,l){return this._x=e,this._y=i,this._z=s,this._w=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,i=!0){const s=e._x,l=e._y,c=e._z,d=e._order,p=Math.cos,m=Math.sin,h=p(s/2),g=p(l/2),x=p(c/2),_=m(s/2),y=m(l/2),M=m(c/2);switch(d){case"XYZ":this._x=_*g*x+h*y*M,this._y=h*y*x-_*g*M,this._z=h*g*M+_*y*x,this._w=h*g*x-_*y*M;break;case"YXZ":this._x=_*g*x+h*y*M,this._y=h*y*x-_*g*M,this._z=h*g*M-_*y*x,this._w=h*g*x+_*y*M;break;case"ZXY":this._x=_*g*x-h*y*M,this._y=h*y*x+_*g*M,this._z=h*g*M+_*y*x,this._w=h*g*x-_*y*M;break;case"ZYX":this._x=_*g*x-h*y*M,this._y=h*y*x+_*g*M,this._z=h*g*M-_*y*x,this._w=h*g*x+_*y*M;break;case"YZX":this._x=_*g*x+h*y*M,this._y=h*y*x+_*g*M,this._z=h*g*M-_*y*x,this._w=h*g*x-_*y*M;break;case"XZY":this._x=_*g*x-h*y*M,this._y=h*y*x-_*g*M,this._z=h*g*M+_*y*x,this._w=h*g*x+_*y*M;break;default:st("Quaternion: .setFromEuler() encountered an unknown order: "+d)}return i===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,i){const s=i/2,l=Math.sin(s);return this._x=e.x*l,this._y=e.y*l,this._z=e.z*l,this._w=Math.cos(s),this._onChangeCallback(),this}setFromRotationMatrix(e){const i=e.elements,s=i[0],l=i[4],c=i[8],d=i[1],p=i[5],m=i[9],h=i[2],g=i[6],x=i[10],_=s+p+x;if(_>0){const y=.5/Math.sqrt(_+1);this._w=.25/y,this._x=(g-m)*y,this._y=(c-h)*y,this._z=(d-l)*y}else if(s>p&&s>x){const y=2*Math.sqrt(1+s-p-x);this._w=(g-m)/y,this._x=.25*y,this._y=(l+d)/y,this._z=(c+h)/y}else if(p>x){const y=2*Math.sqrt(1+p-s-x);this._w=(c-h)/y,this._x=(l+d)/y,this._y=.25*y,this._z=(m+g)/y}else{const y=2*Math.sqrt(1+x-s-p);this._w=(d-l)/y,this._x=(c+h)/y,this._y=(m+g)/y,this._z=.25*y}return this._onChangeCallback(),this}setFromUnitVectors(e,i){let s=e.dot(i)+1;return s<1e-8?(s=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=s):(this._x=0,this._y=-e.z,this._z=e.y,this._w=s)):(this._x=e.y*i.z-e.z*i.y,this._y=e.z*i.x-e.x*i.z,this._z=e.x*i.y-e.y*i.x,this._w=s),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Tt(this.dot(e),-1,1)))}rotateTowards(e,i){const s=this.angleTo(e);if(s===0)return this;const l=Math.min(1,i/s);return this.slerp(e,l),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,i){const s=e._x,l=e._y,c=e._z,d=e._w,p=i._x,m=i._y,h=i._z,g=i._w;return this._x=s*g+d*p+l*h-c*m,this._y=l*g+d*m+c*p-s*h,this._z=c*g+d*h+s*m-l*p,this._w=d*g-s*p-l*m-c*h,this._onChangeCallback(),this}slerp(e,i){let s=e._x,l=e._y,c=e._z,d=e._w,p=this.dot(e);p<0&&(s=-s,l=-l,c=-c,d=-d,p=-p);let m=1-i;if(p<.9995){const h=Math.acos(p),g=Math.sin(h);m=Math.sin(m*h)/g,i=Math.sin(i*h)/g,this._x=this._x*m+s*i,this._y=this._y*m+l*i,this._z=this._z*m+c*i,this._w=this._w*m+d*i,this._onChangeCallback()}else this._x=this._x*m+s*i,this._y=this._y*m+l*i,this._z=this._z*m+c*i,this._w=this._w*m+d*i,this.normalize();return this}slerpQuaternions(e,i,s){return this.copy(e).slerp(i,s)}random(){const e=2*Math.PI*Math.random(),i=2*Math.PI*Math.random(),s=Math.random(),l=Math.sqrt(1-s),c=Math.sqrt(s);return this.set(l*Math.sin(e),l*Math.cos(e),c*Math.sin(i),c*Math.cos(i))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,i=0){return this._x=e[i],this._y=e[i+1],this._z=e[i+2],this._w=e[i+3],this._onChangeCallback(),this}toArray(e=[],i=0){return e[i]=this._x,e[i+1]=this._y,e[i+2]=this._z,e[i+3]=this._w,e}fromBufferAttribute(e,i){return this._x=e.getX(i),this._y=e.getY(i),this._z=e.getZ(i),this._w=e.getW(i),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const Ep=class Ep{constructor(e=0,i=0,s=0){this.x=e,this.y=i,this.z=s}set(e,i,s){return s===void 0&&(s=this.z),this.x=e,this.y=i,this.z=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,i){switch(e){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,i){return this.x=e.x+i.x,this.y=e.y+i.y,this.z=e.z+i.z,this}addScaledVector(e,i){return this.x+=e.x*i,this.y+=e.y*i,this.z+=e.z*i,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,i){return this.x=e.x-i.x,this.y=e.y-i.y,this.z=e.z-i.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,i){return this.x=e.x*i.x,this.y=e.y*i.y,this.z=e.z*i.z,this}applyEuler(e){return this.applyQuaternion(T_.setFromEuler(e))}applyAxisAngle(e,i){return this.applyQuaternion(T_.setFromAxisAngle(e,i))}applyMatrix3(e){const i=this.x,s=this.y,l=this.z,c=e.elements;return this.x=c[0]*i+c[3]*s+c[6]*l,this.y=c[1]*i+c[4]*s+c[7]*l,this.z=c[2]*i+c[5]*s+c[8]*l,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const i=this.x,s=this.y,l=this.z,c=e.elements,d=1/(c[3]*i+c[7]*s+c[11]*l+c[15]);return this.x=(c[0]*i+c[4]*s+c[8]*l+c[12])*d,this.y=(c[1]*i+c[5]*s+c[9]*l+c[13])*d,this.z=(c[2]*i+c[6]*s+c[10]*l+c[14])*d,this}applyQuaternion(e){const i=this.x,s=this.y,l=this.z,c=e.x,d=e.y,p=e.z,m=e.w,h=2*(d*l-p*s),g=2*(p*i-c*l),x=2*(c*s-d*i);return this.x=i+m*h+d*x-p*g,this.y=s+m*g+p*h-c*x,this.z=l+m*x+c*g-d*h,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const i=this.x,s=this.y,l=this.z,c=e.elements;return this.x=c[0]*i+c[4]*s+c[8]*l,this.y=c[1]*i+c[5]*s+c[9]*l,this.z=c[2]*i+c[6]*s+c[10]*l,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,i){return this.x=Tt(this.x,e.x,i.x),this.y=Tt(this.y,e.y,i.y),this.z=Tt(this.z,e.z,i.z),this}clampScalar(e,i){return this.x=Tt(this.x,e,i),this.y=Tt(this.y,e,i),this.z=Tt(this.z,e,i),this}clampLength(e,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(Tt(s,e,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,i){return this.x+=(e.x-this.x)*i,this.y+=(e.y-this.y)*i,this.z+=(e.z-this.z)*i,this}lerpVectors(e,i,s){return this.x=e.x+(i.x-e.x)*s,this.y=e.y+(i.y-e.y)*s,this.z=e.z+(i.z-e.z)*s,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,i){const s=e.x,l=e.y,c=e.z,d=i.x,p=i.y,m=i.z;return this.x=l*m-c*p,this.y=c*d-s*m,this.z=s*p-l*d,this}projectOnVector(e){const i=e.lengthSq();if(i===0)return this.set(0,0,0);const s=e.dot(this)/i;return this.copy(e).multiplyScalar(s)}projectOnPlane(e){return Od.copy(this).projectOnVector(e),this.sub(Od)}reflect(e){return this.sub(Od.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const i=Math.sqrt(this.lengthSq()*e.lengthSq());if(i===0)return Math.PI/2;const s=this.dot(e)/i;return Math.acos(Tt(s,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const i=this.x-e.x,s=this.y-e.y,l=this.z-e.z;return i*i+s*s+l*l}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,i,s){const l=Math.sin(i)*e;return this.x=l*Math.sin(s),this.y=Math.cos(i)*e,this.z=l*Math.cos(s),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,i,s){return this.x=e*Math.sin(i),this.y=s,this.z=e*Math.cos(i),this}setFromMatrixPosition(e){const i=e.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this}setFromMatrixScale(e){const i=this.setFromMatrixColumn(e,0).length(),s=this.setFromMatrixColumn(e,1).length(),l=this.setFromMatrixColumn(e,2).length();return this.x=i,this.y=s,this.z=l,this}setFromMatrixColumn(e,i){return this.fromArray(e.elements,i*4)}setFromMatrix3Column(e,i){return this.fromArray(e.elements,i*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,i=0){return this.x=e[i],this.y=e[i+1],this.z=e[i+2],this}toArray(e=[],i=0){return e[i]=this.x,e[i+1]=this.y,e[i+2]=this.z,e}fromBufferAttribute(e,i){return this.x=e.getX(i),this.y=e.getY(i),this.z=e.getZ(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,i=Math.random()*2-1,s=Math.sqrt(1-i*i);return this.x=s*Math.cos(e),this.y=i,this.z=s*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};Ep.prototype.isVector3=!0;let ee=Ep;const Od=new ee,T_=new ds,Tp=class Tp{constructor(e,i,s,l,c,d,p,m,h){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,i,s,l,c,d,p,m,h)}set(e,i,s,l,c,d,p,m,h){const g=this.elements;return g[0]=e,g[1]=l,g[2]=p,g[3]=i,g[4]=c,g[5]=m,g[6]=s,g[7]=d,g[8]=h,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const i=this.elements,s=e.elements;return i[0]=s[0],i[1]=s[1],i[2]=s[2],i[3]=s[3],i[4]=s[4],i[5]=s[5],i[6]=s[6],i[7]=s[7],i[8]=s[8],this}extractBasis(e,i,s){return e.setFromMatrix3Column(this,0),i.setFromMatrix3Column(this,1),s.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const i=e.elements;return this.set(i[0],i[4],i[8],i[1],i[5],i[9],i[2],i[6],i[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,i){const s=e.elements,l=i.elements,c=this.elements,d=s[0],p=s[3],m=s[6],h=s[1],g=s[4],x=s[7],_=s[2],y=s[5],M=s[8],A=l[0],b=l[3],S=l[6],N=l[1],O=l[4],z=l[7],k=l[2],L=l[5],H=l[8];return c[0]=d*A+p*N+m*k,c[3]=d*b+p*O+m*L,c[6]=d*S+p*z+m*H,c[1]=h*A+g*N+x*k,c[4]=h*b+g*O+x*L,c[7]=h*S+g*z+x*H,c[2]=_*A+y*N+M*k,c[5]=_*b+y*O+M*L,c[8]=_*S+y*z+M*H,this}multiplyScalar(e){const i=this.elements;return i[0]*=e,i[3]*=e,i[6]*=e,i[1]*=e,i[4]*=e,i[7]*=e,i[2]*=e,i[5]*=e,i[8]*=e,this}determinant(){const e=this.elements,i=e[0],s=e[1],l=e[2],c=e[3],d=e[4],p=e[5],m=e[6],h=e[7],g=e[8];return i*d*g-i*p*h-s*c*g+s*p*m+l*c*h-l*d*m}invert(){const e=this.elements,i=e[0],s=e[1],l=e[2],c=e[3],d=e[4],p=e[5],m=e[6],h=e[7],g=e[8],x=g*d-p*h,_=p*m-g*c,y=h*c-d*m,M=i*x+s*_+l*y;if(M===0)return this.set(0,0,0,0,0,0,0,0,0);const A=1/M;return e[0]=x*A,e[1]=(l*h-g*s)*A,e[2]=(p*s-l*d)*A,e[3]=_*A,e[4]=(g*i-l*m)*A,e[5]=(l*c-p*i)*A,e[6]=y*A,e[7]=(s*m-h*i)*A,e[8]=(d*i-s*c)*A,this}transpose(){let e;const i=this.elements;return e=i[1],i[1]=i[3],i[3]=e,e=i[2],i[2]=i[6],i[6]=e,e=i[5],i[5]=i[7],i[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const i=this.elements;return e[0]=i[0],e[1]=i[3],e[2]=i[6],e[3]=i[1],e[4]=i[4],e[5]=i[7],e[6]=i[2],e[7]=i[5],e[8]=i[8],this}setUvTransform(e,i,s,l,c,d,p){const m=Math.cos(c),h=Math.sin(c);return this.set(s*m,s*h,-s*(m*d+h*p)+d+e,-l*h,l*m,-l*(-h*d+m*p)+p+i,0,0,1),this}scale(e,i){return this.premultiply(Pd.makeScale(e,i)),this}rotate(e){return this.premultiply(Pd.makeRotation(-e)),this}translate(e,i){return this.premultiply(Pd.makeTranslation(e,i)),this}makeTranslation(e,i){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,i,0,0,1),this}makeRotation(e){const i=Math.cos(e),s=Math.sin(e);return this.set(i,-s,0,s,i,0,0,0,1),this}makeScale(e,i){return this.set(e,0,0,0,i,0,0,0,1),this}equals(e){const i=this.elements,s=e.elements;for(let l=0;l<9;l++)if(i[l]!==s[l])return!1;return!0}fromArray(e,i=0){for(let s=0;s<9;s++)this.elements[s]=e[s+i];return this}toArray(e=[],i=0){const s=this.elements;return e[i]=s[0],e[i+1]=s[1],e[i+2]=s[2],e[i+3]=s[3],e[i+4]=s[4],e[i+5]=s[5],e[i+6]=s[6],e[i+7]=s[7],e[i+8]=s[8],e}clone(){return new this.constructor().fromArray(this.elements)}};Tp.prototype.isMatrix3=!0;let ht=Tp;const Pd=new ht,A_=new ht().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),R_=new ht().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function gb(){const r={enabled:!0,workingColorSpace:lu,spaces:{},convert:function(l,c,d){return this.enabled===!1||c===d||!c||!d||(this.spaces[c].transfer===jt&&(l.r=Ea(l.r),l.g=Ea(l.g),l.b=Ea(l.b)),this.spaces[c].primaries!==this.spaces[d].primaries&&(l.applyMatrix3(this.spaces[c].toXYZ),l.applyMatrix3(this.spaces[d].fromXYZ)),this.spaces[d].transfer===jt&&(l.r=kr(l.r),l.g=kr(l.g),l.b=kr(l.b))),l},workingToColorSpace:function(l,c){return this.convert(l,this.workingColorSpace,c)},colorSpaceToWorking:function(l,c){return this.convert(l,c,this.workingColorSpace)},getPrimaries:function(l){return this.spaces[l].primaries},getTransfer:function(l){return l===cs?cu:this.spaces[l].transfer},getToneMappingMode:function(l){return this.spaces[l].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(l,c=this.workingColorSpace){return l.fromArray(this.spaces[c].luminanceCoefficients)},define:function(l){Object.assign(this.spaces,l)},_getMatrix:function(l,c,d){return l.copy(this.spaces[c].toXYZ).multiply(this.spaces[d].fromXYZ)},_getDrawingBufferColorSpace:function(l){return this.spaces[l].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(l=this.workingColorSpace){return this.spaces[l].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(l,c){return tp("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),r.workingToColorSpace(l,c)},toWorkingColorSpace:function(l,c){return tp("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),r.colorSpaceToWorking(l,c)}},e=[.64,.33,.3,.6,.15,.06],i=[.2126,.7152,.0722],s=[.3127,.329];return r.define({[lu]:{primaries:e,whitePoint:s,transfer:cu,toXYZ:A_,fromXYZ:R_,luminanceCoefficients:i,workingColorSpaceConfig:{unpackColorSpace:pi},outputColorSpaceConfig:{drawingBufferColorSpace:pi}},[pi]:{primaries:e,whitePoint:s,transfer:jt,toXYZ:A_,fromXYZ:R_,luminanceCoefficients:i,outputColorSpaceConfig:{drawingBufferColorSpace:pi}}}),r}const wt=gb();function Ea(r){return r<.04045?r*.0773993808:Math.pow(r*.9478672986+.0521327014,2.4)}function kr(r){return r<.0031308?r*12.92:1.055*Math.pow(r,.41666)-.055}let Ar;class _b{static getDataURL(e,i="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let s;if(e instanceof HTMLCanvasElement)s=e;else{Ar===void 0&&(Ar=uu("canvas")),Ar.width=e.width,Ar.height=e.height;const l=Ar.getContext("2d");e instanceof ImageData?l.putImageData(e,0,0):l.drawImage(e,0,0,e.width,e.height),s=Ar}return s.toDataURL(i)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const i=uu("canvas");i.width=e.width,i.height=e.height;const s=i.getContext("2d");s.drawImage(e,0,0,e.width,e.height);const l=s.getImageData(0,0,e.width,e.height),c=l.data;for(let d=0;d<c.length;d++)c[d]=Ea(c[d]/255)*255;return s.putImageData(l,0,0),i}else if(e.data){const i=e.data.slice(0);for(let s=0;s<i.length;s++)i instanceof Uint8Array||i instanceof Uint8ClampedArray?i[s]=Math.floor(Ea(i[s]/255)*255):i[s]=Ea(i[s]);return{data:i,width:e.width,height:e.height}}else return st("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let xb=0;class _p{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:xb++}),this.uuid=ul(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const i=this.data;return typeof HTMLVideoElement<"u"&&i instanceof HTMLVideoElement?e.set(i.videoWidth,i.videoHeight,0):typeof VideoFrame<"u"&&i instanceof VideoFrame?e.set(i.displayWidth,i.displayHeight,0):i!==null?e.set(i.width,i.height,i.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const i=e===void 0||typeof e=="string";if(!i&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const s={uuid:this.uuid,url:""},l=this.data;if(l!==null){let c;if(Array.isArray(l)){c=[];for(let d=0,p=l.length;d<p;d++)l[d].isDataTexture?c.push(zd(l[d].image)):c.push(zd(l[d]))}else c=zd(l);s.url=c}return i||(e.images[this.uuid]=s),s}}function zd(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?_b.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(st("Texture: Unable to serialize Texture."),{})}let vb=0;const Fd=new ee;class Wn extends ps{constructor(e=Wn.DEFAULT_IMAGE,i=Wn.DEFAULT_MAPPING,s=ba,l=ba,c=Gn,d=Hs,p=Pi,m=gi,h=Wn.DEFAULT_ANISOTROPY,g=cs){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:vb++}),this.uuid=ul(),this.name="",this.source=new _p(e),this.mipmaps=[],this.mapping=i,this.channel=0,this.wrapS=s,this.wrapT=l,this.magFilter=c,this.minFilter=d,this.anisotropy=h,this.format=p,this.internalFormat=null,this.type=m,this.offset=new gt(0,0),this.repeat=new gt(1,1),this.center=new gt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new ht,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=g,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(Fd).x}get height(){return this.source.getSize(Fd).y}get depth(){return this.source.getSize(Fd).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,i){this.updateRanges.push({start:e,count:i})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const i in e){const s=e[i];if(s===void 0){st(`Texture.setValues(): parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){st(`Texture.setValues(): property '${i}' does not exist.`);continue}l&&s&&l.isVector2&&s.isVector2||l&&s&&l.isVector3&&s.isVector3||l&&s&&l.isMatrix3&&s.isMatrix3?l.copy(s):this[i]=s}}toJSON(e){const i=e===void 0||typeof e=="string";if(!i&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const s={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(s.userData=this.userData),i||(e.textures[this.uuid]=s),s}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==jx)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case bh:e.x=e.x-Math.floor(e.x);break;case ba:e.x=e.x<0?0:1;break;case Mh:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case bh:e.y=e.y-Math.floor(e.y);break;case ba:e.y=e.y<0?0:1;break;case Mh:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Wn.DEFAULT_IMAGE=null;Wn.DEFAULT_MAPPING=jx;Wn.DEFAULT_ANISOTROPY=1;const Ap=class Ap{constructor(e=0,i=0,s=0,l=1){this.x=e,this.y=i,this.z=s,this.w=l}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,i,s,l){return this.x=e,this.y=i,this.z=s,this.w=l,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,i){switch(e){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;case 3:this.w=i;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,i){return this.x=e.x+i.x,this.y=e.y+i.y,this.z=e.z+i.z,this.w=e.w+i.w,this}addScaledVector(e,i){return this.x+=e.x*i,this.y+=e.y*i,this.z+=e.z*i,this.w+=e.w*i,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,i){return this.x=e.x-i.x,this.y=e.y-i.y,this.z=e.z-i.z,this.w=e.w-i.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const i=this.x,s=this.y,l=this.z,c=this.w,d=e.elements;return this.x=d[0]*i+d[4]*s+d[8]*l+d[12]*c,this.y=d[1]*i+d[5]*s+d[9]*l+d[13]*c,this.z=d[2]*i+d[6]*s+d[10]*l+d[14]*c,this.w=d[3]*i+d[7]*s+d[11]*l+d[15]*c,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const i=Math.sqrt(1-e.w*e.w);return i<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/i,this.y=e.y/i,this.z=e.z/i),this}setAxisAngleFromRotationMatrix(e){let i,s,l,c;const m=e.elements,h=m[0],g=m[4],x=m[8],_=m[1],y=m[5],M=m[9],A=m[2],b=m[6],S=m[10];if(Math.abs(g-_)<.01&&Math.abs(x-A)<.01&&Math.abs(M-b)<.01){if(Math.abs(g+_)<.1&&Math.abs(x+A)<.1&&Math.abs(M+b)<.1&&Math.abs(h+y+S-3)<.1)return this.set(1,0,0,0),this;i=Math.PI;const O=(h+1)/2,z=(y+1)/2,k=(S+1)/2,L=(g+_)/4,H=(x+A)/4,T=(M+b)/4;return O>z&&O>k?O<.01?(s=0,l=.707106781,c=.707106781):(s=Math.sqrt(O),l=L/s,c=H/s):z>k?z<.01?(s=.707106781,l=0,c=.707106781):(l=Math.sqrt(z),s=L/l,c=T/l):k<.01?(s=.707106781,l=.707106781,c=0):(c=Math.sqrt(k),s=H/c,l=T/c),this.set(s,l,c,i),this}let N=Math.sqrt((b-M)*(b-M)+(x-A)*(x-A)+(_-g)*(_-g));return Math.abs(N)<.001&&(N=1),this.x=(b-M)/N,this.y=(x-A)/N,this.z=(_-g)/N,this.w=Math.acos((h+y+S-1)/2),this}setFromMatrixPosition(e){const i=e.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this.w=i[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,i){return this.x=Tt(this.x,e.x,i.x),this.y=Tt(this.y,e.y,i.y),this.z=Tt(this.z,e.z,i.z),this.w=Tt(this.w,e.w,i.w),this}clampScalar(e,i){return this.x=Tt(this.x,e,i),this.y=Tt(this.y,e,i),this.z=Tt(this.z,e,i),this.w=Tt(this.w,e,i),this}clampLength(e,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(Tt(s,e,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,i){return this.x+=(e.x-this.x)*i,this.y+=(e.y-this.y)*i,this.z+=(e.z-this.z)*i,this.w+=(e.w-this.w)*i,this}lerpVectors(e,i,s){return this.x=e.x+(i.x-e.x)*s,this.y=e.y+(i.y-e.y)*s,this.z=e.z+(i.z-e.z)*s,this.w=e.w+(i.w-e.w)*s,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,i=0){return this.x=e[i],this.y=e[i+1],this.z=e[i+2],this.w=e[i+3],this}toArray(e=[],i=0){return e[i]=this.x,e[i+1]=this.y,e[i+2]=this.z,e[i+3]=this.w,e}fromBufferAttribute(e,i){return this.x=e.getX(i),this.y=e.getY(i),this.z=e.getZ(i),this.w=e.getW(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};Ap.prototype.isVector4=!0;let cn=Ap;class Sb extends ps{constructor(e=1,i=1,s={}){super(),s=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Gn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},s),this.isRenderTarget=!0,this.width=e,this.height=i,this.depth=s.depth,this.scissor=new cn(0,0,e,i),this.scissorTest=!1,this.viewport=new cn(0,0,e,i),this.textures=[];const l={width:e,height:i,depth:s.depth},c=new Wn(l),d=s.count;for(let p=0;p<d;p++)this.textures[p]=c.clone(),this.textures[p].isRenderTargetTexture=!0,this.textures[p].renderTarget=this;this._setTextureOptions(s),this.depthBuffer=s.depthBuffer,this.stencilBuffer=s.stencilBuffer,this.resolveDepthBuffer=s.resolveDepthBuffer,this.resolveStencilBuffer=s.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=s.depthTexture,this.samples=s.samples,this.multiview=s.multiview}_setTextureOptions(e={}){const i={minFilter:Gn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(i.mapping=e.mapping),e.wrapS!==void 0&&(i.wrapS=e.wrapS),e.wrapT!==void 0&&(i.wrapT=e.wrapT),e.wrapR!==void 0&&(i.wrapR=e.wrapR),e.magFilter!==void 0&&(i.magFilter=e.magFilter),e.minFilter!==void 0&&(i.minFilter=e.minFilter),e.format!==void 0&&(i.format=e.format),e.type!==void 0&&(i.type=e.type),e.anisotropy!==void 0&&(i.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(i.colorSpace=e.colorSpace),e.flipY!==void 0&&(i.flipY=e.flipY),e.generateMipmaps!==void 0&&(i.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(i.internalFormat=e.internalFormat);for(let s=0;s<this.textures.length;s++)this.textures[s].setValues(i)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,i,s=1){if(this.width!==e||this.height!==i||this.depth!==s){this.width=e,this.height=i,this.depth=s;for(let l=0,c=this.textures.length;l<c;l++)this.textures[l].image.width=e,this.textures[l].image.height=i,this.textures[l].image.depth=s,this.textures[l].isData3DTexture!==!0&&(this.textures[l].isArrayTexture=this.textures[l].image.depth>1);this.dispose()}this.viewport.set(0,0,e,i),this.scissor.set(0,0,e,i)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let i=0,s=e.textures.length;i<s;i++){this.textures[i]=e.textures[i].clone(),this.textures[i].isRenderTargetTexture=!0,this.textures[i].renderTarget=this;const l=Object.assign({},e.textures[i].image);this.textures[i].source=new _p(l)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this.multiview=e.multiview,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Zi extends Sb{constructor(e=1,i=1,s={}){super(e,i,s),this.isWebGLRenderTarget=!0}}class $x extends Wn{constructor(e=null,i=1,s=1,l=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:i,height:s,depth:l},this.magFilter=On,this.minFilter=On,this.wrapR=ba,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class yb extends Wn{constructor(e=null,i=1,s=1,l=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:i,height:s,depth:l},this.magFilter=On,this.minFilter=On,this.wrapR=ba,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const hu=class hu{constructor(e,i,s,l,c,d,p,m,h,g,x,_,y,M,A,b){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,i,s,l,c,d,p,m,h,g,x,_,y,M,A,b)}set(e,i,s,l,c,d,p,m,h,g,x,_,y,M,A,b){const S=this.elements;return S[0]=e,S[4]=i,S[8]=s,S[12]=l,S[1]=c,S[5]=d,S[9]=p,S[13]=m,S[2]=h,S[6]=g,S[10]=x,S[14]=_,S[3]=y,S[7]=M,S[11]=A,S[15]=b,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new hu().fromArray(this.elements)}copy(e){const i=this.elements,s=e.elements;return i[0]=s[0],i[1]=s[1],i[2]=s[2],i[3]=s[3],i[4]=s[4],i[5]=s[5],i[6]=s[6],i[7]=s[7],i[8]=s[8],i[9]=s[9],i[10]=s[10],i[11]=s[11],i[12]=s[12],i[13]=s[13],i[14]=s[14],i[15]=s[15],this}copyPosition(e){const i=this.elements,s=e.elements;return i[12]=s[12],i[13]=s[13],i[14]=s[14],this}setFromMatrix3(e){const i=e.elements;return this.set(i[0],i[3],i[6],0,i[1],i[4],i[7],0,i[2],i[5],i[8],0,0,0,0,1),this}extractBasis(e,i,s){return this.determinant()===0?(e.set(1,0,0),i.set(0,1,0),s.set(0,0,1),this):(e.setFromMatrixColumn(this,0),i.setFromMatrixColumn(this,1),s.setFromMatrixColumn(this,2),this)}makeBasis(e,i,s){return this.set(e.x,i.x,s.x,0,e.y,i.y,s.y,0,e.z,i.z,s.z,0,0,0,0,1),this}extractRotation(e){if(e.determinant()===0)return this.identity();const i=this.elements,s=e.elements,l=1/Rr.setFromMatrixColumn(e,0).length(),c=1/Rr.setFromMatrixColumn(e,1).length(),d=1/Rr.setFromMatrixColumn(e,2).length();return i[0]=s[0]*l,i[1]=s[1]*l,i[2]=s[2]*l,i[3]=0,i[4]=s[4]*c,i[5]=s[5]*c,i[6]=s[6]*c,i[7]=0,i[8]=s[8]*d,i[9]=s[9]*d,i[10]=s[10]*d,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromEuler(e){const i=this.elements,s=e.x,l=e.y,c=e.z,d=Math.cos(s),p=Math.sin(s),m=Math.cos(l),h=Math.sin(l),g=Math.cos(c),x=Math.sin(c);if(e.order==="XYZ"){const _=d*g,y=d*x,M=p*g,A=p*x;i[0]=m*g,i[4]=-m*x,i[8]=h,i[1]=y+M*h,i[5]=_-A*h,i[9]=-p*m,i[2]=A-_*h,i[6]=M+y*h,i[10]=d*m}else if(e.order==="YXZ"){const _=m*g,y=m*x,M=h*g,A=h*x;i[0]=_+A*p,i[4]=M*p-y,i[8]=d*h,i[1]=d*x,i[5]=d*g,i[9]=-p,i[2]=y*p-M,i[6]=A+_*p,i[10]=d*m}else if(e.order==="ZXY"){const _=m*g,y=m*x,M=h*g,A=h*x;i[0]=_-A*p,i[4]=-d*x,i[8]=M+y*p,i[1]=y+M*p,i[5]=d*g,i[9]=A-_*p,i[2]=-d*h,i[6]=p,i[10]=d*m}else if(e.order==="ZYX"){const _=d*g,y=d*x,M=p*g,A=p*x;i[0]=m*g,i[4]=M*h-y,i[8]=_*h+A,i[1]=m*x,i[5]=A*h+_,i[9]=y*h-M,i[2]=-h,i[6]=p*m,i[10]=d*m}else if(e.order==="YZX"){const _=d*m,y=d*h,M=p*m,A=p*h;i[0]=m*g,i[4]=A-_*x,i[8]=M*x+y,i[1]=x,i[5]=d*g,i[9]=-p*g,i[2]=-h*g,i[6]=y*x+M,i[10]=_-A*x}else if(e.order==="XZY"){const _=d*m,y=d*h,M=p*m,A=p*h;i[0]=m*g,i[4]=-x,i[8]=h*g,i[1]=_*x+A,i[5]=d*g,i[9]=y*x-M,i[2]=M*x-y,i[6]=p*g,i[10]=A*x+_}return i[3]=0,i[7]=0,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromQuaternion(e){return this.compose(bb,e,Mb)}lookAt(e,i,s){const l=this.elements;return di.subVectors(e,i),di.lengthSq()===0&&(di.z=1),di.normalize(),ns.crossVectors(s,di),ns.lengthSq()===0&&(Math.abs(s.z)===1?di.x+=1e-4:di.z+=1e-4,di.normalize(),ns.crossVectors(s,di)),ns.normalize(),Mc.crossVectors(di,ns),l[0]=ns.x,l[4]=Mc.x,l[8]=di.x,l[1]=ns.y,l[5]=Mc.y,l[9]=di.y,l[2]=ns.z,l[6]=Mc.z,l[10]=di.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,i){const s=e.elements,l=i.elements,c=this.elements,d=s[0],p=s[4],m=s[8],h=s[12],g=s[1],x=s[5],_=s[9],y=s[13],M=s[2],A=s[6],b=s[10],S=s[14],N=s[3],O=s[7],z=s[11],k=s[15],L=l[0],H=l[4],T=l[8],I=l[12],Z=l[1],G=l[5],K=l[9],ue=l[13],pe=l[2],F=l[6],D=l[10],P=l[14],q=l[3],he=l[7],_e=l[11],B=l[15];return c[0]=d*L+p*Z+m*pe+h*q,c[4]=d*H+p*G+m*F+h*he,c[8]=d*T+p*K+m*D+h*_e,c[12]=d*I+p*ue+m*P+h*B,c[1]=g*L+x*Z+_*pe+y*q,c[5]=g*H+x*G+_*F+y*he,c[9]=g*T+x*K+_*D+y*_e,c[13]=g*I+x*ue+_*P+y*B,c[2]=M*L+A*Z+b*pe+S*q,c[6]=M*H+A*G+b*F+S*he,c[10]=M*T+A*K+b*D+S*_e,c[14]=M*I+A*ue+b*P+S*B,c[3]=N*L+O*Z+z*pe+k*q,c[7]=N*H+O*G+z*F+k*he,c[11]=N*T+O*K+z*D+k*_e,c[15]=N*I+O*ue+z*P+k*B,this}multiplyScalar(e){const i=this.elements;return i[0]*=e,i[4]*=e,i[8]*=e,i[12]*=e,i[1]*=e,i[5]*=e,i[9]*=e,i[13]*=e,i[2]*=e,i[6]*=e,i[10]*=e,i[14]*=e,i[3]*=e,i[7]*=e,i[11]*=e,i[15]*=e,this}determinant(){const e=this.elements,i=e[0],s=e[4],l=e[8],c=e[12],d=e[1],p=e[5],m=e[9],h=e[13],g=e[2],x=e[6],_=e[10],y=e[14],M=e[3],A=e[7],b=e[11],S=e[15],N=m*y-h*_,O=p*y-h*x,z=p*_-m*x,k=d*y-h*g,L=d*_-m*g,H=d*x-p*g;return i*(A*N-b*O+S*z)-s*(M*N-b*k+S*L)+l*(M*O-A*k+S*H)-c*(M*z-A*L+b*H)}transpose(){const e=this.elements;let i;return i=e[1],e[1]=e[4],e[4]=i,i=e[2],e[2]=e[8],e[8]=i,i=e[6],e[6]=e[9],e[9]=i,i=e[3],e[3]=e[12],e[12]=i,i=e[7],e[7]=e[13],e[13]=i,i=e[11],e[11]=e[14],e[14]=i,this}setPosition(e,i,s){const l=this.elements;return e.isVector3?(l[12]=e.x,l[13]=e.y,l[14]=e.z):(l[12]=e,l[13]=i,l[14]=s),this}invert(){const e=this.elements,i=e[0],s=e[1],l=e[2],c=e[3],d=e[4],p=e[5],m=e[6],h=e[7],g=e[8],x=e[9],_=e[10],y=e[11],M=e[12],A=e[13],b=e[14],S=e[15],N=i*p-s*d,O=i*m-l*d,z=i*h-c*d,k=s*m-l*p,L=s*h-c*p,H=l*h-c*m,T=g*A-x*M,I=g*b-_*M,Z=g*S-y*M,G=x*b-_*A,K=x*S-y*A,ue=_*S-y*b,pe=N*ue-O*K+z*G+k*Z-L*I+H*T;if(pe===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const F=1/pe;return e[0]=(p*ue-m*K+h*G)*F,e[1]=(l*K-s*ue-c*G)*F,e[2]=(A*H-b*L+S*k)*F,e[3]=(_*L-x*H-y*k)*F,e[4]=(m*Z-d*ue-h*I)*F,e[5]=(i*ue-l*Z+c*I)*F,e[6]=(b*z-M*H-S*O)*F,e[7]=(g*H-_*z+y*O)*F,e[8]=(d*K-p*Z+h*T)*F,e[9]=(s*Z-i*K-c*T)*F,e[10]=(M*L-A*z+S*N)*F,e[11]=(x*z-g*L-y*N)*F,e[12]=(p*I-d*G-m*T)*F,e[13]=(i*G-s*I+l*T)*F,e[14]=(A*O-M*k-b*N)*F,e[15]=(g*k-x*O+_*N)*F,this}scale(e){const i=this.elements,s=e.x,l=e.y,c=e.z;return i[0]*=s,i[4]*=l,i[8]*=c,i[1]*=s,i[5]*=l,i[9]*=c,i[2]*=s,i[6]*=l,i[10]*=c,i[3]*=s,i[7]*=l,i[11]*=c,this}getMaxScaleOnAxis(){const e=this.elements,i=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],s=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],l=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(i,s,l))}makeTranslation(e,i,s){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,i,0,0,1,s,0,0,0,1),this}makeRotationX(e){const i=Math.cos(e),s=Math.sin(e);return this.set(1,0,0,0,0,i,-s,0,0,s,i,0,0,0,0,1),this}makeRotationY(e){const i=Math.cos(e),s=Math.sin(e);return this.set(i,0,s,0,0,1,0,0,-s,0,i,0,0,0,0,1),this}makeRotationZ(e){const i=Math.cos(e),s=Math.sin(e);return this.set(i,-s,0,0,s,i,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,i){const s=Math.cos(i),l=Math.sin(i),c=1-s,d=e.x,p=e.y,m=e.z,h=c*d,g=c*p;return this.set(h*d+s,h*p-l*m,h*m+l*p,0,h*p+l*m,g*p+s,g*m-l*d,0,h*m-l*p,g*m+l*d,c*m*m+s,0,0,0,0,1),this}makeScale(e,i,s){return this.set(e,0,0,0,0,i,0,0,0,0,s,0,0,0,0,1),this}makeShear(e,i,s,l,c,d){return this.set(1,s,c,0,e,1,d,0,i,l,1,0,0,0,0,1),this}compose(e,i,s){const l=this.elements,c=i._x,d=i._y,p=i._z,m=i._w,h=c+c,g=d+d,x=p+p,_=c*h,y=c*g,M=c*x,A=d*g,b=d*x,S=p*x,N=m*h,O=m*g,z=m*x,k=s.x,L=s.y,H=s.z;return l[0]=(1-(A+S))*k,l[1]=(y+z)*k,l[2]=(M-O)*k,l[3]=0,l[4]=(y-z)*L,l[5]=(1-(_+S))*L,l[6]=(b+N)*L,l[7]=0,l[8]=(M+O)*H,l[9]=(b-N)*H,l[10]=(1-(_+A))*H,l[11]=0,l[12]=e.x,l[13]=e.y,l[14]=e.z,l[15]=1,this}decompose(e,i,s){const l=this.elements;e.x=l[12],e.y=l[13],e.z=l[14];const c=this.determinant();if(c===0)return s.set(1,1,1),i.identity(),this;let d=Rr.set(l[0],l[1],l[2]).length();const p=Rr.set(l[4],l[5],l[6]).length(),m=Rr.set(l[8],l[9],l[10]).length();c<0&&(d=-d),Ui.copy(this);const h=1/d,g=1/p,x=1/m;return Ui.elements[0]*=h,Ui.elements[1]*=h,Ui.elements[2]*=h,Ui.elements[4]*=g,Ui.elements[5]*=g,Ui.elements[6]*=g,Ui.elements[8]*=x,Ui.elements[9]*=x,Ui.elements[10]*=x,i.setFromRotationMatrix(Ui),s.x=d,s.y=p,s.z=m,this}makePerspective(e,i,s,l,c,d,p=qi,m=!1){const h=this.elements,g=2*c/(i-e),x=2*c/(s-l),_=(i+e)/(i-e),y=(s+l)/(s-l);let M,A;if(m)M=c/(d-c),A=d*c/(d-c);else if(p===qi)M=-(d+c)/(d-c),A=-2*d*c/(d-c);else if(p===ll)M=-d/(d-c),A=-d*c/(d-c);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+p);return h[0]=g,h[4]=0,h[8]=_,h[12]=0,h[1]=0,h[5]=x,h[9]=y,h[13]=0,h[2]=0,h[6]=0,h[10]=M,h[14]=A,h[3]=0,h[7]=0,h[11]=-1,h[15]=0,this}makeOrthographic(e,i,s,l,c,d,p=qi,m=!1){const h=this.elements,g=2/(i-e),x=2/(s-l),_=-(i+e)/(i-e),y=-(s+l)/(s-l);let M,A;if(m)M=1/(d-c),A=d/(d-c);else if(p===qi)M=-2/(d-c),A=-(d+c)/(d-c);else if(p===ll)M=-1/(d-c),A=-c/(d-c);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+p);return h[0]=g,h[4]=0,h[8]=0,h[12]=_,h[1]=0,h[5]=x,h[9]=0,h[13]=y,h[2]=0,h[6]=0,h[10]=M,h[14]=A,h[3]=0,h[7]=0,h[11]=0,h[15]=1,this}equals(e){const i=this.elements,s=e.elements;for(let l=0;l<16;l++)if(i[l]!==s[l])return!1;return!0}fromArray(e,i=0){for(let s=0;s<16;s++)this.elements[s]=e[s+i];return this}toArray(e=[],i=0){const s=this.elements;return e[i]=s[0],e[i+1]=s[1],e[i+2]=s[2],e[i+3]=s[3],e[i+4]=s[4],e[i+5]=s[5],e[i+6]=s[6],e[i+7]=s[7],e[i+8]=s[8],e[i+9]=s[9],e[i+10]=s[10],e[i+11]=s[11],e[i+12]=s[12],e[i+13]=s[13],e[i+14]=s[14],e[i+15]=s[15],e}};hu.prototype.isMatrix4=!0;let rn=hu;const Rr=new ee,Ui=new rn,bb=new ee(0,0,0),Mb=new ee(1,1,1),ns=new ee,Mc=new ee,di=new ee,C_=new rn,w_=new ds;class hs{constructor(e=0,i=0,s=0,l=hs.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=i,this._z=s,this._order=l}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,i,s,l=this._order){return this._x=e,this._y=i,this._z=s,this._order=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,i=this._order,s=!0){const l=e.elements,c=l[0],d=l[4],p=l[8],m=l[1],h=l[5],g=l[9],x=l[2],_=l[6],y=l[10];switch(i){case"XYZ":this._y=Math.asin(Tt(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(-g,y),this._z=Math.atan2(-d,c)):(this._x=Math.atan2(_,h),this._z=0);break;case"YXZ":this._x=Math.asin(-Tt(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(p,y),this._z=Math.atan2(m,h)):(this._y=Math.atan2(-x,c),this._z=0);break;case"ZXY":this._x=Math.asin(Tt(_,-1,1)),Math.abs(_)<.9999999?(this._y=Math.atan2(-x,y),this._z=Math.atan2(-d,h)):(this._y=0,this._z=Math.atan2(m,c));break;case"ZYX":this._y=Math.asin(-Tt(x,-1,1)),Math.abs(x)<.9999999?(this._x=Math.atan2(_,y),this._z=Math.atan2(m,c)):(this._x=0,this._z=Math.atan2(-d,h));break;case"YZX":this._z=Math.asin(Tt(m,-1,1)),Math.abs(m)<.9999999?(this._x=Math.atan2(-g,h),this._y=Math.atan2(-x,c)):(this._x=0,this._y=Math.atan2(p,y));break;case"XZY":this._z=Math.asin(-Tt(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(_,h),this._y=Math.atan2(p,c)):(this._x=Math.atan2(-g,y),this._y=0);break;default:st("Euler: .setFromRotationMatrix() encountered an unknown order: "+i)}return this._order=i,s===!0&&this._onChangeCallback(),this}setFromQuaternion(e,i,s){return C_.makeRotationFromQuaternion(e),this.setFromRotationMatrix(C_,i,s)}setFromVector3(e,i=this._order){return this.set(e.x,e.y,e.z,i)}reorder(e){return w_.setFromEuler(this),this.setFromQuaternion(w_,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],i=0){return e[i]=this._x,e[i+1]=this._y,e[i+2]=this._z,e[i+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}hs.DEFAULT_ORDER="XYZ";let ev=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}},Eb=0;const D_=new ee,Cr=new ds,ga=new rn,Ec=new ee,Yo=new ee,Tb=new ee,Ab=new ds,N_=new ee(1,0,0),U_=new ee(0,1,0),L_=new ee(0,0,1),O_={type:"added"},Rb={type:"removed"},wr={type:"childadded",child:null},Bd={type:"childremoved",child:null};class Rn extends ps{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Eb++}),this.uuid=ul(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Rn.DEFAULT_UP.clone();const e=new ee,i=new hs,s=new ds,l=new ee(1,1,1);function c(){s.setFromEuler(i,!1)}function d(){i.setFromQuaternion(s,void 0,!1)}i._onChange(c),s._onChange(d),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:i},quaternion:{configurable:!0,enumerable:!0,value:s},scale:{configurable:!0,enumerable:!0,value:l},modelViewMatrix:{value:new rn},normalMatrix:{value:new ht}}),this.matrix=new rn,this.matrixWorld=new rn,this.matrixAutoUpdate=Rn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Rn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new ev,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,i){this.quaternion.setFromAxisAngle(e,i)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,i){return Cr.setFromAxisAngle(e,i),this.quaternion.multiply(Cr),this}rotateOnWorldAxis(e,i){return Cr.setFromAxisAngle(e,i),this.quaternion.premultiply(Cr),this}rotateX(e){return this.rotateOnAxis(N_,e)}rotateY(e){return this.rotateOnAxis(U_,e)}rotateZ(e){return this.rotateOnAxis(L_,e)}translateOnAxis(e,i){return D_.copy(e).applyQuaternion(this.quaternion),this.position.add(D_.multiplyScalar(i)),this}translateX(e){return this.translateOnAxis(N_,e)}translateY(e){return this.translateOnAxis(U_,e)}translateZ(e){return this.translateOnAxis(L_,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(ga.copy(this.matrixWorld).invert())}lookAt(e,i,s){e.isVector3?Ec.copy(e):Ec.set(e,i,s);const l=this.parent;this.updateWorldMatrix(!0,!1),Yo.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ga.lookAt(Yo,Ec,this.up):ga.lookAt(Ec,Yo,this.up),this.quaternion.setFromRotationMatrix(ga),l&&(ga.extractRotation(l.matrixWorld),Cr.setFromRotationMatrix(ga),this.quaternion.premultiply(Cr.invert()))}add(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.add(arguments[i]);return this}return e===this?(Ut("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(O_),wr.child=e,this.dispatchEvent(wr),wr.child=null):Ut("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let s=0;s<arguments.length;s++)this.remove(arguments[s]);return this}const i=this.children.indexOf(e);return i!==-1&&(e.parent=null,this.children.splice(i,1),e.dispatchEvent(Rb),Bd.child=e,this.dispatchEvent(Bd),Bd.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),ga.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),ga.multiply(e.parent.matrixWorld)),e.applyMatrix4(ga),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(O_),wr.child=e,this.dispatchEvent(wr),wr.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,i){if(this[e]===i)return this;for(let s=0,l=this.children.length;s<l;s++){const d=this.children[s].getObjectByProperty(e,i);if(d!==void 0)return d}}getObjectsByProperty(e,i,s=[]){this[e]===i&&s.push(this);const l=this.children;for(let c=0,d=l.length;c<d;c++)l[c].getObjectsByProperty(e,i,s);return s}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Yo,e,Tb),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Yo,Ab,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const i=this.matrixWorld.elements;return e.set(i[8],i[9],i[10]).normalize()}raycast(){}traverse(e){e(this);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].traverseVisible(e)}traverseAncestors(e){const i=this.parent;i!==null&&(e(i),i.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const i=e.x,s=e.y,l=e.z,c=this.matrix.elements;c[12]+=i-c[0]*i-c[4]*s-c[8]*l,c[13]+=s-c[1]*i-c[5]*s-c[9]*l,c[14]+=l-c[2]*i-c[6]*s-c[10]*l}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].updateMatrixWorld(e)}updateWorldMatrix(e,i){const s=this.parent;if(e===!0&&s!==null&&s.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),i===!0){const l=this.children;for(let c=0,d=l.length;c<d;c++)l[c].updateWorldMatrix(!1,!0)}}toJSON(e){const i=e===void 0||typeof e=="string",s={};i&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},s.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const l={};l.uuid=this.uuid,l.type=this.type,this.name!==""&&(l.name=this.name),this.castShadow===!0&&(l.castShadow=!0),this.receiveShadow===!0&&(l.receiveShadow=!0),this.visible===!1&&(l.visible=!1),this.frustumCulled===!1&&(l.frustumCulled=!1),this.renderOrder!==0&&(l.renderOrder=this.renderOrder),this.static!==!1&&(l.static=this.static),Object.keys(this.userData).length>0&&(l.userData=this.userData),l.layers=this.layers.mask,l.matrix=this.matrix.toArray(),l.up=this.up.toArray(),this.pivot!==null&&(l.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(l.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(l.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(l.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(l.type="InstancedMesh",l.count=this.count,l.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(l.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(l.type="BatchedMesh",l.perObjectFrustumCulled=this.perObjectFrustumCulled,l.sortObjects=this.sortObjects,l.drawRanges=this._drawRanges,l.reservedRanges=this._reservedRanges,l.geometryInfo=this._geometryInfo.map(p=>({...p,boundingBox:p.boundingBox?p.boundingBox.toJSON():void 0,boundingSphere:p.boundingSphere?p.boundingSphere.toJSON():void 0})),l.instanceInfo=this._instanceInfo.map(p=>({...p})),l.availableInstanceIds=this._availableInstanceIds.slice(),l.availableGeometryIds=this._availableGeometryIds.slice(),l.nextIndexStart=this._nextIndexStart,l.nextVertexStart=this._nextVertexStart,l.geometryCount=this._geometryCount,l.maxInstanceCount=this._maxInstanceCount,l.maxVertexCount=this._maxVertexCount,l.maxIndexCount=this._maxIndexCount,l.geometryInitialized=this._geometryInitialized,l.matricesTexture=this._matricesTexture.toJSON(e),l.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(l.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(l.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(l.boundingBox=this.boundingBox.toJSON()));function c(p,m){return p[m.uuid]===void 0&&(p[m.uuid]=m.toJSON(e)),m.uuid}if(this.isScene)this.background&&(this.background.isColor?l.background=this.background.toJSON():this.background.isTexture&&(l.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(l.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){l.geometry=c(e.geometries,this.geometry);const p=this.geometry.parameters;if(p!==void 0&&p.shapes!==void 0){const m=p.shapes;if(Array.isArray(m))for(let h=0,g=m.length;h<g;h++){const x=m[h];c(e.shapes,x)}else c(e.shapes,m)}}if(this.isSkinnedMesh&&(l.bindMode=this.bindMode,l.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(c(e.skeletons,this.skeleton),l.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const p=[];for(let m=0,h=this.material.length;m<h;m++)p.push(c(e.materials,this.material[m]));l.material=p}else l.material=c(e.materials,this.material);if(this.children.length>0){l.children=[];for(let p=0;p<this.children.length;p++)l.children.push(this.children[p].toJSON(e).object)}if(this.animations.length>0){l.animations=[];for(let p=0;p<this.animations.length;p++){const m=this.animations[p];l.animations.push(c(e.animations,m))}}if(i){const p=d(e.geometries),m=d(e.materials),h=d(e.textures),g=d(e.images),x=d(e.shapes),_=d(e.skeletons),y=d(e.animations),M=d(e.nodes);p.length>0&&(s.geometries=p),m.length>0&&(s.materials=m),h.length>0&&(s.textures=h),g.length>0&&(s.images=g),x.length>0&&(s.shapes=x),_.length>0&&(s.skeletons=_),y.length>0&&(s.animations=y),M.length>0&&(s.nodes=M)}return s.object=l,s;function d(p){const m=[];for(const h in p){const g=p[h];delete g.metadata,m.push(g)}return m}}clone(e){return new this.constructor().copy(this,e)}copy(e,i=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),i===!0)for(let s=0;s<e.children.length;s++){const l=e.children[s];this.add(l.clone())}return this}}Rn.DEFAULT_UP=new ee(0,1,0);Rn.DEFAULT_MATRIX_AUTO_UPDATE=!0;Rn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class il extends Rn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Cb={type:"move"};class Id{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new il,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new il,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new ee,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new ee),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new il,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new ee,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new ee,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const i=this._hand;if(i)for(const s of e.hand.values())this._getHandJoint(i,s)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,i,s){let l=null,c=null,d=null;const p=this._targetRay,m=this._grip,h=this._hand;if(e&&i.session.visibilityState!=="visible-blurred"){if(h&&e.hand){d=!0;for(const A of e.hand.values()){const b=i.getJointPose(A,s),S=this._getHandJoint(h,A);b!==null&&(S.matrix.fromArray(b.transform.matrix),S.matrix.decompose(S.position,S.rotation,S.scale),S.matrixWorldNeedsUpdate=!0,S.jointRadius=b.radius),S.visible=b!==null}const g=h.joints["index-finger-tip"],x=h.joints["thumb-tip"],_=g.position.distanceTo(x.position),y=.02,M=.005;h.inputState.pinching&&_>y+M?(h.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!h.inputState.pinching&&_<=y-M&&(h.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else m!==null&&e.gripSpace&&(c=i.getPose(e.gripSpace,s),c!==null&&(m.matrix.fromArray(c.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,c.linearVelocity?(m.hasLinearVelocity=!0,m.linearVelocity.copy(c.linearVelocity)):m.hasLinearVelocity=!1,c.angularVelocity?(m.hasAngularVelocity=!0,m.angularVelocity.copy(c.angularVelocity)):m.hasAngularVelocity=!1,m.eventsEnabled&&m.dispatchEvent({type:"gripUpdated",data:e,target:this})));p!==null&&(l=i.getPose(e.targetRaySpace,s),l===null&&c!==null&&(l=c),l!==null&&(p.matrix.fromArray(l.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,l.linearVelocity?(p.hasLinearVelocity=!0,p.linearVelocity.copy(l.linearVelocity)):p.hasLinearVelocity=!1,l.angularVelocity?(p.hasAngularVelocity=!0,p.angularVelocity.copy(l.angularVelocity)):p.hasAngularVelocity=!1,this.dispatchEvent(Cb)))}return p!==null&&(p.visible=l!==null),m!==null&&(m.visible=c!==null),h!==null&&(h.visible=d!==null),this}_getHandJoint(e,i){if(e.joints[i.jointName]===void 0){const s=new il;s.matrixAutoUpdate=!1,s.visible=!1,e.joints[i.jointName]=s,e.add(s)}return e.joints[i.jointName]}}const tv={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},is={h:0,s:0,l:0},Tc={h:0,s:0,l:0};function Hd(r,e,i){return i<0&&(i+=1),i>1&&(i-=1),i<1/6?r+(e-r)*6*i:i<1/2?e:i<2/3?r+(e-r)*6*(2/3-i):r}class ft{constructor(e,i,s){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,i,s)}set(e,i,s){if(i===void 0&&s===void 0){const l=e;l&&l.isColor?this.copy(l):typeof l=="number"?this.setHex(l):typeof l=="string"&&this.setStyle(l)}else this.setRGB(e,i,s);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,i=pi){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,wt.colorSpaceToWorking(this,i),this}setRGB(e,i,s,l=wt.workingColorSpace){return this.r=e,this.g=i,this.b=s,wt.colorSpaceToWorking(this,l),this}setHSL(e,i,s,l=wt.workingColorSpace){if(e=pb(e,1),i=Tt(i,0,1),s=Tt(s,0,1),i===0)this.r=this.g=this.b=s;else{const c=s<=.5?s*(1+i):s+i-s*i,d=2*s-c;this.r=Hd(d,c,e+1/3),this.g=Hd(d,c,e),this.b=Hd(d,c,e-1/3)}return wt.colorSpaceToWorking(this,l),this}setStyle(e,i=pi){function s(c){c!==void 0&&parseFloat(c)<1&&st("Color: Alpha component of "+e+" will be ignored.")}let l;if(l=/^(\w+)\(([^\)]*)\)/.exec(e)){let c;const d=l[1],p=l[2];switch(d){case"rgb":case"rgba":if(c=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(p))return s(c[4]),this.setRGB(Math.min(255,parseInt(c[1],10))/255,Math.min(255,parseInt(c[2],10))/255,Math.min(255,parseInt(c[3],10))/255,i);if(c=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(p))return s(c[4]),this.setRGB(Math.min(100,parseInt(c[1],10))/100,Math.min(100,parseInt(c[2],10))/100,Math.min(100,parseInt(c[3],10))/100,i);break;case"hsl":case"hsla":if(c=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(p))return s(c[4]),this.setHSL(parseFloat(c[1])/360,parseFloat(c[2])/100,parseFloat(c[3])/100,i);break;default:st("Color: Unknown color model "+e)}}else if(l=/^\#([A-Fa-f\d]+)$/.exec(e)){const c=l[1],d=c.length;if(d===3)return this.setRGB(parseInt(c.charAt(0),16)/15,parseInt(c.charAt(1),16)/15,parseInt(c.charAt(2),16)/15,i);if(d===6)return this.setHex(parseInt(c,16),i);st("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,i);return this}setColorName(e,i=pi){const s=tv[e.toLowerCase()];return s!==void 0?this.setHex(s,i):st("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Ea(e.r),this.g=Ea(e.g),this.b=Ea(e.b),this}copyLinearToSRGB(e){return this.r=kr(e.r),this.g=kr(e.g),this.b=kr(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=pi){return wt.workingToColorSpace(Hn.copy(this),e),Math.round(Tt(Hn.r*255,0,255))*65536+Math.round(Tt(Hn.g*255,0,255))*256+Math.round(Tt(Hn.b*255,0,255))}getHexString(e=pi){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,i=wt.workingColorSpace){wt.workingToColorSpace(Hn.copy(this),i);const s=Hn.r,l=Hn.g,c=Hn.b,d=Math.max(s,l,c),p=Math.min(s,l,c);let m,h;const g=(p+d)/2;if(p===d)m=0,h=0;else{const x=d-p;switch(h=g<=.5?x/(d+p):x/(2-d-p),d){case s:m=(l-c)/x+(l<c?6:0);break;case l:m=(c-s)/x+2;break;case c:m=(s-l)/x+4;break}m/=6}return e.h=m,e.s=h,e.l=g,e}getRGB(e,i=wt.workingColorSpace){return wt.workingToColorSpace(Hn.copy(this),i),e.r=Hn.r,e.g=Hn.g,e.b=Hn.b,e}getStyle(e=pi){wt.workingToColorSpace(Hn.copy(this),e);const i=Hn.r,s=Hn.g,l=Hn.b;return e!==pi?`color(${e} ${i.toFixed(3)} ${s.toFixed(3)} ${l.toFixed(3)})`:`rgb(${Math.round(i*255)},${Math.round(s*255)},${Math.round(l*255)})`}offsetHSL(e,i,s){return this.getHSL(is),this.setHSL(is.h+e,is.s+i,is.l+s)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,i){return this.r=e.r+i.r,this.g=e.g+i.g,this.b=e.b+i.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,i){return this.r+=(e.r-this.r)*i,this.g+=(e.g-this.g)*i,this.b+=(e.b-this.b)*i,this}lerpColors(e,i,s){return this.r=e.r+(i.r-e.r)*s,this.g=e.g+(i.g-e.g)*s,this.b=e.b+(i.b-e.b)*s,this}lerpHSL(e,i){this.getHSL(is),e.getHSL(Tc);const s=Ld(is.h,Tc.h,i),l=Ld(is.s,Tc.s,i),c=Ld(is.l,Tc.l,i);return this.setHSL(s,l,c),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const i=this.r,s=this.g,l=this.b,c=e.elements;return this.r=c[0]*i+c[3]*s+c[6]*l,this.g=c[1]*i+c[4]*s+c[7]*l,this.b=c[2]*i+c[5]*s+c[8]*l,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,i=0){return this.r=e[i],this.g=e[i+1],this.b=e[i+2],this}toArray(e=[],i=0){return e[i]=this.r,e[i+1]=this.g,e[i+2]=this.b,e}fromBufferAttribute(e,i){return this.r=e.getX(i),this.g=e.getY(i),this.b=e.getZ(i),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Hn=new ft;ft.NAMES=tv;class wb extends Rn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new hs,this.environmentIntensity=1,this.environmentRotation=new hs,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,i){return super.copy(e,i),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const i=super.toJSON(e);return this.fog!==null&&(i.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(i.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(i.object.backgroundIntensity=this.backgroundIntensity),i.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(i.object.environmentIntensity=this.environmentIntensity),i.object.environmentRotation=this.environmentRotation.toArray(),i}}const Li=new ee,_a=new ee,Gd=new ee,xa=new ee,Dr=new ee,Nr=new ee,P_=new ee,Vd=new ee,kd=new ee,jd=new ee,Xd=new cn,Wd=new cn,qd=new cn;class Ai{constructor(e=new ee,i=new ee,s=new ee){this.a=e,this.b=i,this.c=s}static getNormal(e,i,s,l){l.subVectors(s,i),Li.subVectors(e,i),l.cross(Li);const c=l.lengthSq();return c>0?l.multiplyScalar(1/Math.sqrt(c)):l.set(0,0,0)}static getBarycoord(e,i,s,l,c){Li.subVectors(l,i),_a.subVectors(s,i),Gd.subVectors(e,i);const d=Li.dot(Li),p=Li.dot(_a),m=Li.dot(Gd),h=_a.dot(_a),g=_a.dot(Gd),x=d*h-p*p;if(x===0)return c.set(0,0,0),null;const _=1/x,y=(h*m-p*g)*_,M=(d*g-p*m)*_;return c.set(1-y-M,M,y)}static containsPoint(e,i,s,l){return this.getBarycoord(e,i,s,l,xa)===null?!1:xa.x>=0&&xa.y>=0&&xa.x+xa.y<=1}static getInterpolation(e,i,s,l,c,d,p,m){return this.getBarycoord(e,i,s,l,xa)===null?(m.x=0,m.y=0,"z"in m&&(m.z=0),"w"in m&&(m.w=0),null):(m.setScalar(0),m.addScaledVector(c,xa.x),m.addScaledVector(d,xa.y),m.addScaledVector(p,xa.z),m)}static getInterpolatedAttribute(e,i,s,l,c,d){return Xd.setScalar(0),Wd.setScalar(0),qd.setScalar(0),Xd.fromBufferAttribute(e,i),Wd.fromBufferAttribute(e,s),qd.fromBufferAttribute(e,l),d.setScalar(0),d.addScaledVector(Xd,c.x),d.addScaledVector(Wd,c.y),d.addScaledVector(qd,c.z),d}static isFrontFacing(e,i,s,l){return Li.subVectors(s,i),_a.subVectors(e,i),Li.cross(_a).dot(l)<0}set(e,i,s){return this.a.copy(e),this.b.copy(i),this.c.copy(s),this}setFromPointsAndIndices(e,i,s,l){return this.a.copy(e[i]),this.b.copy(e[s]),this.c.copy(e[l]),this}setFromAttributeAndIndices(e,i,s,l){return this.a.fromBufferAttribute(e,i),this.b.fromBufferAttribute(e,s),this.c.fromBufferAttribute(e,l),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Li.subVectors(this.c,this.b),_a.subVectors(this.a,this.b),Li.cross(_a).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Ai.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,i){return Ai.getBarycoord(e,this.a,this.b,this.c,i)}getInterpolation(e,i,s,l,c){return Ai.getInterpolation(e,this.a,this.b,this.c,i,s,l,c)}containsPoint(e){return Ai.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Ai.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,i){const s=this.a,l=this.b,c=this.c;let d,p;Dr.subVectors(l,s),Nr.subVectors(c,s),Vd.subVectors(e,s);const m=Dr.dot(Vd),h=Nr.dot(Vd);if(m<=0&&h<=0)return i.copy(s);kd.subVectors(e,l);const g=Dr.dot(kd),x=Nr.dot(kd);if(g>=0&&x<=g)return i.copy(l);const _=m*x-g*h;if(_<=0&&m>=0&&g<=0)return d=m/(m-g),i.copy(s).addScaledVector(Dr,d);jd.subVectors(e,c);const y=Dr.dot(jd),M=Nr.dot(jd);if(M>=0&&y<=M)return i.copy(c);const A=y*h-m*M;if(A<=0&&h>=0&&M<=0)return p=h/(h-M),i.copy(s).addScaledVector(Nr,p);const b=g*M-y*x;if(b<=0&&x-g>=0&&y-M>=0)return P_.subVectors(c,l),p=(x-g)/(x-g+(y-M)),i.copy(l).addScaledVector(P_,p);const S=1/(b+A+_);return d=A*S,p=_*S,i.copy(s).addScaledVector(Dr,d).addScaledVector(Nr,p)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class Zr{constructor(e=new ee(1/0,1/0,1/0),i=new ee(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=i}set(e,i){return this.min.copy(e),this.max.copy(i),this}setFromArray(e){this.makeEmpty();for(let i=0,s=e.length;i<s;i+=3)this.expandByPoint(Oi.fromArray(e,i));return this}setFromBufferAttribute(e){this.makeEmpty();for(let i=0,s=e.count;i<s;i++)this.expandByPoint(Oi.fromBufferAttribute(e,i));return this}setFromPoints(e){this.makeEmpty();for(let i=0,s=e.length;i<s;i++)this.expandByPoint(e[i]);return this}setFromCenterAndSize(e,i){const s=Oi.copy(i).multiplyScalar(.5);return this.min.copy(e).sub(s),this.max.copy(e).add(s),this}setFromObject(e,i=!1){return this.makeEmpty(),this.expandByObject(e,i)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,i=!1){e.updateWorldMatrix(!1,!1);const s=e.geometry;if(s!==void 0){const c=s.getAttribute("position");if(i===!0&&c!==void 0&&e.isInstancedMesh!==!0)for(let d=0,p=c.count;d<p;d++)e.isMesh===!0?e.getVertexPosition(d,Oi):Oi.fromBufferAttribute(c,d),Oi.applyMatrix4(e.matrixWorld),this.expandByPoint(Oi);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Ac.copy(e.boundingBox)):(s.boundingBox===null&&s.computeBoundingBox(),Ac.copy(s.boundingBox)),Ac.applyMatrix4(e.matrixWorld),this.union(Ac)}const l=e.children;for(let c=0,d=l.length;c<d;c++)this.expandByObject(l[c],i);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,i){return i.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Oi),Oi.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let i,s;return e.normal.x>0?(i=e.normal.x*this.min.x,s=e.normal.x*this.max.x):(i=e.normal.x*this.max.x,s=e.normal.x*this.min.x),e.normal.y>0?(i+=e.normal.y*this.min.y,s+=e.normal.y*this.max.y):(i+=e.normal.y*this.max.y,s+=e.normal.y*this.min.y),e.normal.z>0?(i+=e.normal.z*this.min.z,s+=e.normal.z*this.max.z):(i+=e.normal.z*this.max.z,s+=e.normal.z*this.min.z),i<=-e.constant&&s>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Zo),Rc.subVectors(this.max,Zo),Ur.subVectors(e.a,Zo),Lr.subVectors(e.b,Zo),Or.subVectors(e.c,Zo),as.subVectors(Lr,Ur),ss.subVectors(Or,Lr),Os.subVectors(Ur,Or);let i=[0,-as.z,as.y,0,-ss.z,ss.y,0,-Os.z,Os.y,as.z,0,-as.x,ss.z,0,-ss.x,Os.z,0,-Os.x,-as.y,as.x,0,-ss.y,ss.x,0,-Os.y,Os.x,0];return!Yd(i,Ur,Lr,Or,Rc)||(i=[1,0,0,0,1,0,0,0,1],!Yd(i,Ur,Lr,Or,Rc))?!1:(Cc.crossVectors(as,ss),i=[Cc.x,Cc.y,Cc.z],Yd(i,Ur,Lr,Or,Rc))}clampPoint(e,i){return i.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Oi).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Oi).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(va[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),va[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),va[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),va[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),va[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),va[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),va[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),va[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(va),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const va=[new ee,new ee,new ee,new ee,new ee,new ee,new ee,new ee],Oi=new ee,Ac=new Zr,Ur=new ee,Lr=new ee,Or=new ee,as=new ee,ss=new ee,Os=new ee,Zo=new ee,Rc=new ee,Cc=new ee,Ps=new ee;function Yd(r,e,i,s,l){for(let c=0,d=r.length-3;c<=d;c+=3){Ps.fromArray(r,c);const p=l.x*Math.abs(Ps.x)+l.y*Math.abs(Ps.y)+l.z*Math.abs(Ps.z),m=e.dot(Ps),h=i.dot(Ps),g=s.dot(Ps);if(Math.max(-Math.max(m,h,g),Math.min(m,h,g))>p)return!1}return!0}const vn=new ee,wc=new gt;let Db=0;class qn extends ps{constructor(e,i,s=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Db++}),this.name="",this.array=e,this.itemSize=i,this.count=e!==void 0?e.length/i:0,this.normalized=s,this.usage=y_,this.updateRanges=[],this.gpuType=Wi,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,i){this.updateRanges.push({start:e,count:i})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,i,s){e*=this.itemSize,s*=i.itemSize;for(let l=0,c=this.itemSize;l<c;l++)this.array[e+l]=i.array[s+l];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let i=0,s=this.count;i<s;i++)wc.fromBufferAttribute(this,i),wc.applyMatrix3(e),this.setXY(i,wc.x,wc.y);else if(this.itemSize===3)for(let i=0,s=this.count;i<s;i++)vn.fromBufferAttribute(this,i),vn.applyMatrix3(e),this.setXYZ(i,vn.x,vn.y,vn.z);return this}applyMatrix4(e){for(let i=0,s=this.count;i<s;i++)vn.fromBufferAttribute(this,i),vn.applyMatrix4(e),this.setXYZ(i,vn.x,vn.y,vn.z);return this}applyNormalMatrix(e){for(let i=0,s=this.count;i<s;i++)vn.fromBufferAttribute(this,i),vn.applyNormalMatrix(e),this.setXYZ(i,vn.x,vn.y,vn.z);return this}transformDirection(e){for(let i=0,s=this.count;i<s;i++)vn.fromBufferAttribute(this,i),vn.transformDirection(e),this.setXYZ(i,vn.x,vn.y,vn.z);return this}set(e,i=0){return this.array.set(e,i),this}getComponent(e,i){let s=this.array[e*this.itemSize+i];return this.normalized&&(s=qo(s,this.array)),s}setComponent(e,i,s){return this.normalized&&(s=ei(s,this.array)),this.array[e*this.itemSize+i]=s,this}getX(e){let i=this.array[e*this.itemSize];return this.normalized&&(i=qo(i,this.array)),i}setX(e,i){return this.normalized&&(i=ei(i,this.array)),this.array[e*this.itemSize]=i,this}getY(e){let i=this.array[e*this.itemSize+1];return this.normalized&&(i=qo(i,this.array)),i}setY(e,i){return this.normalized&&(i=ei(i,this.array)),this.array[e*this.itemSize+1]=i,this}getZ(e){let i=this.array[e*this.itemSize+2];return this.normalized&&(i=qo(i,this.array)),i}setZ(e,i){return this.normalized&&(i=ei(i,this.array)),this.array[e*this.itemSize+2]=i,this}getW(e){let i=this.array[e*this.itemSize+3];return this.normalized&&(i=qo(i,this.array)),i}setW(e,i){return this.normalized&&(i=ei(i,this.array)),this.array[e*this.itemSize+3]=i,this}setXY(e,i,s){return e*=this.itemSize,this.normalized&&(i=ei(i,this.array),s=ei(s,this.array)),this.array[e+0]=i,this.array[e+1]=s,this}setXYZ(e,i,s,l){return e*=this.itemSize,this.normalized&&(i=ei(i,this.array),s=ei(s,this.array),l=ei(l,this.array)),this.array[e+0]=i,this.array[e+1]=s,this.array[e+2]=l,this}setXYZW(e,i,s,l,c){return e*=this.itemSize,this.normalized&&(i=ei(i,this.array),s=ei(s,this.array),l=ei(l,this.array),c=ei(c,this.array)),this.array[e+0]=i,this.array[e+1]=s,this.array[e+2]=l,this.array[e+3]=c,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==y_&&(e.usage=this.usage),e}dispose(){this.dispatchEvent({type:"dispose"})}}class nv extends qn{constructor(e,i,s){super(new Uint16Array(e),i,s)}}class iv extends qn{constructor(e,i,s){super(new Uint32Array(e),i,s)}}class Cn extends qn{constructor(e,i,s){super(new Float32Array(e),i,s)}}const Nb=new Zr,Ko=new ee,Zd=new ee;class fl{constructor(e=new ee,i=-1){this.isSphere=!0,this.center=e,this.radius=i}set(e,i){return this.center.copy(e),this.radius=i,this}setFromPoints(e,i){const s=this.center;i!==void 0?s.copy(i):Nb.setFromPoints(e).getCenter(s);let l=0;for(let c=0,d=e.length;c<d;c++)l=Math.max(l,s.distanceToSquared(e[c]));return this.radius=Math.sqrt(l),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const i=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=i*i}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,i){const s=this.center.distanceToSquared(e);return i.copy(e),s>this.radius*this.radius&&(i.sub(this.center).normalize(),i.multiplyScalar(this.radius).add(this.center)),i}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Ko.subVectors(e,this.center);const i=Ko.lengthSq();if(i>this.radius*this.radius){const s=Math.sqrt(i),l=(s-this.radius)*.5;this.center.addScaledVector(Ko,l/s),this.radius+=l}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Zd.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Ko.copy(e.center).add(Zd)),this.expandByPoint(Ko.copy(e.center).sub(Zd))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let Ub=0;const Ti=new rn,Kd=new Rn,Pr=new ee,hi=new Zr,Qo=new Zr,An=new ee;class Pn extends ps{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Ub++}),this.uuid=ul(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(ub(e)?iv:nv)(e,1):this.index=e,this}setIndirect(e,i=0){return this.indirect=e,this.indirectOffset=i,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,i){return this.attributes[e]=i,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,i,s=0){this.groups.push({start:e,count:i,materialIndex:s})}clearGroups(){this.groups=[]}setDrawRange(e,i){this.drawRange.start=e,this.drawRange.count=i}applyMatrix4(e){const i=this.attributes.position;i!==void 0&&(i.applyMatrix4(e),i.needsUpdate=!0);const s=this.attributes.normal;if(s!==void 0){const c=new ht().getNormalMatrix(e);s.applyNormalMatrix(c),s.needsUpdate=!0}const l=this.attributes.tangent;return l!==void 0&&(l.transformDirection(e),l.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Ti.makeRotationFromQuaternion(e),this.applyMatrix4(Ti),this}rotateX(e){return Ti.makeRotationX(e),this.applyMatrix4(Ti),this}rotateY(e){return Ti.makeRotationY(e),this.applyMatrix4(Ti),this}rotateZ(e){return Ti.makeRotationZ(e),this.applyMatrix4(Ti),this}translate(e,i,s){return Ti.makeTranslation(e,i,s),this.applyMatrix4(Ti),this}scale(e,i,s){return Ti.makeScale(e,i,s),this.applyMatrix4(Ti),this}lookAt(e){return Kd.lookAt(e),Kd.updateMatrix(),this.applyMatrix4(Kd.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Pr).negate(),this.translate(Pr.x,Pr.y,Pr.z),this}setFromPoints(e){const i=this.getAttribute("position");if(i===void 0){const s=[];for(let l=0,c=e.length;l<c;l++){const d=e[l];s.push(d.x,d.y,d.z||0)}this.setAttribute("position",new Cn(s,3))}else{const s=Math.min(e.length,i.count);for(let l=0;l<s;l++){const c=e[l];i.setXYZ(l,c.x,c.y,c.z||0)}e.length>i.count&&st("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),i.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Zr);const e=this.attributes.position,i=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Ut("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new ee(-1/0,-1/0,-1/0),new ee(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),i)for(let s=0,l=i.length;s<l;s++){const c=i[s];hi.setFromBufferAttribute(c),this.morphTargetsRelative?(An.addVectors(this.boundingBox.min,hi.min),this.boundingBox.expandByPoint(An),An.addVectors(this.boundingBox.max,hi.max),this.boundingBox.expandByPoint(An)):(this.boundingBox.expandByPoint(hi.min),this.boundingBox.expandByPoint(hi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Ut('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new fl);const e=this.attributes.position,i=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Ut("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new ee,1/0);return}if(e){const s=this.boundingSphere.center;if(hi.setFromBufferAttribute(e),i)for(let c=0,d=i.length;c<d;c++){const p=i[c];Qo.setFromBufferAttribute(p),this.morphTargetsRelative?(An.addVectors(hi.min,Qo.min),hi.expandByPoint(An),An.addVectors(hi.max,Qo.max),hi.expandByPoint(An)):(hi.expandByPoint(Qo.min),hi.expandByPoint(Qo.max))}hi.getCenter(s);let l=0;for(let c=0,d=e.count;c<d;c++)An.fromBufferAttribute(e,c),l=Math.max(l,s.distanceToSquared(An));if(i)for(let c=0,d=i.length;c<d;c++){const p=i[c],m=this.morphTargetsRelative;for(let h=0,g=p.count;h<g;h++)An.fromBufferAttribute(p,h),m&&(Pr.fromBufferAttribute(e,h),An.add(Pr)),l=Math.max(l,s.distanceToSquared(An))}this.boundingSphere.radius=Math.sqrt(l),isNaN(this.boundingSphere.radius)&&Ut('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,i=this.attributes;if(e===null||i.position===void 0||i.normal===void 0||i.uv===void 0){Ut("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const s=i.position,l=i.normal,c=i.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new qn(new Float32Array(4*s.count),4));const d=this.getAttribute("tangent"),p=[],m=[];for(let T=0;T<s.count;T++)p[T]=new ee,m[T]=new ee;const h=new ee,g=new ee,x=new ee,_=new gt,y=new gt,M=new gt,A=new ee,b=new ee;function S(T,I,Z){h.fromBufferAttribute(s,T),g.fromBufferAttribute(s,I),x.fromBufferAttribute(s,Z),_.fromBufferAttribute(c,T),y.fromBufferAttribute(c,I),M.fromBufferAttribute(c,Z),g.sub(h),x.sub(h),y.sub(_),M.sub(_);const G=1/(y.x*M.y-M.x*y.y);isFinite(G)&&(A.copy(g).multiplyScalar(M.y).addScaledVector(x,-y.y).multiplyScalar(G),b.copy(x).multiplyScalar(y.x).addScaledVector(g,-M.x).multiplyScalar(G),p[T].add(A),p[I].add(A),p[Z].add(A),m[T].add(b),m[I].add(b),m[Z].add(b))}let N=this.groups;N.length===0&&(N=[{start:0,count:e.count}]);for(let T=0,I=N.length;T<I;++T){const Z=N[T],G=Z.start,K=Z.count;for(let ue=G,pe=G+K;ue<pe;ue+=3)S(e.getX(ue+0),e.getX(ue+1),e.getX(ue+2))}const O=new ee,z=new ee,k=new ee,L=new ee;function H(T){k.fromBufferAttribute(l,T),L.copy(k);const I=p[T];O.copy(I),O.sub(k.multiplyScalar(k.dot(I))).normalize(),z.crossVectors(L,I);const G=z.dot(m[T])<0?-1:1;d.setXYZW(T,O.x,O.y,O.z,G)}for(let T=0,I=N.length;T<I;++T){const Z=N[T],G=Z.start,K=Z.count;for(let ue=G,pe=G+K;ue<pe;ue+=3)H(e.getX(ue+0)),H(e.getX(ue+1)),H(e.getX(ue+2))}}computeVertexNormals(){const e=this.index,i=this.getAttribute("position");if(i!==void 0){let s=this.getAttribute("normal");if(s===void 0)s=new qn(new Float32Array(i.count*3),3),this.setAttribute("normal",s);else for(let _=0,y=s.count;_<y;_++)s.setXYZ(_,0,0,0);const l=new ee,c=new ee,d=new ee,p=new ee,m=new ee,h=new ee,g=new ee,x=new ee;if(e)for(let _=0,y=e.count;_<y;_+=3){const M=e.getX(_+0),A=e.getX(_+1),b=e.getX(_+2);l.fromBufferAttribute(i,M),c.fromBufferAttribute(i,A),d.fromBufferAttribute(i,b),g.subVectors(d,c),x.subVectors(l,c),g.cross(x),p.fromBufferAttribute(s,M),m.fromBufferAttribute(s,A),h.fromBufferAttribute(s,b),p.add(g),m.add(g),h.add(g),s.setXYZ(M,p.x,p.y,p.z),s.setXYZ(A,m.x,m.y,m.z),s.setXYZ(b,h.x,h.y,h.z)}else for(let _=0,y=i.count;_<y;_+=3)l.fromBufferAttribute(i,_+0),c.fromBufferAttribute(i,_+1),d.fromBufferAttribute(i,_+2),g.subVectors(d,c),x.subVectors(l,c),g.cross(x),s.setXYZ(_+0,g.x,g.y,g.z),s.setXYZ(_+1,g.x,g.y,g.z),s.setXYZ(_+2,g.x,g.y,g.z);this.normalizeNormals(),s.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let i=0,s=e.count;i<s;i++)An.fromBufferAttribute(e,i),An.normalize(),e.setXYZ(i,An.x,An.y,An.z)}toNonIndexed(){function e(p,m){const h=p.array,g=p.itemSize,x=p.normalized,_=new h.constructor(m.length*g);let y=0,M=0;for(let A=0,b=m.length;A<b;A++){p.isInterleavedBufferAttribute?y=m[A]*p.data.stride+p.offset:y=m[A]*g;for(let S=0;S<g;S++)_[M++]=h[y++]}return new qn(_,g,x)}if(this.index===null)return st("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const i=new Pn,s=this.index.array,l=this.attributes;for(const p in l){const m=l[p],h=e(m,s);i.setAttribute(p,h)}const c=this.morphAttributes;for(const p in c){const m=[],h=c[p];for(let g=0,x=h.length;g<x;g++){const _=h[g],y=e(_,s);m.push(y)}i.morphAttributes[p]=m}i.morphTargetsRelative=this.morphTargetsRelative;const d=this.groups;for(let p=0,m=d.length;p<m;p++){const h=d[p];i.addGroup(h.start,h.count,h.materialIndex)}return i}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const m=this.parameters;for(const h in m)m[h]!==void 0&&(e[h]=m[h]);return e}e.data={attributes:{}};const i=this.index;i!==null&&(e.data.index={type:i.array.constructor.name,array:Array.prototype.slice.call(i.array)});const s=this.attributes;for(const m in s){const h=s[m];e.data.attributes[m]=h.toJSON(e.data)}const l={};let c=!1;for(const m in this.morphAttributes){const h=this.morphAttributes[m],g=[];for(let x=0,_=h.length;x<_;x++){const y=h[x];g.push(y.toJSON(e.data))}g.length>0&&(l[m]=g,c=!0)}c&&(e.data.morphAttributes=l,e.data.morphTargetsRelative=this.morphTargetsRelative);const d=this.groups;d.length>0&&(e.data.groups=JSON.parse(JSON.stringify(d)));const p=this.boundingSphere;return p!==null&&(e.data.boundingSphere=p.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const i={};this.name=e.name;const s=e.index;s!==null&&this.setIndex(s.clone());const l=e.attributes;for(const h in l){const g=l[h];this.setAttribute(h,g.clone(i))}const c=e.morphAttributes;for(const h in c){const g=[],x=c[h];for(let _=0,y=x.length;_<y;_++)g.push(x[_].clone(i));this.morphAttributes[h]=g}this.morphTargetsRelative=e.morphTargetsRelative;const d=e.groups;for(let h=0,g=d.length;h<g;h++){const x=d[h];this.addGroup(x.start,x.count,x.materialIndex)}const p=e.boundingBox;p!==null&&(this.boundingBox=p.clone());const m=e.boundingSphere;return m!==null&&(this.boundingSphere=m.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}let Lb=0;class Ws extends ps{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Lb++}),this.uuid=ul(),this.name="",this.type="Material",this.blending=Vr,this.side=fs,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=hh,this.blendDst=ph,this.blendEquation=Bs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new ft(0,0,0),this.blendAlpha=0,this.depthFunc=jr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=S_,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Tr,this.stencilZFail=Tr,this.stencilZPass=Tr,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const i in e){const s=e[i];if(s===void 0){st(`Material: parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){st(`Material: '${i}' is not a property of THREE.${this.type}.`);continue}l&&l.isColor?l.set(s):l&&l.isVector3&&s&&s.isVector3?l.copy(s):this[i]=s}}toJSON(e){const i=e===void 0||typeof e=="string";i&&(e={textures:{},images:{}});const s={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.color&&this.color.isColor&&(s.color=this.color.getHex()),this.roughness!==void 0&&(s.roughness=this.roughness),this.metalness!==void 0&&(s.metalness=this.metalness),this.sheen!==void 0&&(s.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(s.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(s.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(s.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(s.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(s.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(s.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(s.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(s.shininess=this.shininess),this.clearcoat!==void 0&&(s.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(s.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(s.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(s.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(s.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,s.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(s.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(s.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(s.dispersion=this.dispersion),this.iridescence!==void 0&&(s.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(s.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(s.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(s.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(s.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(s.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(s.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(s.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(s.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(s.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(s.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(s.lightMap=this.lightMap.toJSON(e).uuid,s.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(s.aoMap=this.aoMap.toJSON(e).uuid,s.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(s.bumpMap=this.bumpMap.toJSON(e).uuid,s.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(s.normalMap=this.normalMap.toJSON(e).uuid,s.normalMapType=this.normalMapType,s.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(s.displacementMap=this.displacementMap.toJSON(e).uuid,s.displacementScale=this.displacementScale,s.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(s.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(s.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(s.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(s.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(s.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(s.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(s.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(s.combine=this.combine)),this.envMapRotation!==void 0&&(s.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(s.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(s.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(s.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(s.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(s.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(s.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(s.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(s.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(s.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(s.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(s.size=this.size),this.shadowSide!==null&&(s.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(s.sizeAttenuation=this.sizeAttenuation),this.blending!==Vr&&(s.blending=this.blending),this.side!==fs&&(s.side=this.side),this.vertexColors===!0&&(s.vertexColors=!0),this.opacity<1&&(s.opacity=this.opacity),this.transparent===!0&&(s.transparent=!0),this.blendSrc!==hh&&(s.blendSrc=this.blendSrc),this.blendDst!==ph&&(s.blendDst=this.blendDst),this.blendEquation!==Bs&&(s.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(s.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(s.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(s.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(s.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(s.blendAlpha=this.blendAlpha),this.depthFunc!==jr&&(s.depthFunc=this.depthFunc),this.depthTest===!1&&(s.depthTest=this.depthTest),this.depthWrite===!1&&(s.depthWrite=this.depthWrite),this.colorWrite===!1&&(s.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(s.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==S_&&(s.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(s.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(s.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Tr&&(s.stencilFail=this.stencilFail),this.stencilZFail!==Tr&&(s.stencilZFail=this.stencilZFail),this.stencilZPass!==Tr&&(s.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(s.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(s.rotation=this.rotation),this.polygonOffset===!0&&(s.polygonOffset=!0),this.polygonOffsetFactor!==0&&(s.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(s.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(s.linewidth=this.linewidth),this.dashSize!==void 0&&(s.dashSize=this.dashSize),this.gapSize!==void 0&&(s.gapSize=this.gapSize),this.scale!==void 0&&(s.scale=this.scale),this.dithering===!0&&(s.dithering=!0),this.alphaTest>0&&(s.alphaTest=this.alphaTest),this.alphaHash===!0&&(s.alphaHash=!0),this.alphaToCoverage===!0&&(s.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(s.premultipliedAlpha=!0),this.forceSinglePass===!0&&(s.forceSinglePass=!0),this.allowOverride===!1&&(s.allowOverride=!1),this.wireframe===!0&&(s.wireframe=!0),this.wireframeLinewidth>1&&(s.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(s.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(s.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(s.flatShading=!0),this.visible===!1&&(s.visible=!1),this.toneMapped===!1&&(s.toneMapped=!1),this.fog===!1&&(s.fog=!1),Object.keys(this.userData).length>0&&(s.userData=this.userData);function l(c){const d=[];for(const p in c){const m=c[p];delete m.metadata,d.push(m)}return d}if(i){const c=l(e.textures),d=l(e.images);c.length>0&&(s.textures=c),d.length>0&&(s.images=d)}return s}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const i=e.clippingPlanes;let s=null;if(i!==null){const l=i.length;s=new Array(l);for(let c=0;c!==l;++c)s[c]=i[c].clone()}return this.clippingPlanes=s,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const Sa=new ee,Qd=new ee,Dc=new ee,rs=new ee,Jd=new ee,Nc=new ee,$d=new ee;class mu{constructor(e=new ee,i=new ee(0,0,-1)){this.origin=e,this.direction=i}set(e,i){return this.origin.copy(e),this.direction.copy(i),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,i){return i.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Sa)),this}closestPointToPoint(e,i){i.subVectors(e,this.origin);const s=i.dot(this.direction);return s<0?i.copy(this.origin):i.copy(this.origin).addScaledVector(this.direction,s)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const i=Sa.subVectors(e,this.origin).dot(this.direction);return i<0?this.origin.distanceToSquared(e):(Sa.copy(this.origin).addScaledVector(this.direction,i),Sa.distanceToSquared(e))}distanceSqToSegment(e,i,s,l){Qd.copy(e).add(i).multiplyScalar(.5),Dc.copy(i).sub(e).normalize(),rs.copy(this.origin).sub(Qd);const c=e.distanceTo(i)*.5,d=-this.direction.dot(Dc),p=rs.dot(this.direction),m=-rs.dot(Dc),h=rs.lengthSq(),g=Math.abs(1-d*d);let x,_,y,M;if(g>0)if(x=d*m-p,_=d*p-m,M=c*g,x>=0)if(_>=-M)if(_<=M){const A=1/g;x*=A,_*=A,y=x*(x+d*_+2*p)+_*(d*x+_+2*m)+h}else _=c,x=Math.max(0,-(d*_+p)),y=-x*x+_*(_+2*m)+h;else _=-c,x=Math.max(0,-(d*_+p)),y=-x*x+_*(_+2*m)+h;else _<=-M?(x=Math.max(0,-(-d*c+p)),_=x>0?-c:Math.min(Math.max(-c,-m),c),y=-x*x+_*(_+2*m)+h):_<=M?(x=0,_=Math.min(Math.max(-c,-m),c),y=_*(_+2*m)+h):(x=Math.max(0,-(d*c+p)),_=x>0?c:Math.min(Math.max(-c,-m),c),y=-x*x+_*(_+2*m)+h);else _=d>0?-c:c,x=Math.max(0,-(d*_+p)),y=-x*x+_*(_+2*m)+h;return s&&s.copy(this.origin).addScaledVector(this.direction,x),l&&l.copy(Qd).addScaledVector(Dc,_),y}intersectSphere(e,i){Sa.subVectors(e.center,this.origin);const s=Sa.dot(this.direction),l=Sa.dot(Sa)-s*s,c=e.radius*e.radius;if(l>c)return null;const d=Math.sqrt(c-l),p=s-d,m=s+d;return m<0?null:p<0?this.at(m,i):this.at(p,i)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const i=e.normal.dot(this.direction);if(i===0)return e.distanceToPoint(this.origin)===0?0:null;const s=-(this.origin.dot(e.normal)+e.constant)/i;return s>=0?s:null}intersectPlane(e,i){const s=this.distanceToPlane(e);return s===null?null:this.at(s,i)}intersectsPlane(e){const i=e.distanceToPoint(this.origin);return i===0||e.normal.dot(this.direction)*i<0}intersectBox(e,i){let s,l,c,d,p,m;const h=1/this.direction.x,g=1/this.direction.y,x=1/this.direction.z,_=this.origin;return h>=0?(s=(e.min.x-_.x)*h,l=(e.max.x-_.x)*h):(s=(e.max.x-_.x)*h,l=(e.min.x-_.x)*h),g>=0?(c=(e.min.y-_.y)*g,d=(e.max.y-_.y)*g):(c=(e.max.y-_.y)*g,d=(e.min.y-_.y)*g),s>d||c>l||((c>s||isNaN(s))&&(s=c),(d<l||isNaN(l))&&(l=d),x>=0?(p=(e.min.z-_.z)*x,m=(e.max.z-_.z)*x):(p=(e.max.z-_.z)*x,m=(e.min.z-_.z)*x),s>m||p>l)||((p>s||s!==s)&&(s=p),(m<l||l!==l)&&(l=m),l<0)?null:this.at(s>=0?s:l,i)}intersectsBox(e){return this.intersectBox(e,Sa)!==null}intersectTriangle(e,i,s,l,c){Jd.subVectors(i,e),Nc.subVectors(s,e),$d.crossVectors(Jd,Nc);let d=this.direction.dot($d),p;if(d>0){if(l)return null;p=1}else if(d<0)p=-1,d=-d;else return null;rs.subVectors(this.origin,e);const m=p*this.direction.dot(Nc.crossVectors(rs,Nc));if(m<0)return null;const h=p*this.direction.dot(Jd.cross(rs));if(h<0||m+h>d)return null;const g=-p*rs.dot($d);return g<0?null:this.at(g/d,c)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class av extends Ws{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new ft(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new hs,this.combine=zx,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const z_=new rn,zs=new mu,Uc=new fl,F_=new ee,Lc=new ee,Oc=new ee,Pc=new ee,eh=new ee,zc=new ee,B_=new ee,Fc=new ee;class zi extends Rn{constructor(e=new Pn,i=new av){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,i){return super.copy(e,i),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const i=this.geometry.morphAttributes,s=Object.keys(i);if(s.length>0){const l=i[s[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,d=l.length;c<d;c++){const p=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[p]=c}}}}getVertexPosition(e,i){const s=this.geometry,l=s.attributes.position,c=s.morphAttributes.position,d=s.morphTargetsRelative;i.fromBufferAttribute(l,e);const p=this.morphTargetInfluences;if(c&&p){zc.set(0,0,0);for(let m=0,h=c.length;m<h;m++){const g=p[m],x=c[m];g!==0&&(eh.fromBufferAttribute(x,e),d?zc.addScaledVector(eh,g):zc.addScaledVector(eh.sub(i),g))}i.add(zc)}return i}raycast(e,i){const s=this.geometry,l=this.material,c=this.matrixWorld;l!==void 0&&(s.boundingSphere===null&&s.computeBoundingSphere(),Uc.copy(s.boundingSphere),Uc.applyMatrix4(c),zs.copy(e.ray).recast(e.near),!(Uc.containsPoint(zs.origin)===!1&&(zs.intersectSphere(Uc,F_)===null||zs.origin.distanceToSquared(F_)>(e.far-e.near)**2))&&(z_.copy(c).invert(),zs.copy(e.ray).applyMatrix4(z_),!(s.boundingBox!==null&&zs.intersectsBox(s.boundingBox)===!1)&&this._computeIntersections(e,i,zs)))}_computeIntersections(e,i,s){let l;const c=this.geometry,d=this.material,p=c.index,m=c.attributes.position,h=c.attributes.uv,g=c.attributes.uv1,x=c.attributes.normal,_=c.groups,y=c.drawRange;if(p!==null)if(Array.isArray(d))for(let M=0,A=_.length;M<A;M++){const b=_[M],S=d[b.materialIndex],N=Math.max(b.start,y.start),O=Math.min(p.count,Math.min(b.start+b.count,y.start+y.count));for(let z=N,k=O;z<k;z+=3){const L=p.getX(z),H=p.getX(z+1),T=p.getX(z+2);l=Bc(this,S,e,s,h,g,x,L,H,T),l&&(l.faceIndex=Math.floor(z/3),l.face.materialIndex=b.materialIndex,i.push(l))}}else{const M=Math.max(0,y.start),A=Math.min(p.count,y.start+y.count);for(let b=M,S=A;b<S;b+=3){const N=p.getX(b),O=p.getX(b+1),z=p.getX(b+2);l=Bc(this,d,e,s,h,g,x,N,O,z),l&&(l.faceIndex=Math.floor(b/3),i.push(l))}}else if(m!==void 0)if(Array.isArray(d))for(let M=0,A=_.length;M<A;M++){const b=_[M],S=d[b.materialIndex],N=Math.max(b.start,y.start),O=Math.min(m.count,Math.min(b.start+b.count,y.start+y.count));for(let z=N,k=O;z<k;z+=3){const L=z,H=z+1,T=z+2;l=Bc(this,S,e,s,h,g,x,L,H,T),l&&(l.faceIndex=Math.floor(z/3),l.face.materialIndex=b.materialIndex,i.push(l))}}else{const M=Math.max(0,y.start),A=Math.min(m.count,y.start+y.count);for(let b=M,S=A;b<S;b+=3){const N=b,O=b+1,z=b+2;l=Bc(this,d,e,s,h,g,x,N,O,z),l&&(l.faceIndex=Math.floor(b/3),i.push(l))}}}}function Ob(r,e,i,s,l,c,d,p){let m;if(e.side===ni?m=s.intersectTriangle(d,c,l,!0,p):m=s.intersectTriangle(l,c,d,e.side===fs,p),m===null)return null;Fc.copy(p),Fc.applyMatrix4(r.matrixWorld);const h=i.ray.origin.distanceTo(Fc);return h<i.near||h>i.far?null:{distance:h,point:Fc.clone(),object:r}}function Bc(r,e,i,s,l,c,d,p,m,h){r.getVertexPosition(p,Lc),r.getVertexPosition(m,Oc),r.getVertexPosition(h,Pc);const g=Ob(r,e,i,s,Lc,Oc,Pc,B_);if(g){const x=new ee;Ai.getBarycoord(B_,Lc,Oc,Pc,x),l&&(g.uv=Ai.getInterpolatedAttribute(l,p,m,h,x,new gt)),c&&(g.uv1=Ai.getInterpolatedAttribute(c,p,m,h,x,new gt)),d&&(g.normal=Ai.getInterpolatedAttribute(d,p,m,h,x,new ee),g.normal.dot(s.direction)>0&&g.normal.multiplyScalar(-1));const _={a:p,b:m,c:h,normal:new ee,materialIndex:0};Ai.getNormal(Lc,Oc,Pc,_.normal),g.face=_,g.barycoord=x}return g}class Pb extends Wn{constructor(e=null,i=1,s=1,l,c,d,p,m,h=On,g=On,x,_){super(null,d,p,m,h,g,l,c,x,_),this.isDataTexture=!0,this.image={data:e,width:i,height:s},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const th=new ee,zb=new ee,Fb=new ht;class ls{constructor(e=new ee(1,0,0),i=0){this.isPlane=!0,this.normal=e,this.constant=i}set(e,i){return this.normal.copy(e),this.constant=i,this}setComponents(e,i,s,l){return this.normal.set(e,i,s),this.constant=l,this}setFromNormalAndCoplanarPoint(e,i){return this.normal.copy(e),this.constant=-i.dot(this.normal),this}setFromCoplanarPoints(e,i,s){const l=th.subVectors(s,i).cross(zb.subVectors(e,i)).normalize();return this.setFromNormalAndCoplanarPoint(l,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,i){return i.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,i,s=!0){const l=e.delta(th),c=this.normal.dot(l);if(c===0)return this.distanceToPoint(e.start)===0?i.copy(e.start):null;const d=-(e.start.dot(this.normal)+this.constant)/c;return s===!0&&(d<0||d>1)?null:i.copy(e.start).addScaledVector(l,d)}intersectsLine(e){const i=this.distanceToPoint(e.start),s=this.distanceToPoint(e.end);return i<0&&s>0||s<0&&i>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,i){const s=i||Fb.getNormalMatrix(e),l=this.coplanarPoint(th).applyMatrix4(e),c=this.normal.applyMatrix3(s).normalize();return this.constant=-l.dot(c),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Fs=new fl,Bb=new gt(.5,.5),Ic=new ee;class xp{constructor(e=new ls,i=new ls,s=new ls,l=new ls,c=new ls,d=new ls){this.planes=[e,i,s,l,c,d]}set(e,i,s,l,c,d){const p=this.planes;return p[0].copy(e),p[1].copy(i),p[2].copy(s),p[3].copy(l),p[4].copy(c),p[5].copy(d),this}copy(e){const i=this.planes;for(let s=0;s<6;s++)i[s].copy(e.planes[s]);return this}setFromProjectionMatrix(e,i=qi,s=!1){const l=this.planes,c=e.elements,d=c[0],p=c[1],m=c[2],h=c[3],g=c[4],x=c[5],_=c[6],y=c[7],M=c[8],A=c[9],b=c[10],S=c[11],N=c[12],O=c[13],z=c[14],k=c[15];if(l[0].setComponents(h-d,y-g,S-M,k-N).normalize(),l[1].setComponents(h+d,y+g,S+M,k+N).normalize(),l[2].setComponents(h+p,y+x,S+A,k+O).normalize(),l[3].setComponents(h-p,y-x,S-A,k-O).normalize(),s)l[4].setComponents(m,_,b,z).normalize(),l[5].setComponents(h-m,y-_,S-b,k-z).normalize();else if(l[4].setComponents(h-m,y-_,S-b,k-z).normalize(),i===qi)l[5].setComponents(h+m,y+_,S+b,k+z).normalize();else if(i===ll)l[5].setComponents(m,_,b,z).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+i);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Fs.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const i=e.geometry;i.boundingSphere===null&&i.computeBoundingSphere(),Fs.copy(i.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Fs)}intersectsSprite(e){Fs.center.set(0,0,0);const i=Bb.distanceTo(e.center);return Fs.radius=.7071067811865476+i,Fs.applyMatrix4(e.matrixWorld),this.intersectsSphere(Fs)}intersectsSphere(e){const i=this.planes,s=e.center,l=-e.radius;for(let c=0;c<6;c++)if(i[c].distanceToPoint(s)<l)return!1;return!0}intersectsBox(e){const i=this.planes;for(let s=0;s<6;s++){const l=i[s];if(Ic.x=l.normal.x>0?e.max.x:e.min.x,Ic.y=l.normal.y>0?e.max.y:e.min.y,Ic.z=l.normal.z>0?e.max.z:e.min.z,l.distanceToPoint(Ic)<0)return!1}return!0}containsPoint(e){const i=this.planes;for(let s=0;s<6;s++)if(i[s].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Wr extends Ws{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new ft(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const fu=new ee,du=new ee,I_=new rn,Jo=new mu,Hc=new fl,nh=new ee,H_=new ee;class Ib extends Rn{constructor(e=new Pn,i=new Wr){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,i){return super.copy(e,i),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const i=e.attributes.position,s=[0];for(let l=1,c=i.count;l<c;l++)fu.fromBufferAttribute(i,l-1),du.fromBufferAttribute(i,l),s[l]=s[l-1],s[l]+=fu.distanceTo(du);e.setAttribute("lineDistance",new Cn(s,1))}else st("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,i){const s=this.geometry,l=this.matrixWorld,c=e.params.Line.threshold,d=s.drawRange;if(s.boundingSphere===null&&s.computeBoundingSphere(),Hc.copy(s.boundingSphere),Hc.applyMatrix4(l),Hc.radius+=c,e.ray.intersectsSphere(Hc)===!1)return;I_.copy(l).invert(),Jo.copy(e.ray).applyMatrix4(I_);const p=c/((this.scale.x+this.scale.y+this.scale.z)/3),m=p*p,h=this.isLineSegments?2:1,g=s.index,_=s.attributes.position;if(g!==null){const y=Math.max(0,d.start),M=Math.min(g.count,d.start+d.count);for(let A=y,b=M-1;A<b;A+=h){const S=g.getX(A),N=g.getX(A+1),O=Gc(this,e,Jo,m,S,N,A);O&&i.push(O)}if(this.isLineLoop){const A=g.getX(M-1),b=g.getX(y),S=Gc(this,e,Jo,m,A,b,M-1);S&&i.push(S)}}else{const y=Math.max(0,d.start),M=Math.min(_.count,d.start+d.count);for(let A=y,b=M-1;A<b;A+=h){const S=Gc(this,e,Jo,m,A,A+1,A);S&&i.push(S)}if(this.isLineLoop){const A=Gc(this,e,Jo,m,M-1,y,M-1);A&&i.push(A)}}}updateMorphTargets(){const i=this.geometry.morphAttributes,s=Object.keys(i);if(s.length>0){const l=i[s[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,d=l.length;c<d;c++){const p=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[p]=c}}}}}function Gc(r,e,i,s,l,c,d){const p=r.geometry.attributes.position;if(fu.fromBufferAttribute(p,l),du.fromBufferAttribute(p,c),i.distanceSqToSegment(fu,du,nh,H_)>s)return;nh.applyMatrix4(r.matrixWorld);const h=e.ray.origin.distanceTo(nh);if(!(h<e.near||h>e.far))return{distance:h,point:H_.clone().applyMatrix4(r.matrixWorld),index:d,face:null,faceIndex:null,barycoord:null,object:r}}const G_=new ee,V_=new ee;class cl extends Ib{constructor(e,i){super(e,i),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const i=e.attributes.position,s=[];for(let l=0,c=i.count;l<c;l+=2)G_.fromBufferAttribute(i,l),V_.fromBufferAttribute(i,l+1),s[l]=l===0?0:s[l-1],s[l+1]=s[l]+G_.distanceTo(V_);e.setAttribute("lineDistance",new Cn(s,1))}else st("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class sv extends Ws{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new ft(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const k_=new rn,ip=new mu,Vc=new fl,kc=new ee;class Hb extends Rn{constructor(e=new Pn,i=new sv){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,i){return super.copy(e,i),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,i){const s=this.geometry,l=this.matrixWorld,c=e.params.Points.threshold,d=s.drawRange;if(s.boundingSphere===null&&s.computeBoundingSphere(),Vc.copy(s.boundingSphere),Vc.applyMatrix4(l),Vc.radius+=c,e.ray.intersectsSphere(Vc)===!1)return;k_.copy(l).invert(),ip.copy(e.ray).applyMatrix4(k_);const p=c/((this.scale.x+this.scale.y+this.scale.z)/3),m=p*p,h=s.index,x=s.attributes.position;if(h!==null){const _=Math.max(0,d.start),y=Math.min(h.count,d.start+d.count);for(let M=_,A=y;M<A;M++){const b=h.getX(M);kc.fromBufferAttribute(x,b),j_(kc,b,m,l,e,i,this)}}else{const _=Math.max(0,d.start),y=Math.min(x.count,d.start+d.count);for(let M=_,A=y;M<A;M++)kc.fromBufferAttribute(x,M),j_(kc,M,m,l,e,i,this)}}updateMorphTargets(){const i=this.geometry.morphAttributes,s=Object.keys(i);if(s.length>0){const l=i[s[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,d=l.length;c<d;c++){const p=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[p]=c}}}}}function j_(r,e,i,s,l,c,d){const p=ip.distanceSqToPoint(r);if(p<i){const m=new ee;ip.closestPointToPoint(r,m),m.applyMatrix4(s);const h=l.ray.origin.distanceTo(m);if(h<l.near||h>l.far)return;c.push({distance:h,distanceToRay:Math.sqrt(p),point:m,index:e,face:null,faceIndex:null,barycoord:null,object:d})}}class rv extends Wn{constructor(e=[],i=ks,s,l,c,d,p,m,h,g){super(e,i,s,l,c,d,p,m,h,g),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class qr extends Wn{constructor(e,i,s=Ki,l,c,d,p=On,m=On,h,g=Aa,x=1){if(g!==Aa&&g!==Gs)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const _={width:e,height:i,depth:x};super(_,l,c,d,p,m,g,s,h),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new _p(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const i=super.toJSON(e);return this.compareFunction!==null&&(i.compareFunction=this.compareFunction),i}}class Gb extends qr{constructor(e,i=Ki,s=ks,l,c,d=On,p=On,m,h=Aa){const g={width:e,height:e,depth:1},x=[g,g,g,g,g,g];super(e,e,i,s,l,c,d,p,m,h),this.image=x,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class ov extends Wn{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Kr extends Pn{constructor(e=1,i=1,s=1,l=1,c=1,d=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:i,depth:s,widthSegments:l,heightSegments:c,depthSegments:d};const p=this;l=Math.floor(l),c=Math.floor(c),d=Math.floor(d);const m=[],h=[],g=[],x=[];let _=0,y=0;M("z","y","x",-1,-1,s,i,e,d,c,0),M("z","y","x",1,-1,s,i,-e,d,c,1),M("x","z","y",1,1,e,s,i,l,d,2),M("x","z","y",1,-1,e,s,-i,l,d,3),M("x","y","z",1,-1,e,i,s,l,c,4),M("x","y","z",-1,-1,e,i,-s,l,c,5),this.setIndex(m),this.setAttribute("position",new Cn(h,3)),this.setAttribute("normal",new Cn(g,3)),this.setAttribute("uv",new Cn(x,2));function M(A,b,S,N,O,z,k,L,H,T,I){const Z=z/H,G=k/T,K=z/2,ue=k/2,pe=L/2,F=H+1,D=T+1;let P=0,q=0;const he=new ee;for(let _e=0;_e<D;_e++){const B=_e*G-ue;for(let Q=0;Q<F;Q++){const ve=Q*Z-K;he[A]=ve*N,he[b]=B*O,he[S]=pe,h.push(he.x,he.y,he.z),he[A]=0,he[b]=0,he[S]=L>0?1:-1,g.push(he.x,he.y,he.z),x.push(Q/H),x.push(1-_e/T),P+=1}}for(let _e=0;_e<T;_e++)for(let B=0;B<H;B++){const Q=_+B+F*_e,ve=_+B+F*(_e+1),Ae=_+(B+1)+F*(_e+1),Ce=_+(B+1)+F*_e;m.push(Q,ve,Ce),m.push(ve,Ae,Ce),q+=6}p.addGroup(y,q,I),y+=q,_+=P}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Kr(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}const jc=new ee,Xc=new ee,ih=new ee,Wc=new Ai;class X_ extends Pn{constructor(e=null,i=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:e,thresholdAngle:i},e!==null){const l=Math.pow(10,4),c=Math.cos(sl*i),d=e.getIndex(),p=e.getAttribute("position"),m=d?d.count:p.count,h=[0,0,0],g=["a","b","c"],x=new Array(3),_={},y=[];for(let M=0;M<m;M+=3){d?(h[0]=d.getX(M),h[1]=d.getX(M+1),h[2]=d.getX(M+2)):(h[0]=M,h[1]=M+1,h[2]=M+2);const{a:A,b,c:S}=Wc;if(A.fromBufferAttribute(p,h[0]),b.fromBufferAttribute(p,h[1]),S.fromBufferAttribute(p,h[2]),Wc.getNormal(ih),x[0]=`${Math.round(A.x*l)},${Math.round(A.y*l)},${Math.round(A.z*l)}`,x[1]=`${Math.round(b.x*l)},${Math.round(b.y*l)},${Math.round(b.z*l)}`,x[2]=`${Math.round(S.x*l)},${Math.round(S.y*l)},${Math.round(S.z*l)}`,!(x[0]===x[1]||x[1]===x[2]||x[2]===x[0]))for(let N=0;N<3;N++){const O=(N+1)%3,z=x[N],k=x[O],L=Wc[g[N]],H=Wc[g[O]],T=`${z}_${k}`,I=`${k}_${z}`;I in _&&_[I]?(ih.dot(_[I].normal)<=c&&(y.push(L.x,L.y,L.z),y.push(H.x,H.y,H.z)),_[I]=null):T in _||(_[T]={index0:h[N],index1:h[O],normal:ih.clone()})}}for(const M in _)if(_[M]){const{index0:A,index1:b}=_[M];jc.fromBufferAttribute(p,A),Xc.fromBufferAttribute(p,b),y.push(jc.x,jc.y,jc.z),y.push(Xc.x,Xc.y,Xc.z)}this.setAttribute("position",new Cn(y,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}}class gu extends Pn{constructor(e=1,i=1,s=1,l=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:i,widthSegments:s,heightSegments:l};const c=e/2,d=i/2,p=Math.floor(s),m=Math.floor(l),h=p+1,g=m+1,x=e/p,_=i/m,y=[],M=[],A=[],b=[];for(let S=0;S<g;S++){const N=S*_-d;for(let O=0;O<h;O++){const z=O*x-c;M.push(z,-N,0),A.push(0,0,1),b.push(O/p),b.push(1-S/m)}}for(let S=0;S<m;S++)for(let N=0;N<p;N++){const O=N+h*S,z=N+h*(S+1),k=N+1+h*(S+1),L=N+1+h*S;y.push(O,z,L),y.push(z,k,L)}this.setIndex(y),this.setAttribute("position",new Cn(M,3)),this.setAttribute("normal",new Cn(A,3)),this.setAttribute("uv",new Cn(b,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new gu(e.width,e.height,e.widthSegments,e.heightSegments)}}function Yr(r){const e={};for(const i in r){e[i]={};for(const s in r[i]){const l=r[i][s];if(W_(l))l.isRenderTargetTexture?(st("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[i][s]=null):e[i][s]=l.clone();else if(Array.isArray(l))if(W_(l[0])){const c=[];for(let d=0,p=l.length;d<p;d++)c[d]=l[d].clone();e[i][s]=c}else e[i][s]=l.slice();else e[i][s]=l}}return e}function Xn(r){const e={};for(let i=0;i<r.length;i++){const s=Yr(r[i]);for(const l in s)e[l]=s[l]}return e}function W_(r){return r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)}function Vb(r){const e=[];for(let i=0;i<r.length;i++)e.push(r[i].clone());return e}function lv(r){const e=r.getRenderTarget();return e===null?r.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:wt.workingColorSpace}const kb={clone:Yr,merge:Xn};var jb=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Xb=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Qi extends Ws{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=jb,this.fragmentShader=Xb,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Yr(e.uniforms),this.uniformsGroups=Vb(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const i=super.toJSON(e);i.glslVersion=this.glslVersion,i.uniforms={};for(const l in this.uniforms){const d=this.uniforms[l].value;d&&d.isTexture?i.uniforms[l]={type:"t",value:d.toJSON(e).uuid}:d&&d.isColor?i.uniforms[l]={type:"c",value:d.getHex()}:d&&d.isVector2?i.uniforms[l]={type:"v2",value:d.toArray()}:d&&d.isVector3?i.uniforms[l]={type:"v3",value:d.toArray()}:d&&d.isVector4?i.uniforms[l]={type:"v4",value:d.toArray()}:d&&d.isMatrix3?i.uniforms[l]={type:"m3",value:d.toArray()}:d&&d.isMatrix4?i.uniforms[l]={type:"m4",value:d.toArray()}:i.uniforms[l]={value:d}}Object.keys(this.defines).length>0&&(i.defines=this.defines),i.vertexShader=this.vertexShader,i.fragmentShader=this.fragmentShader,i.lights=this.lights,i.clipping=this.clipping;const s={};for(const l in this.extensions)this.extensions[l]===!0&&(s[l]=!0);return Object.keys(s).length>0&&(i.extensions=s),i}}class Wb extends Qi{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class q_ extends Ws{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new ft(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new ft(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=ep,this.normalScale=new gt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new hs,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class qb extends Ws{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=nb,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Yb extends Ws{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Y_={enabled:!1,files:{},add:function(r,e){this.enabled!==!1&&(Z_(r)||(this.files[r]=e))},get:function(r){if(this.enabled!==!1&&!Z_(r))return this.files[r]},remove:function(r){delete this.files[r]},clear:function(){this.files={}}};function Z_(r){try{const e=r.slice(r.indexOf(":")+1);return new URL(e).protocol==="blob:"}catch{return!1}}class Zb{constructor(e,i,s){const l=this;let c=!1,d=0,p=0,m;const h=[];this.onStart=void 0,this.onLoad=e,this.onProgress=i,this.onError=s,this._abortController=null,this.itemStart=function(g){p++,c===!1&&l.onStart!==void 0&&l.onStart(g,d,p),c=!0},this.itemEnd=function(g){d++,l.onProgress!==void 0&&l.onProgress(g,d,p),d===p&&(c=!1,l.onLoad!==void 0&&l.onLoad())},this.itemError=function(g){l.onError!==void 0&&l.onError(g)},this.resolveURL=function(g){return m?m(g):g},this.setURLModifier=function(g){return m=g,this},this.addHandler=function(g,x){return h.push(g,x),this},this.removeHandler=function(g){const x=h.indexOf(g);return x!==-1&&h.splice(x,2),this},this.getHandler=function(g){for(let x=0,_=h.length;x<_;x+=2){const y=h[x],M=h[x+1];if(y.global&&(y.lastIndex=0),y.test(g))return M}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){return this._abortController||(this._abortController=new AbortController),this._abortController}}const Kb=new Zb;class vp{constructor(e){this.manager=e!==void 0?e:Kb,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}load(){}loadAsync(e,i){const s=this;return new Promise(function(l,c){s.load(e,l,i,c)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}}vp.DEFAULT_MATERIAL_NAME="__DEFAULT";const ya={};class Qb extends Error{constructor(e,i){super(e),this.response=i}}class Jb extends vp{constructor(e){super(e),this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,i,s,l){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const c=Y_.get(`file:${e}`);if(c!==void 0){this.manager.itemStart(e),setTimeout(()=>{i&&i(c),this.manager.itemEnd(e)},0);return}if(ya[e]!==void 0){ya[e].push({onLoad:i,onProgress:s,onError:l});return}ya[e]=[],ya[e].push({onLoad:i,onProgress:s,onError:l});const d=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),p=this.mimeType,m=this.responseType;fetch(d).then(h=>{if(h.status===200||h.status===0){if(h.status===0&&st("FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||h.body===void 0||h.body.getReader===void 0)return h;const g=ya[e],x=h.body.getReader(),_=h.headers.get("X-File-Size")||h.headers.get("Content-Length"),y=_?parseInt(_):0,M=y!==0;let A=0;const b=new ReadableStream({start(S){N();function N(){x.read().then(({done:O,value:z})=>{if(O)S.close();else{A+=z.byteLength;const k=new ProgressEvent("progress",{lengthComputable:M,loaded:A,total:y});for(let L=0,H=g.length;L<H;L++){const T=g[L];T.onProgress&&T.onProgress(k)}S.enqueue(z),N()}},O=>{S.error(O)})}}});return new Response(b)}else throw new Qb(`fetch for "${h.url}" responded with ${h.status}: ${h.statusText}`,h)}).then(h=>{switch(m){case"arraybuffer":return h.arrayBuffer();case"blob":return h.blob();case"document":return h.text().then(g=>new DOMParser().parseFromString(g,p));case"json":return h.json();default:if(p==="")return h.text();{const x=/charset="?([^;"\s]*)"?/i.exec(p),_=x&&x[1]?x[1].toLowerCase():void 0,y=new TextDecoder(_);return h.arrayBuffer().then(M=>y.decode(M))}}}).then(h=>{Y_.add(`file:${e}`,h);const g=ya[e];delete ya[e];for(let x=0,_=g.length;x<_;x++){const y=g[x];y.onLoad&&y.onLoad(h)}}).catch(h=>{const g=ya[e];if(g===void 0)throw this.manager.itemError(e),h;delete ya[e];for(let x=0,_=g.length;x<_;x++){const y=g[x];y.onError&&y.onError(h)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}class cv extends Rn{constructor(e,i=1){super(),this.isLight=!0,this.type="Light",this.color=new ft(e),this.intensity=i}dispose(){this.dispatchEvent({type:"dispose"})}copy(e,i){return super.copy(e,i),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const i=super.toJSON(e);return i.object.color=this.color.getHex(),i.object.intensity=this.intensity,i}}const ah=new rn,K_=new ee,Q_=new ee;class $b{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new gt(512,512),this.mapType=gi,this.map=null,this.mapPass=null,this.matrix=new rn,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new xp,this._frameExtents=new gt(1,1),this._viewportCount=1,this._viewports=[new cn(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const i=this.camera,s=this.matrix;K_.setFromMatrixPosition(e.matrixWorld),i.position.copy(K_),Q_.setFromMatrixPosition(e.target.matrixWorld),i.lookAt(Q_),i.updateMatrixWorld(),ah.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix(ah,i.coordinateSystem,i.reversedDepth),i.coordinateSystem===ll||i.reversedDepth?s.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):s.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),s.multiply(ah)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const qc=new ee,Yc=new ds,Vi=new ee;class uv extends Rn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new rn,this.projectionMatrix=new rn,this.projectionMatrixInverse=new rn,this.coordinateSystem=qi,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,i){return super.copy(e,i),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(qc,Yc,Vi),Vi.x===1&&Vi.y===1&&Vi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(qc,Yc,Vi.set(1,1,1)).invert()}updateWorldMatrix(e,i){super.updateWorldMatrix(e,i),this.matrixWorld.decompose(qc,Yc,Vi),Vi.x===1&&Vi.y===1&&Vi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(qc,Yc,Vi.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const os=new ee,J_=new gt,$_=new gt;class mi extends uv{constructor(e=50,i=1,s=.1,l=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=s,this.far=l,this.focus=10,this.aspect=i,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,i){return super.copy(e,i),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const i=.5*this.getFilmHeight()/e;this.fov=np*2*Math.atan(i),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(sl*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return np*2*Math.atan(Math.tan(sl*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,i,s){os.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(os.x,os.y).multiplyScalar(-e/os.z),os.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),s.set(os.x,os.y).multiplyScalar(-e/os.z)}getViewSize(e,i){return this.getViewBounds(e,J_,$_),i.subVectors($_,J_)}setViewOffset(e,i,s,l,c,d){this.aspect=e/i,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=i,this.view.offsetX=s,this.view.offsetY=l,this.view.width=c,this.view.height=d,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let i=e*Math.tan(sl*.5*this.fov)/this.zoom,s=2*i,l=this.aspect*s,c=-.5*l;const d=this.view;if(this.view!==null&&this.view.enabled){const m=d.fullWidth,h=d.fullHeight;c+=d.offsetX*l/m,i-=d.offsetY*s/h,l*=d.width/m,s*=d.height/h}const p=this.filmOffset;p!==0&&(c+=e*p/this.getFilmWidth()),this.projectionMatrix.makePerspective(c,c+l,i,i-s,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const i=super.toJSON(e);return i.object.fov=this.fov,i.object.zoom=this.zoom,i.object.near=this.near,i.object.far=this.far,i.object.focus=this.focus,i.object.aspect=this.aspect,this.view!==null&&(i.object.view=Object.assign({},this.view)),i.object.filmGauge=this.filmGauge,i.object.filmOffset=this.filmOffset,i}}class _u extends uv{constructor(e=-1,i=1,s=1,l=-1,c=.1,d=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=i,this.top=s,this.bottom=l,this.near=c,this.far=d,this.updateProjectionMatrix()}copy(e,i){return super.copy(e,i),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,i,s,l,c,d){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=i,this.view.offsetX=s,this.view.offsetY=l,this.view.width=c,this.view.height=d,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),i=(this.top-this.bottom)/(2*this.zoom),s=(this.right+this.left)/2,l=(this.top+this.bottom)/2;let c=s-e,d=s+e,p=l+i,m=l-i;if(this.view!==null&&this.view.enabled){const h=(this.right-this.left)/this.view.fullWidth/this.zoom,g=(this.top-this.bottom)/this.view.fullHeight/this.zoom;c+=h*this.view.offsetX,d=c+h*this.view.width,p-=g*this.view.offsetY,m=p-g*this.view.height}this.projectionMatrix.makeOrthographic(c,d,p,m,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const i=super.toJSON(e);return i.object.zoom=this.zoom,i.object.left=this.left,i.object.right=this.right,i.object.top=this.top,i.object.bottom=this.bottom,i.object.near=this.near,i.object.far=this.far,this.view!==null&&(i.object.view=Object.assign({},this.view)),i}}class eM extends $b{constructor(){super(new _u(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class zr extends cv{constructor(e,i){super(e,i),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Rn.DEFAULT_UP),this.updateMatrix(),this.target=new Rn,this.shadow=new eM}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){const i=super.toJSON(e);return i.object.shadow=this.shadow.toJSON(),i.object.target=this.target.uuid,i}}class Zc extends cv{constructor(e,i){super(e,i),this.isAmbientLight=!0,this.type="AmbientLight"}}const Fr=-90,Br=1;class tM extends Rn{constructor(e,i,s){super(),this.type="CubeCamera",this.renderTarget=s,this.coordinateSystem=null,this.activeMipmapLevel=0;const l=new mi(Fr,Br,e,i);l.layers=this.layers,this.add(l);const c=new mi(Fr,Br,e,i);c.layers=this.layers,this.add(c);const d=new mi(Fr,Br,e,i);d.layers=this.layers,this.add(d);const p=new mi(Fr,Br,e,i);p.layers=this.layers,this.add(p);const m=new mi(Fr,Br,e,i);m.layers=this.layers,this.add(m);const h=new mi(Fr,Br,e,i);h.layers=this.layers,this.add(h)}updateCoordinateSystem(){const e=this.coordinateSystem,i=this.children.concat(),[s,l,c,d,p,m]=i;for(const h of i)this.remove(h);if(e===qi)s.up.set(0,1,0),s.lookAt(1,0,0),l.up.set(0,1,0),l.lookAt(-1,0,0),c.up.set(0,0,-1),c.lookAt(0,1,0),d.up.set(0,0,1),d.lookAt(0,-1,0),p.up.set(0,1,0),p.lookAt(0,0,1),m.up.set(0,1,0),m.lookAt(0,0,-1);else if(e===ll)s.up.set(0,-1,0),s.lookAt(-1,0,0),l.up.set(0,-1,0),l.lookAt(1,0,0),c.up.set(0,0,1),c.lookAt(0,1,0),d.up.set(0,0,-1),d.lookAt(0,-1,0),p.up.set(0,-1,0),p.lookAt(0,0,1),m.up.set(0,-1,0),m.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const h of i)this.add(h),h.updateMatrixWorld()}update(e,i){this.parent===null&&this.updateMatrixWorld();const{renderTarget:s,activeMipmapLevel:l}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[c,d,p,m,h,g]=this.children,x=e.getRenderTarget(),_=e.getActiveCubeFace(),y=e.getActiveMipmapLevel(),M=e.xr.enabled;e.xr.enabled=!1;const A=s.texture.generateMipmaps;s.texture.generateMipmaps=!1;let b=!1;e.isWebGLRenderer===!0?b=e.state.buffers.depth.getReversed():b=e.reversedDepthBuffer,e.setRenderTarget(s,0,l),b&&e.autoClear===!1&&e.clearDepth(),e.render(i,c),e.setRenderTarget(s,1,l),b&&e.autoClear===!1&&e.clearDepth(),e.render(i,d),e.setRenderTarget(s,2,l),b&&e.autoClear===!1&&e.clearDepth(),e.render(i,p),e.setRenderTarget(s,3,l),b&&e.autoClear===!1&&e.clearDepth(),e.render(i,m),e.setRenderTarget(s,4,l),b&&e.autoClear===!1&&e.clearDepth(),e.render(i,h),s.texture.generateMipmaps=A,e.setRenderTarget(s,5,l),b&&e.autoClear===!1&&e.clearDepth(),e.render(i,g),e.setRenderTarget(x,_,y),e.xr.enabled=M,s.texture.needsPMREMUpdate=!0}}class nM extends mi{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}class ex{constructor(e=1,i=0,s=0){this.radius=e,this.phi=i,this.theta=s}set(e,i,s){return this.radius=e,this.phi=i,this.theta=s,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=Tt(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,i,s){return this.radius=Math.sqrt(e*e+i*i+s*s),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,s),this.phi=Math.acos(Tt(i/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}const Rp=class Rp{constructor(e,i,s,l){this.elements=[1,0,0,1],e!==void 0&&this.set(e,i,s,l)}identity(){return this.set(1,0,0,1),this}fromArray(e,i=0){for(let s=0;s<4;s++)this.elements[s]=e[s+i];return this}set(e,i,s,l){const c=this.elements;return c[0]=e,c[2]=i,c[1]=s,c[3]=l,this}};Rp.prototype.isMatrix2=!0;let tx=Rp;class nx extends cl{constructor(e=10,i=10,s=4473924,l=8947848){s=new ft(s),l=new ft(l);const c=i/2,d=e/i,p=e/2,m=[],h=[];for(let _=0,y=0,M=-p;_<=i;_++,M+=d){m.push(-p,0,M,p,0,M),m.push(M,0,-p,M,0,p);const A=_===c?s:l;A.toArray(h,y),y+=3,A.toArray(h,y),y+=3,A.toArray(h,y),y+=3,A.toArray(h,y),y+=3}const g=new Pn;g.setAttribute("position",new Cn(m,3)),g.setAttribute("color",new Cn(h,3));const x=new Wr({vertexColors:!0,toneMapped:!1});super(g,x),this.type="GridHelper"}dispose(){this.geometry.dispose(),this.material.dispose()}}const Kc=new Zr;class iM extends cl{constructor(e,i=16776960){const s=new Uint16Array([0,1,1,2,2,3,3,0,4,5,5,6,6,7,7,4,0,4,1,5,2,6,3,7]),l=new Float32Array(24),c=new Pn;c.setIndex(new qn(s,1)),c.setAttribute("position",new qn(l,3)),super(c,new Wr({color:i,toneMapped:!1})),this.object=e,this.type="BoxHelper",this.matrixAutoUpdate=!1,this.update()}update(){if(this.object!==void 0&&Kc.setFromObject(this.object),Kc.isEmpty())return;const e=Kc.min,i=Kc.max,s=this.geometry.attributes.position,l=s.array;l[0]=i.x,l[1]=i.y,l[2]=i.z,l[3]=e.x,l[4]=i.y,l[5]=i.z,l[6]=e.x,l[7]=e.y,l[8]=i.z,l[9]=i.x,l[10]=e.y,l[11]=i.z,l[12]=i.x,l[13]=i.y,l[14]=e.z,l[15]=e.x,l[16]=i.y,l[17]=e.z,l[18]=e.x,l[19]=e.y,l[20]=e.z,l[21]=i.x,l[22]=e.y,l[23]=e.z,s.needsUpdate=!0,this.geometry.computeBoundingSphere()}setFromObject(e){return this.object=e,this.update(),this}copy(e,i){return super.copy(e,i),this.object=e.object,this}dispose(){this.geometry.dispose(),this.material.dispose()}}class aM extends cl{constructor(e=1){const i=[0,0,0,e,0,0,0,0,0,0,e,0,0,0,0,0,0,e],s=[1,0,0,1,.6,0,0,1,0,.6,1,0,0,0,1,0,.6,1],l=new Pn;l.setAttribute("position",new Cn(i,3)),l.setAttribute("color",new Cn(s,3));const c=new Wr({vertexColors:!0,toneMapped:!1});super(l,c),this.type="AxesHelper"}setColors(e,i,s){const l=new ft,c=this.geometry.attributes.color.array;return l.set(e),l.toArray(c,0),l.toArray(c,3),l.set(i),l.toArray(c,6),l.toArray(c,9),l.set(s),l.toArray(c,12),l.toArray(c,15),this.geometry.attributes.color.needsUpdate=!0,this}dispose(){this.geometry.dispose(),this.material.dispose()}}class sM extends ps{constructor(e,i=null){super(),this.object=e,this.domElement=i,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){if(e===void 0){st("Controls: connect() now requires an element.");return}this.domElement!==null&&this.disconnect(),this.domElement=e}disconnect(){}dispose(){}update(){}}function ix(r,e,i,s){const l=rM(s);switch(i){case Zx:return r*e;case Qx:return r*e/l.components*l.byteLength;case dp:return r*e/l.components*l.byteLength;case js:return r*e*2/l.components*l.byteLength;case hp:return r*e*2/l.components*l.byteLength;case Kx:return r*e*3/l.components*l.byteLength;case Pi:return r*e*4/l.components*l.byteLength;case pp:return r*e*4/l.components*l.byteLength;case tu:case nu:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*8;case iu:case au:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case Th:case Rh:return Math.max(r,16)*Math.max(e,8)/4;case Eh:case Ah:return Math.max(r,8)*Math.max(e,8)/2;case Ch:case wh:case Nh:case Uh:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*8;case Dh:case ru:case Lh:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case Oh:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case Ph:return Math.floor((r+4)/5)*Math.floor((e+3)/4)*16;case zh:return Math.floor((r+4)/5)*Math.floor((e+4)/5)*16;case Fh:return Math.floor((r+5)/6)*Math.floor((e+4)/5)*16;case Bh:return Math.floor((r+5)/6)*Math.floor((e+5)/6)*16;case Ih:return Math.floor((r+7)/8)*Math.floor((e+4)/5)*16;case Hh:return Math.floor((r+7)/8)*Math.floor((e+5)/6)*16;case Gh:return Math.floor((r+7)/8)*Math.floor((e+7)/8)*16;case Vh:return Math.floor((r+9)/10)*Math.floor((e+4)/5)*16;case kh:return Math.floor((r+9)/10)*Math.floor((e+5)/6)*16;case jh:return Math.floor((r+9)/10)*Math.floor((e+7)/8)*16;case Xh:return Math.floor((r+9)/10)*Math.floor((e+9)/10)*16;case Wh:return Math.floor((r+11)/12)*Math.floor((e+9)/10)*16;case qh:return Math.floor((r+11)/12)*Math.floor((e+11)/12)*16;case Yh:case Zh:case Kh:return Math.ceil(r/4)*Math.ceil(e/4)*16;case Qh:case Jh:return Math.ceil(r/4)*Math.ceil(e/4)*8;case ou:case $h:return Math.ceil(r/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${i} format.`)}function rM(r){switch(r){case gi:case Xx:return{byteLength:1,components:1};case rl:case Wx:case Ta:return{byteLength:2,components:1};case up:case fp:return{byteLength:2,components:4};case Ki:case cp:case Wi:return{byteLength:4,components:1};case qx:case Yx:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${r}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:lp}}));typeof window<"u"&&(window.__THREE__?st("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=lp);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function fv(){let r=null,e=!1,i=null,s=null;function l(c,d){i(c,d),s=r.requestAnimationFrame(l)}return{start:function(){e!==!0&&i!==null&&r!==null&&(s=r.requestAnimationFrame(l),e=!0)},stop:function(){r!==null&&r.cancelAnimationFrame(s),e=!1},setAnimationLoop:function(c){i=c},setContext:function(c){r=c}}}function oM(r){const e=new WeakMap;function i(p,m){const h=p.array,g=p.usage,x=h.byteLength,_=r.createBuffer();r.bindBuffer(m,_),r.bufferData(m,h,g),p.onUploadCallback();let y;if(h instanceof Float32Array)y=r.FLOAT;else if(typeof Float16Array<"u"&&h instanceof Float16Array)y=r.HALF_FLOAT;else if(h instanceof Uint16Array)p.isFloat16BufferAttribute?y=r.HALF_FLOAT:y=r.UNSIGNED_SHORT;else if(h instanceof Int16Array)y=r.SHORT;else if(h instanceof Uint32Array)y=r.UNSIGNED_INT;else if(h instanceof Int32Array)y=r.INT;else if(h instanceof Int8Array)y=r.BYTE;else if(h instanceof Uint8Array)y=r.UNSIGNED_BYTE;else if(h instanceof Uint8ClampedArray)y=r.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+h);return{buffer:_,type:y,bytesPerElement:h.BYTES_PER_ELEMENT,version:p.version,size:x}}function s(p,m,h){const g=m.array,x=m.updateRanges;if(r.bindBuffer(h,p),x.length===0)r.bufferSubData(h,0,g);else{x.sort((y,M)=>y.start-M.start);let _=0;for(let y=1;y<x.length;y++){const M=x[_],A=x[y];A.start<=M.start+M.count+1?M.count=Math.max(M.count,A.start+A.count-M.start):(++_,x[_]=A)}x.length=_+1;for(let y=0,M=x.length;y<M;y++){const A=x[y];r.bufferSubData(h,A.start*g.BYTES_PER_ELEMENT,g,A.start,A.count)}m.clearUpdateRanges()}m.onUploadCallback()}function l(p){return p.isInterleavedBufferAttribute&&(p=p.data),e.get(p)}function c(p){p.isInterleavedBufferAttribute&&(p=p.data);const m=e.get(p);m&&(r.deleteBuffer(m.buffer),e.delete(p))}function d(p,m){if(p.isInterleavedBufferAttribute&&(p=p.data),p.isGLBufferAttribute){const g=e.get(p);(!g||g.version<p.version)&&e.set(p,{buffer:p.buffer,type:p.type,bytesPerElement:p.elementSize,version:p.version});return}const h=e.get(p);if(h===void 0)e.set(p,i(p,m));else if(h.version<p.version){if(h.size!==p.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");s(h.buffer,p,m),h.version=p.version}}return{get:l,remove:c,update:d}}var lM=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,cM=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,uM=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,fM=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,dM=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,hM=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,pM=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,mM=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,gM=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,_M=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,xM=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,vM=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,SM=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,yM=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bM=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,MM=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,EM=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,TM=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,AM=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,RM=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,CM=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,wM=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,DM=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,NM=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,UM=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,LM=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,OM=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,PM=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,zM=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,FM=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,BM="gl_FragColor = linearToOutputTexel( gl_FragColor );",IM=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,HM=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,GM=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,VM=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,kM=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,jM=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,XM=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,WM=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,qM=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,YM=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,ZM=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,KM=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,QM=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,JM=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,$M=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,e1=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,t1=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,n1=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,i1=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,a1=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,s1=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,r1=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,o1=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = inverseTransformDirection( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,l1=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,c1=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,u1=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,f1=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,d1=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,h1=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,p1=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,m1=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,g1=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,_1=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,x1=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,v1=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,S1=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,y1=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,b1=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,M1=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,E1=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,T1=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,A1=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,R1=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,C1=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,w1=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,D1=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,N1=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,U1=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,L1=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,O1=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,P1=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,z1=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,F1=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,B1=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,I1=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,H1=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,G1=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,V1=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,k1=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,j1=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,X1=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,W1=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,q1=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Y1=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Z1=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,K1=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Q1=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,J1=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,$1=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,eE=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tE=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,nE=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,iE=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,aE=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,sE=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,rE=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,oE=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const lE=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,cE=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,uE=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,fE=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,dE=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,hE=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pE=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,mE=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,gE=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,_E=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,xE=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,vE=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,SE=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,yE=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,bE=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,ME=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,EE=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,TE=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,AE=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,RE=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,CE=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,wE=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,DE=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,NE=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,UE=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,LE=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,OE=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,PE=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,zE=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,FE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,BE=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,IE=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,HE=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,GE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,vt={alphahash_fragment:lM,alphahash_pars_fragment:cM,alphamap_fragment:uM,alphamap_pars_fragment:fM,alphatest_fragment:dM,alphatest_pars_fragment:hM,aomap_fragment:pM,aomap_pars_fragment:mM,batching_pars_vertex:gM,batching_vertex:_M,begin_vertex:xM,beginnormal_vertex:vM,bsdfs:SM,iridescence_fragment:yM,bumpmap_pars_fragment:bM,clipping_planes_fragment:MM,clipping_planes_pars_fragment:EM,clipping_planes_pars_vertex:TM,clipping_planes_vertex:AM,color_fragment:RM,color_pars_fragment:CM,color_pars_vertex:wM,color_vertex:DM,common:NM,cube_uv_reflection_fragment:UM,defaultnormal_vertex:LM,displacementmap_pars_vertex:OM,displacementmap_vertex:PM,emissivemap_fragment:zM,emissivemap_pars_fragment:FM,colorspace_fragment:BM,colorspace_pars_fragment:IM,envmap_fragment:HM,envmap_common_pars_fragment:GM,envmap_pars_fragment:VM,envmap_pars_vertex:kM,envmap_physical_pars_fragment:e1,envmap_vertex:jM,fog_vertex:XM,fog_pars_vertex:WM,fog_fragment:qM,fog_pars_fragment:YM,gradientmap_pars_fragment:ZM,lightmap_pars_fragment:KM,lights_lambert_fragment:QM,lights_lambert_pars_fragment:JM,lights_pars_begin:$M,lights_toon_fragment:t1,lights_toon_pars_fragment:n1,lights_phong_fragment:i1,lights_phong_pars_fragment:a1,lights_physical_fragment:s1,lights_physical_pars_fragment:r1,lights_fragment_begin:o1,lights_fragment_maps:l1,lights_fragment_end:c1,lightprobes_pars_fragment:u1,logdepthbuf_fragment:f1,logdepthbuf_pars_fragment:d1,logdepthbuf_pars_vertex:h1,logdepthbuf_vertex:p1,map_fragment:m1,map_pars_fragment:g1,map_particle_fragment:_1,map_particle_pars_fragment:x1,metalnessmap_fragment:v1,metalnessmap_pars_fragment:S1,morphinstance_vertex:y1,morphcolor_vertex:b1,morphnormal_vertex:M1,morphtarget_pars_vertex:E1,morphtarget_vertex:T1,normal_fragment_begin:A1,normal_fragment_maps:R1,normal_pars_fragment:C1,normal_pars_vertex:w1,normal_vertex:D1,normalmap_pars_fragment:N1,clearcoat_normal_fragment_begin:U1,clearcoat_normal_fragment_maps:L1,clearcoat_pars_fragment:O1,iridescence_pars_fragment:P1,opaque_fragment:z1,packing:F1,premultiplied_alpha_fragment:B1,project_vertex:I1,dithering_fragment:H1,dithering_pars_fragment:G1,roughnessmap_fragment:V1,roughnessmap_pars_fragment:k1,shadowmap_pars_fragment:j1,shadowmap_pars_vertex:X1,shadowmap_vertex:W1,shadowmask_pars_fragment:q1,skinbase_vertex:Y1,skinning_pars_vertex:Z1,skinning_vertex:K1,skinnormal_vertex:Q1,specularmap_fragment:J1,specularmap_pars_fragment:$1,tonemapping_fragment:eE,tonemapping_pars_fragment:tE,transmission_fragment:nE,transmission_pars_fragment:iE,uv_pars_fragment:aE,uv_pars_vertex:sE,uv_vertex:rE,worldpos_vertex:oE,background_vert:lE,background_frag:cE,backgroundCube_vert:uE,backgroundCube_frag:fE,cube_vert:dE,cube_frag:hE,depth_vert:pE,depth_frag:mE,distance_vert:gE,distance_frag:_E,equirect_vert:xE,equirect_frag:vE,linedashed_vert:SE,linedashed_frag:yE,meshbasic_vert:bE,meshbasic_frag:ME,meshlambert_vert:EE,meshlambert_frag:TE,meshmatcap_vert:AE,meshmatcap_frag:RE,meshnormal_vert:CE,meshnormal_frag:wE,meshphong_vert:DE,meshphong_frag:NE,meshphysical_vert:UE,meshphysical_frag:LE,meshtoon_vert:OE,meshtoon_frag:PE,points_vert:zE,points_frag:FE,shadow_vert:BE,shadow_frag:IE,sprite_vert:HE,sprite_frag:GE},Ve={common:{diffuse:{value:new ft(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new ht},alphaMap:{value:null},alphaMapTransform:{value:new ht},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new ht}},envmap:{envMap:{value:null},envMapRotation:{value:new ht},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new ht}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new ht}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new ht},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new ht},normalScale:{value:new gt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new ht},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new ht}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new ht}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new ht}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new ft(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new ee},probesMax:{value:new ee},probesResolution:{value:new ee}},points:{diffuse:{value:new ft(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new ht},alphaTest:{value:0},uvTransform:{value:new ht}},sprite:{diffuse:{value:new ft(16777215)},opacity:{value:1},center:{value:new gt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new ht},alphaMap:{value:null},alphaMapTransform:{value:new ht},alphaTest:{value:0}}},ji={basic:{uniforms:Xn([Ve.common,Ve.specularmap,Ve.envmap,Ve.aomap,Ve.lightmap,Ve.fog]),vertexShader:vt.meshbasic_vert,fragmentShader:vt.meshbasic_frag},lambert:{uniforms:Xn([Ve.common,Ve.specularmap,Ve.envmap,Ve.aomap,Ve.lightmap,Ve.emissivemap,Ve.bumpmap,Ve.normalmap,Ve.displacementmap,Ve.fog,Ve.lights,{emissive:{value:new ft(0)},envMapIntensity:{value:1}}]),vertexShader:vt.meshlambert_vert,fragmentShader:vt.meshlambert_frag},phong:{uniforms:Xn([Ve.common,Ve.specularmap,Ve.envmap,Ve.aomap,Ve.lightmap,Ve.emissivemap,Ve.bumpmap,Ve.normalmap,Ve.displacementmap,Ve.fog,Ve.lights,{emissive:{value:new ft(0)},specular:{value:new ft(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:vt.meshphong_vert,fragmentShader:vt.meshphong_frag},standard:{uniforms:Xn([Ve.common,Ve.envmap,Ve.aomap,Ve.lightmap,Ve.emissivemap,Ve.bumpmap,Ve.normalmap,Ve.displacementmap,Ve.roughnessmap,Ve.metalnessmap,Ve.fog,Ve.lights,{emissive:{value:new ft(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:vt.meshphysical_vert,fragmentShader:vt.meshphysical_frag},toon:{uniforms:Xn([Ve.common,Ve.aomap,Ve.lightmap,Ve.emissivemap,Ve.bumpmap,Ve.normalmap,Ve.displacementmap,Ve.gradientmap,Ve.fog,Ve.lights,{emissive:{value:new ft(0)}}]),vertexShader:vt.meshtoon_vert,fragmentShader:vt.meshtoon_frag},matcap:{uniforms:Xn([Ve.common,Ve.bumpmap,Ve.normalmap,Ve.displacementmap,Ve.fog,{matcap:{value:null}}]),vertexShader:vt.meshmatcap_vert,fragmentShader:vt.meshmatcap_frag},points:{uniforms:Xn([Ve.points,Ve.fog]),vertexShader:vt.points_vert,fragmentShader:vt.points_frag},dashed:{uniforms:Xn([Ve.common,Ve.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:vt.linedashed_vert,fragmentShader:vt.linedashed_frag},depth:{uniforms:Xn([Ve.common,Ve.displacementmap]),vertexShader:vt.depth_vert,fragmentShader:vt.depth_frag},normal:{uniforms:Xn([Ve.common,Ve.bumpmap,Ve.normalmap,Ve.displacementmap,{opacity:{value:1}}]),vertexShader:vt.meshnormal_vert,fragmentShader:vt.meshnormal_frag},sprite:{uniforms:Xn([Ve.sprite,Ve.fog]),vertexShader:vt.sprite_vert,fragmentShader:vt.sprite_frag},background:{uniforms:{uvTransform:{value:new ht},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:vt.background_vert,fragmentShader:vt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new ht}},vertexShader:vt.backgroundCube_vert,fragmentShader:vt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:vt.cube_vert,fragmentShader:vt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:vt.equirect_vert,fragmentShader:vt.equirect_frag},distance:{uniforms:Xn([Ve.common,Ve.displacementmap,{referencePosition:{value:new ee},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:vt.distance_vert,fragmentShader:vt.distance_frag},shadow:{uniforms:Xn([Ve.lights,Ve.fog,{color:{value:new ft(0)},opacity:{value:1}}]),vertexShader:vt.shadow_vert,fragmentShader:vt.shadow_frag}};ji.physical={uniforms:Xn([ji.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new ht},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new ht},clearcoatNormalScale:{value:new gt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new ht},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new ht},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new ht},sheen:{value:0},sheenColor:{value:new ft(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new ht},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new ht},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new ht},transmissionSamplerSize:{value:new gt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new ht},attenuationDistance:{value:0},attenuationColor:{value:new ft(0)},specularColor:{value:new ft(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new ht},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new ht},anisotropyVector:{value:new gt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new ht}}]),vertexShader:vt.meshphysical_vert,fragmentShader:vt.meshphysical_frag};const Qc={r:0,b:0,g:0},VE=new rn,dv=new ht;dv.set(-1,0,0,0,1,0,0,0,1);function kE(r,e,i,s,l,c){const d=new ft(0);let p=l===!0?0:1,m,h,g=null,x=0,_=null;function y(N){let O=N.isScene===!0?N.background:null;if(O&&O.isTexture){const z=N.backgroundBlurriness>0;O=e.get(O,z)}return O}function M(N){let O=!1;const z=y(N);z===null?b(d,p):z&&z.isColor&&(b(z,1),O=!0);const k=r.xr.getEnvironmentBlendMode();k==="additive"?i.buffers.color.setClear(0,0,0,1,c):k==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,c),(r.autoClear||O)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil))}function A(N,O){const z=y(O);z&&(z.isCubeTexture||z.mapping===pu)?(h===void 0&&(h=new zi(new Kr(1,1,1),new Qi({name:"BackgroundCubeMaterial",uniforms:Yr(ji.backgroundCube.uniforms),vertexShader:ji.backgroundCube.vertexShader,fragmentShader:ji.backgroundCube.fragmentShader,side:ni,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(k,L,H){this.matrixWorld.copyPosition(H.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),h.material.uniforms.envMap.value=z,h.material.uniforms.backgroundBlurriness.value=O.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=O.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(VE.makeRotationFromEuler(O.backgroundRotation)).transpose(),z.isCubeTexture&&z.isRenderTargetTexture===!1&&h.material.uniforms.backgroundRotation.value.premultiply(dv),h.material.toneMapped=wt.getTransfer(z.colorSpace)!==jt,(g!==z||x!==z.version||_!==r.toneMapping)&&(h.material.needsUpdate=!0,g=z,x=z.version,_=r.toneMapping),h.layers.enableAll(),N.unshift(h,h.geometry,h.material,0,0,null)):z&&z.isTexture&&(m===void 0&&(m=new zi(new gu(2,2),new Qi({name:"BackgroundMaterial",uniforms:Yr(ji.background.uniforms),vertexShader:ji.background.vertexShader,fragmentShader:ji.background.fragmentShader,side:fs,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),m.geometry.deleteAttribute("normal"),Object.defineProperty(m.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(m)),m.material.uniforms.t2D.value=z,m.material.uniforms.backgroundIntensity.value=O.backgroundIntensity,m.material.toneMapped=wt.getTransfer(z.colorSpace)!==jt,z.matrixAutoUpdate===!0&&z.updateMatrix(),m.material.uniforms.uvTransform.value.copy(z.matrix),(g!==z||x!==z.version||_!==r.toneMapping)&&(m.material.needsUpdate=!0,g=z,x=z.version,_=r.toneMapping),m.layers.enableAll(),N.unshift(m,m.geometry,m.material,0,0,null))}function b(N,O){N.getRGB(Qc,lv(r)),i.buffers.color.setClear(Qc.r,Qc.g,Qc.b,O,c)}function S(){h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0),m!==void 0&&(m.geometry.dispose(),m.material.dispose(),m=void 0)}return{getClearColor:function(){return d},setClearColor:function(N,O=1){d.set(N),p=O,b(d,p)},getClearAlpha:function(){return p},setClearAlpha:function(N){p=N,b(d,p)},render:M,addToRenderList:A,dispose:S}}function jE(r,e){const i=r.getParameter(r.MAX_VERTEX_ATTRIBS),s={},l=_(null);let c=l,d=!1;function p(G,K,ue,pe,F){let D=!1;const P=x(G,pe,ue,K);c!==P&&(c=P,h(c.object)),D=y(G,pe,ue,F),D&&M(G,pe,ue,F),F!==null&&e.update(F,r.ELEMENT_ARRAY_BUFFER),(D||d)&&(d=!1,z(G,K,ue,pe),F!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,e.get(F).buffer))}function m(){return r.createVertexArray()}function h(G){return r.bindVertexArray(G)}function g(G){return r.deleteVertexArray(G)}function x(G,K,ue,pe){const F=pe.wireframe===!0;let D=s[K.id];D===void 0&&(D={},s[K.id]=D);const P=G.isInstancedMesh===!0?G.id:0;let q=D[P];q===void 0&&(q={},D[P]=q);let he=q[ue.id];he===void 0&&(he={},q[ue.id]=he);let _e=he[F];return _e===void 0&&(_e=_(m()),he[F]=_e),_e}function _(G){const K=[],ue=[],pe=[];for(let F=0;F<i;F++)K[F]=0,ue[F]=0,pe[F]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:K,enabledAttributes:ue,attributeDivisors:pe,object:G,attributes:{},index:null}}function y(G,K,ue,pe){const F=c.attributes,D=K.attributes;let P=0;const q=ue.getAttributes();for(const he in q)if(q[he].location>=0){const B=F[he];let Q=D[he];if(Q===void 0&&(he==="instanceMatrix"&&G.instanceMatrix&&(Q=G.instanceMatrix),he==="instanceColor"&&G.instanceColor&&(Q=G.instanceColor)),B===void 0||B.attribute!==Q||Q&&B.data!==Q.data)return!0;P++}return c.attributesNum!==P||c.index!==pe}function M(G,K,ue,pe){const F={},D=K.attributes;let P=0;const q=ue.getAttributes();for(const he in q)if(q[he].location>=0){let B=D[he];B===void 0&&(he==="instanceMatrix"&&G.instanceMatrix&&(B=G.instanceMatrix),he==="instanceColor"&&G.instanceColor&&(B=G.instanceColor));const Q={};Q.attribute=B,B&&B.data&&(Q.data=B.data),F[he]=Q,P++}c.attributes=F,c.attributesNum=P,c.index=pe}function A(){const G=c.newAttributes;for(let K=0,ue=G.length;K<ue;K++)G[K]=0}function b(G){S(G,0)}function S(G,K){const ue=c.newAttributes,pe=c.enabledAttributes,F=c.attributeDivisors;ue[G]=1,pe[G]===0&&(r.enableVertexAttribArray(G),pe[G]=1),F[G]!==K&&(r.vertexAttribDivisor(G,K),F[G]=K)}function N(){const G=c.newAttributes,K=c.enabledAttributes;for(let ue=0,pe=K.length;ue<pe;ue++)K[ue]!==G[ue]&&(r.disableVertexAttribArray(ue),K[ue]=0)}function O(G,K,ue,pe,F,D,P){P===!0?r.vertexAttribIPointer(G,K,ue,F,D):r.vertexAttribPointer(G,K,ue,pe,F,D)}function z(G,K,ue,pe){A();const F=pe.attributes,D=ue.getAttributes(),P=K.defaultAttributeValues;for(const q in D){const he=D[q];if(he.location>=0){let _e=F[q];if(_e===void 0&&(q==="instanceMatrix"&&G.instanceMatrix&&(_e=G.instanceMatrix),q==="instanceColor"&&G.instanceColor&&(_e=G.instanceColor)),_e!==void 0){const B=_e.normalized,Q=_e.itemSize,ve=e.get(_e);if(ve===void 0)continue;const Ae=ve.buffer,Ce=ve.type,ae=ve.bytesPerElement,ye=Ce===r.INT||Ce===r.UNSIGNED_INT||_e.gpuType===cp;if(_e.isInterleavedBufferAttribute){const Me=_e.data,Ie=Me.stride,Ze=_e.offset;if(Me.isInstancedInterleavedBuffer){for(let Ke=0;Ke<he.locationSize;Ke++)S(he.location+Ke,Me.meshPerAttribute);G.isInstancedMesh!==!0&&pe._maxInstanceCount===void 0&&(pe._maxInstanceCount=Me.meshPerAttribute*Me.count)}else for(let Ke=0;Ke<he.locationSize;Ke++)b(he.location+Ke);r.bindBuffer(r.ARRAY_BUFFER,Ae);for(let Ke=0;Ke<he.locationSize;Ke++)O(he.location+Ke,Q/he.locationSize,Ce,B,Ie*ae,(Ze+Q/he.locationSize*Ke)*ae,ye)}else{if(_e.isInstancedBufferAttribute){for(let Me=0;Me<he.locationSize;Me++)S(he.location+Me,_e.meshPerAttribute);G.isInstancedMesh!==!0&&pe._maxInstanceCount===void 0&&(pe._maxInstanceCount=_e.meshPerAttribute*_e.count)}else for(let Me=0;Me<he.locationSize;Me++)b(he.location+Me);r.bindBuffer(r.ARRAY_BUFFER,Ae);for(let Me=0;Me<he.locationSize;Me++)O(he.location+Me,Q/he.locationSize,Ce,B,Q*ae,Q/he.locationSize*Me*ae,ye)}}else if(P!==void 0){const B=P[q];if(B!==void 0)switch(B.length){case 2:r.vertexAttrib2fv(he.location,B);break;case 3:r.vertexAttrib3fv(he.location,B);break;case 4:r.vertexAttrib4fv(he.location,B);break;default:r.vertexAttrib1fv(he.location,B)}}}}N()}function k(){I();for(const G in s){const K=s[G];for(const ue in K){const pe=K[ue];for(const F in pe){const D=pe[F];for(const P in D)g(D[P].object),delete D[P];delete pe[F]}}delete s[G]}}function L(G){if(s[G.id]===void 0)return;const K=s[G.id];for(const ue in K){const pe=K[ue];for(const F in pe){const D=pe[F];for(const P in D)g(D[P].object),delete D[P];delete pe[F]}}delete s[G.id]}function H(G){for(const K in s){const ue=s[K];for(const pe in ue){const F=ue[pe];if(F[G.id]===void 0)continue;const D=F[G.id];for(const P in D)g(D[P].object),delete D[P];delete F[G.id]}}}function T(G){for(const K in s){const ue=s[K],pe=G.isInstancedMesh===!0?G.id:0,F=ue[pe];if(F!==void 0){for(const D in F){const P=F[D];for(const q in P)g(P[q].object),delete P[q];delete F[D]}delete ue[pe],Object.keys(ue).length===0&&delete s[K]}}}function I(){Z(),d=!0,c!==l&&(c=l,h(c.object))}function Z(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:p,reset:I,resetDefaultState:Z,dispose:k,releaseStatesOfGeometry:L,releaseStatesOfObject:T,releaseStatesOfProgram:H,initAttributes:A,enableAttribute:b,disableUnusedAttributes:N}}function XE(r,e,i){let s;function l(m){s=m}function c(m,h){r.drawArrays(s,m,h),i.update(h,s,1)}function d(m,h,g){g!==0&&(r.drawArraysInstanced(s,m,h,g),i.update(h,s,g))}function p(m,h,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(s,m,0,h,0,g);let _=0;for(let y=0;y<g;y++)_+=h[y];i.update(_,s,1)}this.setMode=l,this.render=c,this.renderInstances=d,this.renderMultiDraw=p}function WE(r,e,i,s){let l;function c(){if(l!==void 0)return l;if(e.has("EXT_texture_filter_anisotropic")===!0){const H=e.get("EXT_texture_filter_anisotropic");l=r.getParameter(H.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else l=0;return l}function d(H){return!(H!==Pi&&s.convert(H)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_FORMAT))}function p(H){const T=H===Ta&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(H!==gi&&s.convert(H)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_TYPE)&&H!==Wi&&!T)}function m(H){if(H==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";H="mediump"}return H==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let h=i.precision!==void 0?i.precision:"highp";const g=m(h);g!==h&&(st("WebGLRenderer:",h,"not supported, using",g,"instead."),h=g);const x=i.logarithmicDepthBuffer===!0,_=i.reversedDepthBuffer===!0&&e.has("EXT_clip_control");i.reversedDepthBuffer===!0&&_===!1&&st("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const y=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),M=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),A=r.getParameter(r.MAX_TEXTURE_SIZE),b=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),S=r.getParameter(r.MAX_VERTEX_ATTRIBS),N=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),O=r.getParameter(r.MAX_VARYING_VECTORS),z=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),k=r.getParameter(r.MAX_SAMPLES),L=r.getParameter(r.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:c,getMaxPrecision:m,textureFormatReadable:d,textureTypeReadable:p,precision:h,logarithmicDepthBuffer:x,reversedDepthBuffer:_,maxTextures:y,maxVertexTextures:M,maxTextureSize:A,maxCubemapSize:b,maxAttributes:S,maxVertexUniforms:N,maxVaryings:O,maxFragmentUniforms:z,maxSamples:k,samples:L}}function qE(r){const e=this;let i=null,s=0,l=!1,c=!1;const d=new ls,p=new ht,m={value:null,needsUpdate:!1};this.uniform=m,this.numPlanes=0,this.numIntersection=0,this.init=function(x,_){const y=x.length!==0||_||s!==0||l;return l=_,s=x.length,y},this.beginShadows=function(){c=!0,g(null)},this.endShadows=function(){c=!1},this.setGlobalState=function(x,_){i=g(x,_,0)},this.setState=function(x,_,y){const M=x.clippingPlanes,A=x.clipIntersection,b=x.clipShadows,S=r.get(x);if(!l||M===null||M.length===0||c&&!b)c?g(null):h();else{const N=c?0:s,O=N*4;let z=S.clippingState||null;m.value=z,z=g(M,_,O,y);for(let k=0;k!==O;++k)z[k]=i[k];S.clippingState=z,this.numIntersection=A?this.numPlanes:0,this.numPlanes+=N}};function h(){m.value!==i&&(m.value=i,m.needsUpdate=s>0),e.numPlanes=s,e.numIntersection=0}function g(x,_,y,M){const A=x!==null?x.length:0;let b=null;if(A!==0){if(b=m.value,M!==!0||b===null){const S=y+A*4,N=_.matrixWorldInverse;p.getNormalMatrix(N),(b===null||b.length<S)&&(b=new Float32Array(S));for(let O=0,z=y;O!==A;++O,z+=4)d.copy(x[O]).applyMatrix4(N,p),d.normal.toArray(b,z),b[z+3]=d.constant}m.value=b,m.needsUpdate=!0}return e.numPlanes=A,e.numIntersection=0,b}}const us=4,ax=[.125,.215,.35,.446,.526,.582],Is=20,YE=256,$o=new _u,sx=new ft;let sh=null,rh=0,oh=0,lh=!1;const ZE=new ee;class rx{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,i=0,s=.1,l=100,c={}){const{size:d=256,position:p=ZE}=c;sh=this._renderer.getRenderTarget(),rh=this._renderer.getActiveCubeFace(),oh=this._renderer.getActiveMipmapLevel(),lh=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(d);const m=this._allocateTargets();return m.depthBuffer=!0,this._sceneToCubeUV(e,s,l,m,p),i>0&&this._blur(m,0,0,i),this._applyPMREM(m),this._cleanup(m),m}fromEquirectangular(e,i=null){return this._fromTexture(e,i)}fromCubemap(e,i=null){return this._fromTexture(e,i)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=cx(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=lx(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(sh,rh,oh),this._renderer.xr.enabled=lh,e.scissorTest=!1,Ir(e,0,0,e.width,e.height)}_fromTexture(e,i){e.mapping===ks||e.mapping===Xr?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),sh=this._renderer.getRenderTarget(),rh=this._renderer.getActiveCubeFace(),oh=this._renderer.getActiveMipmapLevel(),lh=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const s=i||this._allocateTargets();return this._textureToCubeUV(e,s),this._applyPMREM(s),this._cleanup(s),s}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),i=4*this._cubeSize,s={magFilter:Gn,minFilter:Gn,generateMipmaps:!1,type:Ta,format:Pi,colorSpace:lu,depthBuffer:!1},l=ox(e,i,s);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==i){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=ox(e,i,s);const{_lodMax:c}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=KE(c)),this._blurMaterial=JE(c,e,i),this._ggxMaterial=QE(c,e,i)}return l}_compileMaterial(e){const i=new zi(new Pn,e);this._renderer.compile(i,$o)}_sceneToCubeUV(e,i,s,l,c){const m=new mi(90,1,i,s),h=[1,-1,1,1,1,1],g=[1,1,1,-1,-1,-1],x=this._renderer,_=x.autoClear,y=x.toneMapping;x.getClearColor(sx),x.toneMapping=Yi,x.autoClear=!1,x.state.buffers.depth.getReversed()&&(x.setRenderTarget(l),x.clearDepth(),x.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new zi(new Kr,new av({name:"PMREM.Background",side:ni,depthWrite:!1,depthTest:!1})));const A=this._backgroundBox,b=A.material;let S=!1;const N=e.background;N?N.isColor&&(b.color.copy(N),e.background=null,S=!0):(b.color.copy(sx),S=!0);for(let O=0;O<6;O++){const z=O%3;z===0?(m.up.set(0,h[O],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x+g[O],c.y,c.z)):z===1?(m.up.set(0,0,h[O]),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y+g[O],c.z)):(m.up.set(0,h[O],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y,c.z+g[O]));const k=this._cubeSize;Ir(l,z*k,O>2?k:0,k,k),x.setRenderTarget(l),S&&x.render(A,m),x.render(e,m)}x.toneMapping=y,x.autoClear=_,e.background=N}_textureToCubeUV(e,i){const s=this._renderer,l=e.mapping===ks||e.mapping===Xr;l?(this._cubemapMaterial===null&&(this._cubemapMaterial=cx()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=lx());const c=l?this._cubemapMaterial:this._equirectMaterial,d=this._lodMeshes[0];d.material=c;const p=c.uniforms;p.envMap.value=e;const m=this._cubeSize;Ir(i,0,0,3*m,2*m),s.setRenderTarget(i),s.render(d,$o)}_applyPMREM(e){const i=this._renderer,s=i.autoClear;i.autoClear=!1;const l=this._lodMeshes.length;for(let c=1;c<l;c++)this._applyGGXFilter(e,c-1,c);i.autoClear=s}_applyGGXFilter(e,i,s){const l=this._renderer,c=this._pingPongRenderTarget,d=this._ggxMaterial,p=this._lodMeshes[s];p.material=d;const m=d.uniforms,h=s/(this._lodMeshes.length-1),g=i/(this._lodMeshes.length-1),x=Math.sqrt(h*h-g*g),_=0+h*1.25,y=x*_,{_lodMax:M}=this,A=this._sizeLods[s],b=3*A*(s>M-us?s-M+us:0),S=4*(this._cubeSize-A);m.envMap.value=e.texture,m.roughness.value=y,m.mipInt.value=M-i,Ir(c,b,S,3*A,2*A),l.setRenderTarget(c),l.render(p,$o),m.envMap.value=c.texture,m.roughness.value=0,m.mipInt.value=M-s,Ir(e,b,S,3*A,2*A),l.setRenderTarget(e),l.render(p,$o)}_blur(e,i,s,l,c){const d=this._pingPongRenderTarget;this._halfBlur(e,d,i,s,l,"latitudinal",c),this._halfBlur(d,e,s,s,l,"longitudinal",c)}_halfBlur(e,i,s,l,c,d,p){const m=this._renderer,h=this._blurMaterial;d!=="latitudinal"&&d!=="longitudinal"&&Ut("blur direction must be either latitudinal or longitudinal!");const g=3,x=this._lodMeshes[l];x.material=h;const _=h.uniforms,y=this._sizeLods[s]-1,M=isFinite(c)?Math.PI/(2*y):2*Math.PI/(2*Is-1),A=c/M,b=isFinite(c)?1+Math.floor(g*A):Is;b>Is&&st(`sigmaRadians, ${c}, is too large and will clip, as it requested ${b} samples when the maximum is set to ${Is}`);const S=[];let N=0;for(let H=0;H<Is;++H){const T=H/A,I=Math.exp(-T*T/2);S.push(I),H===0?N+=I:H<b&&(N+=2*I)}for(let H=0;H<S.length;H++)S[H]=S[H]/N;_.envMap.value=e.texture,_.samples.value=b,_.weights.value=S,_.latitudinal.value=d==="latitudinal",p&&(_.poleAxis.value=p);const{_lodMax:O}=this;_.dTheta.value=M,_.mipInt.value=O-s;const z=this._sizeLods[l],k=3*z*(l>O-us?l-O+us:0),L=4*(this._cubeSize-z);Ir(i,k,L,3*z,2*z),m.setRenderTarget(i),m.render(x,$o)}}function KE(r){const e=[],i=[],s=[];let l=r;const c=r-us+1+ax.length;for(let d=0;d<c;d++){const p=Math.pow(2,l);e.push(p);let m=1/p;d>r-us?m=ax[d-r+us-1]:d===0&&(m=0),i.push(m);const h=1/(p-2),g=-h,x=1+h,_=[g,g,x,g,x,x,g,g,x,x,g,x],y=6,M=6,A=3,b=2,S=1,N=new Float32Array(A*M*y),O=new Float32Array(b*M*y),z=new Float32Array(S*M*y);for(let L=0;L<y;L++){const H=L%3*2/3-1,T=L>2?0:-1,I=[H,T,0,H+2/3,T,0,H+2/3,T+1,0,H,T,0,H+2/3,T+1,0,H,T+1,0];N.set(I,A*M*L),O.set(_,b*M*L);const Z=[L,L,L,L,L,L];z.set(Z,S*M*L)}const k=new Pn;k.setAttribute("position",new qn(N,A)),k.setAttribute("uv",new qn(O,b)),k.setAttribute("faceIndex",new qn(z,S)),s.push(new zi(k,null)),l>us&&l--}return{lodMeshes:s,sizeLods:e,sigmas:i}}function ox(r,e,i){const s=new Zi(r,e,i);return s.texture.mapping=pu,s.texture.name="PMREM.cubeUv",s.scissorTest=!0,s}function Ir(r,e,i,s,l){r.viewport.set(e,i,s,l),r.scissor.set(e,i,s,l)}function QE(r,e,i){return new Qi({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:YE,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/i,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:xu(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Ma,depthTest:!1,depthWrite:!1})}function JE(r,e,i){const s=new Float32Array(Is),l=new ee(0,1,0);return new Qi({name:"SphericalGaussianBlur",defines:{n:Is,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/i,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:s},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:l}},vertexShader:xu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Ma,depthTest:!1,depthWrite:!1})}function lx(){return new Qi({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:xu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ma,depthTest:!1,depthWrite:!1})}function cx(){return new Qi({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:xu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ma,depthTest:!1,depthWrite:!1})}function xu(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class hv extends Zi{constructor(e=1,i={}){super(e,e,i),this.isWebGLCubeRenderTarget=!0;const s={width:e,height:e,depth:1},l=[s,s,s,s,s,s];this.texture=new rv(l),this._setTextureOptions(i),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,i){this.texture.type=i.type,this.texture.colorSpace=i.colorSpace,this.texture.generateMipmaps=i.generateMipmaps,this.texture.minFilter=i.minFilter,this.texture.magFilter=i.magFilter;const s={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},l=new Kr(5,5,5),c=new Qi({name:"CubemapFromEquirect",uniforms:Yr(s.uniforms),vertexShader:s.vertexShader,fragmentShader:s.fragmentShader,side:ni,blending:Ma});c.uniforms.tEquirect.value=i;const d=new zi(l,c),p=i.minFilter;return i.minFilter===Hs&&(i.minFilter=Gn),new tM(1,10,this).update(e,d),i.minFilter=p,d.geometry.dispose(),d.material.dispose(),this}clear(e,i=!0,s=!0,l=!0){const c=e.getRenderTarget();for(let d=0;d<6;d++)e.setRenderTarget(this,d),e.clear(i,s,l);e.setRenderTarget(c)}}function $E(r){let e=new WeakMap,i=new WeakMap,s=null;function l(_,y=!1){return _==null?null:y?d(_):c(_)}function c(_){if(_&&_.isTexture){const y=_.mapping;if(y===Dd||y===Nd)if(e.has(_)){const M=e.get(_).texture;return p(M,_.mapping)}else{const M=_.image;if(M&&M.height>0){const A=new hv(M.height);return A.fromEquirectangularTexture(r,_),e.set(_,A),_.addEventListener("dispose",h),p(A.texture,_.mapping)}else return null}}return _}function d(_){if(_&&_.isTexture){const y=_.mapping,M=y===Dd||y===Nd,A=y===ks||y===Xr;if(M||A){let b=i.get(_);const S=b!==void 0?b.texture.pmremVersion:0;if(_.isRenderTargetTexture&&_.pmremVersion!==S)return s===null&&(s=new rx(r)),b=M?s.fromEquirectangular(_,b):s.fromCubemap(_,b),b.texture.pmremVersion=_.pmremVersion,i.set(_,b),b.texture;if(b!==void 0)return b.texture;{const N=_.image;return M&&N&&N.height>0||A&&N&&m(N)?(s===null&&(s=new rx(r)),b=M?s.fromEquirectangular(_):s.fromCubemap(_),b.texture.pmremVersion=_.pmremVersion,i.set(_,b),_.addEventListener("dispose",g),b.texture):null}}}return _}function p(_,y){return y===Dd?_.mapping=ks:y===Nd&&(_.mapping=Xr),_}function m(_){let y=0;const M=6;for(let A=0;A<M;A++)_[A]!==void 0&&y++;return y===M}function h(_){const y=_.target;y.removeEventListener("dispose",h);const M=e.get(y);M!==void 0&&(e.delete(y),M.dispose())}function g(_){const y=_.target;y.removeEventListener("dispose",g);const M=i.get(y);M!==void 0&&(i.delete(y),M.dispose())}function x(){e=new WeakMap,i=new WeakMap,s!==null&&(s.dispose(),s=null)}return{get:l,dispose:x}}function eT(r){const e={};function i(s){if(e[s]!==void 0)return e[s];const l=r.getExtension(s);return e[s]=l,l}return{has:function(s){return i(s)!==null},init:function(){i("EXT_color_buffer_float"),i("WEBGL_clip_cull_distance"),i("OES_texture_float_linear"),i("EXT_color_buffer_half_float"),i("WEBGL_multisampled_render_to_texture"),i("WEBGL_render_shared_exponent")},get:function(s){const l=i(s);return l===null&&tp("WebGLRenderer: "+s+" extension not supported."),l}}}function tT(r,e,i,s){const l={},c=new WeakMap;function d(x){const _=x.target;_.index!==null&&e.remove(_.index);for(const M in _.attributes)e.remove(_.attributes[M]);_.removeEventListener("dispose",d),delete l[_.id];const y=c.get(_);y&&(e.remove(y),c.delete(_)),s.releaseStatesOfGeometry(_),_.isInstancedBufferGeometry===!0&&delete _._maxInstanceCount,i.memory.geometries--}function p(x,_){return l[_.id]===!0||(_.addEventListener("dispose",d),l[_.id]=!0,i.memory.geometries++),_}function m(x){const _=x.attributes;for(const y in _)e.update(_[y],r.ARRAY_BUFFER)}function h(x){const _=[],y=x.index,M=x.attributes.position;let A=0;if(M===void 0)return;if(y!==null){const N=y.array;A=y.version;for(let O=0,z=N.length;O<z;O+=3){const k=N[O+0],L=N[O+1],H=N[O+2];_.push(k,L,L,H,H,k)}}else{const N=M.array;A=M.version;for(let O=0,z=N.length/3-1;O<z;O+=3){const k=O+0,L=O+1,H=O+2;_.push(k,L,L,H,H,k)}}const b=new(M.count>=65535?iv:nv)(_,1);b.version=A;const S=c.get(x);S&&e.remove(S),c.set(x,b)}function g(x){const _=c.get(x);if(_){const y=x.index;y!==null&&_.version<y.version&&h(x)}else h(x);return c.get(x)}return{get:p,update:m,getWireframeAttribute:g}}function nT(r,e,i){let s;function l(x){s=x}let c,d;function p(x){c=x.type,d=x.bytesPerElement}function m(x,_){r.drawElements(s,_,c,x*d),i.update(_,s,1)}function h(x,_,y){y!==0&&(r.drawElementsInstanced(s,_,c,x*d,y),i.update(_,s,y))}function g(x,_,y){if(y===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(s,_,0,c,x,0,y);let A=0;for(let b=0;b<y;b++)A+=_[b];i.update(A,s,1)}this.setMode=l,this.setIndex=p,this.render=m,this.renderInstances=h,this.renderMultiDraw=g}function iT(r){const e={geometries:0,textures:0},i={frame:0,calls:0,triangles:0,points:0,lines:0};function s(c,d,p){switch(i.calls++,d){case r.TRIANGLES:i.triangles+=p*(c/3);break;case r.LINES:i.lines+=p*(c/2);break;case r.LINE_STRIP:i.lines+=p*(c-1);break;case r.LINE_LOOP:i.lines+=p*c;break;case r.POINTS:i.points+=p*c;break;default:Ut("WebGLInfo: Unknown draw mode:",d);break}}function l(){i.calls=0,i.triangles=0,i.points=0,i.lines=0}return{memory:e,render:i,programs:null,autoReset:!0,reset:l,update:s}}function aT(r,e,i){const s=new WeakMap,l=new cn;function c(d,p,m){const h=d.morphTargetInfluences,g=p.morphAttributes.position||p.morphAttributes.normal||p.morphAttributes.color,x=g!==void 0?g.length:0;let _=s.get(p);if(_===void 0||_.count!==x){let Z=function(){T.dispose(),s.delete(p),p.removeEventListener("dispose",Z)};var y=Z;_!==void 0&&_.texture.dispose();const M=p.morphAttributes.position!==void 0,A=p.morphAttributes.normal!==void 0,b=p.morphAttributes.color!==void 0,S=p.morphAttributes.position||[],N=p.morphAttributes.normal||[],O=p.morphAttributes.color||[];let z=0;M===!0&&(z=1),A===!0&&(z=2),b===!0&&(z=3);let k=p.attributes.position.count*z,L=1;k>e.maxTextureSize&&(L=Math.ceil(k/e.maxTextureSize),k=e.maxTextureSize);const H=new Float32Array(k*L*4*x),T=new $x(H,k,L,x);T.type=Wi,T.needsUpdate=!0;const I=z*4;for(let G=0;G<x;G++){const K=S[G],ue=N[G],pe=O[G],F=k*L*4*G;for(let D=0;D<K.count;D++){const P=D*I;M===!0&&(l.fromBufferAttribute(K,D),H[F+P+0]=l.x,H[F+P+1]=l.y,H[F+P+2]=l.z,H[F+P+3]=0),A===!0&&(l.fromBufferAttribute(ue,D),H[F+P+4]=l.x,H[F+P+5]=l.y,H[F+P+6]=l.z,H[F+P+7]=0),b===!0&&(l.fromBufferAttribute(pe,D),H[F+P+8]=l.x,H[F+P+9]=l.y,H[F+P+10]=l.z,H[F+P+11]=pe.itemSize===4?l.w:1)}}_={count:x,texture:T,size:new gt(k,L)},s.set(p,_),p.addEventListener("dispose",Z)}if(d.isInstancedMesh===!0&&d.morphTexture!==null)m.getUniforms().setValue(r,"morphTexture",d.morphTexture,i);else{let M=0;for(let b=0;b<h.length;b++)M+=h[b];const A=p.morphTargetsRelative?1:1-M;m.getUniforms().setValue(r,"morphTargetBaseInfluence",A),m.getUniforms().setValue(r,"morphTargetInfluences",h)}m.getUniforms().setValue(r,"morphTargetsTexture",_.texture,i),m.getUniforms().setValue(r,"morphTargetsTextureSize",_.size)}return{update:c}}function sT(r,e,i,s,l){let c=new WeakMap;function d(h){const g=l.render.frame,x=h.geometry,_=e.get(h,x);if(c.get(_)!==g&&(e.update(_),c.set(_,g)),h.isInstancedMesh&&(h.hasEventListener("dispose",m)===!1&&h.addEventListener("dispose",m),c.get(h)!==g&&(i.update(h.instanceMatrix,r.ARRAY_BUFFER),h.instanceColor!==null&&i.update(h.instanceColor,r.ARRAY_BUFFER),c.set(h,g))),h.isSkinnedMesh){const y=h.skeleton;c.get(y)!==g&&(y.update(),c.set(y,g))}return _}function p(){c=new WeakMap}function m(h){const g=h.target;g.removeEventListener("dispose",m),s.releaseStatesOfObject(g),i.remove(g.instanceMatrix),g.instanceColor!==null&&i.remove(g.instanceColor)}return{update:d,dispose:p}}const rT={[Fx]:"LINEAR_TONE_MAPPING",[Bx]:"REINHARD_TONE_MAPPING",[Ix]:"CINEON_TONE_MAPPING",[Hx]:"ACES_FILMIC_TONE_MAPPING",[Vx]:"AGX_TONE_MAPPING",[kx]:"NEUTRAL_TONE_MAPPING",[Gx]:"CUSTOM_TONE_MAPPING"};function oT(r,e,i,s,l){const c=new Zi(e,i,{type:r,depthBuffer:s,stencilBuffer:l,depthTexture:s?new qr(e,i):void 0}),d=new Zi(e,i,{type:Ta,depthBuffer:!1,stencilBuffer:!1}),p=new Pn;p.setAttribute("position",new Cn([-1,3,0,-1,-1,0,3,-1,0],3)),p.setAttribute("uv",new Cn([0,2,0,0,2,0],2));const m=new Wb({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),h=new zi(p,m),g=new _u(-1,1,1,-1,0,1);let x=null,_=null,y=!1,M,A=null,b=[],S=!1;this.setSize=function(N,O){c.setSize(N,O),d.setSize(N,O);for(let z=0;z<b.length;z++){const k=b[z];k.setSize&&k.setSize(N,O)}},this.setEffects=function(N){b=N,S=b.length>0&&b[0].isRenderPass===!0;const O=c.width,z=c.height;for(let k=0;k<b.length;k++){const L=b[k];L.setSize&&L.setSize(O,z)}},this.begin=function(N,O){if(y||N.toneMapping===Yi&&b.length===0)return!1;if(A=O,O!==null){const z=O.width,k=O.height;(c.width!==z||c.height!==k)&&this.setSize(z,k)}return S===!1&&N.setRenderTarget(c),M=N.toneMapping,N.toneMapping=Yi,!0},this.hasRenderPass=function(){return S},this.end=function(N,O){N.toneMapping=M,y=!0;let z=c,k=d;for(let L=0;L<b.length;L++){const H=b[L];if(H.enabled!==!1&&(H.render(N,k,z,O),H.needsSwap!==!1)){const T=z;z=k,k=T}}if(x!==N.outputColorSpace||_!==N.toneMapping){x=N.outputColorSpace,_=N.toneMapping,m.defines={},wt.getTransfer(x)===jt&&(m.defines.SRGB_TRANSFER="");const L=rT[_];L&&(m.defines[L]=""),m.needsUpdate=!0}m.uniforms.tDiffuse.value=z.texture,N.setRenderTarget(A),N.render(h,g),A=null,y=!1},this.isCompositing=function(){return y},this.dispose=function(){c.depthTexture&&c.depthTexture.dispose(),c.dispose(),d.dispose(),p.dispose(),m.dispose()}}const pv=new Wn,ap=new qr(1,1),mv=new $x,gv=new yb,_v=new rv,ux=[],fx=[],dx=new Float32Array(16),hx=new Float32Array(9),px=new Float32Array(4);function Qr(r,e,i){const s=r[0];if(s<=0||s>0)return r;const l=e*i;let c=ux[l];if(c===void 0&&(c=new Float32Array(l),ux[l]=c),e!==0){s.toArray(c,0);for(let d=1,p=0;d!==e;++d)p+=i,r[d].toArray(c,p)}return c}function Mn(r,e){if(r.length!==e.length)return!1;for(let i=0,s=r.length;i<s;i++)if(r[i]!==e[i])return!1;return!0}function En(r,e){for(let i=0,s=e.length;i<s;i++)r[i]=e[i]}function vu(r,e){let i=fx[e];i===void 0&&(i=new Int32Array(e),fx[e]=i);for(let s=0;s!==e;++s)i[s]=r.allocateTextureUnit();return i}function lT(r,e){const i=this.cache;i[0]!==e&&(r.uniform1f(this.addr,e),i[0]=e)}function cT(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y)&&(r.uniform2f(this.addr,e.x,e.y),i[0]=e.x,i[1]=e.y);else{if(Mn(i,e))return;r.uniform2fv(this.addr,e),En(i,e)}}function uT(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z)&&(r.uniform3f(this.addr,e.x,e.y,e.z),i[0]=e.x,i[1]=e.y,i[2]=e.z);else if(e.r!==void 0)(i[0]!==e.r||i[1]!==e.g||i[2]!==e.b)&&(r.uniform3f(this.addr,e.r,e.g,e.b),i[0]=e.r,i[1]=e.g,i[2]=e.b);else{if(Mn(i,e))return;r.uniform3fv(this.addr,e),En(i,e)}}function fT(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z||i[3]!==e.w)&&(r.uniform4f(this.addr,e.x,e.y,e.z,e.w),i[0]=e.x,i[1]=e.y,i[2]=e.z,i[3]=e.w);else{if(Mn(i,e))return;r.uniform4fv(this.addr,e),En(i,e)}}function dT(r,e){const i=this.cache,s=e.elements;if(s===void 0){if(Mn(i,e))return;r.uniformMatrix2fv(this.addr,!1,e),En(i,e)}else{if(Mn(i,s))return;px.set(s),r.uniformMatrix2fv(this.addr,!1,px),En(i,s)}}function hT(r,e){const i=this.cache,s=e.elements;if(s===void 0){if(Mn(i,e))return;r.uniformMatrix3fv(this.addr,!1,e),En(i,e)}else{if(Mn(i,s))return;hx.set(s),r.uniformMatrix3fv(this.addr,!1,hx),En(i,s)}}function pT(r,e){const i=this.cache,s=e.elements;if(s===void 0){if(Mn(i,e))return;r.uniformMatrix4fv(this.addr,!1,e),En(i,e)}else{if(Mn(i,s))return;dx.set(s),r.uniformMatrix4fv(this.addr,!1,dx),En(i,s)}}function mT(r,e){const i=this.cache;i[0]!==e&&(r.uniform1i(this.addr,e),i[0]=e)}function gT(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y)&&(r.uniform2i(this.addr,e.x,e.y),i[0]=e.x,i[1]=e.y);else{if(Mn(i,e))return;r.uniform2iv(this.addr,e),En(i,e)}}function _T(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z)&&(r.uniform3i(this.addr,e.x,e.y,e.z),i[0]=e.x,i[1]=e.y,i[2]=e.z);else{if(Mn(i,e))return;r.uniform3iv(this.addr,e),En(i,e)}}function xT(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z||i[3]!==e.w)&&(r.uniform4i(this.addr,e.x,e.y,e.z,e.w),i[0]=e.x,i[1]=e.y,i[2]=e.z,i[3]=e.w);else{if(Mn(i,e))return;r.uniform4iv(this.addr,e),En(i,e)}}function vT(r,e){const i=this.cache;i[0]!==e&&(r.uniform1ui(this.addr,e),i[0]=e)}function ST(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y)&&(r.uniform2ui(this.addr,e.x,e.y),i[0]=e.x,i[1]=e.y);else{if(Mn(i,e))return;r.uniform2uiv(this.addr,e),En(i,e)}}function yT(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z)&&(r.uniform3ui(this.addr,e.x,e.y,e.z),i[0]=e.x,i[1]=e.y,i[2]=e.z);else{if(Mn(i,e))return;r.uniform3uiv(this.addr,e),En(i,e)}}function bT(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z||i[3]!==e.w)&&(r.uniform4ui(this.addr,e.x,e.y,e.z,e.w),i[0]=e.x,i[1]=e.y,i[2]=e.z,i[3]=e.w);else{if(Mn(i,e))return;r.uniform4uiv(this.addr,e),En(i,e)}}function MT(r,e,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l);let c;this.type===r.SAMPLER_2D_SHADOW?(ap.compareFunction=i.isReversedDepthBuffer()?gp:mp,c=ap):c=pv,i.setTexture2D(e||c,l)}function ET(r,e,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l),i.setTexture3D(e||gv,l)}function TT(r,e,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l),i.setTextureCube(e||_v,l)}function AT(r,e,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l),i.setTexture2DArray(e||mv,l)}function RT(r){switch(r){case 5126:return lT;case 35664:return cT;case 35665:return uT;case 35666:return fT;case 35674:return dT;case 35675:return hT;case 35676:return pT;case 5124:case 35670:return mT;case 35667:case 35671:return gT;case 35668:case 35672:return _T;case 35669:case 35673:return xT;case 5125:return vT;case 36294:return ST;case 36295:return yT;case 36296:return bT;case 35678:case 36198:case 36298:case 36306:case 35682:return MT;case 35679:case 36299:case 36307:return ET;case 35680:case 36300:case 36308:case 36293:return TT;case 36289:case 36303:case 36311:case 36292:return AT}}function CT(r,e){r.uniform1fv(this.addr,e)}function wT(r,e){const i=Qr(e,this.size,2);r.uniform2fv(this.addr,i)}function DT(r,e){const i=Qr(e,this.size,3);r.uniform3fv(this.addr,i)}function NT(r,e){const i=Qr(e,this.size,4);r.uniform4fv(this.addr,i)}function UT(r,e){const i=Qr(e,this.size,4);r.uniformMatrix2fv(this.addr,!1,i)}function LT(r,e){const i=Qr(e,this.size,9);r.uniformMatrix3fv(this.addr,!1,i)}function OT(r,e){const i=Qr(e,this.size,16);r.uniformMatrix4fv(this.addr,!1,i)}function PT(r,e){r.uniform1iv(this.addr,e)}function zT(r,e){r.uniform2iv(this.addr,e)}function FT(r,e){r.uniform3iv(this.addr,e)}function BT(r,e){r.uniform4iv(this.addr,e)}function IT(r,e){r.uniform1uiv(this.addr,e)}function HT(r,e){r.uniform2uiv(this.addr,e)}function GT(r,e){r.uniform3uiv(this.addr,e)}function VT(r,e){r.uniform4uiv(this.addr,e)}function kT(r,e,i){const s=this.cache,l=e.length,c=vu(i,l);Mn(s,c)||(r.uniform1iv(this.addr,c),En(s,c));let d;this.type===r.SAMPLER_2D_SHADOW?d=ap:d=pv;for(let p=0;p!==l;++p)i.setTexture2D(e[p]||d,c[p])}function jT(r,e,i){const s=this.cache,l=e.length,c=vu(i,l);Mn(s,c)||(r.uniform1iv(this.addr,c),En(s,c));for(let d=0;d!==l;++d)i.setTexture3D(e[d]||gv,c[d])}function XT(r,e,i){const s=this.cache,l=e.length,c=vu(i,l);Mn(s,c)||(r.uniform1iv(this.addr,c),En(s,c));for(let d=0;d!==l;++d)i.setTextureCube(e[d]||_v,c[d])}function WT(r,e,i){const s=this.cache,l=e.length,c=vu(i,l);Mn(s,c)||(r.uniform1iv(this.addr,c),En(s,c));for(let d=0;d!==l;++d)i.setTexture2DArray(e[d]||mv,c[d])}function qT(r){switch(r){case 5126:return CT;case 35664:return wT;case 35665:return DT;case 35666:return NT;case 35674:return UT;case 35675:return LT;case 35676:return OT;case 5124:case 35670:return PT;case 35667:case 35671:return zT;case 35668:case 35672:return FT;case 35669:case 35673:return BT;case 5125:return IT;case 36294:return HT;case 36295:return GT;case 36296:return VT;case 35678:case 36198:case 36298:case 36306:case 35682:return kT;case 35679:case 36299:case 36307:return jT;case 35680:case 36300:case 36308:case 36293:return XT;case 36289:case 36303:case 36311:case 36292:return WT}}class YT{constructor(e,i,s){this.id=e,this.addr=s,this.cache=[],this.type=i.type,this.setValue=RT(i.type)}}class ZT{constructor(e,i,s){this.id=e,this.addr=s,this.cache=[],this.type=i.type,this.size=i.size,this.setValue=qT(i.type)}}class KT{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,i,s){const l=this.seq;for(let c=0,d=l.length;c!==d;++c){const p=l[c];p.setValue(e,i[p.id],s)}}}const ch=/(\w+)(\])?(\[|\.)?/g;function mx(r,e){r.seq.push(e),r.map[e.id]=e}function QT(r,e,i){const s=r.name,l=s.length;for(ch.lastIndex=0;;){const c=ch.exec(s),d=ch.lastIndex;let p=c[1];const m=c[2]==="]",h=c[3];if(m&&(p=p|0),h===void 0||h==="["&&d+2===l){mx(i,h===void 0?new YT(p,r,e):new ZT(p,r,e));break}else{let x=i.map[p];x===void 0&&(x=new KT(p),mx(i,x)),i=x}}}class su{constructor(e,i){this.seq=[],this.map={};const s=e.getProgramParameter(i,e.ACTIVE_UNIFORMS);for(let d=0;d<s;++d){const p=e.getActiveUniform(i,d),m=e.getUniformLocation(i,p.name);QT(p,m,this)}const l=[],c=[];for(const d of this.seq)d.type===e.SAMPLER_2D_SHADOW||d.type===e.SAMPLER_CUBE_SHADOW||d.type===e.SAMPLER_2D_ARRAY_SHADOW?l.push(d):c.push(d);l.length>0&&(this.seq=l.concat(c))}setValue(e,i,s,l){const c=this.map[i];c!==void 0&&c.setValue(e,s,l)}setOptional(e,i,s){const l=i[s];l!==void 0&&this.setValue(e,s,l)}static upload(e,i,s,l){for(let c=0,d=i.length;c!==d;++c){const p=i[c],m=s[p.id];m.needsUpdate!==!1&&p.setValue(e,m.value,l)}}static seqWithValue(e,i){const s=[];for(let l=0,c=e.length;l!==c;++l){const d=e[l];d.id in i&&s.push(d)}return s}}function gx(r,e,i){const s=r.createShader(e);return r.shaderSource(s,i),r.compileShader(s),s}const JT=37297;let $T=0;function eA(r,e){const i=r.split(`
`),s=[],l=Math.max(e-6,0),c=Math.min(e+6,i.length);for(let d=l;d<c;d++){const p=d+1;s.push(`${p===e?">":" "} ${p}: ${i[d]}`)}return s.join(`
`)}const _x=new ht;function tA(r){wt._getMatrix(_x,wt.workingColorSpace,r);const e=`mat3( ${_x.elements.map(i=>i.toFixed(4))} )`;switch(wt.getTransfer(r)){case cu:return[e,"LinearTransferOETF"];case jt:return[e,"sRGBTransferOETF"];default:return st("WebGLProgram: Unsupported color space: ",r),[e,"LinearTransferOETF"]}}function xx(r,e,i){const s=r.getShaderParameter(e,r.COMPILE_STATUS),c=(r.getShaderInfoLog(e)||"").trim();if(s&&c==="")return"";const d=/ERROR: 0:(\d+)/.exec(c);if(d){const p=parseInt(d[1]);return i.toUpperCase()+`

`+c+`

`+eA(r.getShaderSource(e),p)}else return c}function nA(r,e){const i=tA(e);return[`vec4 ${r}( vec4 value ) {`,`	return ${i[1]}( vec4( value.rgb * ${i[0]}, value.a ) );`,"}"].join(`
`)}const iA={[Fx]:"Linear",[Bx]:"Reinhard",[Ix]:"Cineon",[Hx]:"ACESFilmic",[Vx]:"AgX",[kx]:"Neutral",[Gx]:"Custom"};function aA(r,e){const i=iA[e];return i===void 0?(st("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+r+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+r+"( vec3 color ) { return "+i+"ToneMapping( color ); }"}const Jc=new ee;function sA(){wt.getLuminanceCoefficients(Jc);const r=Jc.x.toFixed(4),e=Jc.y.toFixed(4),i=Jc.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${r}, ${e}, ${i} );`,"	return dot( weights, rgb );","}"].join(`
`)}function rA(r){return[r.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",r.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(al).join(`
`)}function oA(r){const e=[];for(const i in r){const s=r[i];s!==!1&&e.push("#define "+i+" "+s)}return e.join(`
`)}function lA(r,e){const i={},s=r.getProgramParameter(e,r.ACTIVE_ATTRIBUTES);for(let l=0;l<s;l++){const c=r.getActiveAttrib(e,l),d=c.name;let p=1;c.type===r.FLOAT_MAT2&&(p=2),c.type===r.FLOAT_MAT3&&(p=3),c.type===r.FLOAT_MAT4&&(p=4),i[d]={type:c.type,location:r.getAttribLocation(e,d),locationSize:p}}return i}function al(r){return r!==""}function vx(r,e){const i=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,i).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Sx(r,e){return r.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const cA=/^[ \t]*#include +<([\w\d./]+)>/gm;function sp(r){return r.replace(cA,fA)}const uA=new Map;function fA(r,e){let i=vt[e];if(i===void 0){const s=uA.get(e);if(s!==void 0)i=vt[s],st('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,s);else throw new Error("Can not resolve #include <"+e+">")}return sp(i)}const dA=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function yx(r){return r.replace(dA,hA)}function hA(r,e,i,s){let l="";for(let c=parseInt(e);c<parseInt(i);c++)l+=s.replace(/\[\s*i\s*\]/g,"[ "+c+" ]").replace(/UNROLLED_LOOP_INDEX/g,c);return l}function bx(r){let e=`precision ${r.precision} float;
	precision ${r.precision} int;
	precision ${r.precision} sampler2D;
	precision ${r.precision} samplerCube;
	precision ${r.precision} sampler3D;
	precision ${r.precision} sampler2DArray;
	precision ${r.precision} sampler2DShadow;
	precision ${r.precision} samplerCubeShadow;
	precision ${r.precision} sampler2DArrayShadow;
	precision ${r.precision} isampler2D;
	precision ${r.precision} isampler3D;
	precision ${r.precision} isamplerCube;
	precision ${r.precision} isampler2DArray;
	precision ${r.precision} usampler2D;
	precision ${r.precision} usampler3D;
	precision ${r.precision} usamplerCube;
	precision ${r.precision} usampler2DArray;
	`;return r.precision==="highp"?e+=`
#define HIGH_PRECISION`:r.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const pA={[eu]:"SHADOWMAP_TYPE_PCF",[nl]:"SHADOWMAP_TYPE_VSM"};function mA(r){return pA[r.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const gA={[ks]:"ENVMAP_TYPE_CUBE",[Xr]:"ENVMAP_TYPE_CUBE",[pu]:"ENVMAP_TYPE_CUBE_UV"};function _A(r){return r.envMap===!1?"ENVMAP_TYPE_CUBE":gA[r.envMapMode]||"ENVMAP_TYPE_CUBE"}const xA={[Xr]:"ENVMAP_MODE_REFRACTION"};function vA(r){return r.envMap===!1?"ENVMAP_MODE_REFLECTION":xA[r.envMapMode]||"ENVMAP_MODE_REFLECTION"}const SA={[zx]:"ENVMAP_BLENDING_MULTIPLY",[$y]:"ENVMAP_BLENDING_MIX",[eb]:"ENVMAP_BLENDING_ADD"};function yA(r){return r.envMap===!1?"ENVMAP_BLENDING_NONE":SA[r.combine]||"ENVMAP_BLENDING_NONE"}function bA(r){const e=r.envMapCubeUVHeight;if(e===null)return null;const i=Math.log2(e)-2,s=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,i),112)),texelHeight:s,maxMip:i}}function MA(r,e,i,s){const l=r.getContext(),c=i.defines;let d=i.vertexShader,p=i.fragmentShader;const m=mA(i),h=_A(i),g=vA(i),x=yA(i),_=bA(i),y=rA(i),M=oA(c),A=l.createProgram();let b,S,N=i.glslVersion?"#version "+i.glslVersion+`
`:"";i.isRawShaderMaterial?(b=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,M].filter(al).join(`
`),b.length>0&&(b+=`
`),S=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,M].filter(al).join(`
`),S.length>0&&(S+=`
`)):(b=[bx(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,M,i.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",i.batching?"#define USE_BATCHING":"",i.batchingColor?"#define USE_BATCHING_COLOR":"",i.instancing?"#define USE_INSTANCING":"",i.instancingColor?"#define USE_INSTANCING_COLOR":"",i.instancingMorph?"#define USE_INSTANCING_MORPH":"",i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.map?"#define USE_MAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+g:"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.displacementMap?"#define USE_DISPLACEMENTMAP":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.mapUv?"#define MAP_UV "+i.mapUv:"",i.alphaMapUv?"#define ALPHAMAP_UV "+i.alphaMapUv:"",i.lightMapUv?"#define LIGHTMAP_UV "+i.lightMapUv:"",i.aoMapUv?"#define AOMAP_UV "+i.aoMapUv:"",i.emissiveMapUv?"#define EMISSIVEMAP_UV "+i.emissiveMapUv:"",i.bumpMapUv?"#define BUMPMAP_UV "+i.bumpMapUv:"",i.normalMapUv?"#define NORMALMAP_UV "+i.normalMapUv:"",i.displacementMapUv?"#define DISPLACEMENTMAP_UV "+i.displacementMapUv:"",i.metalnessMapUv?"#define METALNESSMAP_UV "+i.metalnessMapUv:"",i.roughnessMapUv?"#define ROUGHNESSMAP_UV "+i.roughnessMapUv:"",i.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+i.anisotropyMapUv:"",i.clearcoatMapUv?"#define CLEARCOATMAP_UV "+i.clearcoatMapUv:"",i.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+i.clearcoatNormalMapUv:"",i.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+i.clearcoatRoughnessMapUv:"",i.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+i.iridescenceMapUv:"",i.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+i.iridescenceThicknessMapUv:"",i.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+i.sheenColorMapUv:"",i.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+i.sheenRoughnessMapUv:"",i.specularMapUv?"#define SPECULARMAP_UV "+i.specularMapUv:"",i.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+i.specularColorMapUv:"",i.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+i.specularIntensityMapUv:"",i.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+i.transmissionMapUv:"",i.thicknessMapUv?"#define THICKNESSMAP_UV "+i.thicknessMapUv:"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexNormals?"#define HAS_NORMAL":"",i.vertexColors?"#define USE_COLOR":"",i.vertexAlphas?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.flatShading?"#define FLAT_SHADED":"",i.skinning?"#define USE_SKINNING":"",i.morphTargets?"#define USE_MORPHTARGETS":"",i.morphNormals&&i.flatShading===!1?"#define USE_MORPHNORMALS":"",i.morphColors?"#define USE_MORPHCOLORS":"",i.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+i.morphTextureStride:"",i.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+i.morphTargetsCount:"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+m:"",i.sizeAttenuation?"#define USE_SIZEATTENUATION":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",i.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(al).join(`
`),S=[bx(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,M,i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",i.map?"#define USE_MAP":"",i.matcap?"#define USE_MATCAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+h:"",i.envMap?"#define "+g:"",i.envMap?"#define "+x:"",_?"#define CUBEUV_TEXEL_WIDTH "+_.texelWidth:"",_?"#define CUBEUV_TEXEL_HEIGHT "+_.texelHeight:"",_?"#define CUBEUV_MAX_MIP "+_.maxMip+".0":"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoat?"#define USE_CLEARCOAT":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.dispersion?"#define USE_DISPERSION":"",i.iridescence?"#define USE_IRIDESCENCE":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaTest?"#define USE_ALPHATEST":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.sheen?"#define USE_SHEEN":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexColors||i.instancingColor?"#define USE_COLOR":"",i.vertexAlphas||i.batchingColor?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.gradientMap?"#define USE_GRADIENTMAP":"",i.flatShading?"#define FLAT_SHADED":"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+m:"",i.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",i.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",i.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",i.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",i.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",i.toneMapping!==Yi?"#define TONE_MAPPING":"",i.toneMapping!==Yi?vt.tonemapping_pars_fragment:"",i.toneMapping!==Yi?aA("toneMapping",i.toneMapping):"",i.dithering?"#define DITHERING":"",i.opaque?"#define OPAQUE":"",vt.colorspace_pars_fragment,nA("linearToOutputTexel",i.outputColorSpace),sA(),i.useDepthPacking?"#define DEPTH_PACKING "+i.depthPacking:"",`
`].filter(al).join(`
`)),d=sp(d),d=vx(d,i),d=Sx(d,i),p=sp(p),p=vx(p,i),p=Sx(p,i),d=yx(d),p=yx(p),i.isRawShaderMaterial!==!0&&(N=`#version 300 es
`,b=[y,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+b,S=["#define varying in",i.glslVersion===b_?"":"layout(location = 0) out highp vec4 pc_fragColor;",i.glslVersion===b_?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+S);const O=N+b+d,z=N+S+p,k=gx(l,l.VERTEX_SHADER,O),L=gx(l,l.FRAGMENT_SHADER,z);l.attachShader(A,k),l.attachShader(A,L),i.index0AttributeName!==void 0?l.bindAttribLocation(A,0,i.index0AttributeName):i.morphTargets===!0&&l.bindAttribLocation(A,0,"position"),l.linkProgram(A);function H(G){if(r.debug.checkShaderErrors){const K=l.getProgramInfoLog(A)||"",ue=l.getShaderInfoLog(k)||"",pe=l.getShaderInfoLog(L)||"",F=K.trim(),D=ue.trim(),P=pe.trim();let q=!0,he=!0;if(l.getProgramParameter(A,l.LINK_STATUS)===!1)if(q=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(l,A,k,L);else{const _e=xx(l,k,"vertex"),B=xx(l,L,"fragment");Ut("THREE.WebGLProgram: Shader Error "+l.getError()+" - VALIDATE_STATUS "+l.getProgramParameter(A,l.VALIDATE_STATUS)+`

Material Name: `+G.name+`
Material Type: `+G.type+`

Program Info Log: `+F+`
`+_e+`
`+B)}else F!==""?st("WebGLProgram: Program Info Log:",F):(D===""||P==="")&&(he=!1);he&&(G.diagnostics={runnable:q,programLog:F,vertexShader:{log:D,prefix:b},fragmentShader:{log:P,prefix:S}})}l.deleteShader(k),l.deleteShader(L),T=new su(l,A),I=lA(l,A)}let T;this.getUniforms=function(){return T===void 0&&H(this),T};let I;this.getAttributes=function(){return I===void 0&&H(this),I};let Z=i.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return Z===!1&&(Z=l.getProgramParameter(A,JT)),Z},this.destroy=function(){s.releaseStatesOfProgram(this),l.deleteProgram(A),this.program=void 0},this.type=i.shaderType,this.name=i.shaderName,this.id=$T++,this.cacheKey=e,this.usedTimes=1,this.program=A,this.vertexShader=k,this.fragmentShader=L,this}let EA=0;class TA{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const i=e.vertexShader,s=e.fragmentShader,l=this._getShaderStage(i),c=this._getShaderStage(s),d=this._getShaderCacheForMaterial(e);return d.has(l)===!1&&(d.add(l),l.usedTimes++),d.has(c)===!1&&(d.add(c),c.usedTimes++),this}remove(e){const i=this.materialCache.get(e);for(const s of i)s.usedTimes--,s.usedTimes===0&&this.shaderCache.delete(s.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const i=this.materialCache;let s=i.get(e);return s===void 0&&(s=new Set,i.set(e,s)),s}_getShaderStage(e){const i=this.shaderCache;let s=i.get(e);return s===void 0&&(s=new AA(e),i.set(e,s)),s}}class AA{constructor(e){this.id=EA++,this.code=e,this.usedTimes=0}}function RA(r){return r===js||r===ru||r===ou}function CA(r,e,i,s,l,c){const d=new ev,p=new TA,m=new Set,h=[],g=new Map,x=s.logarithmicDepthBuffer;let _=s.precision;const y={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function M(T){return m.add(T),T===0?"uv":`uv${T}`}function A(T,I,Z,G,K,ue){const pe=G.fog,F=K.geometry,D=T.isMeshStandardMaterial||T.isMeshLambertMaterial||T.isMeshPhongMaterial?G.environment:null,P=T.isMeshStandardMaterial||T.isMeshLambertMaterial&&!T.envMap||T.isMeshPhongMaterial&&!T.envMap,q=e.get(T.envMap||D,P),he=q&&q.mapping===pu?q.image.height:null,_e=y[T.type];T.precision!==null&&(_=s.getMaxPrecision(T.precision),_!==T.precision&&st("WebGLProgram.getParameters:",T.precision,"not supported, using",_,"instead."));const B=F.morphAttributes.position||F.morphAttributes.normal||F.morphAttributes.color,Q=B!==void 0?B.length:0;let ve=0;F.morphAttributes.position!==void 0&&(ve=1),F.morphAttributes.normal!==void 0&&(ve=2),F.morphAttributes.color!==void 0&&(ve=3);let Ae,Ce,ae,ye;if(_e){const it=ji[_e];Ae=it.vertexShader,Ce=it.fragmentShader}else Ae=T.vertexShader,Ce=T.fragmentShader,p.update(T),ae=p.getVertexShaderID(T),ye=p.getFragmentShaderID(T);const Me=r.getRenderTarget(),Ie=r.state.buffers.depth.getReversed(),Ze=K.isInstancedMesh===!0,Ke=K.isBatchedMesh===!0,Lt=!!T.map,nt=!!T.matcap,dt=!!q,St=!!T.aoMap,ct=!!T.lightMap,$t=!!T.bumpMap,te=!!T.normalMap,Fe=!!T.displacementMap,j=!!T.emissiveMap,yt=!!T.metalnessMap,lt=!!T.roughnessMap,Nt=T.anisotropy>0,we=T.clearcoat>0,Xt=T.dispersion>0,U=T.iridescence>0,E=T.sheen>0,$=T.transmission>0,xe=Nt&&!!T.anisotropyMap,Te=we&&!!T.clearcoatMap,Ne=we&&!!T.clearcoatNormalMap,Pe=we&&!!T.clearcoatRoughnessMap,ne=U&&!!T.iridescenceMap,de=U&&!!T.iridescenceThicknessMap,Oe=E&&!!T.sheenColorMap,ze=E&&!!T.sheenRoughnessMap,Ue=!!T.specularMap,De=!!T.specularColorMap,rt=!!T.specularIntensityMap,ot=$&&!!T.transmissionMap,_t=$&&!!T.thicknessMap,X=!!T.gradientMap,Re=!!T.alphaMap,me=T.alphaTest>0,He=!!T.alphaHash,Le=!!T.extensions;let Ee=Yi;T.toneMapped&&(Me===null||Me.isXRRenderTarget===!0)&&(Ee=r.toneMapping);const We={shaderID:_e,shaderType:T.type,shaderName:T.name,vertexShader:Ae,fragmentShader:Ce,defines:T.defines,customVertexShaderID:ae,customFragmentShaderID:ye,isRawShaderMaterial:T.isRawShaderMaterial===!0,glslVersion:T.glslVersion,precision:_,batching:Ke,batchingColor:Ke&&K._colorsTexture!==null,instancing:Ze,instancingColor:Ze&&K.instanceColor!==null,instancingMorph:Ze&&K.morphTexture!==null,outputColorSpace:Me===null?r.outputColorSpace:Me.isXRRenderTarget===!0?Me.texture.colorSpace:wt.workingColorSpace,alphaToCoverage:!!T.alphaToCoverage,map:Lt,matcap:nt,envMap:dt,envMapMode:dt&&q.mapping,envMapCubeUVHeight:he,aoMap:St,lightMap:ct,bumpMap:$t,normalMap:te,displacementMap:Fe,emissiveMap:j,normalMapObjectSpace:te&&T.normalMapType===ib,normalMapTangentSpace:te&&T.normalMapType===ep,packedNormalMap:te&&T.normalMapType===ep&&RA(T.normalMap.format),metalnessMap:yt,roughnessMap:lt,anisotropy:Nt,anisotropyMap:xe,clearcoat:we,clearcoatMap:Te,clearcoatNormalMap:Ne,clearcoatRoughnessMap:Pe,dispersion:Xt,iridescence:U,iridescenceMap:ne,iridescenceThicknessMap:de,sheen:E,sheenColorMap:Oe,sheenRoughnessMap:ze,specularMap:Ue,specularColorMap:De,specularIntensityMap:rt,transmission:$,transmissionMap:ot,thicknessMap:_t,gradientMap:X,opaque:T.transparent===!1&&T.blending===Vr&&T.alphaToCoverage===!1,alphaMap:Re,alphaTest:me,alphaHash:He,combine:T.combine,mapUv:Lt&&M(T.map.channel),aoMapUv:St&&M(T.aoMap.channel),lightMapUv:ct&&M(T.lightMap.channel),bumpMapUv:$t&&M(T.bumpMap.channel),normalMapUv:te&&M(T.normalMap.channel),displacementMapUv:Fe&&M(T.displacementMap.channel),emissiveMapUv:j&&M(T.emissiveMap.channel),metalnessMapUv:yt&&M(T.metalnessMap.channel),roughnessMapUv:lt&&M(T.roughnessMap.channel),anisotropyMapUv:xe&&M(T.anisotropyMap.channel),clearcoatMapUv:Te&&M(T.clearcoatMap.channel),clearcoatNormalMapUv:Ne&&M(T.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Pe&&M(T.clearcoatRoughnessMap.channel),iridescenceMapUv:ne&&M(T.iridescenceMap.channel),iridescenceThicknessMapUv:de&&M(T.iridescenceThicknessMap.channel),sheenColorMapUv:Oe&&M(T.sheenColorMap.channel),sheenRoughnessMapUv:ze&&M(T.sheenRoughnessMap.channel),specularMapUv:Ue&&M(T.specularMap.channel),specularColorMapUv:De&&M(T.specularColorMap.channel),specularIntensityMapUv:rt&&M(T.specularIntensityMap.channel),transmissionMapUv:ot&&M(T.transmissionMap.channel),thicknessMapUv:_t&&M(T.thicknessMap.channel),alphaMapUv:Re&&M(T.alphaMap.channel),vertexTangents:!!F.attributes.tangent&&(te||Nt),vertexNormals:!!F.attributes.normal,vertexColors:T.vertexColors,vertexAlphas:T.vertexColors===!0&&!!F.attributes.color&&F.attributes.color.itemSize===4,pointsUvs:K.isPoints===!0&&!!F.attributes.uv&&(Lt||Re),fog:!!pe,useFog:T.fog===!0,fogExp2:!!pe&&pe.isFogExp2,flatShading:T.wireframe===!1&&(T.flatShading===!0||F.attributes.normal===void 0&&te===!1&&(T.isMeshLambertMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isMeshPhysicalMaterial)),sizeAttenuation:T.sizeAttenuation===!0,logarithmicDepthBuffer:x,reversedDepthBuffer:Ie,skinning:K.isSkinnedMesh===!0,morphTargets:F.morphAttributes.position!==void 0,morphNormals:F.morphAttributes.normal!==void 0,morphColors:F.morphAttributes.color!==void 0,morphTargetsCount:Q,morphTextureStride:ve,numDirLights:I.directional.length,numPointLights:I.point.length,numSpotLights:I.spot.length,numSpotLightMaps:I.spotLightMap.length,numRectAreaLights:I.rectArea.length,numHemiLights:I.hemi.length,numDirLightShadows:I.directionalShadowMap.length,numPointLightShadows:I.pointShadowMap.length,numSpotLightShadows:I.spotShadowMap.length,numSpotLightShadowsWithMaps:I.numSpotLightShadowsWithMaps,numLightProbes:I.numLightProbes,numLightProbeGrids:ue.length,numClippingPlanes:c.numPlanes,numClipIntersection:c.numIntersection,dithering:T.dithering,shadowMapEnabled:r.shadowMap.enabled&&Z.length>0,shadowMapType:r.shadowMap.type,toneMapping:Ee,decodeVideoTexture:Lt&&T.map.isVideoTexture===!0&&wt.getTransfer(T.map.colorSpace)===jt,decodeVideoTextureEmissive:j&&T.emissiveMap.isVideoTexture===!0&&wt.getTransfer(T.emissiveMap.colorSpace)===jt,premultipliedAlpha:T.premultipliedAlpha,doubleSided:T.side===Xi,flipSided:T.side===ni,useDepthPacking:T.depthPacking>=0,depthPacking:T.depthPacking||0,index0AttributeName:T.index0AttributeName,extensionClipCullDistance:Le&&T.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Le&&T.extensions.multiDraw===!0||Ke)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:T.customProgramCacheKey()};return We.vertexUv1s=m.has(1),We.vertexUv2s=m.has(2),We.vertexUv3s=m.has(3),m.clear(),We}function b(T){const I=[];if(T.shaderID?I.push(T.shaderID):(I.push(T.customVertexShaderID),I.push(T.customFragmentShaderID)),T.defines!==void 0)for(const Z in T.defines)I.push(Z),I.push(T.defines[Z]);return T.isRawShaderMaterial===!1&&(S(I,T),N(I,T),I.push(r.outputColorSpace)),I.push(T.customProgramCacheKey),I.join()}function S(T,I){T.push(I.precision),T.push(I.outputColorSpace),T.push(I.envMapMode),T.push(I.envMapCubeUVHeight),T.push(I.mapUv),T.push(I.alphaMapUv),T.push(I.lightMapUv),T.push(I.aoMapUv),T.push(I.bumpMapUv),T.push(I.normalMapUv),T.push(I.displacementMapUv),T.push(I.emissiveMapUv),T.push(I.metalnessMapUv),T.push(I.roughnessMapUv),T.push(I.anisotropyMapUv),T.push(I.clearcoatMapUv),T.push(I.clearcoatNormalMapUv),T.push(I.clearcoatRoughnessMapUv),T.push(I.iridescenceMapUv),T.push(I.iridescenceThicknessMapUv),T.push(I.sheenColorMapUv),T.push(I.sheenRoughnessMapUv),T.push(I.specularMapUv),T.push(I.specularColorMapUv),T.push(I.specularIntensityMapUv),T.push(I.transmissionMapUv),T.push(I.thicknessMapUv),T.push(I.combine),T.push(I.fogExp2),T.push(I.sizeAttenuation),T.push(I.morphTargetsCount),T.push(I.morphAttributeCount),T.push(I.numDirLights),T.push(I.numPointLights),T.push(I.numSpotLights),T.push(I.numSpotLightMaps),T.push(I.numHemiLights),T.push(I.numRectAreaLights),T.push(I.numDirLightShadows),T.push(I.numPointLightShadows),T.push(I.numSpotLightShadows),T.push(I.numSpotLightShadowsWithMaps),T.push(I.numLightProbes),T.push(I.shadowMapType),T.push(I.toneMapping),T.push(I.numClippingPlanes),T.push(I.numClipIntersection),T.push(I.depthPacking)}function N(T,I){d.disableAll(),I.instancing&&d.enable(0),I.instancingColor&&d.enable(1),I.instancingMorph&&d.enable(2),I.matcap&&d.enable(3),I.envMap&&d.enable(4),I.normalMapObjectSpace&&d.enable(5),I.normalMapTangentSpace&&d.enable(6),I.clearcoat&&d.enable(7),I.iridescence&&d.enable(8),I.alphaTest&&d.enable(9),I.vertexColors&&d.enable(10),I.vertexAlphas&&d.enable(11),I.vertexUv1s&&d.enable(12),I.vertexUv2s&&d.enable(13),I.vertexUv3s&&d.enable(14),I.vertexTangents&&d.enable(15),I.anisotropy&&d.enable(16),I.alphaHash&&d.enable(17),I.batching&&d.enable(18),I.dispersion&&d.enable(19),I.batchingColor&&d.enable(20),I.gradientMap&&d.enable(21),I.packedNormalMap&&d.enable(22),I.vertexNormals&&d.enable(23),T.push(d.mask),d.disableAll(),I.fog&&d.enable(0),I.useFog&&d.enable(1),I.flatShading&&d.enable(2),I.logarithmicDepthBuffer&&d.enable(3),I.reversedDepthBuffer&&d.enable(4),I.skinning&&d.enable(5),I.morphTargets&&d.enable(6),I.morphNormals&&d.enable(7),I.morphColors&&d.enable(8),I.premultipliedAlpha&&d.enable(9),I.shadowMapEnabled&&d.enable(10),I.doubleSided&&d.enable(11),I.flipSided&&d.enable(12),I.useDepthPacking&&d.enable(13),I.dithering&&d.enable(14),I.transmission&&d.enable(15),I.sheen&&d.enable(16),I.opaque&&d.enable(17),I.pointsUvs&&d.enable(18),I.decodeVideoTexture&&d.enable(19),I.decodeVideoTextureEmissive&&d.enable(20),I.alphaToCoverage&&d.enable(21),I.numLightProbeGrids>0&&d.enable(22),T.push(d.mask)}function O(T){const I=y[T.type];let Z;if(I){const G=ji[I];Z=kb.clone(G.uniforms)}else Z=T.uniforms;return Z}function z(T,I){let Z=g.get(I);return Z!==void 0?++Z.usedTimes:(Z=new MA(r,I,T,l),h.push(Z),g.set(I,Z)),Z}function k(T){if(--T.usedTimes===0){const I=h.indexOf(T);h[I]=h[h.length-1],h.pop(),g.delete(T.cacheKey),T.destroy()}}function L(T){p.remove(T)}function H(){p.dispose()}return{getParameters:A,getProgramCacheKey:b,getUniforms:O,acquireProgram:z,releaseProgram:k,releaseShaderCache:L,programs:h,dispose:H}}function wA(){let r=new WeakMap;function e(d){return r.has(d)}function i(d){let p=r.get(d);return p===void 0&&(p={},r.set(d,p)),p}function s(d){r.delete(d)}function l(d,p,m){r.get(d)[p]=m}function c(){r=new WeakMap}return{has:e,get:i,remove:s,update:l,dispose:c}}function DA(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.material.id!==e.material.id?r.material.id-e.material.id:r.materialVariant!==e.materialVariant?r.materialVariant-e.materialVariant:r.z!==e.z?r.z-e.z:r.id-e.id}function Mx(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.z!==e.z?e.z-r.z:r.id-e.id}function Ex(){const r=[];let e=0;const i=[],s=[],l=[];function c(){e=0,i.length=0,s.length=0,l.length=0}function d(_){let y=0;return _.isInstancedMesh&&(y+=2),_.isSkinnedMesh&&(y+=1),y}function p(_,y,M,A,b,S){let N=r[e];return N===void 0?(N={id:_.id,object:_,geometry:y,material:M,materialVariant:d(_),groupOrder:A,renderOrder:_.renderOrder,z:b,group:S},r[e]=N):(N.id=_.id,N.object=_,N.geometry=y,N.material=M,N.materialVariant=d(_),N.groupOrder=A,N.renderOrder=_.renderOrder,N.z=b,N.group=S),e++,N}function m(_,y,M,A,b,S){const N=p(_,y,M,A,b,S);M.transmission>0?s.push(N):M.transparent===!0?l.push(N):i.push(N)}function h(_,y,M,A,b,S){const N=p(_,y,M,A,b,S);M.transmission>0?s.unshift(N):M.transparent===!0?l.unshift(N):i.unshift(N)}function g(_,y){i.length>1&&i.sort(_||DA),s.length>1&&s.sort(y||Mx),l.length>1&&l.sort(y||Mx)}function x(){for(let _=e,y=r.length;_<y;_++){const M=r[_];if(M.id===null)break;M.id=null,M.object=null,M.geometry=null,M.material=null,M.group=null}}return{opaque:i,transmissive:s,transparent:l,init:c,push:m,unshift:h,finish:x,sort:g}}function NA(){let r=new WeakMap;function e(s,l){const c=r.get(s);let d;return c===void 0?(d=new Ex,r.set(s,[d])):l>=c.length?(d=new Ex,c.push(d)):d=c[l],d}function i(){r=new WeakMap}return{get:e,dispose:i}}function UA(){const r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let i;switch(e.type){case"DirectionalLight":i={direction:new ee,color:new ft};break;case"SpotLight":i={position:new ee,direction:new ee,color:new ft,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":i={position:new ee,color:new ft,distance:0,decay:0};break;case"HemisphereLight":i={direction:new ee,skyColor:new ft,groundColor:new ft};break;case"RectAreaLight":i={color:new ft,position:new ee,halfWidth:new ee,halfHeight:new ee};break}return r[e.id]=i,i}}}function LA(){const r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let i;switch(e.type){case"DirectionalLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new gt};break;case"SpotLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new gt};break;case"PointLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new gt,shadowCameraNear:1,shadowCameraFar:1e3};break}return r[e.id]=i,i}}}let OA=0;function PA(r,e){return(e.castShadow?2:0)-(r.castShadow?2:0)+(e.map?1:0)-(r.map?1:0)}function zA(r){const e=new UA,i=LA(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)s.probe.push(new ee);const l=new ee,c=new rn,d=new rn;function p(h){let g=0,x=0,_=0;for(let I=0;I<9;I++)s.probe[I].set(0,0,0);let y=0,M=0,A=0,b=0,S=0,N=0,O=0,z=0,k=0,L=0,H=0;h.sort(PA);for(let I=0,Z=h.length;I<Z;I++){const G=h[I],K=G.color,ue=G.intensity,pe=G.distance;let F=null;if(G.shadow&&G.shadow.map&&(G.shadow.map.texture.format===js?F=G.shadow.map.texture:F=G.shadow.map.depthTexture||G.shadow.map.texture),G.isAmbientLight)g+=K.r*ue,x+=K.g*ue,_+=K.b*ue;else if(G.isLightProbe){for(let D=0;D<9;D++)s.probe[D].addScaledVector(G.sh.coefficients[D],ue);H++}else if(G.isDirectionalLight){const D=e.get(G);if(D.color.copy(G.color).multiplyScalar(G.intensity),G.castShadow){const P=G.shadow,q=i.get(G);q.shadowIntensity=P.intensity,q.shadowBias=P.bias,q.shadowNormalBias=P.normalBias,q.shadowRadius=P.radius,q.shadowMapSize=P.mapSize,s.directionalShadow[y]=q,s.directionalShadowMap[y]=F,s.directionalShadowMatrix[y]=G.shadow.matrix,N++}s.directional[y]=D,y++}else if(G.isSpotLight){const D=e.get(G);D.position.setFromMatrixPosition(G.matrixWorld),D.color.copy(K).multiplyScalar(ue),D.distance=pe,D.coneCos=Math.cos(G.angle),D.penumbraCos=Math.cos(G.angle*(1-G.penumbra)),D.decay=G.decay,s.spot[A]=D;const P=G.shadow;if(G.map&&(s.spotLightMap[k]=G.map,k++,P.updateMatrices(G),G.castShadow&&L++),s.spotLightMatrix[A]=P.matrix,G.castShadow){const q=i.get(G);q.shadowIntensity=P.intensity,q.shadowBias=P.bias,q.shadowNormalBias=P.normalBias,q.shadowRadius=P.radius,q.shadowMapSize=P.mapSize,s.spotShadow[A]=q,s.spotShadowMap[A]=F,z++}A++}else if(G.isRectAreaLight){const D=e.get(G);D.color.copy(K).multiplyScalar(ue),D.halfWidth.set(G.width*.5,0,0),D.halfHeight.set(0,G.height*.5,0),s.rectArea[b]=D,b++}else if(G.isPointLight){const D=e.get(G);if(D.color.copy(G.color).multiplyScalar(G.intensity),D.distance=G.distance,D.decay=G.decay,G.castShadow){const P=G.shadow,q=i.get(G);q.shadowIntensity=P.intensity,q.shadowBias=P.bias,q.shadowNormalBias=P.normalBias,q.shadowRadius=P.radius,q.shadowMapSize=P.mapSize,q.shadowCameraNear=P.camera.near,q.shadowCameraFar=P.camera.far,s.pointShadow[M]=q,s.pointShadowMap[M]=F,s.pointShadowMatrix[M]=G.shadow.matrix,O++}s.point[M]=D,M++}else if(G.isHemisphereLight){const D=e.get(G);D.skyColor.copy(G.color).multiplyScalar(ue),D.groundColor.copy(G.groundColor).multiplyScalar(ue),s.hemi[S]=D,S++}}b>0&&(r.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=Ve.LTC_FLOAT_1,s.rectAreaLTC2=Ve.LTC_FLOAT_2):(s.rectAreaLTC1=Ve.LTC_HALF_1,s.rectAreaLTC2=Ve.LTC_HALF_2)),s.ambient[0]=g,s.ambient[1]=x,s.ambient[2]=_;const T=s.hash;(T.directionalLength!==y||T.pointLength!==M||T.spotLength!==A||T.rectAreaLength!==b||T.hemiLength!==S||T.numDirectionalShadows!==N||T.numPointShadows!==O||T.numSpotShadows!==z||T.numSpotMaps!==k||T.numLightProbes!==H)&&(s.directional.length=y,s.spot.length=A,s.rectArea.length=b,s.point.length=M,s.hemi.length=S,s.directionalShadow.length=N,s.directionalShadowMap.length=N,s.pointShadow.length=O,s.pointShadowMap.length=O,s.spotShadow.length=z,s.spotShadowMap.length=z,s.directionalShadowMatrix.length=N,s.pointShadowMatrix.length=O,s.spotLightMatrix.length=z+k-L,s.spotLightMap.length=k,s.numSpotLightShadowsWithMaps=L,s.numLightProbes=H,T.directionalLength=y,T.pointLength=M,T.spotLength=A,T.rectAreaLength=b,T.hemiLength=S,T.numDirectionalShadows=N,T.numPointShadows=O,T.numSpotShadows=z,T.numSpotMaps=k,T.numLightProbes=H,s.version=OA++)}function m(h,g){let x=0,_=0,y=0,M=0,A=0;const b=g.matrixWorldInverse;for(let S=0,N=h.length;S<N;S++){const O=h[S];if(O.isDirectionalLight){const z=s.directional[x];z.direction.setFromMatrixPosition(O.matrixWorld),l.setFromMatrixPosition(O.target.matrixWorld),z.direction.sub(l),z.direction.transformDirection(b),x++}else if(O.isSpotLight){const z=s.spot[y];z.position.setFromMatrixPosition(O.matrixWorld),z.position.applyMatrix4(b),z.direction.setFromMatrixPosition(O.matrixWorld),l.setFromMatrixPosition(O.target.matrixWorld),z.direction.sub(l),z.direction.transformDirection(b),y++}else if(O.isRectAreaLight){const z=s.rectArea[M];z.position.setFromMatrixPosition(O.matrixWorld),z.position.applyMatrix4(b),d.identity(),c.copy(O.matrixWorld),c.premultiply(b),d.extractRotation(c),z.halfWidth.set(O.width*.5,0,0),z.halfHeight.set(0,O.height*.5,0),z.halfWidth.applyMatrix4(d),z.halfHeight.applyMatrix4(d),M++}else if(O.isPointLight){const z=s.point[_];z.position.setFromMatrixPosition(O.matrixWorld),z.position.applyMatrix4(b),_++}else if(O.isHemisphereLight){const z=s.hemi[A];z.direction.setFromMatrixPosition(O.matrixWorld),z.direction.transformDirection(b),A++}}}return{setup:p,setupView:m,state:s}}function Tx(r){const e=new zA(r),i=[],s=[],l=[];function c(_){x.camera=_,i.length=0,s.length=0,l.length=0}function d(_){i.push(_)}function p(_){s.push(_)}function m(_){l.push(_)}function h(){e.setup(i)}function g(_){e.setupView(i,_)}const x={lightsArray:i,shadowsArray:s,lightProbeGridArray:l,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:c,state:x,setupLights:h,setupLightsView:g,pushLight:d,pushShadow:p,pushLightProbeGrid:m}}function FA(r){let e=new WeakMap;function i(l,c=0){const d=e.get(l);let p;return d===void 0?(p=new Tx(r),e.set(l,[p])):c>=d.length?(p=new Tx(r),d.push(p)):p=d[c],p}function s(){e=new WeakMap}return{get:i,dispose:s}}const BA=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,IA=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,HA=[new ee(1,0,0),new ee(-1,0,0),new ee(0,1,0),new ee(0,-1,0),new ee(0,0,1),new ee(0,0,-1)],GA=[new ee(0,-1,0),new ee(0,-1,0),new ee(0,0,1),new ee(0,0,-1),new ee(0,-1,0),new ee(0,-1,0)],Ax=new rn,el=new ee,uh=new ee;function VA(r,e,i){let s=new xp;const l=new gt,c=new gt,d=new cn,p=new qb,m=new Yb,h={},g=i.maxTextureSize,x={[fs]:ni,[ni]:fs,[Xi]:Xi},_=new Qi({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new gt},radius:{value:4}},vertexShader:BA,fragmentShader:IA}),y=_.clone();y.defines.HORIZONTAL_PASS=1;const M=new Pn;M.setAttribute("position",new qn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const A=new zi(M,_),b=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=eu;let S=this.type;this.render=function(L,H,T){if(b.enabled===!1||b.autoUpdate===!1&&b.needsUpdate===!1||L.length===0)return;this.type===Px&&(st("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=eu);const I=r.getRenderTarget(),Z=r.getActiveCubeFace(),G=r.getActiveMipmapLevel(),K=r.state;K.setBlending(Ma),K.buffers.depth.getReversed()===!0?K.buffers.color.setClear(0,0,0,0):K.buffers.color.setClear(1,1,1,1),K.buffers.depth.setTest(!0),K.setScissorTest(!1);const ue=S!==this.type;ue&&H.traverse(function(pe){pe.material&&(Array.isArray(pe.material)?pe.material.forEach(F=>F.needsUpdate=!0):pe.material.needsUpdate=!0)});for(let pe=0,F=L.length;pe<F;pe++){const D=L[pe],P=D.shadow;if(P===void 0){st("WebGLShadowMap:",D,"has no shadow.");continue}if(P.autoUpdate===!1&&P.needsUpdate===!1)continue;l.copy(P.mapSize);const q=P.getFrameExtents();l.multiply(q),c.copy(P.mapSize),(l.x>g||l.y>g)&&(l.x>g&&(c.x=Math.floor(g/q.x),l.x=c.x*q.x,P.mapSize.x=c.x),l.y>g&&(c.y=Math.floor(g/q.y),l.y=c.y*q.y,P.mapSize.y=c.y));const he=r.state.buffers.depth.getReversed();if(P.camera._reversedDepth=he,P.map===null||ue===!0){if(P.map!==null&&(P.map.depthTexture!==null&&(P.map.depthTexture.dispose(),P.map.depthTexture=null),P.map.dispose()),this.type===nl){if(D.isPointLight){st("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}P.map=new Zi(l.x,l.y,{format:js,type:Ta,minFilter:Gn,magFilter:Gn,generateMipmaps:!1}),P.map.texture.name=D.name+".shadowMap",P.map.depthTexture=new qr(l.x,l.y,Wi),P.map.depthTexture.name=D.name+".shadowMapDepth",P.map.depthTexture.format=Aa,P.map.depthTexture.compareFunction=null,P.map.depthTexture.minFilter=On,P.map.depthTexture.magFilter=On}else D.isPointLight?(P.map=new hv(l.x),P.map.depthTexture=new Gb(l.x,Ki)):(P.map=new Zi(l.x,l.y),P.map.depthTexture=new qr(l.x,l.y,Ki)),P.map.depthTexture.name=D.name+".shadowMap",P.map.depthTexture.format=Aa,this.type===eu?(P.map.depthTexture.compareFunction=he?gp:mp,P.map.depthTexture.minFilter=Gn,P.map.depthTexture.magFilter=Gn):(P.map.depthTexture.compareFunction=null,P.map.depthTexture.minFilter=On,P.map.depthTexture.magFilter=On);P.camera.updateProjectionMatrix()}const _e=P.map.isWebGLCubeRenderTarget?6:1;for(let B=0;B<_e;B++){if(P.map.isWebGLCubeRenderTarget)r.setRenderTarget(P.map,B),r.clear();else{B===0&&(r.setRenderTarget(P.map),r.clear());const Q=P.getViewport(B);d.set(c.x*Q.x,c.y*Q.y,c.x*Q.z,c.y*Q.w),K.viewport(d)}if(D.isPointLight){const Q=P.camera,ve=P.matrix,Ae=D.distance||Q.far;Ae!==Q.far&&(Q.far=Ae,Q.updateProjectionMatrix()),el.setFromMatrixPosition(D.matrixWorld),Q.position.copy(el),uh.copy(Q.position),uh.add(HA[B]),Q.up.copy(GA[B]),Q.lookAt(uh),Q.updateMatrixWorld(),ve.makeTranslation(-el.x,-el.y,-el.z),Ax.multiplyMatrices(Q.projectionMatrix,Q.matrixWorldInverse),P._frustum.setFromProjectionMatrix(Ax,Q.coordinateSystem,Q.reversedDepth)}else P.updateMatrices(D);s=P.getFrustum(),z(H,T,P.camera,D,this.type)}P.isPointLightShadow!==!0&&this.type===nl&&N(P,T),P.needsUpdate=!1}S=this.type,b.needsUpdate=!1,r.setRenderTarget(I,Z,G)};function N(L,H){const T=e.update(A);_.defines.VSM_SAMPLES!==L.blurSamples&&(_.defines.VSM_SAMPLES=L.blurSamples,y.defines.VSM_SAMPLES=L.blurSamples,_.needsUpdate=!0,y.needsUpdate=!0),L.mapPass===null&&(L.mapPass=new Zi(l.x,l.y,{format:js,type:Ta})),_.uniforms.shadow_pass.value=L.map.depthTexture,_.uniforms.resolution.value=L.mapSize,_.uniforms.radius.value=L.radius,r.setRenderTarget(L.mapPass),r.clear(),r.renderBufferDirect(H,null,T,_,A,null),y.uniforms.shadow_pass.value=L.mapPass.texture,y.uniforms.resolution.value=L.mapSize,y.uniforms.radius.value=L.radius,r.setRenderTarget(L.map),r.clear(),r.renderBufferDirect(H,null,T,y,A,null)}function O(L,H,T,I){let Z=null;const G=T.isPointLight===!0?L.customDistanceMaterial:L.customDepthMaterial;if(G!==void 0)Z=G;else if(Z=T.isPointLight===!0?m:p,r.localClippingEnabled&&H.clipShadows===!0&&Array.isArray(H.clippingPlanes)&&H.clippingPlanes.length!==0||H.displacementMap&&H.displacementScale!==0||H.alphaMap&&H.alphaTest>0||H.map&&H.alphaTest>0||H.alphaToCoverage===!0){const K=Z.uuid,ue=H.uuid;let pe=h[K];pe===void 0&&(pe={},h[K]=pe);let F=pe[ue];F===void 0&&(F=Z.clone(),pe[ue]=F,H.addEventListener("dispose",k)),Z=F}if(Z.visible=H.visible,Z.wireframe=H.wireframe,I===nl?Z.side=H.shadowSide!==null?H.shadowSide:H.side:Z.side=H.shadowSide!==null?H.shadowSide:x[H.side],Z.alphaMap=H.alphaMap,Z.alphaTest=H.alphaToCoverage===!0?.5:H.alphaTest,Z.map=H.map,Z.clipShadows=H.clipShadows,Z.clippingPlanes=H.clippingPlanes,Z.clipIntersection=H.clipIntersection,Z.displacementMap=H.displacementMap,Z.displacementScale=H.displacementScale,Z.displacementBias=H.displacementBias,Z.wireframeLinewidth=H.wireframeLinewidth,Z.linewidth=H.linewidth,T.isPointLight===!0&&Z.isMeshDistanceMaterial===!0){const K=r.properties.get(Z);K.light=T}return Z}function z(L,H,T,I,Z){if(L.visible===!1)return;if(L.layers.test(H.layers)&&(L.isMesh||L.isLine||L.isPoints)&&(L.castShadow||L.receiveShadow&&Z===nl)&&(!L.frustumCulled||s.intersectsObject(L))){L.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,L.matrixWorld);const ue=e.update(L),pe=L.material;if(Array.isArray(pe)){const F=ue.groups;for(let D=0,P=F.length;D<P;D++){const q=F[D],he=pe[q.materialIndex];if(he&&he.visible){const _e=O(L,he,I,Z);L.onBeforeShadow(r,L,H,T,ue,_e,q),r.renderBufferDirect(T,null,ue,_e,L,q),L.onAfterShadow(r,L,H,T,ue,_e,q)}}}else if(pe.visible){const F=O(L,pe,I,Z);L.onBeforeShadow(r,L,H,T,ue,F,null),r.renderBufferDirect(T,null,ue,F,L,null),L.onAfterShadow(r,L,H,T,ue,F,null)}}const K=L.children;for(let ue=0,pe=K.length;ue<pe;ue++)z(K[ue],H,T,I,Z)}function k(L){L.target.removeEventListener("dispose",k);for(const T in h){const I=h[T],Z=L.target.uuid;Z in I&&(I[Z].dispose(),delete I[Z])}}}function kA(r,e){function i(){let X=!1;const Re=new cn;let me=null;const He=new cn(0,0,0,0);return{setMask:function(Le){me!==Le&&!X&&(r.colorMask(Le,Le,Le,Le),me=Le)},setLocked:function(Le){X=Le},setClear:function(Le,Ee,We,it,Jt){Jt===!0&&(Le*=it,Ee*=it,We*=it),Re.set(Le,Ee,We,it),He.equals(Re)===!1&&(r.clearColor(Le,Ee,We,it),He.copy(Re))},reset:function(){X=!1,me=null,He.set(-1,0,0,0)}}}function s(){let X=!1,Re=!1,me=null,He=null,Le=null;return{setReversed:function(Ee){if(Re!==Ee){const We=e.get("EXT_clip_control");Ee?We.clipControlEXT(We.LOWER_LEFT_EXT,We.ZERO_TO_ONE_EXT):We.clipControlEXT(We.LOWER_LEFT_EXT,We.NEGATIVE_ONE_TO_ONE_EXT),Re=Ee;const it=Le;Le=null,this.setClear(it)}},getReversed:function(){return Re},setTest:function(Ee){Ee?Me(r.DEPTH_TEST):Ie(r.DEPTH_TEST)},setMask:function(Ee){me!==Ee&&!X&&(r.depthMask(Ee),me=Ee)},setFunc:function(Ee){if(Re&&(Ee=hb[Ee]),He!==Ee){switch(Ee){case mh:r.depthFunc(r.NEVER);break;case gh:r.depthFunc(r.ALWAYS);break;case _h:r.depthFunc(r.LESS);break;case jr:r.depthFunc(r.LEQUAL);break;case xh:r.depthFunc(r.EQUAL);break;case vh:r.depthFunc(r.GEQUAL);break;case Sh:r.depthFunc(r.GREATER);break;case yh:r.depthFunc(r.NOTEQUAL);break;default:r.depthFunc(r.LEQUAL)}He=Ee}},setLocked:function(Ee){X=Ee},setClear:function(Ee){Le!==Ee&&(Le=Ee,Re&&(Ee=1-Ee),r.clearDepth(Ee))},reset:function(){X=!1,me=null,He=null,Le=null,Re=!1}}}function l(){let X=!1,Re=null,me=null,He=null,Le=null,Ee=null,We=null,it=null,Jt=null;return{setTest:function(Dt){X||(Dt?Me(r.STENCIL_TEST):Ie(r.STENCIL_TEST))},setMask:function(Dt){Re!==Dt&&!X&&(r.stencilMask(Dt),Re=Dt)},setFunc:function(Dt,Vn,kn){(me!==Dt||He!==Vn||Le!==kn)&&(r.stencilFunc(Dt,Vn,kn),me=Dt,He=Vn,Le=kn)},setOp:function(Dt,Vn,kn){(Ee!==Dt||We!==Vn||it!==kn)&&(r.stencilOp(Dt,Vn,kn),Ee=Dt,We=Vn,it=kn)},setLocked:function(Dt){X=Dt},setClear:function(Dt){Jt!==Dt&&(r.clearStencil(Dt),Jt=Dt)},reset:function(){X=!1,Re=null,me=null,He=null,Le=null,Ee=null,We=null,it=null,Jt=null}}}const c=new i,d=new s,p=new l,m=new WeakMap,h=new WeakMap;let g={},x={},_={},y=new WeakMap,M=[],A=null,b=!1,S=null,N=null,O=null,z=null,k=null,L=null,H=null,T=new ft(0,0,0),I=0,Z=!1,G=null,K=null,ue=null,pe=null,F=null;const D=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let P=!1,q=0;const he=r.getParameter(r.VERSION);he.indexOf("WebGL")!==-1?(q=parseFloat(/^WebGL (\d)/.exec(he)[1]),P=q>=1):he.indexOf("OpenGL ES")!==-1&&(q=parseFloat(/^OpenGL ES (\d)/.exec(he)[1]),P=q>=2);let _e=null,B={};const Q=r.getParameter(r.SCISSOR_BOX),ve=r.getParameter(r.VIEWPORT),Ae=new cn().fromArray(Q),Ce=new cn().fromArray(ve);function ae(X,Re,me,He){const Le=new Uint8Array(4),Ee=r.createTexture();r.bindTexture(X,Ee),r.texParameteri(X,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(X,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let We=0;We<me;We++)X===r.TEXTURE_3D||X===r.TEXTURE_2D_ARRAY?r.texImage3D(Re,0,r.RGBA,1,1,He,0,r.RGBA,r.UNSIGNED_BYTE,Le):r.texImage2D(Re+We,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,Le);return Ee}const ye={};ye[r.TEXTURE_2D]=ae(r.TEXTURE_2D,r.TEXTURE_2D,1),ye[r.TEXTURE_CUBE_MAP]=ae(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),ye[r.TEXTURE_2D_ARRAY]=ae(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),ye[r.TEXTURE_3D]=ae(r.TEXTURE_3D,r.TEXTURE_3D,1,1),c.setClear(0,0,0,1),d.setClear(1),p.setClear(0),Me(r.DEPTH_TEST),d.setFunc(jr),$t(!1),te(g_),Me(r.CULL_FACE),St(Ma);function Me(X){g[X]!==!0&&(r.enable(X),g[X]=!0)}function Ie(X){g[X]!==!1&&(r.disable(X),g[X]=!1)}function Ze(X,Re){return _[X]!==Re?(r.bindFramebuffer(X,Re),_[X]=Re,X===r.DRAW_FRAMEBUFFER&&(_[r.FRAMEBUFFER]=Re),X===r.FRAMEBUFFER&&(_[r.DRAW_FRAMEBUFFER]=Re),!0):!1}function Ke(X,Re){let me=M,He=!1;if(X){me=y.get(Re),me===void 0&&(me=[],y.set(Re,me));const Le=X.textures;if(me.length!==Le.length||me[0]!==r.COLOR_ATTACHMENT0){for(let Ee=0,We=Le.length;Ee<We;Ee++)me[Ee]=r.COLOR_ATTACHMENT0+Ee;me.length=Le.length,He=!0}}else me[0]!==r.BACK&&(me[0]=r.BACK,He=!0);He&&r.drawBuffers(me)}function Lt(X){return A!==X?(r.useProgram(X),A=X,!0):!1}const nt={[Bs]:r.FUNC_ADD,[zy]:r.FUNC_SUBTRACT,[Fy]:r.FUNC_REVERSE_SUBTRACT};nt[By]=r.MIN,nt[Iy]=r.MAX;const dt={[Hy]:r.ZERO,[Gy]:r.ONE,[Vy]:r.SRC_COLOR,[hh]:r.SRC_ALPHA,[Yy]:r.SRC_ALPHA_SATURATE,[Wy]:r.DST_COLOR,[jy]:r.DST_ALPHA,[ky]:r.ONE_MINUS_SRC_COLOR,[ph]:r.ONE_MINUS_SRC_ALPHA,[qy]:r.ONE_MINUS_DST_COLOR,[Xy]:r.ONE_MINUS_DST_ALPHA,[Zy]:r.CONSTANT_COLOR,[Ky]:r.ONE_MINUS_CONSTANT_COLOR,[Qy]:r.CONSTANT_ALPHA,[Jy]:r.ONE_MINUS_CONSTANT_ALPHA};function St(X,Re,me,He,Le,Ee,We,it,Jt,Dt){if(X===Ma){b===!0&&(Ie(r.BLEND),b=!1);return}if(b===!1&&(Me(r.BLEND),b=!0),X!==Py){if(X!==S||Dt!==Z){if((N!==Bs||k!==Bs)&&(r.blendEquation(r.FUNC_ADD),N=Bs,k=Bs),Dt)switch(X){case Vr:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case __:r.blendFunc(r.ONE,r.ONE);break;case x_:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case v_:r.blendFuncSeparate(r.DST_COLOR,r.ONE_MINUS_SRC_ALPHA,r.ZERO,r.ONE);break;default:Ut("WebGLState: Invalid blending: ",X);break}else switch(X){case Vr:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case __:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE,r.ONE,r.ONE);break;case x_:Ut("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case v_:Ut("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Ut("WebGLState: Invalid blending: ",X);break}O=null,z=null,L=null,H=null,T.set(0,0,0),I=0,S=X,Z=Dt}return}Le=Le||Re,Ee=Ee||me,We=We||He,(Re!==N||Le!==k)&&(r.blendEquationSeparate(nt[Re],nt[Le]),N=Re,k=Le),(me!==O||He!==z||Ee!==L||We!==H)&&(r.blendFuncSeparate(dt[me],dt[He],dt[Ee],dt[We]),O=me,z=He,L=Ee,H=We),(it.equals(T)===!1||Jt!==I)&&(r.blendColor(it.r,it.g,it.b,Jt),T.copy(it),I=Jt),S=X,Z=!1}function ct(X,Re){X.side===Xi?Ie(r.CULL_FACE):Me(r.CULL_FACE);let me=X.side===ni;Re&&(me=!me),$t(me),X.blending===Vr&&X.transparent===!1?St(Ma):St(X.blending,X.blendEquation,X.blendSrc,X.blendDst,X.blendEquationAlpha,X.blendSrcAlpha,X.blendDstAlpha,X.blendColor,X.blendAlpha,X.premultipliedAlpha),d.setFunc(X.depthFunc),d.setTest(X.depthTest),d.setMask(X.depthWrite),c.setMask(X.colorWrite);const He=X.stencilWrite;p.setTest(He),He&&(p.setMask(X.stencilWriteMask),p.setFunc(X.stencilFunc,X.stencilRef,X.stencilFuncMask),p.setOp(X.stencilFail,X.stencilZFail,X.stencilZPass)),j(X.polygonOffset,X.polygonOffsetFactor,X.polygonOffsetUnits),X.alphaToCoverage===!0?Me(r.SAMPLE_ALPHA_TO_COVERAGE):Ie(r.SAMPLE_ALPHA_TO_COVERAGE)}function $t(X){G!==X&&(X?r.frontFace(r.CW):r.frontFace(r.CCW),G=X)}function te(X){X!==Ly?(Me(r.CULL_FACE),X!==K&&(X===g_?r.cullFace(r.BACK):X===Oy?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):Ie(r.CULL_FACE),K=X}function Fe(X){X!==ue&&(P&&r.lineWidth(X),ue=X)}function j(X,Re,me){X?(Me(r.POLYGON_OFFSET_FILL),(pe!==Re||F!==me)&&(pe=Re,F=me,d.getReversed()&&(Re=-Re),r.polygonOffset(Re,me))):Ie(r.POLYGON_OFFSET_FILL)}function yt(X){X?Me(r.SCISSOR_TEST):Ie(r.SCISSOR_TEST)}function lt(X){X===void 0&&(X=r.TEXTURE0+D-1),_e!==X&&(r.activeTexture(X),_e=X)}function Nt(X,Re,me){me===void 0&&(_e===null?me=r.TEXTURE0+D-1:me=_e);let He=B[me];He===void 0&&(He={type:void 0,texture:void 0},B[me]=He),(He.type!==X||He.texture!==Re)&&(_e!==me&&(r.activeTexture(me),_e=me),r.bindTexture(X,Re||ye[X]),He.type=X,He.texture=Re)}function we(){const X=B[_e];X!==void 0&&X.type!==void 0&&(r.bindTexture(X.type,null),X.type=void 0,X.texture=void 0)}function Xt(){try{r.compressedTexImage2D(...arguments)}catch(X){Ut("WebGLState:",X)}}function U(){try{r.compressedTexImage3D(...arguments)}catch(X){Ut("WebGLState:",X)}}function E(){try{r.texSubImage2D(...arguments)}catch(X){Ut("WebGLState:",X)}}function $(){try{r.texSubImage3D(...arguments)}catch(X){Ut("WebGLState:",X)}}function xe(){try{r.compressedTexSubImage2D(...arguments)}catch(X){Ut("WebGLState:",X)}}function Te(){try{r.compressedTexSubImage3D(...arguments)}catch(X){Ut("WebGLState:",X)}}function Ne(){try{r.texStorage2D(...arguments)}catch(X){Ut("WebGLState:",X)}}function Pe(){try{r.texStorage3D(...arguments)}catch(X){Ut("WebGLState:",X)}}function ne(){try{r.texImage2D(...arguments)}catch(X){Ut("WebGLState:",X)}}function de(){try{r.texImage3D(...arguments)}catch(X){Ut("WebGLState:",X)}}function Oe(X){return x[X]!==void 0?x[X]:r.getParameter(X)}function ze(X,Re){x[X]!==Re&&(r.pixelStorei(X,Re),x[X]=Re)}function Ue(X){Ae.equals(X)===!1&&(r.scissor(X.x,X.y,X.z,X.w),Ae.copy(X))}function De(X){Ce.equals(X)===!1&&(r.viewport(X.x,X.y,X.z,X.w),Ce.copy(X))}function rt(X,Re){let me=h.get(Re);me===void 0&&(me=new WeakMap,h.set(Re,me));let He=me.get(X);He===void 0&&(He=r.getUniformBlockIndex(Re,X.name),me.set(X,He))}function ot(X,Re){const He=h.get(Re).get(X);m.get(Re)!==He&&(r.uniformBlockBinding(Re,He,X.__bindingPointIndex),m.set(Re,He))}function _t(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),d.setReversed(!1),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),r.pixelStorei(r.PACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,!1),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,r.BROWSER_DEFAULT_WEBGL),r.pixelStorei(r.PACK_ROW_LENGTH,0),r.pixelStorei(r.PACK_SKIP_PIXELS,0),r.pixelStorei(r.PACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_ROW_LENGTH,0),r.pixelStorei(r.UNPACK_IMAGE_HEIGHT,0),r.pixelStorei(r.UNPACK_SKIP_PIXELS,0),r.pixelStorei(r.UNPACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_SKIP_IMAGES,0),g={},x={},_e=null,B={},_={},y=new WeakMap,M=[],A=null,b=!1,S=null,N=null,O=null,z=null,k=null,L=null,H=null,T=new ft(0,0,0),I=0,Z=!1,G=null,K=null,ue=null,pe=null,F=null,Ae.set(0,0,r.canvas.width,r.canvas.height),Ce.set(0,0,r.canvas.width,r.canvas.height),c.reset(),d.reset(),p.reset()}return{buffers:{color:c,depth:d,stencil:p},enable:Me,disable:Ie,bindFramebuffer:Ze,drawBuffers:Ke,useProgram:Lt,setBlending:St,setMaterial:ct,setFlipSided:$t,setCullFace:te,setLineWidth:Fe,setPolygonOffset:j,setScissorTest:yt,activeTexture:lt,bindTexture:Nt,unbindTexture:we,compressedTexImage2D:Xt,compressedTexImage3D:U,texImage2D:ne,texImage3D:de,pixelStorei:ze,getParameter:Oe,updateUBOMapping:rt,uniformBlockBinding:ot,texStorage2D:Ne,texStorage3D:Pe,texSubImage2D:E,texSubImage3D:$,compressedTexSubImage2D:xe,compressedTexSubImage3D:Te,scissor:Ue,viewport:De,reset:_t}}function jA(r,e,i,s,l,c,d){const p=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,m=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new gt,g=new WeakMap,x=new Set;let _;const y=new WeakMap;let M=!1;try{M=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function A(U,E){return M?new OffscreenCanvas(U,E):uu("canvas")}function b(U,E,$){let xe=1;const Te=Xt(U);if((Te.width>$||Te.height>$)&&(xe=$/Math.max(Te.width,Te.height)),xe<1)if(typeof HTMLImageElement<"u"&&U instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&U instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&U instanceof ImageBitmap||typeof VideoFrame<"u"&&U instanceof VideoFrame){const Ne=Math.floor(xe*Te.width),Pe=Math.floor(xe*Te.height);_===void 0&&(_=A(Ne,Pe));const ne=E?A(Ne,Pe):_;return ne.width=Ne,ne.height=Pe,ne.getContext("2d").drawImage(U,0,0,Ne,Pe),st("WebGLRenderer: Texture has been resized from ("+Te.width+"x"+Te.height+") to ("+Ne+"x"+Pe+")."),ne}else return"data"in U&&st("WebGLRenderer: Image in DataTexture is too big ("+Te.width+"x"+Te.height+")."),U;return U}function S(U){return U.generateMipmaps}function N(U){r.generateMipmap(U)}function O(U){return U.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:U.isWebGL3DRenderTarget?r.TEXTURE_3D:U.isWebGLArrayRenderTarget||U.isCompressedArrayTexture?r.TEXTURE_2D_ARRAY:r.TEXTURE_2D}function z(U,E,$,xe,Te,Ne=!1){if(U!==null){if(r[U]!==void 0)return r[U];st("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+U+"'")}let Pe;xe&&(Pe=e.get("EXT_texture_norm16"),Pe||st("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let ne=E;if(E===r.RED&&($===r.FLOAT&&(ne=r.R32F),$===r.HALF_FLOAT&&(ne=r.R16F),$===r.UNSIGNED_BYTE&&(ne=r.R8),$===r.UNSIGNED_SHORT&&Pe&&(ne=Pe.R16_EXT),$===r.SHORT&&Pe&&(ne=Pe.R16_SNORM_EXT)),E===r.RED_INTEGER&&($===r.UNSIGNED_BYTE&&(ne=r.R8UI),$===r.UNSIGNED_SHORT&&(ne=r.R16UI),$===r.UNSIGNED_INT&&(ne=r.R32UI),$===r.BYTE&&(ne=r.R8I),$===r.SHORT&&(ne=r.R16I),$===r.INT&&(ne=r.R32I)),E===r.RG&&($===r.FLOAT&&(ne=r.RG32F),$===r.HALF_FLOAT&&(ne=r.RG16F),$===r.UNSIGNED_BYTE&&(ne=r.RG8),$===r.UNSIGNED_SHORT&&Pe&&(ne=Pe.RG16_EXT),$===r.SHORT&&Pe&&(ne=Pe.RG16_SNORM_EXT)),E===r.RG_INTEGER&&($===r.UNSIGNED_BYTE&&(ne=r.RG8UI),$===r.UNSIGNED_SHORT&&(ne=r.RG16UI),$===r.UNSIGNED_INT&&(ne=r.RG32UI),$===r.BYTE&&(ne=r.RG8I),$===r.SHORT&&(ne=r.RG16I),$===r.INT&&(ne=r.RG32I)),E===r.RGB_INTEGER&&($===r.UNSIGNED_BYTE&&(ne=r.RGB8UI),$===r.UNSIGNED_SHORT&&(ne=r.RGB16UI),$===r.UNSIGNED_INT&&(ne=r.RGB32UI),$===r.BYTE&&(ne=r.RGB8I),$===r.SHORT&&(ne=r.RGB16I),$===r.INT&&(ne=r.RGB32I)),E===r.RGBA_INTEGER&&($===r.UNSIGNED_BYTE&&(ne=r.RGBA8UI),$===r.UNSIGNED_SHORT&&(ne=r.RGBA16UI),$===r.UNSIGNED_INT&&(ne=r.RGBA32UI),$===r.BYTE&&(ne=r.RGBA8I),$===r.SHORT&&(ne=r.RGBA16I),$===r.INT&&(ne=r.RGBA32I)),E===r.RGB&&($===r.UNSIGNED_SHORT&&Pe&&(ne=Pe.RGB16_EXT),$===r.SHORT&&Pe&&(ne=Pe.RGB16_SNORM_EXT),$===r.UNSIGNED_INT_5_9_9_9_REV&&(ne=r.RGB9_E5),$===r.UNSIGNED_INT_10F_11F_11F_REV&&(ne=r.R11F_G11F_B10F)),E===r.RGBA){const de=Ne?cu:wt.getTransfer(Te);$===r.FLOAT&&(ne=r.RGBA32F),$===r.HALF_FLOAT&&(ne=r.RGBA16F),$===r.UNSIGNED_BYTE&&(ne=de===jt?r.SRGB8_ALPHA8:r.RGBA8),$===r.UNSIGNED_SHORT&&Pe&&(ne=Pe.RGBA16_EXT),$===r.SHORT&&Pe&&(ne=Pe.RGBA16_SNORM_EXT),$===r.UNSIGNED_SHORT_4_4_4_4&&(ne=r.RGBA4),$===r.UNSIGNED_SHORT_5_5_5_1&&(ne=r.RGB5_A1)}return(ne===r.R16F||ne===r.R32F||ne===r.RG16F||ne===r.RG32F||ne===r.RGBA16F||ne===r.RGBA32F)&&e.get("EXT_color_buffer_float"),ne}function k(U,E){let $;return U?E===null||E===Ki||E===ol?$=r.DEPTH24_STENCIL8:E===Wi?$=r.DEPTH32F_STENCIL8:E===rl&&($=r.DEPTH24_STENCIL8,st("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):E===null||E===Ki||E===ol?$=r.DEPTH_COMPONENT24:E===Wi?$=r.DEPTH_COMPONENT32F:E===rl&&($=r.DEPTH_COMPONENT16),$}function L(U,E){return S(U)===!0||U.isFramebufferTexture&&U.minFilter!==On&&U.minFilter!==Gn?Math.log2(Math.max(E.width,E.height))+1:U.mipmaps!==void 0&&U.mipmaps.length>0?U.mipmaps.length:U.isCompressedTexture&&Array.isArray(U.image)?E.mipmaps.length:1}function H(U){const E=U.target;E.removeEventListener("dispose",H),I(E),E.isVideoTexture&&g.delete(E),E.isHTMLTexture&&x.delete(E)}function T(U){const E=U.target;E.removeEventListener("dispose",T),G(E)}function I(U){const E=s.get(U);if(E.__webglInit===void 0)return;const $=U.source,xe=y.get($);if(xe){const Te=xe[E.__cacheKey];Te.usedTimes--,Te.usedTimes===0&&Z(U),Object.keys(xe).length===0&&y.delete($)}s.remove(U)}function Z(U){const E=s.get(U);r.deleteTexture(E.__webglTexture);const $=U.source,xe=y.get($);delete xe[E.__cacheKey],d.memory.textures--}function G(U){const E=s.get(U);if(U.depthTexture&&(U.depthTexture.dispose(),s.remove(U.depthTexture)),U.isWebGLCubeRenderTarget)for(let xe=0;xe<6;xe++){if(Array.isArray(E.__webglFramebuffer[xe]))for(let Te=0;Te<E.__webglFramebuffer[xe].length;Te++)r.deleteFramebuffer(E.__webglFramebuffer[xe][Te]);else r.deleteFramebuffer(E.__webglFramebuffer[xe]);E.__webglDepthbuffer&&r.deleteRenderbuffer(E.__webglDepthbuffer[xe])}else{if(Array.isArray(E.__webglFramebuffer))for(let xe=0;xe<E.__webglFramebuffer.length;xe++)r.deleteFramebuffer(E.__webglFramebuffer[xe]);else r.deleteFramebuffer(E.__webglFramebuffer);if(E.__webglDepthbuffer&&r.deleteRenderbuffer(E.__webglDepthbuffer),E.__webglMultisampledFramebuffer&&r.deleteFramebuffer(E.__webglMultisampledFramebuffer),E.__webglColorRenderbuffer)for(let xe=0;xe<E.__webglColorRenderbuffer.length;xe++)E.__webglColorRenderbuffer[xe]&&r.deleteRenderbuffer(E.__webglColorRenderbuffer[xe]);E.__webglDepthRenderbuffer&&r.deleteRenderbuffer(E.__webglDepthRenderbuffer)}const $=U.textures;for(let xe=0,Te=$.length;xe<Te;xe++){const Ne=s.get($[xe]);Ne.__webglTexture&&(r.deleteTexture(Ne.__webglTexture),d.memory.textures--),s.remove($[xe])}s.remove(U)}let K=0;function ue(){K=0}function pe(){return K}function F(U){K=U}function D(){const U=K;return U>=l.maxTextures&&st("WebGLTextures: Trying to use "+U+" texture units while this GPU supports only "+l.maxTextures),K+=1,U}function P(U){const E=[];return E.push(U.wrapS),E.push(U.wrapT),E.push(U.wrapR||0),E.push(U.magFilter),E.push(U.minFilter),E.push(U.anisotropy),E.push(U.internalFormat),E.push(U.format),E.push(U.type),E.push(U.generateMipmaps),E.push(U.premultiplyAlpha),E.push(U.flipY),E.push(U.unpackAlignment),E.push(U.colorSpace),E.join()}function q(U,E){const $=s.get(U);if(U.isVideoTexture&&Nt(U),U.isRenderTargetTexture===!1&&U.isExternalTexture!==!0&&U.version>0&&$.__version!==U.version){const xe=U.image;if(xe===null)st("WebGLRenderer: Texture marked for update but no image data found.");else if(xe.complete===!1)st("WebGLRenderer: Texture marked for update but image is incomplete");else{Ie($,U,E);return}}else U.isExternalTexture&&($.__webglTexture=U.sourceTexture?U.sourceTexture:null);i.bindTexture(r.TEXTURE_2D,$.__webglTexture,r.TEXTURE0+E)}function he(U,E){const $=s.get(U);if(U.isRenderTargetTexture===!1&&U.version>0&&$.__version!==U.version){Ie($,U,E);return}else U.isExternalTexture&&($.__webglTexture=U.sourceTexture?U.sourceTexture:null);i.bindTexture(r.TEXTURE_2D_ARRAY,$.__webglTexture,r.TEXTURE0+E)}function _e(U,E){const $=s.get(U);if(U.isRenderTargetTexture===!1&&U.version>0&&$.__version!==U.version){Ie($,U,E);return}i.bindTexture(r.TEXTURE_3D,$.__webglTexture,r.TEXTURE0+E)}function B(U,E){const $=s.get(U);if(U.isCubeDepthTexture!==!0&&U.version>0&&$.__version!==U.version){Ze($,U,E);return}i.bindTexture(r.TEXTURE_CUBE_MAP,$.__webglTexture,r.TEXTURE0+E)}const Q={[bh]:r.REPEAT,[ba]:r.CLAMP_TO_EDGE,[Mh]:r.MIRRORED_REPEAT},ve={[On]:r.NEAREST,[tb]:r.NEAREST_MIPMAP_NEAREST,[bc]:r.NEAREST_MIPMAP_LINEAR,[Gn]:r.LINEAR,[Ud]:r.LINEAR_MIPMAP_NEAREST,[Hs]:r.LINEAR_MIPMAP_LINEAR},Ae={[ab]:r.NEVER,[cb]:r.ALWAYS,[sb]:r.LESS,[mp]:r.LEQUAL,[rb]:r.EQUAL,[gp]:r.GEQUAL,[ob]:r.GREATER,[lb]:r.NOTEQUAL};function Ce(U,E){if(E.type===Wi&&e.has("OES_texture_float_linear")===!1&&(E.magFilter===Gn||E.magFilter===Ud||E.magFilter===bc||E.magFilter===Hs||E.minFilter===Gn||E.minFilter===Ud||E.minFilter===bc||E.minFilter===Hs)&&st("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),r.texParameteri(U,r.TEXTURE_WRAP_S,Q[E.wrapS]),r.texParameteri(U,r.TEXTURE_WRAP_T,Q[E.wrapT]),(U===r.TEXTURE_3D||U===r.TEXTURE_2D_ARRAY)&&r.texParameteri(U,r.TEXTURE_WRAP_R,Q[E.wrapR]),r.texParameteri(U,r.TEXTURE_MAG_FILTER,ve[E.magFilter]),r.texParameteri(U,r.TEXTURE_MIN_FILTER,ve[E.minFilter]),E.compareFunction&&(r.texParameteri(U,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(U,r.TEXTURE_COMPARE_FUNC,Ae[E.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(E.magFilter===On||E.minFilter!==bc&&E.minFilter!==Hs||E.type===Wi&&e.has("OES_texture_float_linear")===!1)return;if(E.anisotropy>1||s.get(E).__currentAnisotropy){const $=e.get("EXT_texture_filter_anisotropic");r.texParameterf(U,$.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(E.anisotropy,l.getMaxAnisotropy())),s.get(E).__currentAnisotropy=E.anisotropy}}}function ae(U,E){let $=!1;U.__webglInit===void 0&&(U.__webglInit=!0,E.addEventListener("dispose",H));const xe=E.source;let Te=y.get(xe);Te===void 0&&(Te={},y.set(xe,Te));const Ne=P(E);if(Ne!==U.__cacheKey){Te[Ne]===void 0&&(Te[Ne]={texture:r.createTexture(),usedTimes:0},d.memory.textures++,$=!0),Te[Ne].usedTimes++;const Pe=Te[U.__cacheKey];Pe!==void 0&&(Te[U.__cacheKey].usedTimes--,Pe.usedTimes===0&&Z(E)),U.__cacheKey=Ne,U.__webglTexture=Te[Ne].texture}return $}function ye(U,E,$){return Math.floor(Math.floor(U/$)/E)}function Me(U,E,$,xe){const Ne=U.updateRanges;if(Ne.length===0)i.texSubImage2D(r.TEXTURE_2D,0,0,0,E.width,E.height,$,xe,E.data);else{Ne.sort((ze,Ue)=>ze.start-Ue.start);let Pe=0;for(let ze=1;ze<Ne.length;ze++){const Ue=Ne[Pe],De=Ne[ze],rt=Ue.start+Ue.count,ot=ye(De.start,E.width,4),_t=ye(Ue.start,E.width,4);De.start<=rt+1&&ot===_t&&ye(De.start+De.count-1,E.width,4)===ot?Ue.count=Math.max(Ue.count,De.start+De.count-Ue.start):(++Pe,Ne[Pe]=De)}Ne.length=Pe+1;const ne=i.getParameter(r.UNPACK_ROW_LENGTH),de=i.getParameter(r.UNPACK_SKIP_PIXELS),Oe=i.getParameter(r.UNPACK_SKIP_ROWS);i.pixelStorei(r.UNPACK_ROW_LENGTH,E.width);for(let ze=0,Ue=Ne.length;ze<Ue;ze++){const De=Ne[ze],rt=Math.floor(De.start/4),ot=Math.ceil(De.count/4),_t=rt%E.width,X=Math.floor(rt/E.width),Re=ot,me=1;i.pixelStorei(r.UNPACK_SKIP_PIXELS,_t),i.pixelStorei(r.UNPACK_SKIP_ROWS,X),i.texSubImage2D(r.TEXTURE_2D,0,_t,X,Re,me,$,xe,E.data)}U.clearUpdateRanges(),i.pixelStorei(r.UNPACK_ROW_LENGTH,ne),i.pixelStorei(r.UNPACK_SKIP_PIXELS,de),i.pixelStorei(r.UNPACK_SKIP_ROWS,Oe)}}function Ie(U,E,$){let xe=r.TEXTURE_2D;(E.isDataArrayTexture||E.isCompressedArrayTexture)&&(xe=r.TEXTURE_2D_ARRAY),E.isData3DTexture&&(xe=r.TEXTURE_3D);const Te=ae(U,E),Ne=E.source;i.bindTexture(xe,U.__webglTexture,r.TEXTURE0+$);const Pe=s.get(Ne);if(Ne.version!==Pe.__version||Te===!0){if(i.activeTexture(r.TEXTURE0+$),(typeof ImageBitmap<"u"&&E.image instanceof ImageBitmap)===!1){const me=wt.getPrimaries(wt.workingColorSpace),He=E.colorSpace===cs?null:wt.getPrimaries(E.colorSpace),Le=E.colorSpace===cs||me===He?r.NONE:r.BROWSER_DEFAULT_WEBGL;i.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,Le)}i.pixelStorei(r.UNPACK_ALIGNMENT,E.unpackAlignment);let de=b(E.image,!1,l.maxTextureSize);de=we(E,de);const Oe=c.convert(E.format,E.colorSpace),ze=c.convert(E.type);let Ue=z(E.internalFormat,Oe,ze,E.normalized,E.colorSpace,E.isVideoTexture);Ce(xe,E);let De;const rt=E.mipmaps,ot=E.isVideoTexture!==!0,_t=Pe.__version===void 0||Te===!0,X=Ne.dataReady,Re=L(E,de);if(E.isDepthTexture)Ue=k(E.format===Gs,E.type),_t&&(ot?i.texStorage2D(r.TEXTURE_2D,1,Ue,de.width,de.height):i.texImage2D(r.TEXTURE_2D,0,Ue,de.width,de.height,0,Oe,ze,null));else if(E.isDataTexture)if(rt.length>0){ot&&_t&&i.texStorage2D(r.TEXTURE_2D,Re,Ue,rt[0].width,rt[0].height);for(let me=0,He=rt.length;me<He;me++)De=rt[me],ot?X&&i.texSubImage2D(r.TEXTURE_2D,me,0,0,De.width,De.height,Oe,ze,De.data):i.texImage2D(r.TEXTURE_2D,me,Ue,De.width,De.height,0,Oe,ze,De.data);E.generateMipmaps=!1}else ot?(_t&&i.texStorage2D(r.TEXTURE_2D,Re,Ue,de.width,de.height),X&&Me(E,de,Oe,ze)):i.texImage2D(r.TEXTURE_2D,0,Ue,de.width,de.height,0,Oe,ze,de.data);else if(E.isCompressedTexture)if(E.isCompressedArrayTexture){ot&&_t&&i.texStorage3D(r.TEXTURE_2D_ARRAY,Re,Ue,rt[0].width,rt[0].height,de.depth);for(let me=0,He=rt.length;me<He;me++)if(De=rt[me],E.format!==Pi)if(Oe!==null)if(ot){if(X)if(E.layerUpdates.size>0){const Le=ix(De.width,De.height,E.format,E.type);for(const Ee of E.layerUpdates){const We=De.data.subarray(Ee*Le/De.data.BYTES_PER_ELEMENT,(Ee+1)*Le/De.data.BYTES_PER_ELEMENT);i.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,me,0,0,Ee,De.width,De.height,1,Oe,We)}E.clearLayerUpdates()}else i.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,me,0,0,0,De.width,De.height,de.depth,Oe,De.data)}else i.compressedTexImage3D(r.TEXTURE_2D_ARRAY,me,Ue,De.width,De.height,de.depth,0,De.data,0,0);else st("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else ot?X&&i.texSubImage3D(r.TEXTURE_2D_ARRAY,me,0,0,0,De.width,De.height,de.depth,Oe,ze,De.data):i.texImage3D(r.TEXTURE_2D_ARRAY,me,Ue,De.width,De.height,de.depth,0,Oe,ze,De.data)}else{ot&&_t&&i.texStorage2D(r.TEXTURE_2D,Re,Ue,rt[0].width,rt[0].height);for(let me=0,He=rt.length;me<He;me++)De=rt[me],E.format!==Pi?Oe!==null?ot?X&&i.compressedTexSubImage2D(r.TEXTURE_2D,me,0,0,De.width,De.height,Oe,De.data):i.compressedTexImage2D(r.TEXTURE_2D,me,Ue,De.width,De.height,0,De.data):st("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ot?X&&i.texSubImage2D(r.TEXTURE_2D,me,0,0,De.width,De.height,Oe,ze,De.data):i.texImage2D(r.TEXTURE_2D,me,Ue,De.width,De.height,0,Oe,ze,De.data)}else if(E.isDataArrayTexture)if(ot){if(_t&&i.texStorage3D(r.TEXTURE_2D_ARRAY,Re,Ue,de.width,de.height,de.depth),X)if(E.layerUpdates.size>0){const me=ix(de.width,de.height,E.format,E.type);for(const He of E.layerUpdates){const Le=de.data.subarray(He*me/de.data.BYTES_PER_ELEMENT,(He+1)*me/de.data.BYTES_PER_ELEMENT);i.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,He,de.width,de.height,1,Oe,ze,Le)}E.clearLayerUpdates()}else i.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,de.width,de.height,de.depth,Oe,ze,de.data)}else i.texImage3D(r.TEXTURE_2D_ARRAY,0,Ue,de.width,de.height,de.depth,0,Oe,ze,de.data);else if(E.isData3DTexture)ot?(_t&&i.texStorage3D(r.TEXTURE_3D,Re,Ue,de.width,de.height,de.depth),X&&i.texSubImage3D(r.TEXTURE_3D,0,0,0,0,de.width,de.height,de.depth,Oe,ze,de.data)):i.texImage3D(r.TEXTURE_3D,0,Ue,de.width,de.height,de.depth,0,Oe,ze,de.data);else if(E.isFramebufferTexture){if(_t)if(ot)i.texStorage2D(r.TEXTURE_2D,Re,Ue,de.width,de.height);else{let me=de.width,He=de.height;for(let Le=0;Le<Re;Le++)i.texImage2D(r.TEXTURE_2D,Le,Ue,me,He,0,Oe,ze,null),me>>=1,He>>=1}}else if(E.isHTMLTexture){if("texElementImage2D"in r){const me=r.canvas;if(me.hasAttribute("layoutsubtree")||me.setAttribute("layoutsubtree","true"),de.parentNode!==me){me.appendChild(de),x.add(E),me.onpaint=it=>{const Jt=it.changedElements;for(const Dt of x)Jt.includes(Dt.image)&&(Dt.needsUpdate=!0)},me.requestPaint();return}const He=0,Le=r.RGBA,Ee=r.RGBA,We=r.UNSIGNED_BYTE;r.texElementImage2D(r.TEXTURE_2D,He,Le,Ee,We,de),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE)}}else if(rt.length>0){if(ot&&_t){const me=Xt(rt[0]);i.texStorage2D(r.TEXTURE_2D,Re,Ue,me.width,me.height)}for(let me=0,He=rt.length;me<He;me++)De=rt[me],ot?X&&i.texSubImage2D(r.TEXTURE_2D,me,0,0,Oe,ze,De):i.texImage2D(r.TEXTURE_2D,me,Ue,Oe,ze,De);E.generateMipmaps=!1}else if(ot){if(_t){const me=Xt(de);i.texStorage2D(r.TEXTURE_2D,Re,Ue,me.width,me.height)}X&&i.texSubImage2D(r.TEXTURE_2D,0,0,0,Oe,ze,de)}else i.texImage2D(r.TEXTURE_2D,0,Ue,Oe,ze,de);S(E)&&N(xe),Pe.__version=Ne.version,E.onUpdate&&E.onUpdate(E)}U.__version=E.version}function Ze(U,E,$){if(E.image.length!==6)return;const xe=ae(U,E),Te=E.source;i.bindTexture(r.TEXTURE_CUBE_MAP,U.__webglTexture,r.TEXTURE0+$);const Ne=s.get(Te);if(Te.version!==Ne.__version||xe===!0){i.activeTexture(r.TEXTURE0+$);const Pe=wt.getPrimaries(wt.workingColorSpace),ne=E.colorSpace===cs?null:wt.getPrimaries(E.colorSpace),de=E.colorSpace===cs||Pe===ne?r.NONE:r.BROWSER_DEFAULT_WEBGL;i.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(r.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,de);const Oe=E.isCompressedTexture||E.image[0].isCompressedTexture,ze=E.image[0]&&E.image[0].isDataTexture,Ue=[];for(let Ee=0;Ee<6;Ee++)!Oe&&!ze?Ue[Ee]=b(E.image[Ee],!0,l.maxCubemapSize):Ue[Ee]=ze?E.image[Ee].image:E.image[Ee],Ue[Ee]=we(E,Ue[Ee]);const De=Ue[0],rt=c.convert(E.format,E.colorSpace),ot=c.convert(E.type),_t=z(E.internalFormat,rt,ot,E.normalized,E.colorSpace),X=E.isVideoTexture!==!0,Re=Ne.__version===void 0||xe===!0,me=Te.dataReady;let He=L(E,De);Ce(r.TEXTURE_CUBE_MAP,E);let Le;if(Oe){X&&Re&&i.texStorage2D(r.TEXTURE_CUBE_MAP,He,_t,De.width,De.height);for(let Ee=0;Ee<6;Ee++){Le=Ue[Ee].mipmaps;for(let We=0;We<Le.length;We++){const it=Le[We];E.format!==Pi?rt!==null?X?me&&i.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,We,0,0,it.width,it.height,rt,it.data):i.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,We,_t,it.width,it.height,0,it.data):st("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):X?me&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,We,0,0,it.width,it.height,rt,ot,it.data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,We,_t,it.width,it.height,0,rt,ot,it.data)}}}else{if(Le=E.mipmaps,X&&Re){Le.length>0&&He++;const Ee=Xt(Ue[0]);i.texStorage2D(r.TEXTURE_CUBE_MAP,He,_t,Ee.width,Ee.height)}for(let Ee=0;Ee<6;Ee++)if(ze){X?me&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,0,0,0,Ue[Ee].width,Ue[Ee].height,rt,ot,Ue[Ee].data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,0,_t,Ue[Ee].width,Ue[Ee].height,0,rt,ot,Ue[Ee].data);for(let We=0;We<Le.length;We++){const Jt=Le[We].image[Ee].image;X?me&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,We+1,0,0,Jt.width,Jt.height,rt,ot,Jt.data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,We+1,_t,Jt.width,Jt.height,0,rt,ot,Jt.data)}}else{X?me&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,0,0,0,rt,ot,Ue[Ee]):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,0,_t,rt,ot,Ue[Ee]);for(let We=0;We<Le.length;We++){const it=Le[We];X?me&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,We+1,0,0,rt,ot,it.image[Ee]):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,We+1,_t,rt,ot,it.image[Ee])}}}S(E)&&N(r.TEXTURE_CUBE_MAP),Ne.__version=Te.version,E.onUpdate&&E.onUpdate(E)}U.__version=E.version}function Ke(U,E,$,xe,Te,Ne){const Pe=c.convert($.format,$.colorSpace),ne=c.convert($.type),de=z($.internalFormat,Pe,ne,$.normalized,$.colorSpace),Oe=s.get(E),ze=s.get($);if(ze.__renderTarget=E,!Oe.__hasExternalTextures){const Ue=Math.max(1,E.width>>Ne),De=Math.max(1,E.height>>Ne);Te===r.TEXTURE_3D||Te===r.TEXTURE_2D_ARRAY?i.texImage3D(Te,Ne,de,Ue,De,E.depth,0,Pe,ne,null):i.texImage2D(Te,Ne,de,Ue,De,0,Pe,ne,null)}i.bindFramebuffer(r.FRAMEBUFFER,U),lt(E)?p.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,xe,Te,ze.__webglTexture,0,yt(E)):(Te===r.TEXTURE_2D||Te>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&Te<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,xe,Te,ze.__webglTexture,Ne),i.bindFramebuffer(r.FRAMEBUFFER,null)}function Lt(U,E,$){if(r.bindRenderbuffer(r.RENDERBUFFER,U),E.depthBuffer){const xe=E.depthTexture,Te=xe&&xe.isDepthTexture?xe.type:null,Ne=k(E.stencilBuffer,Te),Pe=E.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;lt(E)?p.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,yt(E),Ne,E.width,E.height):$?r.renderbufferStorageMultisample(r.RENDERBUFFER,yt(E),Ne,E.width,E.height):r.renderbufferStorage(r.RENDERBUFFER,Ne,E.width,E.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,Pe,r.RENDERBUFFER,U)}else{const xe=E.textures;for(let Te=0;Te<xe.length;Te++){const Ne=xe[Te],Pe=c.convert(Ne.format,Ne.colorSpace),ne=c.convert(Ne.type),de=z(Ne.internalFormat,Pe,ne,Ne.normalized,Ne.colorSpace);lt(E)?p.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,yt(E),de,E.width,E.height):$?r.renderbufferStorageMultisample(r.RENDERBUFFER,yt(E),de,E.width,E.height):r.renderbufferStorage(r.RENDERBUFFER,de,E.width,E.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function nt(U,E,$){const xe=E.isWebGLCubeRenderTarget===!0;if(i.bindFramebuffer(r.FRAMEBUFFER,U),!(E.depthTexture&&E.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const Te=s.get(E.depthTexture);if(Te.__renderTarget=E,(!Te.__webglTexture||E.depthTexture.image.width!==E.width||E.depthTexture.image.height!==E.height)&&(E.depthTexture.image.width=E.width,E.depthTexture.image.height=E.height,E.depthTexture.needsUpdate=!0),xe){if(Te.__webglInit===void 0&&(Te.__webglInit=!0,E.depthTexture.addEventListener("dispose",H)),Te.__webglTexture===void 0){Te.__webglTexture=r.createTexture(),i.bindTexture(r.TEXTURE_CUBE_MAP,Te.__webglTexture),Ce(r.TEXTURE_CUBE_MAP,E.depthTexture);const Oe=c.convert(E.depthTexture.format),ze=c.convert(E.depthTexture.type);let Ue;E.depthTexture.format===Aa?Ue=r.DEPTH_COMPONENT24:E.depthTexture.format===Gs&&(Ue=r.DEPTH24_STENCIL8);for(let De=0;De<6;De++)r.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,0,Ue,E.width,E.height,0,Oe,ze,null)}}else q(E.depthTexture,0);const Ne=Te.__webglTexture,Pe=yt(E),ne=xe?r.TEXTURE_CUBE_MAP_POSITIVE_X+$:r.TEXTURE_2D,de=E.depthTexture.format===Gs?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;if(E.depthTexture.format===Aa)lt(E)?p.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,de,ne,Ne,0,Pe):r.framebufferTexture2D(r.FRAMEBUFFER,de,ne,Ne,0);else if(E.depthTexture.format===Gs)lt(E)?p.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,de,ne,Ne,0,Pe):r.framebufferTexture2D(r.FRAMEBUFFER,de,ne,Ne,0);else throw new Error("Unknown depthTexture format")}function dt(U){const E=s.get(U),$=U.isWebGLCubeRenderTarget===!0;if(E.__boundDepthTexture!==U.depthTexture){const xe=U.depthTexture;if(E.__depthDisposeCallback&&E.__depthDisposeCallback(),xe){const Te=()=>{delete E.__boundDepthTexture,delete E.__depthDisposeCallback,xe.removeEventListener("dispose",Te)};xe.addEventListener("dispose",Te),E.__depthDisposeCallback=Te}E.__boundDepthTexture=xe}if(U.depthTexture&&!E.__autoAllocateDepthBuffer)if($)for(let xe=0;xe<6;xe++)nt(E.__webglFramebuffer[xe],U,xe);else{const xe=U.texture.mipmaps;xe&&xe.length>0?nt(E.__webglFramebuffer[0],U,0):nt(E.__webglFramebuffer,U,0)}else if($){E.__webglDepthbuffer=[];for(let xe=0;xe<6;xe++)if(i.bindFramebuffer(r.FRAMEBUFFER,E.__webglFramebuffer[xe]),E.__webglDepthbuffer[xe]===void 0)E.__webglDepthbuffer[xe]=r.createRenderbuffer(),Lt(E.__webglDepthbuffer[xe],U,!1);else{const Te=U.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Ne=E.__webglDepthbuffer[xe];r.bindRenderbuffer(r.RENDERBUFFER,Ne),r.framebufferRenderbuffer(r.FRAMEBUFFER,Te,r.RENDERBUFFER,Ne)}}else{const xe=U.texture.mipmaps;if(xe&&xe.length>0?i.bindFramebuffer(r.FRAMEBUFFER,E.__webglFramebuffer[0]):i.bindFramebuffer(r.FRAMEBUFFER,E.__webglFramebuffer),E.__webglDepthbuffer===void 0)E.__webglDepthbuffer=r.createRenderbuffer(),Lt(E.__webglDepthbuffer,U,!1);else{const Te=U.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Ne=E.__webglDepthbuffer;r.bindRenderbuffer(r.RENDERBUFFER,Ne),r.framebufferRenderbuffer(r.FRAMEBUFFER,Te,r.RENDERBUFFER,Ne)}}i.bindFramebuffer(r.FRAMEBUFFER,null)}function St(U,E,$){const xe=s.get(U);E!==void 0&&Ke(xe.__webglFramebuffer,U,U.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),$!==void 0&&dt(U)}function ct(U){const E=U.texture,$=s.get(U),xe=s.get(E);U.addEventListener("dispose",T);const Te=U.textures,Ne=U.isWebGLCubeRenderTarget===!0,Pe=Te.length>1;if(Pe||(xe.__webglTexture===void 0&&(xe.__webglTexture=r.createTexture()),xe.__version=E.version,d.memory.textures++),Ne){$.__webglFramebuffer=[];for(let ne=0;ne<6;ne++)if(E.mipmaps&&E.mipmaps.length>0){$.__webglFramebuffer[ne]=[];for(let de=0;de<E.mipmaps.length;de++)$.__webglFramebuffer[ne][de]=r.createFramebuffer()}else $.__webglFramebuffer[ne]=r.createFramebuffer()}else{if(E.mipmaps&&E.mipmaps.length>0){$.__webglFramebuffer=[];for(let ne=0;ne<E.mipmaps.length;ne++)$.__webglFramebuffer[ne]=r.createFramebuffer()}else $.__webglFramebuffer=r.createFramebuffer();if(Pe)for(let ne=0,de=Te.length;ne<de;ne++){const Oe=s.get(Te[ne]);Oe.__webglTexture===void 0&&(Oe.__webglTexture=r.createTexture(),d.memory.textures++)}if(U.samples>0&&lt(U)===!1){$.__webglMultisampledFramebuffer=r.createFramebuffer(),$.__webglColorRenderbuffer=[],i.bindFramebuffer(r.FRAMEBUFFER,$.__webglMultisampledFramebuffer);for(let ne=0;ne<Te.length;ne++){const de=Te[ne];$.__webglColorRenderbuffer[ne]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,$.__webglColorRenderbuffer[ne]);const Oe=c.convert(de.format,de.colorSpace),ze=c.convert(de.type),Ue=z(de.internalFormat,Oe,ze,de.normalized,de.colorSpace,U.isXRRenderTarget===!0),De=yt(U);r.renderbufferStorageMultisample(r.RENDERBUFFER,De,Ue,U.width,U.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ne,r.RENDERBUFFER,$.__webglColorRenderbuffer[ne])}r.bindRenderbuffer(r.RENDERBUFFER,null),U.depthBuffer&&($.__webglDepthRenderbuffer=r.createRenderbuffer(),Lt($.__webglDepthRenderbuffer,U,!0)),i.bindFramebuffer(r.FRAMEBUFFER,null)}}if(Ne){i.bindTexture(r.TEXTURE_CUBE_MAP,xe.__webglTexture),Ce(r.TEXTURE_CUBE_MAP,E);for(let ne=0;ne<6;ne++)if(E.mipmaps&&E.mipmaps.length>0)for(let de=0;de<E.mipmaps.length;de++)Ke($.__webglFramebuffer[ne][de],U,E,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+ne,de);else Ke($.__webglFramebuffer[ne],U,E,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0);S(E)&&N(r.TEXTURE_CUBE_MAP),i.unbindTexture()}else if(Pe){for(let ne=0,de=Te.length;ne<de;ne++){const Oe=Te[ne],ze=s.get(Oe);let Ue=r.TEXTURE_2D;(U.isWebGL3DRenderTarget||U.isWebGLArrayRenderTarget)&&(Ue=U.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),i.bindTexture(Ue,ze.__webglTexture),Ce(Ue,Oe),Ke($.__webglFramebuffer,U,Oe,r.COLOR_ATTACHMENT0+ne,Ue,0),S(Oe)&&N(Ue)}i.unbindTexture()}else{let ne=r.TEXTURE_2D;if((U.isWebGL3DRenderTarget||U.isWebGLArrayRenderTarget)&&(ne=U.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),i.bindTexture(ne,xe.__webglTexture),Ce(ne,E),E.mipmaps&&E.mipmaps.length>0)for(let de=0;de<E.mipmaps.length;de++)Ke($.__webglFramebuffer[de],U,E,r.COLOR_ATTACHMENT0,ne,de);else Ke($.__webglFramebuffer,U,E,r.COLOR_ATTACHMENT0,ne,0);S(E)&&N(ne),i.unbindTexture()}U.depthBuffer&&dt(U)}function $t(U){const E=U.textures;for(let $=0,xe=E.length;$<xe;$++){const Te=E[$];if(S(Te)){const Ne=O(U),Pe=s.get(Te).__webglTexture;i.bindTexture(Ne,Pe),N(Ne),i.unbindTexture()}}}const te=[],Fe=[];function j(U){if(U.samples>0){if(lt(U)===!1){const E=U.textures,$=U.width,xe=U.height;let Te=r.COLOR_BUFFER_BIT;const Ne=U.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Pe=s.get(U),ne=E.length>1;if(ne)for(let Oe=0;Oe<E.length;Oe++)i.bindFramebuffer(r.FRAMEBUFFER,Pe.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Oe,r.RENDERBUFFER,null),i.bindFramebuffer(r.FRAMEBUFFER,Pe.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Oe,r.TEXTURE_2D,null,0);i.bindFramebuffer(r.READ_FRAMEBUFFER,Pe.__webglMultisampledFramebuffer);const de=U.texture.mipmaps;de&&de.length>0?i.bindFramebuffer(r.DRAW_FRAMEBUFFER,Pe.__webglFramebuffer[0]):i.bindFramebuffer(r.DRAW_FRAMEBUFFER,Pe.__webglFramebuffer);for(let Oe=0;Oe<E.length;Oe++){if(U.resolveDepthBuffer&&(U.depthBuffer&&(Te|=r.DEPTH_BUFFER_BIT),U.stencilBuffer&&U.resolveStencilBuffer&&(Te|=r.STENCIL_BUFFER_BIT)),ne){r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,Pe.__webglColorRenderbuffer[Oe]);const ze=s.get(E[Oe]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,ze,0)}r.blitFramebuffer(0,0,$,xe,0,0,$,xe,Te,r.NEAREST),m===!0&&(te.length=0,Fe.length=0,te.push(r.COLOR_ATTACHMENT0+Oe),U.depthBuffer&&U.resolveDepthBuffer===!1&&(te.push(Ne),Fe.push(Ne),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,Fe)),r.invalidateFramebuffer(r.READ_FRAMEBUFFER,te))}if(i.bindFramebuffer(r.READ_FRAMEBUFFER,null),i.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),ne)for(let Oe=0;Oe<E.length;Oe++){i.bindFramebuffer(r.FRAMEBUFFER,Pe.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Oe,r.RENDERBUFFER,Pe.__webglColorRenderbuffer[Oe]);const ze=s.get(E[Oe]).__webglTexture;i.bindFramebuffer(r.FRAMEBUFFER,Pe.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Oe,r.TEXTURE_2D,ze,0)}i.bindFramebuffer(r.DRAW_FRAMEBUFFER,Pe.__webglMultisampledFramebuffer)}else if(U.depthBuffer&&U.resolveDepthBuffer===!1&&m){const E=U.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[E])}}}function yt(U){return Math.min(l.maxSamples,U.samples)}function lt(U){const E=s.get(U);return U.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&E.__useRenderToTexture!==!1}function Nt(U){const E=d.render.frame;g.get(U)!==E&&(g.set(U,E),U.update())}function we(U,E){const $=U.colorSpace,xe=U.format,Te=U.type;return U.isCompressedTexture===!0||U.isVideoTexture===!0||$!==lu&&$!==cs&&(wt.getTransfer($)===jt?(xe!==Pi||Te!==gi)&&st("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Ut("WebGLTextures: Unsupported texture color space:",$)),E}function Xt(U){return typeof HTMLImageElement<"u"&&U instanceof HTMLImageElement?(h.width=U.naturalWidth||U.width,h.height=U.naturalHeight||U.height):typeof VideoFrame<"u"&&U instanceof VideoFrame?(h.width=U.displayWidth,h.height=U.displayHeight):(h.width=U.width,h.height=U.height),h}this.allocateTextureUnit=D,this.resetTextureUnits=ue,this.getTextureUnits=pe,this.setTextureUnits=F,this.setTexture2D=q,this.setTexture2DArray=he,this.setTexture3D=_e,this.setTextureCube=B,this.rebindTextures=St,this.setupRenderTarget=ct,this.updateRenderTargetMipmap=$t,this.updateMultisampleRenderTarget=j,this.setupDepthRenderbuffer=dt,this.setupFrameBufferTexture=Ke,this.useMultisampledRTT=lt,this.isReversedDepthBuffer=function(){return i.buffers.depth.getReversed()}}function XA(r,e){function i(s,l=cs){let c;const d=wt.getTransfer(l);if(s===gi)return r.UNSIGNED_BYTE;if(s===up)return r.UNSIGNED_SHORT_4_4_4_4;if(s===fp)return r.UNSIGNED_SHORT_5_5_5_1;if(s===qx)return r.UNSIGNED_INT_5_9_9_9_REV;if(s===Yx)return r.UNSIGNED_INT_10F_11F_11F_REV;if(s===Xx)return r.BYTE;if(s===Wx)return r.SHORT;if(s===rl)return r.UNSIGNED_SHORT;if(s===cp)return r.INT;if(s===Ki)return r.UNSIGNED_INT;if(s===Wi)return r.FLOAT;if(s===Ta)return r.HALF_FLOAT;if(s===Zx)return r.ALPHA;if(s===Kx)return r.RGB;if(s===Pi)return r.RGBA;if(s===Aa)return r.DEPTH_COMPONENT;if(s===Gs)return r.DEPTH_STENCIL;if(s===Qx)return r.RED;if(s===dp)return r.RED_INTEGER;if(s===js)return r.RG;if(s===hp)return r.RG_INTEGER;if(s===pp)return r.RGBA_INTEGER;if(s===tu||s===nu||s===iu||s===au)if(d===jt)if(c=e.get("WEBGL_compressed_texture_s3tc_srgb"),c!==null){if(s===tu)return c.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===nu)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===iu)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===au)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(c=e.get("WEBGL_compressed_texture_s3tc"),c!==null){if(s===tu)return c.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===nu)return c.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===iu)return c.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===au)return c.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===Eh||s===Th||s===Ah||s===Rh)if(c=e.get("WEBGL_compressed_texture_pvrtc"),c!==null){if(s===Eh)return c.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===Th)return c.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===Ah)return c.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===Rh)return c.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===Ch||s===wh||s===Dh||s===Nh||s===Uh||s===ru||s===Lh)if(c=e.get("WEBGL_compressed_texture_etc"),c!==null){if(s===Ch||s===wh)return d===jt?c.COMPRESSED_SRGB8_ETC2:c.COMPRESSED_RGB8_ETC2;if(s===Dh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:c.COMPRESSED_RGBA8_ETC2_EAC;if(s===Nh)return c.COMPRESSED_R11_EAC;if(s===Uh)return c.COMPRESSED_SIGNED_R11_EAC;if(s===ru)return c.COMPRESSED_RG11_EAC;if(s===Lh)return c.COMPRESSED_SIGNED_RG11_EAC}else return null;if(s===Oh||s===Ph||s===zh||s===Fh||s===Bh||s===Ih||s===Hh||s===Gh||s===Vh||s===kh||s===jh||s===Xh||s===Wh||s===qh)if(c=e.get("WEBGL_compressed_texture_astc"),c!==null){if(s===Oh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:c.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===Ph)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:c.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===zh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:c.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===Fh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:c.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===Bh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:c.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===Ih)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:c.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===Hh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:c.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===Gh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:c.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===Vh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:c.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===kh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:c.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===jh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:c.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===Xh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:c.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===Wh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:c.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===qh)return d===jt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:c.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===Yh||s===Zh||s===Kh)if(c=e.get("EXT_texture_compression_bptc"),c!==null){if(s===Yh)return d===jt?c.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:c.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(s===Zh)return c.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(s===Kh)return c.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(s===Qh||s===Jh||s===ou||s===$h)if(c=e.get("EXT_texture_compression_rgtc"),c!==null){if(s===Qh)return c.COMPRESSED_RED_RGTC1_EXT;if(s===Jh)return c.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(s===ou)return c.COMPRESSED_RED_GREEN_RGTC2_EXT;if(s===$h)return c.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return s===ol?r.UNSIGNED_INT_24_8:r[s]!==void 0?r[s]:null}return{convert:i}}const WA=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,qA=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class YA{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,i){if(this.texture===null){const s=new ov(e.texture);(e.depthNear!==i.depthNear||e.depthFar!==i.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=s}}getMesh(e){if(this.texture!==null&&this.mesh===null){const i=e.cameras[0].viewport,s=new Qi({vertexShader:WA,fragmentShader:qA,uniforms:{depthColor:{value:this.texture},depthWidth:{value:i.z},depthHeight:{value:i.w}}});this.mesh=new zi(new gu(20,20),s)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class ZA extends ps{constructor(e,i){super();const s=this;let l=null,c=1,d=null,p="local-floor",m=1,h=null,g=null,x=null,_=null,y=null,M=null;const A=typeof XRWebGLBinding<"u",b=new YA,S={},N=i.getContextAttributes();let O=null,z=null;const k=[],L=[],H=new gt;let T=null;const I=new mi;I.viewport=new cn;const Z=new mi;Z.viewport=new cn;const G=[I,Z],K=new nM;let ue=null,pe=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(ae){let ye=k[ae];return ye===void 0&&(ye=new Id,k[ae]=ye),ye.getTargetRaySpace()},this.getControllerGrip=function(ae){let ye=k[ae];return ye===void 0&&(ye=new Id,k[ae]=ye),ye.getGripSpace()},this.getHand=function(ae){let ye=k[ae];return ye===void 0&&(ye=new Id,k[ae]=ye),ye.getHandSpace()};function F(ae){const ye=L.indexOf(ae.inputSource);if(ye===-1)return;const Me=k[ye];Me!==void 0&&(Me.update(ae.inputSource,ae.frame,h||d),Me.dispatchEvent({type:ae.type,data:ae.inputSource}))}function D(){l.removeEventListener("select",F),l.removeEventListener("selectstart",F),l.removeEventListener("selectend",F),l.removeEventListener("squeeze",F),l.removeEventListener("squeezestart",F),l.removeEventListener("squeezeend",F),l.removeEventListener("end",D),l.removeEventListener("inputsourceschange",P);for(let ae=0;ae<k.length;ae++){const ye=L[ae];ye!==null&&(L[ae]=null,k[ae].disconnect(ye))}ue=null,pe=null,b.reset();for(const ae in S)delete S[ae];e.setRenderTarget(O),y=null,_=null,x=null,l=null,z=null,Ce.stop(),s.isPresenting=!1,e.setPixelRatio(T),e.setSize(H.width,H.height,!1),s.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(ae){c=ae,s.isPresenting===!0&&st("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(ae){p=ae,s.isPresenting===!0&&st("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return h||d},this.setReferenceSpace=function(ae){h=ae},this.getBaseLayer=function(){return _!==null?_:y},this.getBinding=function(){return x===null&&A&&(x=new XRWebGLBinding(l,i)),x},this.getFrame=function(){return M},this.getSession=function(){return l},this.setSession=async function(ae){if(l=ae,l!==null){if(O=e.getRenderTarget(),l.addEventListener("select",F),l.addEventListener("selectstart",F),l.addEventListener("selectend",F),l.addEventListener("squeeze",F),l.addEventListener("squeezestart",F),l.addEventListener("squeezeend",F),l.addEventListener("end",D),l.addEventListener("inputsourceschange",P),N.xrCompatible!==!0&&await i.makeXRCompatible(),T=e.getPixelRatio(),e.getSize(H),A&&"createProjectionLayer"in XRWebGLBinding.prototype){let Me=null,Ie=null,Ze=null;N.depth&&(Ze=N.stencil?i.DEPTH24_STENCIL8:i.DEPTH_COMPONENT24,Me=N.stencil?Gs:Aa,Ie=N.stencil?ol:Ki);const Ke={colorFormat:i.RGBA8,depthFormat:Ze,scaleFactor:c};x=this.getBinding(),_=x.createProjectionLayer(Ke),l.updateRenderState({layers:[_]}),e.setPixelRatio(1),e.setSize(_.textureWidth,_.textureHeight,!1),z=new Zi(_.textureWidth,_.textureHeight,{format:Pi,type:gi,depthTexture:new qr(_.textureWidth,_.textureHeight,Ie,void 0,void 0,void 0,void 0,void 0,void 0,Me),stencilBuffer:N.stencil,colorSpace:e.outputColorSpace,samples:N.antialias?4:0,resolveDepthBuffer:_.ignoreDepthValues===!1,resolveStencilBuffer:_.ignoreDepthValues===!1})}else{const Me={antialias:N.antialias,alpha:!0,depth:N.depth,stencil:N.stencil,framebufferScaleFactor:c};y=new XRWebGLLayer(l,i,Me),l.updateRenderState({baseLayer:y}),e.setPixelRatio(1),e.setSize(y.framebufferWidth,y.framebufferHeight,!1),z=new Zi(y.framebufferWidth,y.framebufferHeight,{format:Pi,type:gi,colorSpace:e.outputColorSpace,stencilBuffer:N.stencil,resolveDepthBuffer:y.ignoreDepthValues===!1,resolveStencilBuffer:y.ignoreDepthValues===!1})}z.isXRRenderTarget=!0,this.setFoveation(m),h=null,d=await l.requestReferenceSpace(p),Ce.setContext(l),Ce.start(),s.isPresenting=!0,s.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(l!==null)return l.environmentBlendMode},this.getDepthTexture=function(){return b.getDepthTexture()};function P(ae){for(let ye=0;ye<ae.removed.length;ye++){const Me=ae.removed[ye],Ie=L.indexOf(Me);Ie>=0&&(L[Ie]=null,k[Ie].disconnect(Me))}for(let ye=0;ye<ae.added.length;ye++){const Me=ae.added[ye];let Ie=L.indexOf(Me);if(Ie===-1){for(let Ke=0;Ke<k.length;Ke++)if(Ke>=L.length){L.push(Me),Ie=Ke;break}else if(L[Ke]===null){L[Ke]=Me,Ie=Ke;break}if(Ie===-1)break}const Ze=k[Ie];Ze&&Ze.connect(Me)}}const q=new ee,he=new ee;function _e(ae,ye,Me){q.setFromMatrixPosition(ye.matrixWorld),he.setFromMatrixPosition(Me.matrixWorld);const Ie=q.distanceTo(he),Ze=ye.projectionMatrix.elements,Ke=Me.projectionMatrix.elements,Lt=Ze[14]/(Ze[10]-1),nt=Ze[14]/(Ze[10]+1),dt=(Ze[9]+1)/Ze[5],St=(Ze[9]-1)/Ze[5],ct=(Ze[8]-1)/Ze[0],$t=(Ke[8]+1)/Ke[0],te=Lt*ct,Fe=Lt*$t,j=Ie/(-ct+$t),yt=j*-ct;if(ye.matrixWorld.decompose(ae.position,ae.quaternion,ae.scale),ae.translateX(yt),ae.translateZ(j),ae.matrixWorld.compose(ae.position,ae.quaternion,ae.scale),ae.matrixWorldInverse.copy(ae.matrixWorld).invert(),Ze[10]===-1)ae.projectionMatrix.copy(ye.projectionMatrix),ae.projectionMatrixInverse.copy(ye.projectionMatrixInverse);else{const lt=Lt+j,Nt=nt+j,we=te-yt,Xt=Fe+(Ie-yt),U=dt*nt/Nt*lt,E=St*nt/Nt*lt;ae.projectionMatrix.makePerspective(we,Xt,U,E,lt,Nt),ae.projectionMatrixInverse.copy(ae.projectionMatrix).invert()}}function B(ae,ye){ye===null?ae.matrixWorld.copy(ae.matrix):ae.matrixWorld.multiplyMatrices(ye.matrixWorld,ae.matrix),ae.matrixWorldInverse.copy(ae.matrixWorld).invert()}this.updateCamera=function(ae){if(l===null)return;let ye=ae.near,Me=ae.far;b.texture!==null&&(b.depthNear>0&&(ye=b.depthNear),b.depthFar>0&&(Me=b.depthFar)),K.near=Z.near=I.near=ye,K.far=Z.far=I.far=Me,(ue!==K.near||pe!==K.far)&&(l.updateRenderState({depthNear:K.near,depthFar:K.far}),ue=K.near,pe=K.far),K.layers.mask=ae.layers.mask|6,I.layers.mask=K.layers.mask&-5,Z.layers.mask=K.layers.mask&-3;const Ie=ae.parent,Ze=K.cameras;B(K,Ie);for(let Ke=0;Ke<Ze.length;Ke++)B(Ze[Ke],Ie);Ze.length===2?_e(K,I,Z):K.projectionMatrix.copy(I.projectionMatrix),Q(ae,K,Ie)};function Q(ae,ye,Me){Me===null?ae.matrix.copy(ye.matrixWorld):(ae.matrix.copy(Me.matrixWorld),ae.matrix.invert(),ae.matrix.multiply(ye.matrixWorld)),ae.matrix.decompose(ae.position,ae.quaternion,ae.scale),ae.updateMatrixWorld(!0),ae.projectionMatrix.copy(ye.projectionMatrix),ae.projectionMatrixInverse.copy(ye.projectionMatrixInverse),ae.isPerspectiveCamera&&(ae.fov=np*2*Math.atan(1/ae.projectionMatrix.elements[5]),ae.zoom=1)}this.getCamera=function(){return K},this.getFoveation=function(){if(!(_===null&&y===null))return m},this.setFoveation=function(ae){m=ae,_!==null&&(_.fixedFoveation=ae),y!==null&&y.fixedFoveation!==void 0&&(y.fixedFoveation=ae)},this.hasDepthSensing=function(){return b.texture!==null},this.getDepthSensingMesh=function(){return b.getMesh(K)},this.getCameraTexture=function(ae){return S[ae]};let ve=null;function Ae(ae,ye){if(g=ye.getViewerPose(h||d),M=ye,g!==null){const Me=g.views;y!==null&&(e.setRenderTargetFramebuffer(z,y.framebuffer),e.setRenderTarget(z));let Ie=!1;Me.length!==K.cameras.length&&(K.cameras.length=0,Ie=!0);for(let nt=0;nt<Me.length;nt++){const dt=Me[nt];let St=null;if(y!==null)St=y.getViewport(dt);else{const $t=x.getViewSubImage(_,dt);St=$t.viewport,nt===0&&(e.setRenderTargetTextures(z,$t.colorTexture,$t.depthStencilTexture),e.setRenderTarget(z))}let ct=G[nt];ct===void 0&&(ct=new mi,ct.layers.enable(nt),ct.viewport=new cn,G[nt]=ct),ct.matrix.fromArray(dt.transform.matrix),ct.matrix.decompose(ct.position,ct.quaternion,ct.scale),ct.projectionMatrix.fromArray(dt.projectionMatrix),ct.projectionMatrixInverse.copy(ct.projectionMatrix).invert(),ct.viewport.set(St.x,St.y,St.width,St.height),nt===0&&(K.matrix.copy(ct.matrix),K.matrix.decompose(K.position,K.quaternion,K.scale)),Ie===!0&&K.cameras.push(ct)}const Ze=l.enabledFeatures;if(Ze&&Ze.includes("depth-sensing")&&l.depthUsage=="gpu-optimized"&&A){x=s.getBinding();const nt=x.getDepthInformation(Me[0]);nt&&nt.isValid&&nt.texture&&b.init(nt,l.renderState)}if(Ze&&Ze.includes("camera-access")&&A){e.state.unbindTexture(),x=s.getBinding();for(let nt=0;nt<Me.length;nt++){const dt=Me[nt].camera;if(dt){let St=S[dt];St||(St=new ov,S[dt]=St);const ct=x.getCameraImage(dt);St.sourceTexture=ct}}}}for(let Me=0;Me<k.length;Me++){const Ie=L[Me],Ze=k[Me];Ie!==null&&Ze!==void 0&&Ze.update(Ie,ye,h||d)}ve&&ve(ae,ye),ye.detectedPlanes&&s.dispatchEvent({type:"planesdetected",data:ye}),M=null}const Ce=new fv;Ce.setAnimationLoop(Ae),this.setAnimationLoop=function(ae){ve=ae},this.dispose=function(){}}}const KA=new rn,xv=new ht;xv.set(-1,0,0,0,1,0,0,0,1);function QA(r,e){function i(b,S){b.matrixAutoUpdate===!0&&b.updateMatrix(),S.value.copy(b.matrix)}function s(b,S){S.color.getRGB(b.fogColor.value,lv(r)),S.isFog?(b.fogNear.value=S.near,b.fogFar.value=S.far):S.isFogExp2&&(b.fogDensity.value=S.density)}function l(b,S,N,O,z){S.isNodeMaterial?S.uniformsNeedUpdate=!1:S.isMeshBasicMaterial?c(b,S):S.isMeshLambertMaterial?(c(b,S),S.envMap&&(b.envMapIntensity.value=S.envMapIntensity)):S.isMeshToonMaterial?(c(b,S),x(b,S)):S.isMeshPhongMaterial?(c(b,S),g(b,S),S.envMap&&(b.envMapIntensity.value=S.envMapIntensity)):S.isMeshStandardMaterial?(c(b,S),_(b,S),S.isMeshPhysicalMaterial&&y(b,S,z)):S.isMeshMatcapMaterial?(c(b,S),M(b,S)):S.isMeshDepthMaterial?c(b,S):S.isMeshDistanceMaterial?(c(b,S),A(b,S)):S.isMeshNormalMaterial?c(b,S):S.isLineBasicMaterial?(d(b,S),S.isLineDashedMaterial&&p(b,S)):S.isPointsMaterial?m(b,S,N,O):S.isSpriteMaterial?h(b,S):S.isShadowMaterial?(b.color.value.copy(S.color),b.opacity.value=S.opacity):S.isShaderMaterial&&(S.uniformsNeedUpdate=!1)}function c(b,S){b.opacity.value=S.opacity,S.color&&b.diffuse.value.copy(S.color),S.emissive&&b.emissive.value.copy(S.emissive).multiplyScalar(S.emissiveIntensity),S.map&&(b.map.value=S.map,i(S.map,b.mapTransform)),S.alphaMap&&(b.alphaMap.value=S.alphaMap,i(S.alphaMap,b.alphaMapTransform)),S.bumpMap&&(b.bumpMap.value=S.bumpMap,i(S.bumpMap,b.bumpMapTransform),b.bumpScale.value=S.bumpScale,S.side===ni&&(b.bumpScale.value*=-1)),S.normalMap&&(b.normalMap.value=S.normalMap,i(S.normalMap,b.normalMapTransform),b.normalScale.value.copy(S.normalScale),S.side===ni&&b.normalScale.value.negate()),S.displacementMap&&(b.displacementMap.value=S.displacementMap,i(S.displacementMap,b.displacementMapTransform),b.displacementScale.value=S.displacementScale,b.displacementBias.value=S.displacementBias),S.emissiveMap&&(b.emissiveMap.value=S.emissiveMap,i(S.emissiveMap,b.emissiveMapTransform)),S.specularMap&&(b.specularMap.value=S.specularMap,i(S.specularMap,b.specularMapTransform)),S.alphaTest>0&&(b.alphaTest.value=S.alphaTest);const N=e.get(S),O=N.envMap,z=N.envMapRotation;O&&(b.envMap.value=O,b.envMapRotation.value.setFromMatrix4(KA.makeRotationFromEuler(z)).transpose(),O.isCubeTexture&&O.isRenderTargetTexture===!1&&b.envMapRotation.value.premultiply(xv),b.reflectivity.value=S.reflectivity,b.ior.value=S.ior,b.refractionRatio.value=S.refractionRatio),S.lightMap&&(b.lightMap.value=S.lightMap,b.lightMapIntensity.value=S.lightMapIntensity,i(S.lightMap,b.lightMapTransform)),S.aoMap&&(b.aoMap.value=S.aoMap,b.aoMapIntensity.value=S.aoMapIntensity,i(S.aoMap,b.aoMapTransform))}function d(b,S){b.diffuse.value.copy(S.color),b.opacity.value=S.opacity,S.map&&(b.map.value=S.map,i(S.map,b.mapTransform))}function p(b,S){b.dashSize.value=S.dashSize,b.totalSize.value=S.dashSize+S.gapSize,b.scale.value=S.scale}function m(b,S,N,O){b.diffuse.value.copy(S.color),b.opacity.value=S.opacity,b.size.value=S.size*N,b.scale.value=O*.5,S.map&&(b.map.value=S.map,i(S.map,b.uvTransform)),S.alphaMap&&(b.alphaMap.value=S.alphaMap,i(S.alphaMap,b.alphaMapTransform)),S.alphaTest>0&&(b.alphaTest.value=S.alphaTest)}function h(b,S){b.diffuse.value.copy(S.color),b.opacity.value=S.opacity,b.rotation.value=S.rotation,S.map&&(b.map.value=S.map,i(S.map,b.mapTransform)),S.alphaMap&&(b.alphaMap.value=S.alphaMap,i(S.alphaMap,b.alphaMapTransform)),S.alphaTest>0&&(b.alphaTest.value=S.alphaTest)}function g(b,S){b.specular.value.copy(S.specular),b.shininess.value=Math.max(S.shininess,1e-4)}function x(b,S){S.gradientMap&&(b.gradientMap.value=S.gradientMap)}function _(b,S){b.metalness.value=S.metalness,S.metalnessMap&&(b.metalnessMap.value=S.metalnessMap,i(S.metalnessMap,b.metalnessMapTransform)),b.roughness.value=S.roughness,S.roughnessMap&&(b.roughnessMap.value=S.roughnessMap,i(S.roughnessMap,b.roughnessMapTransform)),S.envMap&&(b.envMapIntensity.value=S.envMapIntensity)}function y(b,S,N){b.ior.value=S.ior,S.sheen>0&&(b.sheenColor.value.copy(S.sheenColor).multiplyScalar(S.sheen),b.sheenRoughness.value=S.sheenRoughness,S.sheenColorMap&&(b.sheenColorMap.value=S.sheenColorMap,i(S.sheenColorMap,b.sheenColorMapTransform)),S.sheenRoughnessMap&&(b.sheenRoughnessMap.value=S.sheenRoughnessMap,i(S.sheenRoughnessMap,b.sheenRoughnessMapTransform))),S.clearcoat>0&&(b.clearcoat.value=S.clearcoat,b.clearcoatRoughness.value=S.clearcoatRoughness,S.clearcoatMap&&(b.clearcoatMap.value=S.clearcoatMap,i(S.clearcoatMap,b.clearcoatMapTransform)),S.clearcoatRoughnessMap&&(b.clearcoatRoughnessMap.value=S.clearcoatRoughnessMap,i(S.clearcoatRoughnessMap,b.clearcoatRoughnessMapTransform)),S.clearcoatNormalMap&&(b.clearcoatNormalMap.value=S.clearcoatNormalMap,i(S.clearcoatNormalMap,b.clearcoatNormalMapTransform),b.clearcoatNormalScale.value.copy(S.clearcoatNormalScale),S.side===ni&&b.clearcoatNormalScale.value.negate())),S.dispersion>0&&(b.dispersion.value=S.dispersion),S.iridescence>0&&(b.iridescence.value=S.iridescence,b.iridescenceIOR.value=S.iridescenceIOR,b.iridescenceThicknessMinimum.value=S.iridescenceThicknessRange[0],b.iridescenceThicknessMaximum.value=S.iridescenceThicknessRange[1],S.iridescenceMap&&(b.iridescenceMap.value=S.iridescenceMap,i(S.iridescenceMap,b.iridescenceMapTransform)),S.iridescenceThicknessMap&&(b.iridescenceThicknessMap.value=S.iridescenceThicknessMap,i(S.iridescenceThicknessMap,b.iridescenceThicknessMapTransform))),S.transmission>0&&(b.transmission.value=S.transmission,b.transmissionSamplerMap.value=N.texture,b.transmissionSamplerSize.value.set(N.width,N.height),S.transmissionMap&&(b.transmissionMap.value=S.transmissionMap,i(S.transmissionMap,b.transmissionMapTransform)),b.thickness.value=S.thickness,S.thicknessMap&&(b.thicknessMap.value=S.thicknessMap,i(S.thicknessMap,b.thicknessMapTransform)),b.attenuationDistance.value=S.attenuationDistance,b.attenuationColor.value.copy(S.attenuationColor)),S.anisotropy>0&&(b.anisotropyVector.value.set(S.anisotropy*Math.cos(S.anisotropyRotation),S.anisotropy*Math.sin(S.anisotropyRotation)),S.anisotropyMap&&(b.anisotropyMap.value=S.anisotropyMap,i(S.anisotropyMap,b.anisotropyMapTransform))),b.specularIntensity.value=S.specularIntensity,b.specularColor.value.copy(S.specularColor),S.specularColorMap&&(b.specularColorMap.value=S.specularColorMap,i(S.specularColorMap,b.specularColorMapTransform)),S.specularIntensityMap&&(b.specularIntensityMap.value=S.specularIntensityMap,i(S.specularIntensityMap,b.specularIntensityMapTransform))}function M(b,S){S.matcap&&(b.matcap.value=S.matcap)}function A(b,S){const N=e.get(S).light;b.referencePosition.value.setFromMatrixPosition(N.matrixWorld),b.nearDistance.value=N.shadow.camera.near,b.farDistance.value=N.shadow.camera.far}return{refreshFogUniforms:s,refreshMaterialUniforms:l}}function JA(r,e,i,s){let l={},c={},d=[];const p=r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS);function m(N,O){const z=O.program;s.uniformBlockBinding(N,z)}function h(N,O){let z=l[N.id];z===void 0&&(M(N),z=g(N),l[N.id]=z,N.addEventListener("dispose",b));const k=O.program;s.updateUBOMapping(N,k);const L=e.render.frame;c[N.id]!==L&&(_(N),c[N.id]=L)}function g(N){const O=x();N.__bindingPointIndex=O;const z=r.createBuffer(),k=N.__size,L=N.usage;return r.bindBuffer(r.UNIFORM_BUFFER,z),r.bufferData(r.UNIFORM_BUFFER,k,L),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,O,z),z}function x(){for(let N=0;N<p;N++)if(d.indexOf(N)===-1)return d.push(N),N;return Ut("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function _(N){const O=l[N.id],z=N.uniforms,k=N.__cache;r.bindBuffer(r.UNIFORM_BUFFER,O);for(let L=0,H=z.length;L<H;L++){const T=Array.isArray(z[L])?z[L]:[z[L]];for(let I=0,Z=T.length;I<Z;I++){const G=T[I];if(y(G,L,I,k)===!0){const K=G.__offset,ue=Array.isArray(G.value)?G.value:[G.value];let pe=0;for(let F=0;F<ue.length;F++){const D=ue[F],P=A(D);typeof D=="number"||typeof D=="boolean"?(G.__data[0]=D,r.bufferSubData(r.UNIFORM_BUFFER,K+pe,G.__data)):D.isMatrix3?(G.__data[0]=D.elements[0],G.__data[1]=D.elements[1],G.__data[2]=D.elements[2],G.__data[3]=0,G.__data[4]=D.elements[3],G.__data[5]=D.elements[4],G.__data[6]=D.elements[5],G.__data[7]=0,G.__data[8]=D.elements[6],G.__data[9]=D.elements[7],G.__data[10]=D.elements[8],G.__data[11]=0):ArrayBuffer.isView(D)?G.__data.set(new D.constructor(D.buffer,D.byteOffset,G.__data.length)):(D.toArray(G.__data,pe),pe+=P.storage/Float32Array.BYTES_PER_ELEMENT)}r.bufferSubData(r.UNIFORM_BUFFER,K,G.__data)}}}r.bindBuffer(r.UNIFORM_BUFFER,null)}function y(N,O,z,k){const L=N.value,H=O+"_"+z;if(k[H]===void 0)return typeof L=="number"||typeof L=="boolean"?k[H]=L:ArrayBuffer.isView(L)?k[H]=L.slice():k[H]=L.clone(),!0;{const T=k[H];if(typeof L=="number"||typeof L=="boolean"){if(T!==L)return k[H]=L,!0}else{if(ArrayBuffer.isView(L))return!0;if(T.equals(L)===!1)return T.copy(L),!0}}return!1}function M(N){const O=N.uniforms;let z=0;const k=16;for(let H=0,T=O.length;H<T;H++){const I=Array.isArray(O[H])?O[H]:[O[H]];for(let Z=0,G=I.length;Z<G;Z++){const K=I[Z],ue=Array.isArray(K.value)?K.value:[K.value];for(let pe=0,F=ue.length;pe<F;pe++){const D=ue[pe],P=A(D),q=z%k,he=q%P.boundary,_e=q+he;z+=he,_e!==0&&k-_e<P.storage&&(z+=k-_e),K.__data=new Float32Array(P.storage/Float32Array.BYTES_PER_ELEMENT),K.__offset=z,z+=P.storage}}}const L=z%k;return L>0&&(z+=k-L),N.__size=z,N.__cache={},this}function A(N){const O={boundary:0,storage:0};return typeof N=="number"||typeof N=="boolean"?(O.boundary=4,O.storage=4):N.isVector2?(O.boundary=8,O.storage=8):N.isVector3||N.isColor?(O.boundary=16,O.storage=12):N.isVector4?(O.boundary=16,O.storage=16):N.isMatrix3?(O.boundary=48,O.storage=48):N.isMatrix4?(O.boundary=64,O.storage=64):N.isTexture?st("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(N)?(O.boundary=16,O.storage=N.byteLength):st("WebGLRenderer: Unsupported uniform value type.",N),O}function b(N){const O=N.target;O.removeEventListener("dispose",b);const z=d.indexOf(O.__bindingPointIndex);d.splice(z,1),r.deleteBuffer(l[O.id]),delete l[O.id],delete c[O.id]}function S(){for(const N in l)r.deleteBuffer(l[N]);d=[],l={},c={}}return{bind:m,update:h,dispose:S}}const $A=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let ki=null;function e2(){return ki===null&&(ki=new Pb($A,16,16,js,Ta),ki.name="DFG_LUT",ki.minFilter=Gn,ki.magFilter=Gn,ki.wrapS=ba,ki.wrapT=ba,ki.generateMipmaps=!1,ki.needsUpdate=!0),ki}class t2{constructor(e={}){const{canvas:i=fb(),context:s=null,depth:l=!0,stencil:c=!1,alpha:d=!1,antialias:p=!1,premultipliedAlpha:m=!0,preserveDrawingBuffer:h=!1,powerPreference:g="default",failIfMajorPerformanceCaveat:x=!1,reversedDepthBuffer:_=!1,outputBufferType:y=gi}=e;this.isWebGLRenderer=!0;let M;if(s!==null){if(typeof WebGLRenderingContext<"u"&&s instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");M=s.getContextAttributes().alpha}else M=d;const A=y,b=new Set([pp,hp,dp]),S=new Set([gi,Ki,rl,ol,up,fp]),N=new Uint32Array(4),O=new Int32Array(4),z=new ee;let k=null,L=null;const H=[],T=[];let I=null;this.domElement=i,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Yi,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const Z=this;let G=!1,K=null;this._outputColorSpace=pi;let ue=0,pe=0,F=null,D=-1,P=null;const q=new cn,he=new cn;let _e=null;const B=new ft(0);let Q=0,ve=i.width,Ae=i.height,Ce=1,ae=null,ye=null;const Me=new cn(0,0,ve,Ae),Ie=new cn(0,0,ve,Ae);let Ze=!1;const Ke=new xp;let Lt=!1,nt=!1;const dt=new rn,St=new ee,ct=new cn,$t={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let te=!1;function Fe(){return F===null?Ce:1}let j=s;function yt(C,Y){return i.getContext(C,Y)}try{const C={alpha:!0,depth:l,stencil:c,antialias:p,premultipliedAlpha:m,preserveDrawingBuffer:h,powerPreference:g,failIfMajorPerformanceCaveat:x};if("setAttribute"in i&&i.setAttribute("data-engine",`three.js r${lp}`),i.addEventListener("webglcontextlost",Ee,!1),i.addEventListener("webglcontextrestored",We,!1),i.addEventListener("webglcontextcreationerror",it,!1),j===null){const Y="webgl2";if(j=yt(Y,C),j===null)throw yt(Y)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(C){throw Ut("WebGLRenderer: "+C.message),C}let lt,Nt,we,Xt,U,E,$,xe,Te,Ne,Pe,ne,de,Oe,ze,Ue,De,rt,ot,_t,X,Re,me;function He(){lt=new eT(j),lt.init(),X=new XA(j,lt),Nt=new WE(j,lt,e,X),we=new kA(j,lt),Nt.reversedDepthBuffer&&_&&we.buffers.depth.setReversed(!0),Xt=new iT(j),U=new wA,E=new jA(j,lt,we,U,Nt,X,Xt),$=new $E(Z),xe=new oM(j),Re=new jE(j,xe),Te=new tT(j,xe,Xt,Re),Ne=new sT(j,Te,xe,Re,Xt),rt=new aT(j,Nt,E),ze=new qE(U),Pe=new CA(Z,$,lt,Nt,Re,ze),ne=new QA(Z,U),de=new NA,Oe=new FA(lt),De=new kE(Z,$,we,Ne,M,m),Ue=new VA(Z,Ne,Nt),me=new JA(j,Xt,Nt,we),ot=new XE(j,lt,Xt),_t=new nT(j,lt,Xt),Xt.programs=Pe.programs,Z.capabilities=Nt,Z.extensions=lt,Z.properties=U,Z.renderLists=de,Z.shadowMap=Ue,Z.state=we,Z.info=Xt}He(),A!==gi&&(I=new oT(A,i.width,i.height,l,c));const Le=new ZA(Z,j);this.xr=Le,this.getContext=function(){return j},this.getContextAttributes=function(){return j.getContextAttributes()},this.forceContextLoss=function(){const C=lt.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){const C=lt.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return Ce},this.setPixelRatio=function(C){C!==void 0&&(Ce=C,this.setSize(ve,Ae,!1))},this.getSize=function(C){return C.set(ve,Ae)},this.setSize=function(C,Y,le=!0){if(Le.isPresenting){st("WebGLRenderer: Can't change size while VR device is presenting.");return}ve=C,Ae=Y,i.width=Math.floor(C*Ce),i.height=Math.floor(Y*Ce),le===!0&&(i.style.width=C+"px",i.style.height=Y+"px"),I!==null&&I.setSize(i.width,i.height),this.setViewport(0,0,C,Y)},this.getDrawingBufferSize=function(C){return C.set(ve*Ce,Ae*Ce).floor()},this.setDrawingBufferSize=function(C,Y,le){ve=C,Ae=Y,Ce=le,i.width=Math.floor(C*le),i.height=Math.floor(Y*le),this.setViewport(0,0,C,Y)},this.setEffects=function(C){if(A===gi){Ut("THREE.WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(C){for(let Y=0;Y<C.length;Y++)if(C[Y].isOutputPass===!0){st("THREE.WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}I.setEffects(C||[])},this.getCurrentViewport=function(C){return C.copy(q)},this.getViewport=function(C){return C.copy(Me)},this.setViewport=function(C,Y,le,re){C.isVector4?Me.set(C.x,C.y,C.z,C.w):Me.set(C,Y,le,re),we.viewport(q.copy(Me).multiplyScalar(Ce).round())},this.getScissor=function(C){return C.copy(Ie)},this.setScissor=function(C,Y,le,re){C.isVector4?Ie.set(C.x,C.y,C.z,C.w):Ie.set(C,Y,le,re),we.scissor(he.copy(Ie).multiplyScalar(Ce).round())},this.getScissorTest=function(){return Ze},this.setScissorTest=function(C){we.setScissorTest(Ze=C)},this.setOpaqueSort=function(C){ae=C},this.setTransparentSort=function(C){ye=C},this.getClearColor=function(C){return C.copy(De.getClearColor())},this.setClearColor=function(){De.setClearColor(...arguments)},this.getClearAlpha=function(){return De.getClearAlpha()},this.setClearAlpha=function(){De.setClearAlpha(...arguments)},this.clear=function(C=!0,Y=!0,le=!0){let re=0;if(C){let oe=!1;if(F!==null){const Ge=F.texture.format;oe=b.has(Ge)}if(oe){const Ge=F.texture.type,je=S.has(Ge),Be=De.getClearColor(),qe=De.getClearAlpha(),Xe=Be.r,$e=Be.g,pt=Be.b;je?(N[0]=Xe,N[1]=$e,N[2]=pt,N[3]=qe,j.clearBufferuiv(j.COLOR,0,N)):(O[0]=Xe,O[1]=$e,O[2]=pt,O[3]=qe,j.clearBufferiv(j.COLOR,0,O))}else re|=j.COLOR_BUFFER_BIT}Y&&(re|=j.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),le&&(re|=j.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),re!==0&&j.clear(re)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(C){C.setRenderer(this),K=C},this.dispose=function(){i.removeEventListener("webglcontextlost",Ee,!1),i.removeEventListener("webglcontextrestored",We,!1),i.removeEventListener("webglcontextcreationerror",it,!1),De.dispose(),de.dispose(),Oe.dispose(),U.dispose(),$.dispose(),Ne.dispose(),Re.dispose(),me.dispose(),Pe.dispose(),Le.dispose(),Le.removeEventListener("sessionstart",$r),Le.removeEventListener("sessionend",eo),zn.stop()};function Ee(C){C.preventDefault(),E_("WebGLRenderer: Context Lost."),G=!0}function We(){E_("WebGLRenderer: Context Restored."),G=!1;const C=Xt.autoReset,Y=Ue.enabled,le=Ue.autoUpdate,re=Ue.needsUpdate,oe=Ue.type;He(),Xt.autoReset=C,Ue.enabled=Y,Ue.autoUpdate=le,Ue.needsUpdate=re,Ue.type=oe}function it(C){Ut("WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function Jt(C){const Y=C.target;Y.removeEventListener("dispose",Jt),Dt(Y)}function Dt(C){Vn(C),U.remove(C)}function Vn(C){const Y=U.get(C).programs;Y!==void 0&&(Y.forEach(function(le){Pe.releaseProgram(le)}),C.isShaderMaterial&&Pe.releaseShaderCache(C))}this.renderBufferDirect=function(C,Y,le,re,oe,Ge){Y===null&&(Y=$t);const je=oe.isMesh&&oe.matrixWorld.determinant()<0,Be=wa(C,Y,le,re,oe);we.setMaterial(re,je);let qe=le.index,Xe=1;if(re.wireframe===!0){if(qe=Te.getWireframeAttribute(le),qe===void 0)return;Xe=2}const $e=le.drawRange,pt=le.attributes.position;let Je=$e.start*Xe,Ot=($e.start+$e.count)*Xe;Ge!==null&&(Je=Math.max(Je,Ge.start*Xe),Ot=Math.min(Ot,(Ge.start+Ge.count)*Xe)),qe!==null?(Je=Math.max(Je,0),Ot=Math.min(Ot,qe.count)):pt!=null&&(Je=Math.max(Je,0),Ot=Math.min(Ot,pt.count));const nn=Ot-Je;if(nn<0||nn===1/0)return;Re.setup(oe,re,Be,le,qe);let Kt,It=ot;if(qe!==null&&(Kt=xe.get(qe),It=_t,It.setIndex(Kt)),oe.isMesh)re.wireframe===!0?(we.setLineWidth(re.wireframeLinewidth*Fe()),It.setMode(j.LINES)):It.setMode(j.TRIANGLES);else if(oe.isLine){let Ht=re.linewidth;Ht===void 0&&(Ht=1),we.setLineWidth(Ht*Fe()),oe.isLineSegments?It.setMode(j.LINES):oe.isLineLoop?It.setMode(j.LINE_LOOP):It.setMode(j.LINE_STRIP)}else oe.isPoints?It.setMode(j.POINTS):oe.isSprite&&It.setMode(j.TRIANGLES);if(oe.isBatchedMesh)if(lt.get("WEBGL_multi_draw"))It.renderMultiDraw(oe._multiDrawStarts,oe._multiDrawCounts,oe._multiDrawCount);else{const Ht=oe._multiDrawStarts,ke=oe._multiDrawCounts,Fn=oe._multiDrawCount,bt=qe?xe.get(qe).bytesPerElement:1,Sn=U.get(re).currentProgram.getUniforms();for(let ii=0;ii<Fn;ii++)Sn.setValue(j,"_gl_DrawID",ii),It.render(Ht[ii]/bt,ke[ii])}else if(oe.isInstancedMesh)It.renderInstances(Je,nn,oe.count);else if(le.isInstancedBufferGeometry){const Ht=le._maxInstanceCount!==void 0?le._maxInstanceCount:1/0,ke=Math.min(le.instanceCount,Ht);It.renderInstances(Je,nn,ke)}else It.render(Je,nn)};function kn(C,Y,le){C.transparent===!0&&C.side===Xi&&C.forceSinglePass===!1?(C.side=ni,C.needsUpdate=!0,qs(C,Y,le),C.side=fs,C.needsUpdate=!0,qs(C,Y,le),C.side=Xi):qs(C,Y,le)}this.compile=function(C,Y,le=null){le===null&&(le=C),L=Oe.get(le),L.init(Y),T.push(L),le.traverseVisible(function(oe){oe.isLight&&oe.layers.test(Y.layers)&&(L.pushLight(oe),oe.castShadow&&L.pushShadow(oe))}),C!==le&&C.traverseVisible(function(oe){oe.isLight&&oe.layers.test(Y.layers)&&(L.pushLight(oe),oe.castShadow&&L.pushShadow(oe))}),L.setupLights();const re=new Set;return C.traverse(function(oe){if(!(oe.isMesh||oe.isPoints||oe.isLine||oe.isSprite))return;const Ge=oe.material;if(Ge)if(Array.isArray(Ge))for(let je=0;je<Ge.length;je++){const Be=Ge[je];kn(Be,le,oe),re.add(Be)}else kn(Ge,le,oe),re.add(Ge)}),L=T.pop(),re},this.compileAsync=function(C,Y,le=null){const re=this.compile(C,Y,le);return new Promise(oe=>{function Ge(){if(re.forEach(function(je){U.get(je).currentProgram.isReady()&&re.delete(je)}),re.size===0){oe(C);return}setTimeout(Ge,10)}lt.get("KHR_parallel_shader_compile")!==null?Ge():setTimeout(Ge,10)})};let ms=null;function Jr(C){ms&&ms(C)}function $r(){zn.stop()}function eo(){zn.start()}const zn=new fv;zn.setAnimationLoop(Jr),typeof self<"u"&&zn.setContext(self),this.setAnimationLoop=function(C){ms=C,Le.setAnimationLoop(C),C===null?zn.stop():zn.start()},Le.addEventListener("sessionstart",$r),Le.addEventListener("sessionend",eo),this.render=function(C,Y){if(Y!==void 0&&Y.isCamera!==!0){Ut("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(G===!0)return;K!==null&&K.renderStart(C,Y);const le=Le.enabled===!0&&Le.isPresenting===!0,re=I!==null&&(F===null||le)&&I.begin(Z,F);if(C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),Y.parent===null&&Y.matrixWorldAutoUpdate===!0&&Y.updateMatrixWorld(),Le.enabled===!0&&Le.isPresenting===!0&&(I===null||I.isCompositing()===!1)&&(Le.cameraAutoUpdate===!0&&Le.updateCamera(Y),Y=Le.getCamera()),C.isScene===!0&&C.onBeforeRender(Z,C,Y,F),L=Oe.get(C,T.length),L.init(Y),L.state.textureUnits=E.getTextureUnits(),T.push(L),dt.multiplyMatrices(Y.projectionMatrix,Y.matrixWorldInverse),Ke.setFromProjectionMatrix(dt,qi,Y.reversedDepth),nt=this.localClippingEnabled,Lt=ze.init(this.clippingPlanes,nt),k=de.get(C,H.length),k.init(),H.push(k),Le.enabled===!0&&Le.isPresenting===!0){const je=Z.xr.getDepthSensingMesh();je!==null&&un(je,Y,-1/0,Z.sortObjects)}un(C,Y,0,Z.sortObjects),k.finish(),Z.sortObjects===!0&&k.sort(ae,ye),te=Le.enabled===!1||Le.isPresenting===!1||Le.hasDepthSensing()===!1,te&&De.addToRenderList(k,C),this.info.render.frame++,Lt===!0&&ze.beginShadows();const oe=L.state.shadowsArray;if(Ue.render(oe,C,Y),Lt===!0&&ze.endShadows(),this.info.autoReset===!0&&this.info.reset(),(re&&I.hasRenderPass())===!1){const je=k.opaque,Be=k.transmissive;if(L.setupLights(),Y.isArrayCamera){const qe=Y.cameras;if(Be.length>0)for(let Xe=0,$e=qe.length;Xe<$e;Xe++){const pt=qe[Xe];Ji(je,Be,C,pt)}te&&De.render(C);for(let Xe=0,$e=qe.length;Xe<$e;Xe++){const pt=qe[Xe];wn(k,C,pt,pt.viewport)}}else Be.length>0&&Ji(je,Be,C,Y),te&&De.render(C),wn(k,C,Y)}F!==null&&pe===0&&(E.updateMultisampleRenderTarget(F),E.updateRenderTargetMipmap(F)),re&&I.end(Z),C.isScene===!0&&C.onAfterRender(Z,C,Y),Re.resetDefaultState(),D=-1,P=null,T.pop(),T.length>0?(L=T[T.length-1],E.setTextureUnits(L.state.textureUnits),Lt===!0&&ze.setGlobalState(Z.clippingPlanes,L.state.camera)):L=null,H.pop(),H.length>0?k=H[H.length-1]:k=null,K!==null&&K.renderEnd()};function un(C,Y,le,re){if(C.visible===!1)return;if(C.layers.test(Y.layers)){if(C.isGroup)le=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(Y);else if(C.isLightProbeGrid)L.pushLightProbeGrid(C);else if(C.isLight)L.pushLight(C),C.castShadow&&L.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||Ke.intersectsSprite(C)){re&&ct.setFromMatrixPosition(C.matrixWorld).applyMatrix4(dt);const je=Ne.update(C),Be=C.material;Be.visible&&k.push(C,je,Be,le,ct.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||Ke.intersectsObject(C))){const je=Ne.update(C),Be=C.material;if(re&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),ct.copy(C.boundingSphere.center)):(je.boundingSphere===null&&je.computeBoundingSphere(),ct.copy(je.boundingSphere.center)),ct.applyMatrix4(C.matrixWorld).applyMatrix4(dt)),Array.isArray(Be)){const qe=je.groups;for(let Xe=0,$e=qe.length;Xe<$e;Xe++){const pt=qe[Xe],Je=Be[pt.materialIndex];Je&&Je.visible&&k.push(C,je,Je,le,ct.z,pt)}}else Be.visible&&k.push(C,je,Be,le,ct.z,null)}}const Ge=C.children;for(let je=0,Be=Ge.length;je<Be;je++)un(Ge[je],Y,le,re)}function wn(C,Y,le,re){const{opaque:oe,transmissive:Ge,transparent:je}=C;L.setupLightsView(le),Lt===!0&&ze.setGlobalState(Z.clippingPlanes,le),re&&we.viewport(q.copy(re)),oe.length>0&&Ra(oe,Y,le),Ge.length>0&&Ra(Ge,Y,le),je.length>0&&Ra(je,Y,le),we.buffers.depth.setTest(!0),we.buffers.depth.setMask(!0),we.buffers.color.setMask(!0),we.setPolygonOffset(!1)}function Ji(C,Y,le,re){if((le.isScene===!0?le.overrideMaterial:null)!==null)return;if(L.state.transmissionRenderTarget[re.id]===void 0){const Je=lt.has("EXT_color_buffer_half_float")||lt.has("EXT_color_buffer_float");L.state.transmissionRenderTarget[re.id]=new Zi(1,1,{generateMipmaps:!0,type:Je?Ta:gi,minFilter:Hs,samples:Math.max(4,Nt.samples),stencilBuffer:c,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:wt.workingColorSpace})}const Ge=L.state.transmissionRenderTarget[re.id],je=re.viewport||q;Ge.setSize(je.z*Z.transmissionResolutionScale,je.w*Z.transmissionResolutionScale);const Be=Z.getRenderTarget(),qe=Z.getActiveCubeFace(),Xe=Z.getActiveMipmapLevel();Z.setRenderTarget(Ge),Z.getClearColor(B),Q=Z.getClearAlpha(),Q<1&&Z.setClearColor(16777215,.5),Z.clear(),te&&De.render(le);const $e=Z.toneMapping;Z.toneMapping=Yi;const pt=re.viewport;if(re.viewport!==void 0&&(re.viewport=void 0),L.setupLightsView(re),Lt===!0&&ze.setGlobalState(Z.clippingPlanes,re),Ra(C,le,re),E.updateMultisampleRenderTarget(Ge),E.updateRenderTargetMipmap(Ge),lt.has("WEBGL_multisampled_render_to_texture")===!1){let Je=!1;for(let Ot=0,nn=Y.length;Ot<nn;Ot++){const Kt=Y[Ot],{object:It,geometry:Ht,material:ke,group:Fn}=Kt;if(ke.side===Xi&&It.layers.test(re.layers)){const bt=ke.side;ke.side=ni,ke.needsUpdate=!0,dl(It,le,re,Ht,ke,Fn),ke.side=bt,ke.needsUpdate=!0,Je=!0}}Je===!0&&(E.updateMultisampleRenderTarget(Ge),E.updateRenderTargetMipmap(Ge))}Z.setRenderTarget(Be,qe,Xe),Z.setClearColor(B,Q),pt!==void 0&&(re.viewport=pt),Z.toneMapping=$e}function Ra(C,Y,le){const re=Y.isScene===!0?Y.overrideMaterial:null;for(let oe=0,Ge=C.length;oe<Ge;oe++){const je=C[oe],{object:Be,geometry:qe,group:Xe}=je;let $e=je.material;$e.allowOverride===!0&&re!==null&&($e=re),Be.layers.test(le.layers)&&dl(Be,Y,le,qe,$e,Xe)}}function dl(C,Y,le,re,oe,Ge){C.onBeforeRender(Z,Y,le,re,oe,Ge),C.modelViewMatrix.multiplyMatrices(le.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),oe.onBeforeRender(Z,Y,le,re,C,Ge),oe.transparent===!0&&oe.side===Xi&&oe.forceSinglePass===!1?(oe.side=ni,oe.needsUpdate=!0,Z.renderBufferDirect(le,Y,re,oe,C,Ge),oe.side=fs,oe.needsUpdate=!0,Z.renderBufferDirect(le,Y,re,oe,C,Ge),oe.side=Xi):Z.renderBufferDirect(le,Y,re,oe,C,Ge),C.onAfterRender(Z,Y,le,re,oe,Ge)}function qs(C,Y,le){Y.isScene!==!0&&(Y=$t);const re=U.get(C),oe=L.state.lights,Ge=L.state.shadowsArray,je=oe.state.version,Be=Pe.getParameters(C,oe.state,Ge,Y,le,L.state.lightProbeGridArray),qe=Pe.getProgramCacheKey(Be);let Xe=re.programs;re.environment=C.isMeshStandardMaterial||C.isMeshLambertMaterial||C.isMeshPhongMaterial?Y.environment:null,re.fog=Y.fog;const $e=C.isMeshStandardMaterial||C.isMeshLambertMaterial&&!C.envMap||C.isMeshPhongMaterial&&!C.envMap;re.envMap=$.get(C.envMap||re.environment,$e),re.envMapRotation=re.environment!==null&&C.envMap===null?Y.environmentRotation:C.envMapRotation,Xe===void 0&&(C.addEventListener("dispose",Jt),Xe=new Map,re.programs=Xe);let pt=Xe.get(qe);if(pt!==void 0){if(re.currentProgram===pt&&re.lightsStateVersion===je)return Ca(C,Be),pt}else Be.uniforms=Pe.getUniforms(C),K!==null&&C.isNodeMaterial&&K.build(C,le,Be),C.onBeforeCompile(Be,Z),pt=Pe.acquireProgram(Be,qe),Xe.set(qe,pt),re.uniforms=Be.uniforms;const Je=re.uniforms;return(!C.isShaderMaterial&&!C.isRawShaderMaterial||C.clipping===!0)&&(Je.clippingPlanes=ze.uniform),Ca(C,Be),re.needsLights=gs(C),re.lightsStateVersion=je,re.needsLights&&(Je.ambientLightColor.value=oe.state.ambient,Je.lightProbe.value=oe.state.probe,Je.directionalLights.value=oe.state.directional,Je.directionalLightShadows.value=oe.state.directionalShadow,Je.spotLights.value=oe.state.spot,Je.spotLightShadows.value=oe.state.spotShadow,Je.rectAreaLights.value=oe.state.rectArea,Je.ltc_1.value=oe.state.rectAreaLTC1,Je.ltc_2.value=oe.state.rectAreaLTC2,Je.pointLights.value=oe.state.point,Je.pointLightShadows.value=oe.state.pointShadow,Je.hemisphereLights.value=oe.state.hemi,Je.directionalShadowMatrix.value=oe.state.directionalShadowMatrix,Je.spotLightMatrix.value=oe.state.spotLightMatrix,Je.spotLightMap.value=oe.state.spotLightMap,Je.pointShadowMatrix.value=oe.state.pointShadowMatrix),re.lightProbeGrid=L.state.lightProbeGridArray.length>0,re.currentProgram=pt,re.uniformsList=null,pt}function to(C){if(C.uniformsList===null){const Y=C.currentProgram.getUniforms();C.uniformsList=su.seqWithValue(Y.seq,C.uniforms)}return C.uniformsList}function Ca(C,Y){const le=U.get(C);le.outputColorSpace=Y.outputColorSpace,le.batching=Y.batching,le.batchingColor=Y.batchingColor,le.instancing=Y.instancing,le.instancingColor=Y.instancingColor,le.instancingMorph=Y.instancingMorph,le.skinning=Y.skinning,le.morphTargets=Y.morphTargets,le.morphNormals=Y.morphNormals,le.morphColors=Y.morphColors,le.morphTargetsCount=Y.morphTargetsCount,le.numClippingPlanes=Y.numClippingPlanes,le.numIntersection=Y.numClipIntersection,le.vertexAlphas=Y.vertexAlphas,le.vertexTangents=Y.vertexTangents,le.toneMapping=Y.toneMapping}function no(C,Y){if(C.length===0)return null;if(C.length===1)return C[0].texture!==null?C[0]:null;z.setFromMatrixPosition(Y.matrixWorld);for(let le=0,re=C.length;le<re;le++){const oe=C[le];if(oe.texture!==null&&oe.boundingBox.containsPoint(z))return oe}return null}function wa(C,Y,le,re,oe){Y.isScene!==!0&&(Y=$t),E.resetTextureUnits();const Ge=Y.fog,je=re.isMeshStandardMaterial||re.isMeshLambertMaterial||re.isMeshPhongMaterial?Y.environment:null,Be=F===null?Z.outputColorSpace:F.isXRRenderTarget===!0?F.texture.colorSpace:wt.workingColorSpace,qe=re.isMeshStandardMaterial||re.isMeshLambertMaterial&&!re.envMap||re.isMeshPhongMaterial&&!re.envMap,Xe=$.get(re.envMap||je,qe),$e=re.vertexColors===!0&&!!le.attributes.color&&le.attributes.color.itemSize===4,pt=!!le.attributes.tangent&&(!!re.normalMap||re.anisotropy>0),Je=!!le.morphAttributes.position,Ot=!!le.morphAttributes.normal,nn=!!le.morphAttributes.color;let Kt=Yi;re.toneMapped&&(F===null||F.isXRRenderTarget===!0)&&(Kt=Z.toneMapping);const It=le.morphAttributes.position||le.morphAttributes.normal||le.morphAttributes.color,Ht=It!==void 0?It.length:0,ke=U.get(re),Fn=L.state.lights;if(Lt===!0&&(nt===!0||C!==P)){const Bt=C===P&&re.id===D;ze.setState(re,C,Bt)}let bt=!1;re.version===ke.__version?(ke.needsLights&&ke.lightsStateVersion!==Fn.state.version||ke.outputColorSpace!==Be||oe.isBatchedMesh&&ke.batching===!1||!oe.isBatchedMesh&&ke.batching===!0||oe.isBatchedMesh&&ke.batchingColor===!0&&oe.colorTexture===null||oe.isBatchedMesh&&ke.batchingColor===!1&&oe.colorTexture!==null||oe.isInstancedMesh&&ke.instancing===!1||!oe.isInstancedMesh&&ke.instancing===!0||oe.isSkinnedMesh&&ke.skinning===!1||!oe.isSkinnedMesh&&ke.skinning===!0||oe.isInstancedMesh&&ke.instancingColor===!0&&oe.instanceColor===null||oe.isInstancedMesh&&ke.instancingColor===!1&&oe.instanceColor!==null||oe.isInstancedMesh&&ke.instancingMorph===!0&&oe.morphTexture===null||oe.isInstancedMesh&&ke.instancingMorph===!1&&oe.morphTexture!==null||ke.envMap!==Xe||re.fog===!0&&ke.fog!==Ge||ke.numClippingPlanes!==void 0&&(ke.numClippingPlanes!==ze.numPlanes||ke.numIntersection!==ze.numIntersection)||ke.vertexAlphas!==$e||ke.vertexTangents!==pt||ke.morphTargets!==Je||ke.morphNormals!==Ot||ke.morphColors!==nn||ke.toneMapping!==Kt||ke.morphTargetsCount!==Ht||!!ke.lightProbeGrid!=L.state.lightProbeGridArray.length>0)&&(bt=!0):(bt=!0,ke.__version=re.version);let Sn=ke.currentProgram;bt===!0&&(Sn=qs(re,Y,oe),K&&re.isNodeMaterial&&K.onUpdateProgram(re,Sn,ke));let ii=!1,Ri=!1,ai=!1;const Gt=Sn.getUniforms(),an=ke.uniforms;if(we.useProgram(Sn.program)&&(ii=!0,Ri=!0,ai=!0),re.id!==D&&(D=re.id,Ri=!0),ke.needsLights){const Bt=no(L.state.lightProbeGridArray,oe);ke.lightProbeGrid!==Bt&&(ke.lightProbeGrid=Bt,Ri=!0)}if(ii||P!==C){we.buffers.depth.getReversed()&&C.reversedDepth!==!0&&(C._reversedDepth=!0,C.updateProjectionMatrix()),Gt.setValue(j,"projectionMatrix",C.projectionMatrix),Gt.setValue(j,"viewMatrix",C.matrixWorldInverse);const Fi=Gt.map.cameraPosition;Fi!==void 0&&Fi.setValue(j,St.setFromMatrixPosition(C.matrixWorld)),Nt.logarithmicDepthBuffer&&Gt.setValue(j,"logDepthBufFC",2/(Math.log(C.far+1)/Math.LN2)),(re.isMeshPhongMaterial||re.isMeshToonMaterial||re.isMeshLambertMaterial||re.isMeshBasicMaterial||re.isMeshStandardMaterial||re.isShaderMaterial)&&Gt.setValue(j,"isOrthographic",C.isOrthographicCamera===!0),P!==C&&(P=C,Ri=!0,ai=!0)}if(ke.needsLights&&(Fn.state.directionalShadowMap.length>0&&Gt.setValue(j,"directionalShadowMap",Fn.state.directionalShadowMap,E),Fn.state.spotShadowMap.length>0&&Gt.setValue(j,"spotShadowMap",Fn.state.spotShadowMap,E),Fn.state.pointShadowMap.length>0&&Gt.setValue(j,"pointShadowMap",Fn.state.pointShadowMap,E)),oe.isSkinnedMesh){Gt.setOptional(j,oe,"bindMatrix"),Gt.setOptional(j,oe,"bindMatrixInverse");const Bt=oe.skeleton;Bt&&(Bt.boneTexture===null&&Bt.computeBoneTexture(),Gt.setValue(j,"boneTexture",Bt.boneTexture,E))}oe.isBatchedMesh&&(Gt.setOptional(j,oe,"batchingTexture"),Gt.setValue(j,"batchingTexture",oe._matricesTexture,E),Gt.setOptional(j,oe,"batchingIdTexture"),Gt.setValue(j,"batchingIdTexture",oe._indirectTexture,E),Gt.setOptional(j,oe,"batchingColorTexture"),oe._colorsTexture!==null&&Gt.setValue(j,"batchingColorTexture",oe._colorsTexture,E));const Ci=le.morphAttributes;if((Ci.position!==void 0||Ci.normal!==void 0||Ci.color!==void 0)&&rt.update(oe,le,Sn),(Ri||ke.receiveShadow!==oe.receiveShadow)&&(ke.receiveShadow=oe.receiveShadow,Gt.setValue(j,"receiveShadow",oe.receiveShadow)),(re.isMeshStandardMaterial||re.isMeshLambertMaterial||re.isMeshPhongMaterial)&&re.envMap===null&&Y.environment!==null&&(an.envMapIntensity.value=Y.environmentIntensity),an.dfgLUT!==void 0&&(an.dfgLUT.value=e2()),Ri){if(Gt.setValue(j,"toneMappingExposure",Z.toneMappingExposure),ke.needsLights&&Da(an,ai),Ge&&re.fog===!0&&ne.refreshFogUniforms(an,Ge),ne.refreshMaterialUniforms(an,re,Ce,Ae,L.state.transmissionRenderTarget[C.id]),ke.needsLights&&ke.lightProbeGrid){const Bt=ke.lightProbeGrid;an.probesSH.value=Bt.texture,an.probesMin.value.copy(Bt.boundingBox.min),an.probesMax.value.copy(Bt.boundingBox.max),an.probesResolution.value.copy(Bt.resolution)}su.upload(j,to(ke),an,E)}if(re.isShaderMaterial&&re.uniformsNeedUpdate===!0&&(su.upload(j,to(ke),an,E),re.uniformsNeedUpdate=!1),re.isSpriteMaterial&&Gt.setValue(j,"center",oe.center),Gt.setValue(j,"modelViewMatrix",oe.modelViewMatrix),Gt.setValue(j,"normalMatrix",oe.normalMatrix),Gt.setValue(j,"modelMatrix",oe.matrixWorld),re.uniformsGroups!==void 0){const Bt=re.uniformsGroups;for(let Fi=0,Ua=Bt.length;Fi<Ua;Fi++){const _s=Bt[Fi];me.update(_s,Sn),me.bind(_s,Sn)}}return Sn}function Da(C,Y){C.ambientLightColor.needsUpdate=Y,C.lightProbe.needsUpdate=Y,C.directionalLights.needsUpdate=Y,C.directionalLightShadows.needsUpdate=Y,C.pointLights.needsUpdate=Y,C.pointLightShadows.needsUpdate=Y,C.spotLights.needsUpdate=Y,C.spotLightShadows.needsUpdate=Y,C.rectAreaLights.needsUpdate=Y,C.hemisphereLights.needsUpdate=Y}function gs(C){return C.isMeshLambertMaterial||C.isMeshToonMaterial||C.isMeshPhongMaterial||C.isMeshStandardMaterial||C.isShadowMaterial||C.isShaderMaterial&&C.lights===!0}this.getActiveCubeFace=function(){return ue},this.getActiveMipmapLevel=function(){return pe},this.getRenderTarget=function(){return F},this.setRenderTargetTextures=function(C,Y,le){const re=U.get(C);re.__autoAllocateDepthBuffer=C.resolveDepthBuffer===!1,re.__autoAllocateDepthBuffer===!1&&(re.__useRenderToTexture=!1),U.get(C.texture).__webglTexture=Y,U.get(C.depthTexture).__webglTexture=re.__autoAllocateDepthBuffer?void 0:le,re.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(C,Y){const le=U.get(C);le.__webglFramebuffer=Y,le.__useDefaultFramebuffer=Y===void 0};const Na=j.createFramebuffer();this.setRenderTarget=function(C,Y=0,le=0){F=C,ue=Y,pe=le;let re=null,oe=!1,Ge=!1;if(C){const Be=U.get(C);if(Be.__useDefaultFramebuffer!==void 0){we.bindFramebuffer(j.FRAMEBUFFER,Be.__webglFramebuffer),q.copy(C.viewport),he.copy(C.scissor),_e=C.scissorTest,we.viewport(q),we.scissor(he),we.setScissorTest(_e),D=-1;return}else if(Be.__webglFramebuffer===void 0)E.setupRenderTarget(C);else if(Be.__hasExternalTextures)E.rebindTextures(C,U.get(C.texture).__webglTexture,U.get(C.depthTexture).__webglTexture);else if(C.depthBuffer){const $e=C.depthTexture;if(Be.__boundDepthTexture!==$e){if($e!==null&&U.has($e)&&(C.width!==$e.image.width||C.height!==$e.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");E.setupDepthRenderbuffer(C)}}const qe=C.texture;(qe.isData3DTexture||qe.isDataArrayTexture||qe.isCompressedArrayTexture)&&(Ge=!0);const Xe=U.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(Array.isArray(Xe[Y])?re=Xe[Y][le]:re=Xe[Y],oe=!0):C.samples>0&&E.useMultisampledRTT(C)===!1?re=U.get(C).__webglMultisampledFramebuffer:Array.isArray(Xe)?re=Xe[le]:re=Xe,q.copy(C.viewport),he.copy(C.scissor),_e=C.scissorTest}else q.copy(Me).multiplyScalar(Ce).floor(),he.copy(Ie).multiplyScalar(Ce).floor(),_e=Ze;if(le!==0&&(re=Na),we.bindFramebuffer(j.FRAMEBUFFER,re)&&we.drawBuffers(C,re),we.viewport(q),we.scissor(he),we.setScissorTest(_e),oe){const Be=U.get(C.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_CUBE_MAP_POSITIVE_X+Y,Be.__webglTexture,le)}else if(Ge){const Be=Y;for(let qe=0;qe<C.textures.length;qe++){const Xe=U.get(C.textures[qe]);j.framebufferTextureLayer(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0+qe,Xe.__webglTexture,le,Be)}}else if(C!==null&&le!==0){const Be=U.get(C.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,Be.__webglTexture,le)}D=-1},this.readRenderTargetPixels=function(C,Y,le,re,oe,Ge,je,Be=0){if(!(C&&C.isWebGLRenderTarget)){Ut("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let qe=U.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&je!==void 0&&(qe=qe[je]),qe){we.bindFramebuffer(j.FRAMEBUFFER,qe);try{const Xe=C.textures[Be],$e=Xe.format,pt=Xe.type;if(C.textures.length>1&&j.readBuffer(j.COLOR_ATTACHMENT0+Be),!Nt.textureFormatReadable($e)){Ut("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Nt.textureTypeReadable(pt)){Ut("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}Y>=0&&Y<=C.width-re&&le>=0&&le<=C.height-oe&&j.readPixels(Y,le,re,oe,X.convert($e),X.convert(pt),Ge)}finally{const Xe=F!==null?U.get(F).__webglFramebuffer:null;we.bindFramebuffer(j.FRAMEBUFFER,Xe)}}},this.readRenderTargetPixelsAsync=async function(C,Y,le,re,oe,Ge,je,Be=0){if(!(C&&C.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let qe=U.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&je!==void 0&&(qe=qe[je]),qe)if(Y>=0&&Y<=C.width-re&&le>=0&&le<=C.height-oe){we.bindFramebuffer(j.FRAMEBUFFER,qe);const Xe=C.textures[Be],$e=Xe.format,pt=Xe.type;if(C.textures.length>1&&j.readBuffer(j.COLOR_ATTACHMENT0+Be),!Nt.textureFormatReadable($e))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Nt.textureTypeReadable(pt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Je=j.createBuffer();j.bindBuffer(j.PIXEL_PACK_BUFFER,Je),j.bufferData(j.PIXEL_PACK_BUFFER,Ge.byteLength,j.STREAM_READ),j.readPixels(Y,le,re,oe,X.convert($e),X.convert(pt),0);const Ot=F!==null?U.get(F).__webglFramebuffer:null;we.bindFramebuffer(j.FRAMEBUFFER,Ot);const nn=j.fenceSync(j.SYNC_GPU_COMMANDS_COMPLETE,0);return j.flush(),await db(j,nn,4),j.bindBuffer(j.PIXEL_PACK_BUFFER,Je),j.getBufferSubData(j.PIXEL_PACK_BUFFER,0,Ge),j.deleteBuffer(Je),j.deleteSync(nn),Ge}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(C,Y=null,le=0){const re=Math.pow(2,-le),oe=Math.floor(C.image.width*re),Ge=Math.floor(C.image.height*re),je=Y!==null?Y.x:0,Be=Y!==null?Y.y:0;E.setTexture2D(C,0),j.copyTexSubImage2D(j.TEXTURE_2D,le,0,0,je,Be,oe,Ge),we.unbindTexture()};const pn=j.createFramebuffer(),hl=j.createFramebuffer();this.copyTextureToTexture=function(C,Y,le=null,re=null,oe=0,Ge=0){let je,Be,qe,Xe,$e,pt,Je,Ot,nn;const Kt=C.isCompressedTexture?C.mipmaps[Ge]:C.image;if(le!==null)je=le.max.x-le.min.x,Be=le.max.y-le.min.y,qe=le.isBox3?le.max.z-le.min.z:1,Xe=le.min.x,$e=le.min.y,pt=le.isBox3?le.min.z:0;else{const an=Math.pow(2,-oe);je=Math.floor(Kt.width*an),Be=Math.floor(Kt.height*an),C.isDataArrayTexture?qe=Kt.depth:C.isData3DTexture?qe=Math.floor(Kt.depth*an):qe=1,Xe=0,$e=0,pt=0}re!==null?(Je=re.x,Ot=re.y,nn=re.z):(Je=0,Ot=0,nn=0);const It=X.convert(Y.format),Ht=X.convert(Y.type);let ke;Y.isData3DTexture?(E.setTexture3D(Y,0),ke=j.TEXTURE_3D):Y.isDataArrayTexture||Y.isCompressedArrayTexture?(E.setTexture2DArray(Y,0),ke=j.TEXTURE_2D_ARRAY):(E.setTexture2D(Y,0),ke=j.TEXTURE_2D),we.activeTexture(j.TEXTURE0),we.pixelStorei(j.UNPACK_FLIP_Y_WEBGL,Y.flipY),we.pixelStorei(j.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Y.premultiplyAlpha),we.pixelStorei(j.UNPACK_ALIGNMENT,Y.unpackAlignment);const Fn=we.getParameter(j.UNPACK_ROW_LENGTH),bt=we.getParameter(j.UNPACK_IMAGE_HEIGHT),Sn=we.getParameter(j.UNPACK_SKIP_PIXELS),ii=we.getParameter(j.UNPACK_SKIP_ROWS),Ri=we.getParameter(j.UNPACK_SKIP_IMAGES);we.pixelStorei(j.UNPACK_ROW_LENGTH,Kt.width),we.pixelStorei(j.UNPACK_IMAGE_HEIGHT,Kt.height),we.pixelStorei(j.UNPACK_SKIP_PIXELS,Xe),we.pixelStorei(j.UNPACK_SKIP_ROWS,$e),we.pixelStorei(j.UNPACK_SKIP_IMAGES,pt);const ai=C.isDataArrayTexture||C.isData3DTexture,Gt=Y.isDataArrayTexture||Y.isData3DTexture;if(C.isDepthTexture){const an=U.get(C),Ci=U.get(Y),Bt=U.get(an.__renderTarget),Fi=U.get(Ci.__renderTarget);we.bindFramebuffer(j.READ_FRAMEBUFFER,Bt.__webglFramebuffer),we.bindFramebuffer(j.DRAW_FRAMEBUFFER,Fi.__webglFramebuffer);for(let Ua=0;Ua<qe;Ua++)ai&&(j.framebufferTextureLayer(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,U.get(C).__webglTexture,oe,pt+Ua),j.framebufferTextureLayer(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,U.get(Y).__webglTexture,Ge,nn+Ua)),j.blitFramebuffer(Xe,$e,je,Be,Je,Ot,je,Be,j.DEPTH_BUFFER_BIT,j.NEAREST);we.bindFramebuffer(j.READ_FRAMEBUFFER,null),we.bindFramebuffer(j.DRAW_FRAMEBUFFER,null)}else if(oe!==0||C.isRenderTargetTexture||U.has(C)){const an=U.get(C),Ci=U.get(Y);we.bindFramebuffer(j.READ_FRAMEBUFFER,pn),we.bindFramebuffer(j.DRAW_FRAMEBUFFER,hl);for(let Bt=0;Bt<qe;Bt++)ai?j.framebufferTextureLayer(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,an.__webglTexture,oe,pt+Bt):j.framebufferTexture2D(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,an.__webglTexture,oe),Gt?j.framebufferTextureLayer(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,Ci.__webglTexture,Ge,nn+Bt):j.framebufferTexture2D(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,Ci.__webglTexture,Ge),oe!==0?j.blitFramebuffer(Xe,$e,je,Be,Je,Ot,je,Be,j.COLOR_BUFFER_BIT,j.NEAREST):Gt?j.copyTexSubImage3D(ke,Ge,Je,Ot,nn+Bt,Xe,$e,je,Be):j.copyTexSubImage2D(ke,Ge,Je,Ot,Xe,$e,je,Be);we.bindFramebuffer(j.READ_FRAMEBUFFER,null),we.bindFramebuffer(j.DRAW_FRAMEBUFFER,null)}else Gt?C.isDataTexture||C.isData3DTexture?j.texSubImage3D(ke,Ge,Je,Ot,nn,je,Be,qe,It,Ht,Kt.data):Y.isCompressedArrayTexture?j.compressedTexSubImage3D(ke,Ge,Je,Ot,nn,je,Be,qe,It,Kt.data):j.texSubImage3D(ke,Ge,Je,Ot,nn,je,Be,qe,It,Ht,Kt):C.isDataTexture?j.texSubImage2D(j.TEXTURE_2D,Ge,Je,Ot,je,Be,It,Ht,Kt.data):C.isCompressedTexture?j.compressedTexSubImage2D(j.TEXTURE_2D,Ge,Je,Ot,Kt.width,Kt.height,It,Kt.data):j.texSubImage2D(j.TEXTURE_2D,Ge,Je,Ot,je,Be,It,Ht,Kt);we.pixelStorei(j.UNPACK_ROW_LENGTH,Fn),we.pixelStorei(j.UNPACK_IMAGE_HEIGHT,bt),we.pixelStorei(j.UNPACK_SKIP_PIXELS,Sn),we.pixelStorei(j.UNPACK_SKIP_ROWS,ii),we.pixelStorei(j.UNPACK_SKIP_IMAGES,Ri),Ge===0&&Y.generateMipmaps&&j.generateMipmap(ke),we.unbindTexture()},this.initRenderTarget=function(C){U.get(C).__webglFramebuffer===void 0&&E.setupRenderTarget(C)},this.initTexture=function(C){C.isCubeTexture?E.setTextureCube(C,0):C.isData3DTexture?E.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?E.setTexture2DArray(C,0):E.setTexture2D(C,0),we.unbindTexture()},this.resetState=function(){ue=0,pe=0,F=null,we.reset(),Re.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return qi}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const i=this.getContext();i.drawingBufferColorSpace=wt._getDrawingBufferColorSpace(e),i.unpackColorSpace=wt._getUnpackColorSpace()}}const Rx={type:"change"},Sp={type:"start"},vv={type:"end"},$c=new mu,Cx=new ls,n2=Math.cos(70*mb.DEG2RAD),bn=new ee,ti=2*Math.PI,Zt={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},fh=1e-6;class i2 extends sM{constructor(e,i=null){super(e,i),this.state=Zt.NONE,this.target=new ee,this.cursor=new ee,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Gr.ROTATE,MIDDLE:Gr.DOLLY,RIGHT:Gr.PAN},this.touches={ONE:Hr.ROTATE,TWO:Hr.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._cursorStyle="auto",this._domElementKeyEvents=null,this._lastPosition=new ee,this._lastQuaternion=new ds,this._lastTargetPosition=new ee,this._quat=new ds().setFromUnitVectors(e.up,new ee(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new ex,this._sphericalDelta=new ex,this._scale=1,this._panOffset=new ee,this._rotateStart=new gt,this._rotateEnd=new gt,this._rotateDelta=new gt,this._panStart=new gt,this._panEnd=new gt,this._panDelta=new gt,this._dollyStart=new gt,this._dollyEnd=new gt,this._dollyDelta=new gt,this._dollyDirection=new ee,this._mouse=new gt,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=s2.bind(this),this._onPointerDown=a2.bind(this),this._onPointerUp=r2.bind(this),this._onContextMenu=h2.bind(this),this._onMouseWheel=c2.bind(this),this._onKeyDown=u2.bind(this),this._onTouchStart=f2.bind(this),this._onTouchMove=d2.bind(this),this._onMouseDown=o2.bind(this),this._onMouseMove=l2.bind(this),this._interceptControlDown=p2.bind(this),this._interceptControlUp=m2.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}set cursorStyle(e){this._cursorStyle=e,e==="grab"?this.domElement.style.cursor="grab":this.domElement.style.cursor="auto"}get cursorStyle(){return this._cursorStyle}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction=""}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Rx),this.update(),this.state=Zt.NONE}pan(e,i){this._pan(e,i),this.update()}dollyIn(e){this._dollyIn(e),this.update()}dollyOut(e){this._dollyOut(e),this.update()}rotateLeft(e){this._rotateLeft(e),this.update()}rotateUp(e){this._rotateUp(e),this.update()}update(e=null){const i=this.object.position;bn.copy(i).sub(this.target),bn.applyQuaternion(this._quat),this._spherical.setFromVector3(bn),this.autoRotate&&this.state===Zt.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let s=this.minAzimuthAngle,l=this.maxAzimuthAngle;isFinite(s)&&isFinite(l)&&(s<-Math.PI?s+=ti:s>Math.PI&&(s-=ti),l<-Math.PI?l+=ti:l>Math.PI&&(l-=ti),s<=l?this._spherical.theta=Math.max(s,Math.min(l,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(s+l)/2?Math.max(s,this._spherical.theta):Math.min(l,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let c=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const d=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),c=d!=this._spherical.radius}if(bn.setFromSpherical(this._spherical),bn.applyQuaternion(this._quatInverse),i.copy(this.target).add(bn),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let d=null;if(this.object.isPerspectiveCamera){const p=bn.length();d=this._clampDistance(p*this._scale);const m=p-d;this.object.position.addScaledVector(this._dollyDirection,m),this.object.updateMatrixWorld(),c=!!m}else if(this.object.isOrthographicCamera){const p=new ee(this._mouse.x,this._mouse.y,0);p.unproject(this.object);const m=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),c=m!==this.object.zoom;const h=new ee(this._mouse.x,this._mouse.y,0);h.unproject(this.object),this.object.position.sub(h).add(p),this.object.updateMatrixWorld(),d=bn.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;d!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(d).add(this.object.position):($c.origin.copy(this.object.position),$c.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot($c.direction))<n2?this.object.lookAt(this.target):(Cx.setFromNormalAndCoplanarPoint(this.object.up,this.target),$c.intersectPlane(Cx,this.target))))}else if(this.object.isOrthographicCamera){const d=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),d!==this.object.zoom&&(this.object.updateProjectionMatrix(),c=!0)}return this._scale=1,this._performCursorZoom=!1,c||this._lastPosition.distanceToSquared(this.object.position)>fh||8*(1-this._lastQuaternion.dot(this.object.quaternion))>fh||this._lastTargetPosition.distanceToSquared(this.target)>fh?(this.dispatchEvent(Rx),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?ti/60*this.autoRotateSpeed*e:ti/60/60*this.autoRotateSpeed}_getZoomScale(e){const i=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*i)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,i){bn.setFromMatrixColumn(i,0),bn.multiplyScalar(-e),this._panOffset.add(bn)}_panUp(e,i){this.screenSpacePanning===!0?bn.setFromMatrixColumn(i,1):(bn.setFromMatrixColumn(i,0),bn.crossVectors(this.object.up,bn)),bn.multiplyScalar(e),this._panOffset.add(bn)}_pan(e,i){const s=this.domElement;if(this.object.isPerspectiveCamera){const l=this.object.position;bn.copy(l).sub(this.target);let c=bn.length();c*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*c/s.clientHeight,this.object.matrix),this._panUp(2*i*c/s.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/s.clientWidth,this.object.matrix),this._panUp(i*(this.object.top-this.object.bottom)/this.object.zoom/s.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,i){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const s=this.domElement.getBoundingClientRect(),l=e-s.left,c=i-s.top,d=s.width,p=s.height;this._mouse.x=l/d*2-1,this._mouse.y=-(c/p)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const i=this.domElement;this._rotateLeft(ti*this._rotateDelta.x/i.clientHeight),this._rotateUp(ti*this._rotateDelta.y/i.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let i=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(ti*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),i=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-ti*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),i=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(ti*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),i=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-ti*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),i=!0;break}i&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{const i=this._getSecondPointerPosition(e),s=.5*(e.pageX+i.x),l=.5*(e.pageY+i.y);this._rotateStart.set(s,l)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{const i=this._getSecondPointerPosition(e),s=.5*(e.pageX+i.x),l=.5*(e.pageY+i.y);this._panStart.set(s,l)}}_handleTouchStartDolly(e){const i=this._getSecondPointerPosition(e),s=e.pageX-i.x,l=e.pageY-i.y,c=Math.sqrt(s*s+l*l);this._dollyStart.set(0,c)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{const s=this._getSecondPointerPosition(e),l=.5*(e.pageX+s.x),c=.5*(e.pageY+s.y);this._rotateEnd.set(l,c)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const i=this.domElement;this._rotateLeft(ti*this._rotateDelta.x/i.clientHeight),this._rotateUp(ti*this._rotateDelta.y/i.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{const i=this._getSecondPointerPosition(e),s=.5*(e.pageX+i.x),l=.5*(e.pageY+i.y);this._panEnd.set(s,l)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){const i=this._getSecondPointerPosition(e),s=e.pageX-i.x,l=e.pageY-i.y,c=Math.sqrt(s*s+l*l);this._dollyEnd.set(0,c),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const d=(e.pageX+i.x)*.5,p=(e.pageY+i.y)*.5;this._updateZoomParameters(d,p)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let i=0;i<this._pointers.length;i++)if(this._pointers[i]==e.pointerId){this._pointers.splice(i,1);return}}_isTrackingPointer(e){for(let i=0;i<this._pointers.length;i++)if(this._pointers[i]==e.pointerId)return!0;return!1}_trackPointer(e){let i=this._pointerPositions[e.pointerId];i===void 0&&(i=new gt,this._pointerPositions[e.pointerId]=i),i.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){const i=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[i]}_customWheelEvent(e){const i=e.deltaMode,s={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(i){case 1:s.deltaY*=16;break;case 2:s.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(s.deltaY*=10),s}}function a2(r){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(r.pointerId),this.domElement.ownerDocument.addEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(r)&&(this._addPointer(r),r.pointerType==="touch"?this._onTouchStart(r):this._onMouseDown(r),this._cursorStyle==="grab"&&(this.domElement.style.cursor="grabbing")))}function s2(r){this.enabled!==!1&&(r.pointerType==="touch"?this._onTouchMove(r):this._onMouseMove(r))}function r2(r){switch(this._removePointer(r),this._pointers.length){case 0:this.domElement.releasePointerCapture(r.pointerId),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(vv),this.state=Zt.NONE,this._cursorStyle==="grab"&&(this.domElement.style.cursor="grab");break;case 1:const e=this._pointers[0],i=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:i.x,pageY:i.y});break}}function o2(r){let e;switch(r.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case Gr.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(r),this.state=Zt.DOLLY;break;case Gr.ROTATE:if(r.ctrlKey||r.metaKey||r.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(r),this.state=Zt.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(r),this.state=Zt.ROTATE}break;case Gr.PAN:if(r.ctrlKey||r.metaKey||r.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(r),this.state=Zt.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(r),this.state=Zt.PAN}break;default:this.state=Zt.NONE}this.state!==Zt.NONE&&this.dispatchEvent(Sp)}function l2(r){switch(this.state){case Zt.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(r);break;case Zt.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(r);break;case Zt.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(r);break}}function c2(r){this.enabled===!1||this.enableZoom===!1||this.state!==Zt.NONE||(r.preventDefault(),this.dispatchEvent(Sp),this._handleMouseWheel(this._customWheelEvent(r)),this.dispatchEvent(vv))}function u2(r){this.enabled!==!1&&this._handleKeyDown(r)}function f2(r){switch(this._trackPointer(r),this._pointers.length){case 1:switch(this.touches.ONE){case Hr.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(r),this.state=Zt.TOUCH_ROTATE;break;case Hr.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(r),this.state=Zt.TOUCH_PAN;break;default:this.state=Zt.NONE}break;case 2:switch(this.touches.TWO){case Hr.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(r),this.state=Zt.TOUCH_DOLLY_PAN;break;case Hr.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(r),this.state=Zt.TOUCH_DOLLY_ROTATE;break;default:this.state=Zt.NONE}break;default:this.state=Zt.NONE}this.state!==Zt.NONE&&this.dispatchEvent(Sp)}function d2(r){switch(this._trackPointer(r),this.state){case Zt.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(r),this.update();break;case Zt.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(r),this.update();break;case Zt.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(r),this.update();break;case Zt.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(r),this.update();break;default:this.state=Zt.NONE}}function h2(r){this.enabled!==!1&&r.preventDefault()}function p2(r){r.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function m2(r){r.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}class g2 extends vp{constructor(e){super(e)}load(e,i,s,l){const c=this,d=new Jb(this.manager);d.setPath(this.path),d.setResponseType("arraybuffer"),d.setRequestHeader(this.requestHeader),d.setWithCredentials(this.withCredentials),d.load(e,function(p){try{i(c.parse(p))}catch(m){l?l(m):console.error(m),c.manager.itemError(e)}},s,l)}parse(e){function i(h){const g=new DataView(h),x=32/8*3+32/8*3*3+16/8,_=g.getUint32(80,!0);if(80+32/8+_*x===g.byteLength)return!0;const M=[115,111,108,105,100];for(let A=0;A<5;A++)if(s(M,g,A))return!1;return!0}function s(h,g,x){for(let _=0,y=h.length;_<y;_++)if(h[_]!==g.getUint8(x+_))return!1;return!0}function l(h){const g=new DataView(h),x=g.getUint32(80,!0);let _,y,M,A=!1,b,S,N,O,z;for(let G=0;G<70;G++)g.getUint32(G,!1)==1129270351&&g.getUint8(G+4)==82&&g.getUint8(G+5)==61&&(A=!0,b=new Float32Array(x*3*3),S=g.getUint8(G+6)/255,N=g.getUint8(G+7)/255,O=g.getUint8(G+8)/255,z=g.getUint8(G+9)/255);const k=84,L=50,H=new Pn,T=new Float32Array(x*3*3),I=new Float32Array(x*3*3),Z=new ft;for(let G=0;G<x;G++){const K=k+G*L,ue=g.getFloat32(K,!0),pe=g.getFloat32(K+4,!0),F=g.getFloat32(K+8,!0);if(A){const D=g.getUint16(K+48,!0);(D&32768)===0?(_=(D&31)/31,y=(D>>5&31)/31,M=(D>>10&31)/31):(_=S,y=N,M=O)}for(let D=1;D<=3;D++){const P=K+D*12,q=G*3*3+(D-1)*3;T[q]=g.getFloat32(P,!0),T[q+1]=g.getFloat32(P+4,!0),T[q+2]=g.getFloat32(P+8,!0),I[q]=ue,I[q+1]=pe,I[q+2]=F,A&&(Z.setRGB(_,y,M,pi),b[q]=Z.r,b[q+1]=Z.g,b[q+2]=Z.b)}}return H.setAttribute("position",new qn(T,3)),H.setAttribute("normal",new qn(I,3)),A&&(H.setAttribute("color",new qn(b,3)),H.hasColors=!0,H.alpha=z),H}function c(h){const g=new Pn,x=/solid([\s\S]*?)endsolid/g,_=/facet([\s\S]*?)endfacet/g,y=/solid\s(.+)/;let M=0;const A=/[\s]+([+-]?(?:\d*)(?:\.\d*)?(?:[eE][+-]?\d+)?)/.source,b=new RegExp("vertex"+A+A+A,"g"),S=new RegExp("normal"+A+A+A,"g"),N=[],O=[],z=[],k=new ee;let L,H=0,T=0,I=0;for(;(L=x.exec(h))!==null;){T=I;const Z=L[0],G=(L=y.exec(Z))!==null?L[1]:"";for(z.push(G);(L=_.exec(Z))!==null;){let pe=0,F=0;const D=L[0];for(;(L=S.exec(D))!==null;)k.x=parseFloat(L[1]),k.y=parseFloat(L[2]),k.z=parseFloat(L[3]),F++;for(;(L=b.exec(D))!==null;)N.push(parseFloat(L[1]),parseFloat(L[2]),parseFloat(L[3])),O.push(k.x,k.y,k.z),pe++,I++;F!==1&&console.error("THREE.STLLoader: Something isn't right with the normal of face number "+M),pe!==3&&console.error("THREE.STLLoader: Something isn't right with the vertices of face number "+M),M++}const K=T,ue=I-T;g.userData.groupNames=z,g.addGroup(K,ue,H),H++}return g.setAttribute("position",new Cn(N,3)),g.setAttribute("normal",new Cn(O,3)),g}function d(h){return typeof h!="string"?new TextDecoder().decode(h):h}function p(h){if(typeof h=="string"){const g=new Uint8Array(h.length);for(let x=0;x<h.length;x++)g[x]=h.charCodeAt(x)&255;return g.buffer||g}else return h}const m=p(e);return i(m)?l(m):c(d(e))}}/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _2=r=>r.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),x2=r=>r.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,i,s)=>s?s.toUpperCase():i.toLowerCase()),wx=r=>{const e=x2(r);return e.charAt(0).toUpperCase()+e.slice(1)},Sv=(...r)=>r.filter((e,i,s)=>!!e&&e.trim()!==""&&s.indexOf(e)===i).join(" ").trim(),v2=r=>{for(const e in r)if(e.startsWith("aria-")||e==="role"||e==="title")return!0};/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var S2={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y2=tt.forwardRef(({color:r="currentColor",size:e=24,strokeWidth:i=2,absoluteStrokeWidth:s,className:l="",children:c,iconNode:d,...p},m)=>tt.createElement("svg",{ref:m,...S2,width:e,height:e,stroke:r,strokeWidth:s?Number(i)*24/Number(e):i,className:Sv("lucide",l),...!c&&!v2(p)&&{"aria-hidden":"true"},...p},[...d.map(([h,g])=>tt.createElement(h,g)),...Array.isArray(c)?c:[c]]));/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const hn=(r,e)=>{const i=tt.forwardRef(({className:s,...l},c)=>tt.createElement(y2,{ref:c,iconNode:e,className:Sv(`lucide-${_2(wx(r))}`,`lucide-${r}`,s),...l}));return i.displayName=wx(r),i};/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b2=[["path",{d:"M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z",key:"hh9hay"}],["path",{d:"m3.3 7 8.7 5 8.7-5",key:"g66t2b"}],["path",{d:"M12 22V12",key:"d0xqtd"}]],dh=hn("box",b2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M2=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],tl=hn("chevron-right",M2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E2=[["circle",{cx:"8",cy:"8",r:"6",key:"3yglwk"}],["path",{d:"M18.09 10.37A6 6 0 1 1 10.34 18",key:"t5s6rm"}],["path",{d:"M7 6h1v4",key:"1obek4"}],["path",{d:"m16.71 13.88.7.71-2.82 2.82",key:"1rbuyh"}]],T2=hn("coins",E2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A2=[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],R2=hn("compass",A2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C2=[["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M17 20v2",key:"1rnc9c"}],["path",{d:"M17 2v2",key:"11trls"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M2 17h2",key:"7oei6x"}],["path",{d:"M2 7h2",key:"asdhe0"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"M20 17h2",key:"1fpfkl"}],["path",{d:"M20 7h2",key:"1o8tra"}],["path",{d:"M7 20v2",key:"4gnj0m"}],["path",{d:"M7 2v2",key:"1i4yhu"}],["rect",{x:"4",y:"4",width:"16",height:"16",rx:"2",key:"1vbyd7"}],["rect",{x:"8",y:"8",width:"8",height:"8",rx:"1",key:"z9xiuo"}]],w2=hn("cpu",C2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D2=[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]],Dx=hn("database",D2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N2=[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]],U2=hn("download",N2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L2=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M3 15h18",key:"5xshup"}],["path",{d:"M9 3v18",key:"fh3hqa"}],["path",{d:"M15 3v18",key:"14nvp0"}]],O2=hn("grid-3x3",L2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P2=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]],z2=hn("info",P2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F2=[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]],B2=hn("layers",F2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I2=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],H2=hn("loader-circle",I2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G2=[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]],V2=hn("printer",G2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k2=[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]],Nx=hn("refresh-cw",k2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j2=[["path",{d:"M14 17H5",key:"gfn3mx"}],["path",{d:"M19 7h-9",key:"6i9tg"}],["circle",{cx:"17",cy:"17",r:"3",key:"18b49y"}],["circle",{cx:"7",cy:"7",r:"3",key:"dfmy0x"}]],X2=hn("settings-2",j2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W2=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]],rp=hn("shield-alert",W2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q2=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],Y2=hn("shield-check",q2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z2=[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]],K2=hn("sparkles",Z2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q2=[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]],Ux=hn("upload",Q2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J2=[["path",{d:"M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z",key:"1ngwbx"}]],$2=hn("wrench",J2);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e3=[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["line",{x1:"21",x2:"16.65",y1:"21",y2:"16.65",key:"13gj7c"}],["line",{x1:"11",x2:"11",y1:"8",y2:"14",key:"1vmskp"}],["line",{x1:"8",x2:"14",y1:"11",y2:"11",key:"durymu"}]],t3=hn("zoom-in",e3);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n3=[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["line",{x1:"21",x2:"16.65",y1:"21",y2:"16.65",key:"13gj7c"}],["line",{x1:"8",x2:"14",y1:"11",y2:"11",key:"durymu"}]],i3=hn("zoom-out",n3),a3=({modelData:r,settings:e,onModelLoaded:i,modelScale:s})=>{const l=tt.useRef(null),c=tt.useRef(null),d=tt.useRef(null),p=tt.useRef(null),m=tt.useRef(null),h=tt.useRef(null),g=tt.useRef(null),x=tt.useRef(null),_=tt.useRef(null),y=tt.useRef(null),M=tt.useRef(null),A=tt.useRef(null),b=tt.useRef(null),S=tt.useRef(1),N=tt.useRef(0),O=tt.useRef(0),z=tt.useRef(0),k=tt.useRef(null),L=tt.useRef(e.autoRotate);tt.useEffect(()=>{L.current=e.autoRotate},[e.autoRotate]);const[H,T]=tt.useState(!1),[I,Z]=tt.useState(null);tt.useEffect(()=>{if(!l.current)return;const F=new wb;F.background=new ft(16645629),d.current=F;const D=l.current.clientWidth,P=l.current.clientHeight||500,q=new t2({antialias:!0,alpha:!1});q.setSize(D,P),q.setPixelRatio(Math.min(window.devicePixelRatio,2)),q.shadowMap.enabled=!0,q.shadowMap.type=Px,l.current.innerHTML="",l.current.appendChild(q.domElement),c.current=q;const he=new mi(45,D/P,.1,1e3);he.position.set(40,40,60),p.current=he;const _e=new i2(he,q.domElement);_e.enableDamping=!0,_e.dampingFactor=.05,_e.maxDistance=300,_e.minDistance=5,m.current=_e;const B=new il;F.add(B),k.current=B;const Q=new nx(50,50,16739072,14737632);Q.position.y=-10,F.add(Q),y.current=Q;const ve=new aM(15);ve.position.set(-25,-10,-25),F.add(ve),M.current=ve;const Ae=new ResizeObserver(ye=>{if(!ye||ye.length===0)return;const{width:Me,height:Ie}=ye[0].contentRect;if(c.current&&p.current){if(c.current.setSize(Me,Ie),p.current instanceof mi)p.current.aspect=Me/Ie,p.current.updateProjectionMatrix();else if(p.current instanceof _u){const Ze=Me/Ie,Ke=35;p.current.left=-Ke*Ze,p.current.right=Ke*Ze,p.current.top=Ke,p.current.bottom=-Ke,p.current.updateProjectionMatrix()}}});Ae.observe(l.current);let Ce;const ae=()=>{Ce=requestAnimationFrame(ae),m.current&&(L.current&&h.current&&(h.current.rotation.y+=.005,g.current&&(g.current.rotation.y=h.current.rotation.y),x.current&&(x.current.rotation.y=h.current.rotation.y),_.current&&_.current.update()),m.current.update()),c.current&&d.current&&p.current&&c.current.render(d.current,p.current)};return ae(),()=>{cancelAnimationFrame(Ce),Ae.disconnect(),c.current&&c.current.dispose()}},[]),tt.useEffect(()=>{const F=k.current;if(F){for(;F.children.length>0;)F.remove(F.children[0]);if(e.lighting==="studio"){const D=new Zc(16777215,.5);F.add(D);const P=new zr(16777215,.8);P.position.set(40,60,40),P.castShadow=!0,F.add(P);const q=new zr(9684477,.3);q.position.set(-40,20,-40),F.add(q)}else if(e.lighting==="sunset"){const D=new Zc(1973067,.4);F.add(D);const P=new zr(16628340,1.2);P.position.set(50,30,20),P.castShadow=!0,F.add(P);const q=new zr(15485081,.5);q.position.set(-30,-10,-30),F.add(q)}else if(e.lighting==="industrial"){const D=new Zc(988970,.3);F.add(D);const P=new zr(16777215,1.5);P.position.set(0,80,0),P.castShadow=!0,F.add(P);const q=new zr(3718648,.4);q.position.set(30,20,-50),F.add(q)}else{const D=new Zc(16777215,1.1);F.add(D)}}},[e.lighting]),tt.useEffect(()=>{!r||!d.current||(T(!0),Z(null),setTimeout(()=>{try{const F=d.current;h.current&&(F.remove(h.current),h.current.geometry.dispose(),Array.isArray(h.current.material)?h.current.material.forEach(ne=>ne.dispose()):h.current.material.dispose(),h.current=null),g.current&&(F.remove(g.current),g.current.geometry.dispose(),Array.isArray(g.current.material)?g.current.material.forEach(ne=>ne.dispose()):g.current.material.dispose(),g.current=null),x.current&&(F.remove(x.current),x.current.geometry.dispose(),x.current.material.dispose(),x.current=null),_.current&&(F.remove(_.current),_.current=null);const P=new g2().parse(r);P.computeVertexNormals();let q=0,he=0;const _e=P.attributes.position,B=_e.count/3;for(let ne=0;ne<B;ne++){const de=_e.getX(ne*3+0),Oe=_e.getY(ne*3+0),ze=_e.getZ(ne*3+0),Ue=_e.getX(ne*3+1),De=_e.getY(ne*3+1),rt=_e.getZ(ne*3+1),ot=_e.getX(ne*3+2),_t=_e.getY(ne*3+2),X=_e.getZ(ne*3+2),Re=(-ot*De*ze+Ue*_t*ze+ot*Oe*rt-de*_t*rt-Ue*Oe*X+de*De*X)/6;q+=Re;const me=Ue-de,He=De-Oe,Le=rt-ze,Ee=ot-de,We=_t-Oe,it=X-ze,Jt=He*it-Le*We,Dt=Le*Ee-me*it,Vn=me*We-He*Ee,kn=.5*Math.sqrt(Jt*Jt+Dt*Dt+Vn*Vn);he+=kn}P.center(),P.computeBoundingBox();const Q=P.boundingBox,ve=Q.max.x-Q.min.x,Ae=Q.max.y-Q.min.y,Ce=Q.max.z-Q.min.z;O.current=ve,z.current=Ce;const ae=Math.max(ve,Ae,Ce),ye=30/(ae||1);S.current=ye,P.scale(ye,ye,ye),P.computeBoundingBox();const Me=P.boundingBox,Ie=Me.max.y-Me.min.y,Ze=Me.min.y;N.current=Ze,A.current&&(F.remove(A.current),A.current.geometry.dispose(),A.current.material.dispose(),A.current=null),b.current&&(F.remove(b.current),b.current.geometry.dispose(),b.current.material.dispose(),b.current=null);const Ke=new ft(e.color),Lt=new q_({color:Ke,roughness:e.roughness,metalness:e.metalness,roughnessMap:null,metalnessMap:null,bumpScale:1,side:Xi}),nt=s/100,dt=ve*nt>250||Ce*nt>250,St=new zi(P,Lt);St.scale.setScalar(nt),St.castShadow=!0,St.receiveShadow=!0,F.add(St),h.current=St;const ct=new X_(P),$t=new Wr({color:16777215,linewidth:1.5,transparent:!0,opacity:.6}),te=new cl(ct,$t);te.scale.setScalar(nt),F.add(te),x.current=te;const Fe=new sv({color:Ke,size:.4,sizeAttenuation:!0}),j=new Hb(P,Fe);j.scale.setScalar(nt),F.add(j),g.current=j;const yt=new iM(St,16739072);F.add(yt),_.current=yt;const lt=250*ye,Nt=new Kr(lt,.4,lt),we=new q_({color:dt?15680580:16317180,roughness:.25,metalness:.1,transparent:!0,opacity:dt?.35:.6}),Xt=new zi(Nt,we);Xt.position.y=Ze*nt-.21,F.add(Xt),A.current=Xt;const U=new X_(Nt),E=new Wr({color:dt?15680580:14870768,linewidth:2}),$=new cl(U,E);if($.position.y=Ze*nt-.21,F.add($),b.current=$,y.current){F.remove(y.current);const ne=new nx(lt,25,16739072,13751771);ne.position.y=Ze*nt-.01,F.add(ne),y.current=ne}if(M.current){const ne=Math.max(25,ve*ye*1.2);M.current.position.set(-ne,Ze*nt+.1,-ne)}if(p.current&&m.current){const ne=ae*ye*1.8;p.current.position.set(ne,ne,ne*1.2),p.current.lookAt(0,0,0),m.current.target.set(0,0,0),m.current.update()}const xe=Math.abs(q),Ne=xe/1e3*1.24,Pe=xe/2405.28;i({volume:Math.abs(q),surfaceArea:he,boundingBox:{width:ve,height:Ae,depth:Ce},triangleCount:B,estimatedWeight:Ne,filamentLength:Pe}),G(e.mode),K(e)}catch(F){console.error("Error building 3D STL structure:",F),Z((F==null?void 0:F.message)||"Ocurrió un error al procesar el archivo STL.")}finally{T(!1)}},50))},[r]);const G=F=>{if(!h.current||!g.current||!x.current)return;h.current.visible=!1,g.current.visible=!1,x.current.visible=!1;const D=h.current.material;F==="solid"?(h.current.visible=!0,D.wireframe=!1,D.transparent=!1,D.opacity=1):F==="wireframe"?(h.current.visible=!0,D.wireframe=!0,D.transparent=!1,D.opacity=1):F==="points"?g.current.visible=!0:F==="xray"&&(h.current.visible=!0,x.current.visible=!0,D.wireframe=!1,D.transparent=!0,D.opacity=.35)},K=F=>{if(_.current&&(_.current.visible=F.showBoundingBox),y.current&&(y.current.visible=F.showGrid),M.current&&(M.current.visible=F.showAxes),h.current){const D=h.current.material;D.color.set(F.color),D.roughness=F.roughness,D.metalness=F.metalness,D.needsUpdate=!0}if(x.current){const D=new ft(F.color),P=(D.r+D.g+D.b)/3>.7;x.current.material.color.set(P?1120295:16777215)}if(g.current){const D=g.current.material;D.color.set(F.color),D.needsUpdate=!0}};tt.useEffect(()=>{h.current&&(G(e.mode),K(e))},[e.color,e.mode,e.roughness,e.metalness,e.showGrid,e.showAxes,e.showBoundingBox]),tt.useEffect(()=>{if(!h.current)return;const F=s/100;h.current.scale.setScalar(F),g.current&&g.current.scale.setScalar(F),x.current&&x.current.scale.setScalar(F),_.current&&_.current.update();const D=N.current*F;if(y.current&&(y.current.position.y=D-.01),M.current&&S.current){const P=Math.max(25,O.current*S.current*1.2);M.current.position.set(-P,D+.1,-P)}if(A.current){A.current.position.y=D-.21;const P=O.current*F>250||z.current*F>250,q=A.current.material;q.color.set(P?new ft(15680580):new ft(16317180)),q.opacity=P?.35:.6,q.needsUpdate=!0}if(b.current){b.current.position.y=D-.21;const P=O.current*F>250||z.current*F>250,q=b.current.material;q.color.set(P?new ft(15680580):new ft(14870768)),q.needsUpdate=!0}},[s]);const ue=F=>{if(!p.current||!m.current||!h.current)return;const D=h.current.geometry.boundingBox,P=Math.max(D.max.x-D.min.x,D.max.y-D.min.y,D.max.z-D.min.z),q=1.6;if(m.current.target.set(0,0,0),F==="top")p.current.position.set(0,P*q*2,0);else if(F==="front")p.current.position.set(0,0,P*q*2);else if(F==="side")p.current.position.set(P*q*2,0,0);else{const he=P*1.5;p.current.position.set(he,he,he*1.2)}m.current.update()},pe=F=>{if(!p.current||!m.current)return;const D=F==="in"?.8:1.2;p.current.position.multiplyScalar(D),m.current.update()};return R.jsxs("div",{id:"stl-viewer-root",className:"relative w-full h-full bg-surface2 rounded-none overflow-hidden border border-border flex flex-col min-h-0",children:[R.jsx("div",{ref:l,id:"canvas-container",className:"w-full flex-grow relative cursor-grab active:cursor-grabbing"}),H&&R.jsxs("div",{className:"absolute inset-0 bg-surface/95 backdrop-blur-sm z-35 flex flex-col items-center justify-center",children:[R.jsx(H2,{className:"w-12 h-12 text-orange animate-spin mb-4"}),R.jsx("p",{className:"text-text text-sm font-mono uppercase tracking-widest font-bold",children:"Analizando y renderizando STL..."}),R.jsx("p",{className:"text-muted text-[10px] uppercase font-mono mt-2",children:"Calculando métricas volumétricas físicas..."})]}),I&&R.jsxs("div",{className:"absolute inset-0 bg-red-100/95 backdrop-blur-sm z-35 flex flex-col items-center justify-center p-6 text-center border-2 border-red-250",children:[R.jsx(rp,{className:"w-14 h-14 text-red-650 mb-4"}),R.jsx("p",{className:"text-text text-base font-semibold font-mono uppercase tracking-wider",children:"Error al cargar modelo STL"}),R.jsx("p",{className:"text-red-850 text-xs max-w-md mt-2 leading-relaxed bg-white/80 p-3 rounded-none border border-red-300 font-mono",children:I}),R.jsxs("button",{onClick:()=>window.location.reload(),className:"mt-5 px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-none text-xs font-mono font-semibold shadow-md transition-all flex items-center gap-1.5 cursor-pointer",children:[R.jsx(Nx,{className:"w-3.5 h-3.5"})," Reintentar"]})]}),!H&&!I&&r&&R.jsxs("div",{className:"absolute top-4 left-4 z-10 pointer-events-none bg-surface/90 backdrop-blur-md px-3 py-2.5 rounded-none border border-border hidden sm:block shadow-sm",children:[R.jsxs("p",{className:"text-orange font-mono text-[10px] uppercase tracking-widest mb-2.5 flex items-center gap-1.5 font-bold",children:[R.jsx("span",{className:"w-1.5 h-1.5 bg-orange rounded-full"})," CONTROLES NAVEGACIÓN"]}),R.jsxs("ul",{className:"text-muted font-mono text-[10px] leading-relaxed space-y-1",children:[R.jsxs("li",{children:["• ",R.jsx("strong",{className:"text-text",children:"Arrastrar:"})," Rotar modelo"]}),R.jsxs("li",{children:["• ",R.jsx("strong",{className:"text-text",children:"Click Der. / Shift:"})," Desplazar (Pan)"]}),R.jsxs("li",{children:["• ",R.jsx("strong",{className:"text-text",children:"Scroll:"})," Zoom Acercar / Alejar"]})]})]}),!H&&!I&&r&&R.jsxs("div",{className:"absolute bottom-4 right-4 z-10 flex items-center gap-1 bg-surface/95 backdrop-blur-md p-1 rounded-none border border-border shadow-md",children:[R.jsx("button",{onClick:()=>ue("reset"),title:"Vista de Perspectiva",className:"p-1.5 hover:bg-surface2 text-muted hover:text-orange rounded-none transition-all cursor-pointer",children:R.jsx(R2,{className:"w-4 h-4"})}),R.jsx("div",{className:"h-4 w-[1px] bg-border mx-1"}),R.jsx("button",{onClick:()=>ue("top"),title:"Vista Superior",className:"px-2 py-1 text-[10px] font-bold font-mono tracking-wider hover:bg-surface2 text-muted hover:text-text rounded-none transition-all uppercase cursor-pointer",children:"Top"}),R.jsx("button",{onClick:()=>ue("front"),title:"Vista Frontal",className:"px-2 py-1 text-[10px] font-bold font-mono tracking-wider hover:bg-surface2 text-muted hover:text-text rounded-none transition-all uppercase cursor-pointer",children:"Front"}),R.jsx("button",{onClick:()=>ue("side"),title:"Vista Lateral",className:"px-2 py-1 text-[10px] font-bold font-mono tracking-wider hover:bg-surface2 text-muted hover:text-text rounded-none transition-all uppercase cursor-pointer",children:"Side"}),R.jsx("div",{className:"h-4 w-[1px] bg-border mx-1"}),R.jsx("button",{onClick:()=>pe("in"),title:"Acercar",className:"p-1.5 hover:bg-surface2 text-muted hover:text-orange rounded-none transition-all cursor-pointer",children:R.jsx(t3,{className:"w-4 h-4"})}),R.jsx("button",{onClick:()=>pe("out"),title:"Alejar",className:"p-1.5 hover:bg-surface2 text-muted hover:text-orange rounded-none transition-all cursor-pointer",children:R.jsx(i3,{className:"w-4 h-4"})})]}),R.jsxs("div",{id:"canvas-footer",className:"bg-surface border-t border-border px-4 py-2.5 flex items-center justify-between text-[10px] text-muted font-mono uppercase tracking-wider",children:[R.jsxs("div",{className:"flex items-center gap-1.5 font-semibold",children:[R.jsx("span",{className:`w-1.5 h-1.5 rounded-full ${r?"bg-orange animate-pulse":"bg-amber-500"}`}),R.jsx("span",{children:r?"ENGINE.ST_ONLINE":"WAITING.STL"})]}),e.autoRotate&&r&&R.jsxs("div",{className:"flex items-center gap-1.5 text-orange font-bold",children:[R.jsx(Nx,{className:"w-3 h-3 animate-spin"}),R.jsx("span",{children:"ROTACIÓN_CONSOLA"})]})]})]})};function Vs(r,e,i){const s=e[0]-r[0],l=e[1]-r[1],c=e[2]-r[2],d=i[0]-r[0],p=i[1]-r[1],m=i[2]-r[2],h=l*m-c*p,g=c*d-s*m,x=s*p-l*d,_=Math.sqrt(h*h+g*g+x*x);return _===0?[0,0,1]:[h/_,g/_,x/_]}function yp(r,e="Procedural"){const i=`STL generated by STL 3D Viewer - ${e.substring(0,40)}`,s=new ArrayBuffer(84+r.length*50),l=new DataView(s);for(let d=0;d<80;d++)d<i.length?l.setUint8(d,i.charCodeAt(d)):l.setUint8(d,32);l.setUint32(80,r.length,!0);let c=84;for(const d of r)l.setFloat32(c+0,d.normal[0],!0),l.setFloat32(c+4,d.normal[1],!0),l.setFloat32(c+8,d.normal[2],!0),l.setFloat32(c+12,d.v1[0],!0),l.setFloat32(c+16,d.v1[1],!0),l.setFloat32(c+20,d.v1[2],!0),l.setFloat32(c+24,d.v2[0],!0),l.setFloat32(c+28,d.v2[1],!0),l.setFloat32(c+32,d.v2[2],!0),l.setFloat32(c+36,d.v3[0],!0),l.setFloat32(c+40,d.v3[1],!0),l.setFloat32(c+44,d.v3[2],!0),l.setUint16(c+48,0,!0),c+=50;return s}function s3(){const i=[{x:-10,y:-10,z:-10},{x:10,y:-10,z:-10},{x:10,y:10,z:-10},{x:-10,y:10,z:-10},{x:-10,y:-10,z:10},{x:10,y:-10,z:10},{x:10,y:10,z:10},{x:-10,y:10,z:10}],s=[[2,1,0],[3,2,0],[4,5,6],[4,6,7],[0,1,5],[0,5,4],[2,3,7],[2,7,6],[3,0,4],[3,4,7],[1,2,6],[1,6,5]],l=[];for(const c of s){const d=i[c[0]],p=i[c[1]],m=i[c[2]],h=[d.x,d.y,d.z],g=[p.x,p.y,p.z],x=[m.x,m.y,m.z],_=Vs(h,g,x);l.push({normal:_,v1:h,v2:g,v3:x})}return yp(l,"CalibrationCube_20mm")}function r3(){const l=[];l.push({x:0,y:0,z:5});for(let g=0;g<8;g++){const x=g/8*Math.PI*2;l.push({x:Math.cos(x)*12,y:Math.sin(x)*12,z:5})}for(let g=0;g<8;g++){const x=(g+.5)/8*Math.PI*2;l.push({x:Math.cos(x)*15,y:Math.sin(x)*15,z:0})}l.push({x:0,y:0,z:-15});const m=[];for(let g=0;g<8;g++){const x=(g+1)%8,_=0,y=1+g,M=1+x,A=[l[_].x,l[_].y,l[_].z],b=[l[M].x,l[M].y,l[M].z],S=[l[y].x,l[y].y,l[y].z];m.push({normal:Vs(A,b,S),v1:A,v2:b,v3:S})}for(let g=0;g<8;g++){const x=(g+1)%8,_=1+g,y=1+x,M=9+g,A=9+(g-1+8)%8;{const b=[l[_].x,l[_].y,l[_].z],S=[l[y].x,l[y].y,l[y].z],N=[l[M].x,l[M].y,l[M].z];m.push({normal:Vs(b,S,N),v1:b,v2:S,v3:N})}{const b=[l[_].x,l[_].y,l[_].z],S=[l[M].x,l[M].y,l[M].z],N=[l[A].x,l[A].y,l[A].z];m.push({normal:Vs(b,S,N),v1:b,v2:S,v3:N})}}const h=17;for(let g=0;g<8;g++){const x=(g+1)%8,_=9+g,y=9+x,M=[l[y].x,l[y].y,l[y].z],A=[l[_].x,l[_].y,l[_].z],b=[l[h].x,l[h].y,l[h].z];m.push({normal:Vs(M,A,b),v1:M,v2:A,v3:b})}return yp(m,"FacetedDiamond_25mm")}function o3(){const d=[];for(let h=0;h<=64;h++){const g=h/64*Math.PI*2,x=15+4*Math.cos(3*g),_=x*Math.cos(2*g),y=x*Math.sin(2*g),M=4*Math.sin(3*g);d.push({x:_,y,z:M})}const p=[],m=[];for(let h=0;h<64;h++){const g=d[h],x=d[h+1],_=x.x-g.x,y=x.y-g.y,M=x.z-g.z,A=Math.sqrt(_*_+y*y+M*M),b={x:_/A,y:y/A,z:M/A},S=g.x,N=g.y,O=0,z=Math.sqrt(S*S+N*N+O*O),k={x:S/z,y:N/z,z:O/z},L={x:b.y*k.z-b.z*k.y,y:b.z*k.x-b.x*k.z,z:b.x*k.y-b.y*k.x},H=Math.sqrt(L.x*L.x+L.y*L.y+L.z*L.z);L.x/=H,L.y/=H,L.z/=H,k.x=L.y*b.z-L.z*b.y,k.y=L.z*b.x-L.x*b.z,k.z=L.x*b.y-L.y*b.x;const T=[],I=3.5;for(let Z=0;Z<12;Z++){const G=Z/12*Math.PI*2,K=Math.cos(G),ue=Math.sin(G);T.push({x:g.x+I*(K*k.x+ue*L.x),y:g.y+I*(K*k.y+ue*L.y),z:g.z+I*(K*k.z+ue*L.z)})}m.push(T)}m.push(m[0]);for(let h=0;h<64;h++){const g=m[h],x=m[h+1];for(let _=0;_<12;_++){const y=(_+1)%12,M=g[_],A=x[_],b=g[y],S=x[y];{const N=[M.x,M.y,M.z],O=[A.x,A.y,A.z],z=[S.x,S.y,S.z];p.push({normal:Vs(N,O,z),v1:N,v2:O,v3:z})}{const N=[M.x,M.y,M.z],O=[S.x,S.y,S.z],z=[b.x,b.y,b.z];p.push({normal:Vs(N,O,z),v1:N,v2:O,v3:z})}}}return yp(p,"TorusKnot_2x3")}const l3="stlviewer_db",Xs="files";function bp(){return new Promise((r,e)=>{const i=indexedDB.open(l3,1);i.onupgradeneeded=()=>{i.result.createObjectStore(Xs,{keyPath:"id"})},i.onsuccess=()=>r(i.result),i.onerror=()=>e(i.error)})}async function c3(r){const e=await bp();return new Promise((i,s)=>{const l=e.transaction(Xs,"readwrite");l.objectStore(Xs).put(r),l.oncomplete=()=>i(),l.onerror=()=>s(l.error)})}async function Lx(){const r=await bp();return new Promise((e,i)=>{const l=r.transaction(Xs,"readonly").objectStore(Xs).getAll();l.onsuccess=()=>e(l.result||[]),l.onerror=()=>i(l.error)})}async function u3(r){const e=await bp();return new Promise((i,s)=>{const l=e.transaction(Xs,"readwrite");l.objectStore(Xs).delete(r),l.oncomplete=()=>i(),l.onerror=()=>s(l.error)})}const f3=[{id:"torus_knot",name:"Nudo Toroidal 3D",description:"Una escultura matemática continua de geometría compleja con 1,536 polígonos.",category:"Escultura"},{id:"diamond",name:"Gema Brillante Octogonal",description:"Un diamante tallado con facetas planas que reflejan la luz desde múltiples ángulos.",category:"Joyería"},{id:"cube",name:"Cubo de Calibración 20mm",description:"Un cubo estándar de precisión métrica utilizado para probar tolerancias de impresión.",category:"Ingeniería"}],d3=[{id:"esquina",name:"Esquina",description:"Pieza de esquina de perfil.",category:"Estructura",file:"/models/esquina.stl"},{id:"esquina2",name:"Esquina v2",description:"Esquina variante 2.",category:"Estructura",file:"/models/esquina2.stl"},{id:"pinza",name:"Pinza",description:"Herramienta de sujeción.",category:"Herramienta",file:"/models/pinza.stl"},{id:"pinza1",name:"Pinza v1",description:"Pinza variante 1.",category:"Herramienta",file:"/models/pinza1.stl"},{id:"pinza2",name:"Pinza v2",description:"Pinza variante 2.",category:"Herramienta",file:"/models/pinza2.stl"},{id:"pinza3",name:"Pinza v3",description:"Pinza variante 3.",category:"Herramienta",file:"/models/pinza3.stl"},{id:"pozo",name:"Tapa de Pozo",description:"Tapa para pozo o desagüe.",category:"Estructura",file:"/models/pozo.stl"},{id:"pozo3",name:"Tapa de Pozo v3",description:"Variante 3 de tapa de pozo.",category:"Estructura",file:"/models/pozo3.stl"},{id:"soporte_mangera",name:"Soporte Manguera",description:"Soporte para manguera.",category:"Soporte",file:"/models/soporte_mangera.stl"},{id:"soporte_mangera2",name:"Soporte Manguera v2",description:"Soporte manguera variante 2.",category:"Soporte",file:"/models/soporte_mangera2.stl"},{id:"soporte_mangera3",name:"Soporte Manguera v3",description:"Soporte manguera variante 3.",category:"Soporte",file:"/models/soporte_mangera3.stl"},{id:"soporte_movil",name:"Soporte Móvil",description:"Soporte de agarre móvil.",category:"Soporte",file:"/models/soporte_movil.stl"},{id:"conector_mangera2",name:"Conector Manguera v2",description:"Conector para manguera variante 2.",category:"Conector",file:"/models/conector_mangera2.stl"},{id:"conector_mangera3",name:"Conector Manguera v3",description:"Conector para manguera variante 3.",category:"Conector",file:"/models/conector_mangera3.stl"},{id:"tapon20",name:"Tapón 20mm",description:"Tapón de cierre de 20 mm.",category:"Pieza",file:"/models/tapon20.stl"},{id:"interminiete",name:"Intermedieto",description:"Pieza intermedia de ensamblaje.",category:"Pieza",file:"/models/interminiete.stl"},{id:"interminiete1",name:"Intermedieto v2",description:"Intermedieto variante 2.",category:"Pieza",file:"/models/interminiete1.stl"},{id:"giroide_50mm",name:"Giroide 50mm",description:"Estructura giroide de 50 mm de lado.",category:"Especial",file:"/models/giroide_50mm.stl"},{id:"cuerpoPad",name:"Cuerpo Pad",description:"Cuerpo de pieza pad.",category:"Pieza",file:"/models/cuerpoPad.stl"},{id:"pruba2",name:"Prueba 2",description:"Pieza de prueba de diseño.",category:"Prueba",file:"/models/pruba2.stl"}],Ox=[{name:"PLA (Ácido Poliláctico)",value:"PLA",density:1.24,defaultPrice:22},{name:"PLA-CF (Fibra de Carbono PLA)",value:"PLA-CF",density:1.28,defaultPrice:29.5},{name:"PETG-CF (Fibra de Carbono PETG)",value:"PETG-CF",density:1.32,defaultPrice:34},{name:"PA-CF (Fibra de Carbono Nylon)",value:"PA-CF",density:1.18,defaultPrice:45},{name:"ABS (Acrilonitrilo Butadieno Estireno)",value:"ABS",density:1.04,defaultPrice:20},{name:"PETG (Polietileno Tereftalato Glicol)",value:"PETG",density:1.27,defaultPrice:24},{name:"TPU Flexible (Poliuretano Termoplástico)",value:"TPU",valueLabel:"TPU",density:1.21,defaultPrice:32}],h3=[{name:"Estudio de Slicer",value:"studio",desc:"Luz ambiental suave con sombras realistas"},{name:"Atardecer Cálido",value:"sunset",desc:"Atmósfera dramática con tonos anaranjados y rosados"},{name:"Industrial Frío",value:"industrial",desc:"Contraste metálico fuerte con foco frío superior"},{name:"Luz Plana (CAD)",value:"flat",desc:"Luz difusa sin sombras para inspección técnica"}],p3=[{name:"Oro Seda",value:"#d4af37",roughness:.18,metalness:.9},{name:"Peltre Plateado",value:"#cbd5e1",roughness:.2,metalness:.85},{name:"Naranja PLA",value:"#ea580c",roughness:.45,metalness:.05},{name:"Jade Verde",value:"#059669",roughness:.4,metalness:.1},{name:"Cobalto Brillante",value:"#1d4ed8",roughness:.35,metalness:.15},{name:"Rubí Traslúcido",value:"#e11d48",roughness:.25,metalness:.3},{name:"Antracita Mate",value:"#334155",roughness:.7,metalness:0},{name:"Blanco Caliza",value:"#f8fafc",roughness:.6,metalness:0}];function m3(){const[r,e]=tt.useState(null),[i,s]=tt.useState("torus_knot"),[l,c]=tt.useState("TorusKnot_2x3.stl"),[d,p]=tt.useState(!1),[m,h]=tt.useState(!1),g=tt.useRef(null),[x,_]=tt.useState([]),[y,M]=tt.useState({color:"#d4af37",roughness:.18,metalness:.9,mode:"solid",showGrid:!0,showAxes:!0,autoRotate:!1,showBoundingBox:!1,projection:"perspective",lighting:"studio",gridSize:50,gridDivisions:50}),[A,b]=tt.useState(null),[S,N]=tt.useState(100),[O,z]=tt.useState("PLA"),[k,L]=tt.useState(1.24),[H,T]=tt.useState(25),[I,Z]=tt.useState(1e3),[G,K]=tt.useState(20),[ue,pe]=tt.useState(0),[F,D]=tt.useState(.2),[P,q]=tt.useState("material");tt.useEffect(()=>{he("torus_knot"),Lx().then(te=>_(te)).catch(()=>{})},[]),tt.useEffect(()=>{const te=Ox.find(Fe=>Fe.value===O);te&&(L(te.density),T(te.defaultPrice))},[O]),tt.useEffect(()=>{if(A){const te=A.boundingBox.height*(S/100),Fe=Math.max(1,Math.ceil(te/F));pe(Fe)}},[A,F,S]);const he=te=>{let Fe,j="";te==="cube"?(Fe=s3(),j="CalibrationCube_20mm.stl",M(yt=>({...yt,color:"#475569",roughness:.65,metalness:.05}))):te==="diamond"?(Fe=r3(),j="FacetedDiamond_25mm.stl",M(yt=>({...yt,color:"#e11d48",roughness:.2,metalness:.4}))):(Fe=o3(),j="TorusKnot_2x3.stl",M(yt=>({...yt,color:"#d4af37",roughness:.18,metalness:.9}))),e(Fe),c(j),s(te),N(100)},_e=async te=>{h(!0),s(te.id);try{const j=await(await fetch(te.file)).arrayBuffer();e(j),c(te.name+".stl"),N(100)}catch{alert("No se pudo cargar el diseño.")}finally{h(!1)}},B=te=>{const Fe=te.target.files;Fe&&Fe.length>0&&Q(Fe[0])},Q=te=>{if(!te.name.toLowerCase().endsWith(".stl")){alert("Por favor selecciona un archivo con extensión .stl");return}const Fe=new FileReader;Fe.onload=j=>{var lt;const yt=(lt=j.target)==null?void 0:lt.result;if(yt){e(yt),c(te.name),s(""),N(100);const Nt={id:`${te.name}_${te.size}`,name:te.name,data:yt.slice(0),savedAt:Date.now()};c3(Nt).then(()=>Lx()).then(we=>_(we)).catch(()=>{})}},Fe.readAsArrayBuffer(te)},ve=te=>{te.preventDefault(),p(!0)},Ae=()=>{p(!1)},Ce=te=>{te.preventDefault(),p(!1);const Fe=te.dataTransfer.files;Fe&&Fe.length>0&&Q(Fe[0])},ae=te=>{te==="placf"?(z("PLA-CF"),M(Fe=>({...Fe,color:"#272d37",roughness:.85,metalness:.15})),K(30),D(.2)):te==="petgcf"?(z("PETG-CF"),M(Fe=>({...Fe,color:"#111827",roughness:.82,metalness:.22})),K(40),D(.16)):te==="pacf"&&(z("PA-CF"),M(Fe=>({...Fe,color:"#1e293b",roughness:.9,metalness:.05})),K(50),D(.12))},ye=()=>{if(!A)return{weight:0,cost:0,length:0};const te=Math.pow(S/100,3),Fe=.2+.8*(G/100),j=A.estimatedWeight*Fe*te,yt=j/I*H,lt=A.filamentLength*Fe*te;return{weight:Math.max(.1,j),cost:Math.max(.01,yt),length:Math.max(.1,lt)}},Me=A?A.boundingBox.width*(S/100):0,Ie=A?A.boundingBox.height*(S/100):0,Ze=A?A.boundingBox.depth*(S/100):0,Ke=A?A.volume*Math.pow(S/100,3):0,Lt=A?A.surfaceArea*Math.pow(S/100,2):0,nt=A?Me>250||Ze>250:!1,{weight:dt,cost:St,length:ct}=ye(),$t=()=>{if(!r)return;const te=new Blob([r],{type:"application/octet-stream"}),Fe=URL.createObjectURL(te),j=document.createElement("a");j.href=Fe,j.download=l,document.body.appendChild(j),j.click(),document.body.removeChild(j),URL.revokeObjectURL(Fe)};return R.jsxs("div",{id:"app-root",className:"relative min-h-screen bg-bg text-text flex flex-col font-sans selection:bg-orange/20 selection:text-orange overflow-x-hidden",children:[R.jsx("div",{className:"absolute top-[-10px] left-[-10px] sm:top-[-40px] sm:left-[-20px] text-[120px] sm:text-[320px] font-black text-border/30 leading-none select-none pointer-events-none uppercase italic overflow-hidden hidden sm:block",children:"Mesh"}),R.jsxs("header",{className:"border-b border-border bg-surface/90 backdrop-blur-md px-3 py-2 sm:px-6 sm:py-3.5 flex flex-row items-center justify-between sticky top-0 z-40",children:[R.jsxs("div",{className:"flex items-center gap-2",children:[R.jsx("div",{className:"bg-orange text-white p-1.5 rounded-none shadow-md shadow-orange/10 shrink-0",children:R.jsx(dh,{className:"w-4 h-4 stroke-[2]"})}),R.jsxs("div",{children:[R.jsx("h1",{className:"text-lg sm:text-xl font-black tracking-tight text-text uppercase italic leading-none",children:"Visor:STL"}),R.jsx("span",{className:"text-[7.5px] tracking-[0.2em] font-mono font-bold text-muted uppercase leading-none mt-0.5 hidden xs:block",children:"Roberto Garcia Sanz"})]})]}),R.jsxs("div",{className:"flex items-center gap-1.5 font-mono",children:[R.jsxs("button",{onClick:()=>{var te;return(te=g.current)==null?void 0:te.click()},className:"flex items-center justify-center gap-1.5 px-2.5 py-1.5 sm:px-4 sm:py-2 bg-orange hover:bg-orange2 active:translate-y-0.5 text-white text-[9.5px] sm:text-xs font-bold uppercase tracking-wider rounded-none shadow-md transition-all cursor-pointer font-semibold shrink-0",children:[R.jsx(Ux,{className:"w-3.5 h-3.5"}),R.jsx("span",{className:"hidden xs:inline",children:"Subir STL"}),R.jsx("span",{className:"xs:hidden",children:"Subir"})]}),R.jsx("input",{ref:g,type:"file",accept:".stl",onChange:B,className:"hidden"}),r&&R.jsx("button",{onClick:$t,className:"flex items-center justify-center gap-1.5 px-2 py-1.5 sm:px-3 sm:py-2 bg-surface border border-border hover:bg-surface2 text-text text-[9.5px] sm:text-xs font-bold uppercase tracking-wider rounded-none transition-all cursor-pointer font-semibold shrink-0",title:"Exportar archivo STL activo",children:"Exportar"})]})]}),R.jsxs("main",{className:"flex-grow p-3 sm:p-4 lg:p-6 lg:max-w-[1600px] lg:mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-6 relative z-10",children:[R.jsxs("div",{className:"lg:col-span-8 flex flex-col gap-4 sm:gap-5",children:[R.jsxs("div",{onDragOver:ve,onDragLeave:Ae,onDrop:Ce,className:`relative w-full h-[260px] sm:h-[460px] rounded-none flex flex-col transition-all duration-350 border border-border bg-surface ${d?"ring-2 ring-orange ring-offset-4 ring-offset-bg scale-[0.995]":""}`,children:[d&&R.jsxs("div",{className:"absolute inset-0 bg-bg/95 backdrop-blur-md z-30 flex flex-col items-center justify-center border-2 border-dashed border-orange text-center m-2 rounded-none pointer-events-none",children:[R.jsx(Ux,{className:"w-16 h-16 text-orange animate-bounce mb-3"}),R.jsx("h3",{className:"text-lg font-mono font-bold text-text uppercase tracking-wider",children:"SOLTAR ARCHIVO .STL"}),R.jsx("p",{className:"text-xs font-mono text-muted mt-2",children:"Cargando malla tridimensional en tiempo real."})]}),R.jsx(a3,{modelData:r,settings:y,onModelLoaded:te=>b(te),modelScale:S})]}),R.jsxs("div",{className:"flex flex-col sm:flex-row items-center justify-between gap-4 p-3.5 rounded-none border border-dashed border-border bg-surface",children:[R.jsxs("div",{className:"flex items-center gap-3.5",children:[R.jsx("div",{className:"bg-surface2 p-2.5 rounded-none border border-border text-muted",children:R.jsx(Dx,{className:"w-3.5 h-3.5"})}),R.jsxs("div",{className:"text-left",children:[R.jsxs("p",{className:"text-xs font-mono font-bold text-text flex items-center gap-1.5 uppercase",children:["Archivo activo: ",R.jsx("span",{className:"text-orange break-all select-all font-semibold italic",children:l})]}),R.jsx("p",{className:"text-[9px] text-muted mt-0.5 font-mono",children:"Suelta archivos .stl en el visor o elígelos localmente."})]})]}),R.jsxs("button",{onClick:()=>{var te;return(te=g.current)==null?void 0:te.click()},className:"text-[10px] sm:text-xs font-mono font-bold text-orange hover:text-orange2 flex items-center gap-1 transition-all group shrink-0 uppercase tracking-wider cursor-pointer",children:["Examinar local ",R.jsx(tl,{className:"w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform"})]})]}),R.jsxs("div",{className:"bg-surface border border-border rounded-none p-4",children:[R.jsxs("div",{className:"flex items-center justify-between mb-3 border-b border-border/60 pb-2 flex-wrap gap-2",children:[R.jsxs("h2",{className:"text-xs font-bold uppercase tracking-widest text-muted flex items-center gap-2 font-mono",children:[R.jsx("span",{className:"w-1.5 h-1.5 bg-orange rounded-full"})," Modelos de Prueba"]}),R.jsx("span",{className:"text-[8px] font-mono text-muted uppercase bg-surface2 px-1.5 py-0.5 border border-border/40",children:"PRESETS.CONF"})]}),R.jsx("div",{className:"grid grid-cols-2 sm:grid-cols-3 gap-2.5 sm:gap-3.5",children:f3.map(te=>R.jsx("button",{onClick:()=>he(te.id),className:`group relative text-left p-2.5 sm:p-3.5 rounded-none border transition-all duration-200 flex flex-col justify-between h-20 sm:h-28 cursor-pointer ${i===te.id?"bg-surface2 border-orange shadow-md shadow-orange/5":"bg-surface hover:bg-surface2/50 border-border"}`,children:R.jsxs("div",{children:[R.jsxs("div",{className:"flex items-center justify-between",children:[R.jsx("span",{className:"text-[8px] bg-surface2 text-muted px-1.5 py-0.5 rounded-none font-mono uppercase tracking-wider border border-border/40",children:te.category}),R.jsx(tl,{className:`w-3 h-3 transition-transform duration-200 ${i===te.id?"text-orange translate-x-0.5":"text-muted group-hover:text-text"}`})]}),R.jsx("h3",{className:"text-[10px] sm:text-xs font-bold text-text mt-1.5 group-hover:text-orange transition-colors uppercase font-mono line-clamp-1",children:te.name}),R.jsx("p",{className:"text-[9px] text-muted line-clamp-1 sm:line-clamp-2 mt-0.5 font-mono leading-normal",children:te.description})]})},te.id))})]}),R.jsxs("div",{className:"bg-surface border border-border rounded-none p-4",children:[R.jsxs("div",{className:"flex items-center justify-between mb-3 border-b border-border/60 pb-2 flex-wrap gap-2",children:[R.jsxs("h2",{className:"text-xs font-bold uppercase tracking-widest text-muted flex items-center gap-2 font-mono",children:[R.jsx("span",{className:"w-1.5 h-1.5 bg-emerald-500 rounded-full"})," Mis Diseños"]}),R.jsx("span",{className:"text-[8px] font-mono text-muted uppercase bg-surface2 px-1.5 py-0.5 border border-border/40",children:"STL.LOCAL"})]}),R.jsx("div",{className:"grid grid-cols-2 sm:grid-cols-3 gap-2.5 sm:gap-3.5",children:d3.map(te=>R.jsxs("div",{className:`group relative text-left rounded-none border transition-all duration-200 flex flex-col justify-between h-20 sm:h-28 overflow-hidden ${i===te.id?"bg-surface2 border-emerald-500 shadow-md shadow-emerald-500/5":"bg-surface hover:bg-surface2/50 border-border"} ${m?"opacity-60":""}`,children:[R.jsxs("button",{onClick:()=>_e(te),disabled:m,className:"flex-1 text-left p-2.5 sm:p-3.5 flex flex-col gap-1 cursor-pointer w-full",children:[R.jsxs("div",{className:"flex items-center justify-between",children:[R.jsx("span",{className:"text-[8px] bg-surface2 text-muted px-1.5 py-0.5 rounded-none font-mono uppercase tracking-wider border border-border/40",children:te.category}),R.jsx(tl,{className:`w-3 h-3 transition-transform duration-200 ${i===te.id?"text-emerald-500 translate-x-0.5":"text-muted group-hover:text-text"}`})]}),R.jsx("h3",{className:"text-[10px] sm:text-xs font-bold text-text group-hover:text-emerald-500 transition-colors uppercase font-mono line-clamp-1",children:te.name}),R.jsx("p",{className:"text-[9px] text-muted line-clamp-1 sm:line-clamp-2 font-mono leading-normal",children:te.description}),m&&i===te.id&&R.jsx("span",{className:"text-[8px] font-mono text-emerald-500 animate-pulse",children:"Cargando..."})]}),R.jsx("a",{href:te.file,download:te.name+".stl",onClick:Fe=>Fe.stopPropagation(),title:"Descargar STL",className:"absolute bottom-2 right-2 p-1 rounded-none bg-surface2 border border-border text-muted hover:text-emerald-500 hover:border-emerald-500 transition-colors",children:R.jsx(U2,{className:"w-3 h-3"})})]},te.id))})]}),x.length>0&&R.jsxs("div",{className:"bg-surface border border-border rounded-none p-3.5",children:[R.jsxs("div",{className:"flex items-center justify-between mb-2.5 border-b border-border/60 pb-2",children:[R.jsxs("h2",{className:"text-xs font-bold uppercase tracking-widest text-muted flex items-center gap-2 font-mono",children:[R.jsx("span",{className:"w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"})," Modelos Guardados"]}),R.jsxs("span",{className:"text-[9px] font-mono text-muted uppercase",children:[x.length," archivo",x.length!==1?"s":""]})]}),R.jsx("div",{className:"flex gap-2 overflow-x-auto pb-2 -mx-1 px-1",children:[...x].sort((te,Fe)=>Fe.savedAt-te.savedAt).map(te=>R.jsxs("div",{className:"flex-shrink-0 flex flex-col gap-1.5 bg-surface2 border border-border p-2 w-[130px]",children:[R.jsxs("div",{className:"flex items-start gap-1.5",children:[R.jsx(Dx,{className:"w-3 h-3 text-orange shrink-0 mt-0.5"}),R.jsx("span",{className:"text-[9px] font-mono text-text font-bold leading-tight line-clamp-2 break-all",children:te.name})]}),R.jsx("span",{className:"text-[8px] font-mono text-muted",children:new Date(te.savedAt).toLocaleDateString("es-ES",{day:"2-digit",month:"2-digit",year:"2-digit"})}),R.jsxs("div",{className:"flex gap-1 mt-0.5",children:[R.jsx("button",{onClick:()=>{e(te.data.slice(0)),c(te.name),s(""),N(100)},className:"flex-1 py-1.5 text-[9px] font-mono font-bold bg-orange text-white uppercase tracking-wider cursor-pointer text-center hover:bg-orange2 transition-colors",children:"Cargar"}),R.jsx("button",{onClick:()=>{u3(te.id).then(()=>_(Fe=>Fe.filter(j=>j.id!==te.id))).catch(()=>{})},className:"px-2 py-1.5 text-[11px] font-mono bg-surface border border-border text-muted hover:text-red-600 hover:border-red-300 cursor-pointer transition-colors",title:"Eliminar archivo guardado",children:"×"})]})]},te.id))})]}),R.jsxs("details",{className:"group bg-surface border border-border rounded-none p-3.5 transition-all text-left",children:[R.jsxs("summary",{className:"list-none flex items-center justify-between text-xs font-mono font-bold text-text uppercase tracking-wider cursor-pointer select-none",children:[R.jsxs("span",{className:"flex items-center gap-2",children:[R.jsx(z2,{className:"w-4 h-4 text-orange"}),"¿Qué son los archivos STL?"]}),R.jsx(tl,{className:"w-4 h-4 text-muted group-open:rotate-90 transition-transform duration-250"})]}),R.jsx("div",{className:"mt-2.5 border-t border-border/60 pt-2.5",children:R.jsxs("p",{className:"text-[10px] sm:text-[11px] text-muted leading-relaxed font-mono",children:["La extensión ",R.jsx("strong",{className:"text-text",children:"STL (Stereolithography)"})," codifica la geometría tridimensional mediante una malla de triángulos. Todo el procesamiento y análisis se realiza de forma 100% local y privada en tu navegador."]})})]})]}),R.jsxs("div",{className:"lg:col-span-4 flex flex-col gap-5 sm:gap-6 font-mono col-span-1",children:[R.jsxs("div",{className:"bg-surface border border-border rounded-none overflow-hidden shadow-lg",children:[R.jsxs("div",{className:"bg-surface2 border-b border-border px-4 py-3.5 flex items-center justify-between",children:[R.jsxs("h3",{className:"text-xs font-mono font-bold uppercase tracking-widest text-text flex items-center gap-2",children:[R.jsx(dh,{className:"w-4 h-4 text-orange"})," Métricas y Geometría 3D"]}),R.jsx("span",{className:"text-[9px] font-mono bg-orange/10 text-orange border border-orange/20 px-2 py-0.5 rounded-none font-bold uppercase tracking-widest",children:"Inspección"})]}),R.jsx("div",{className:"p-4 space-y-4",children:A?R.jsxs(R.Fragment,{children:[R.jsxs("div",{className:"bg-surface2/60 border border-border p-3.5 rounded-none",children:[R.jsxs("div",{className:"flex justify-between items-center text-[10px] uppercase font-bold text-muted tracking-wider mb-2 font-mono",children:[R.jsx("span",{children:"Escalar Modelo (Tamaño)"}),R.jsxs("span",{className:"text-orange font-bold font-mono bg-orange/10 px-2 py-0.5 border border-orange/15",children:[S,"%"]})]}),R.jsxs("div",{className:"flex items-center gap-3",children:[R.jsx("input",{type:"range",min:"10",max:"300",step:"5",value:S,onChange:te=>N(parseInt(te.target.value)),className:"w-full accent-orange h-1 bg-surface border border-border/10 rounded-none cursor-pointer"}),R.jsx("button",{onClick:()=>N(100),className:"px-2.5 py-1 border border-border bg-surface hover:bg-surface2 text-[9px] font-mono text-muted uppercase shrink-0 hover:text-text cursor-pointer transition-colors",title:"Restaurar a escala original 1:1",children:"1:1"})]}),R.jsxs("p",{className:"text-[9px] text-muted font-mono leading-tight mt-2",children:["Usa la barra para ampliar o reducir. La base de impresión de tu máquina es de ",R.jsx("strong",{children:"250×250 mm"}),"."]})]}),nt&&R.jsxs("div",{className:"bg-red-50/90 border border-red-200 p-3.5 rounded-none text-left flex gap-3 text-red-650",children:[R.jsx(rp,{className:"w-5 h-5 shrink-0 mt-0.5 text-red-650"}),R.jsxs("div",{children:[R.jsx("h4",{className:"text-[10px] font-mono font-bold uppercase tracking-wider text-red-700",children:"¡Fuera de Límites!"}),R.jsxs("p",{className:"text-[10px] leading-relaxed font-sans text-red-650 mt-1",children:["Las dimensiones (",Me.toFixed(1)," × ",Ze.toFixed(1)," mm) exceden el límite de la base de tu impresora 3D (",R.jsx("strong",{children:"250 × 250 mm"}),"). El modelo se saldrá de la cama de trabajo."]})]})]}),R.jsxs("div",{children:[R.jsx("p",{className:"text-[9px] font-mono font-bold uppercase tracking-wider text-muted mb-1.5",children:"Caja de Contención (Bounding Box)"}),R.jsxs("div",{className:"grid grid-cols-3 gap-2.5 text-center",children:[R.jsxs("div",{className:"bg-surface2 p-2 rounded-none border border-border",children:[R.jsx("span",{className:"text-[9px] font-mono text-muted block mb-0.5",children:"X-ANCHO"}),R.jsx("strong",{className:`text-sm font-mono ${Me>250?"text-red-600 font-bold":"text-text"}`,children:Me.toFixed(1)}),R.jsx("span",{className:"text-[9px] font-mono text-muted ml-0.5",children:"mm"}),S!==100&&R.jsxs("span",{className:"text-[8px] font-mono text-muted block mt-0.5 border-t border-border/40 pt-0.5",children:["Orig: ",A.boundingBox.width.toFixed(1)]})]}),R.jsxs("div",{className:"bg-surface2 p-2 rounded-none border border-border",children:[R.jsx("span",{className:"text-[9px] font-mono text-muted block mb-0.5",children:"Y-ALTO"}),R.jsx("strong",{className:"text-sm font-mono text-text",children:Ie.toFixed(1)}),R.jsx("span",{className:"text-[9px] font-mono text-muted ml-0.5",children:"mm"}),S!==100&&R.jsxs("span",{className:"text-[8px] font-mono text-muted block mt-0.5 border-t border-border/40 pt-0.5",children:["Orig: ",A.boundingBox.height.toFixed(1)]})]}),R.jsxs("div",{className:"bg-surface2 p-2 rounded-none border border-border",children:[R.jsx("span",{className:"text-[9px] font-mono text-muted block mb-0.5",children:"Z-LARGO"}),R.jsx("strong",{className:`text-sm font-mono ${Ze>250?"text-red-600 font-bold":"text-text"}`,children:Ze.toFixed(1)}),R.jsx("span",{className:"text-[9px] font-mono text-muted ml-0.5",children:"mm"}),S!==100&&R.jsxs("span",{className:"text-[8px] font-mono text-muted block mt-0.5 border-t border-border/40 pt-0.5",children:["Orig: ",A.boundingBox.depth.toFixed(1)]})]})]})]}),R.jsxs("div",{className:"grid grid-cols-2 gap-2.5",children:[R.jsxs("div",{className:"bg-surface2 p-3 rounded-none border border-border",children:[R.jsx("span",{className:"text-[10px] text-muted block mb-1 font-bold uppercase tracking-wider",children:"Volumen"}),R.jsx("strong",{className:"text-base font-mono text-orange",children:(Ke/1e3).toFixed(2)}),R.jsx("span",{className:"text-xs font-mono text-text ml-1",children:"cm³"}),R.jsxs("div",{className:"text-[9px] text-muted mt-1 font-mono",children:[Ke.toLocaleString(void 0,{maximumFractionDigits:0})," mm³"]})]}),R.jsxs("div",{className:"bg-surface2 p-3 rounded-none border border-border",children:[R.jsx("span",{className:"text-[10px] text-muted block mb-1 font-bold uppercase tracking-wider",children:"Superficie"}),R.jsx("strong",{className:"text-base font-mono text-orange",children:(Lt/100).toFixed(1)}),R.jsx("span",{className:"text-xs font-mono text-text ml-1",children:"cm²"}),R.jsxs("div",{className:"text-[9px] text-muted mt-1 font-mono",children:[Lt.toLocaleString(void 0,{maximumFractionDigits:0})," mm²"]})]})]}),R.jsxs("div",{className:"bg-surface2 px-3 py-2 rounded-none border border-border flex justify-between items-center text-xs font-mono uppercase",children:[R.jsx("span",{className:"text-muted font-bold",children:"Complejidad:"}),R.jsxs("strong",{className:"text-text tracking-wide",children:[A.triangleCount.toLocaleString()," ",R.jsx("span",{className:"text-[9px] text-muted font-normal font-sans",children:"políg."})]})]})]}):R.jsxs("div",{className:"text-center py-8 text-muted flex flex-col items-center",children:[R.jsx(dh,{className:"w-8 h-8 text-border mb-2 animate-bounce"}),R.jsx("p",{className:"text-xs font-mono uppercase",children:"Pendiente de simulación geométrica"})]})})]}),R.jsxs("div",{className:"bg-surface border border-border rounded-none overflow-hidden shadow-lg flex flex-col",children:[R.jsxs("div",{className:"bg-surface2 border-b border-border flex text-center",children:[R.jsxs("button",{onClick:()=>q("material"),className:`flex-1 py-2.5 sm:py-3.5 px-1 text-[9px] sm:text-[10px] font-bold tracking-wider sm:tracking-widest uppercase border-b-2 transition-all flex items-center justify-center gap-1 sm:gap-1.5 font-mono cursor-pointer ${P==="material"?"border-orange text-orange bg-surface/50 font-extrabold":"border-transparent text-muted hover:text-text hover:bg-surface2/60"}`,children:[R.jsx(B2,{className:"w-3.5 h-3.5"})," Diseño"]}),R.jsxs("button",{onClick:()=>q("helpers"),className:`flex-1 py-2.5 sm:py-3.5 px-1 text-[9px] sm:text-[10px] font-bold tracking-wider sm:tracking-widest uppercase border-b-2 transition-all flex items-center justify-center gap-1 sm:gap-1.5 font-mono cursor-pointer ${P==="helpers"?"border-orange text-orange bg-surface/50 font-extrabold":"border-transparent text-muted hover:text-text hover:bg-surface2/60"}`,children:[R.jsx(X2,{className:"w-3.5 h-3.5"})," Escenario"]}),R.jsxs("button",{onClick:()=>q("slicer"),className:`flex-1 py-2.5 sm:py-3.5 px-1 text-[9px] sm:text-[10px] font-bold tracking-wider sm:tracking-widest uppercase border-b-2 transition-all flex items-center justify-center gap-1 sm:gap-1.5 font-mono cursor-pointer ${P==="slicer"?"border-orange text-orange bg-surface/50 font-extrabold":"border-transparent text-muted hover:text-text hover:bg-surface2/60"}`,children:[R.jsx(V2,{className:"w-3.5 h-3.5"})," Slicing"]}),R.jsxs("button",{onClick:()=>q("elegoo"),className:`flex-1 py-2.5 sm:py-3.5 px-1 text-[9px] sm:text-[10px] font-bold tracking-wider sm:tracking-widest uppercase border-b-2 transition-all flex items-center justify-center gap-1 sm:gap-1.5 font-mono cursor-pointer ${P==="elegoo"?"border-orange text-orange bg-surface/50 font-extrabold":"border-transparent text-muted hover:text-text hover:bg-surface2/60"}`,children:[R.jsx(w2,{className:"w-3.5 h-3.5 text-orange"})," Elegoo CF"]})]}),R.jsxs("div",{className:"p-4 flex-grow min-h-[280px]",children:[P==="material"&&R.jsxs("div",{className:"space-y-4 text-left",children:[R.jsxs("div",{children:[R.jsx("label",{className:"text-[9px] font-bold uppercase tracking-widest text-muted block mb-2 font-mono",children:"Modo de Visualización"}),R.jsx("div",{className:"grid grid-cols-2 gap-2 font-mono",children:["solid","wireframe","points","xray"].map(te=>R.jsxs("button",{onClick:()=>M(Fe=>({...Fe,mode:te})),className:`py-1.5 px-2 text-[9px] font-bold rounded-none border uppercase tracking-wider transition-all text-center cursor-pointer ${y.mode===te?"bg-orange border-orange text-white shadow-sm":"bg-surface border-border text-text hover:bg-surface2"}`,children:[te==="solid"&&"Sólido",te==="wireframe"&&"Malla",te==="points"&&"Puntos",te==="xray"&&"Rayos X"]},te))})]}),R.jsxs("div",{children:[R.jsx("label",{className:"text-[9px] font-bold uppercase tracking-widest text-muted block mb-2 font-mono",children:"Filamento (Material)"}),R.jsx("div",{className:"grid grid-cols-4 gap-1.5",children:p3.map(te=>R.jsx("button",{onClick:()=>M(Fe=>({...Fe,color:te.value,roughness:te.roughness,metalness:te.metalness})),style:{backgroundColor:te.value},className:`h-8 w-full rounded-none border transition-all relative flex items-center justify-center cursor-pointer ${y.color.toLowerCase()===te.value.toLowerCase()?"border-orange scale-105 shadow-md z-10":"border-border hover:scale-102"}`,title:te.name,children:y.color.toLowerCase()===te.value.toLowerCase()&&R.jsx("span",{className:"absolute inset-0 m-auto h-2.5 w-2.5 rounded-full bg-white border border-text/40 shadow-sm"})},te.value))}),R.jsxs("div",{className:"mt-3 flex items-center gap-2 font-mono",children:[R.jsxs("div",{className:"relative flex-grow",children:[R.jsx("input",{type:"text",value:y.color,onChange:te=>M(Fe=>({...Fe,color:te.target.value})),className:"w-full bg-surface border border-border rounded-none py-1 px-2.5 text-xs font-mono text-text focus:outline-none focus:border-orange"}),R.jsx("span",{className:"absolute right-2 top-1.5 text-[8px] text-muted font-mono font-bold",children:"HEX"})]}),R.jsx("input",{type:"color",value:y.color,onChange:te=>M(Fe=>({...Fe,color:te.target.value})),className:"h-7 w-10 rounded-none cursor-pointer border border-border bg-transparent"})]})]}),R.jsxs("div",{className:"space-y-3 pt-1 font-mono",children:[R.jsxs("div",{children:[R.jsxs("div",{className:"flex justify-between text-[9px] uppercase font-bold text-muted tracking-wider mb-1",children:[R.jsx("span",{children:"Rugosidad (Mate / Brillo)"}),R.jsx("span",{className:"text-orange font-bold",children:y.roughness.toFixed(2)})]}),R.jsx("input",{type:"range",min:"0.0",max:"1.0",step:"0.05",value:y.roughness,onChange:te=>M(Fe=>({...Fe,roughness:parseFloat(te.target.value)})),className:"w-full accent-orange h-1 bg-surface2 border border-border/10 rounded-none cursor-pointer"})]}),R.jsxs("div",{children:[R.jsxs("div",{className:"flex justify-between text-[9px] uppercase font-bold text-muted tracking-wider mb-1",children:[R.jsx("span",{children:"Metalizado (Metal / PLA)"}),R.jsx("span",{className:"text-orange font-bold",children:y.metalness.toFixed(2)})]}),R.jsx("input",{type:"range",min:"0.0",max:"1.0",step:"0.05",value:y.metalness,onChange:te=>M(Fe=>({...Fe,metalness:parseFloat(te.target.value)})),className:"w-full accent-orange h-1 bg-surface2 border border-border/10 rounded-none cursor-pointer"})]})]})]}),P==="helpers"&&R.jsxs("div",{className:"space-y-4 text-left font-mono",children:[R.jsxs("div",{children:[R.jsx("label",{className:"text-[9px] font-bold uppercase tracking-widest text-text block mb-2",children:"Referencias de Escenario"}),R.jsxs("div",{className:"space-y-1.5",children:[R.jsxs("label",{className:"flex items-center gap-2.5 bg-surface2/65 p-2 rounded-none border border-border cursor-pointer hover:bg-surface2",children:[R.jsx("input",{type:"checkbox",checked:y.showGrid,onChange:te=>M(Fe=>({...Fe,showGrid:te.target.checked})),className:"accent-orange rounded h-3.5 w-3.5"}),R.jsxs("div",{children:[R.jsx("span",{className:"text-[10px] font-bold text-text block",children:"BASE DE TRABAJO (GRID)"}),R.jsx("span",{className:"text-[8px] text-muted uppercase leading-none",children:"Rejilla bajo el modelo"})]})]}),R.jsxs("label",{className:"flex items-center gap-2.5 bg-surface2/65 p-2 rounded-none border border-border cursor-pointer hover:bg-surface2",children:[R.jsx("input",{type:"checkbox",checked:y.showAxes,onChange:te=>M(Fe=>({...Fe,showAxes:te.target.checked})),className:"accent-orange rounded h-3.5 w-3.5"}),R.jsxs("div",{children:[R.jsx("span",{className:"text-[10px] font-bold text-text block",children:"EJES COORDENADAS"}),R.jsx("span",{className:"text-[8px] text-muted uppercase leading-none",children:"Direcciones cartesianas"})]})]}),R.jsxs("label",{className:"flex items-center gap-2.5 bg-surface2/65 p-2 rounded-none border border-border cursor-pointer hover:bg-surface2",children:[R.jsx("input",{type:"checkbox",checked:y.showBoundingBox,onChange:te=>M(Fe=>({...Fe,showBoundingBox:te.target.checked})),className:"accent-orange rounded h-3.5 w-3.5"}),R.jsxs("div",{children:[R.jsx("span",{className:"text-[10px] font-bold text-text block",children:"CAJA DELIMITADORA"}),R.jsx("span",{className:"text-[8px] text-muted uppercase leading-none",children:"Límites máximos en naranja"})]})]}),R.jsxs("label",{className:"flex items-center gap-2.5 bg-surface2/65 p-2 rounded-none border border-border cursor-pointer hover:bg-surface2",children:[R.jsx("input",{type:"checkbox",checked:y.autoRotate,onChange:te=>M(Fe=>({...Fe,autoRotate:te.target.checked})),className:"accent-orange rounded h-3.5 w-3.5"}),R.jsxs("div",{children:[R.jsx("span",{className:"text-[10px] font-bold text-text block",children:"AUTO_ROTACIÓN CÁMARA"}),R.jsx("span",{className:"text-[8px] text-muted uppercase leading-none",children:"Giro automático constante"})]})]})]})]}),R.jsxs("div",{children:[R.jsx("label",{className:"text-[9px] font-bold uppercase tracking-widest text-text block mb-2",children:"Esquemas de Luces"}),R.jsx("div",{className:"space-y-1",children:h3.map(te=>R.jsxs("button",{onClick:()=>M(Fe=>({...Fe,lighting:te.value})),className:`w-full p-2 rounded-none text-left border transition-all flex items-center justify-between cursor-pointer ${y.lighting===te.value?"bg-surface border-orange text-orange font-bold":"bg-surface2 border-border text-muted hover:bg-surface"}`,children:[R.jsxs("div",{children:[R.jsx("span",{className:"text-[10px] font-bold block uppercase tracking-wide",children:te.name}),R.jsx("span",{className:"text-[8px] text-muted uppercase leading-none",children:te.desc})]}),y.lighting===te.value&&R.jsx("div",{className:"h-1.5 w-1.5 rounded-full bg-orange"})]},te.value))})]})]}),P==="slicer"&&R.jsxs("div",{className:"space-y-3.5 text-left font-mono",children:[R.jsxs("div",{children:[R.jsx("label",{className:"text-[9px] font-bold uppercase tracking-widest text-muted block mb-1",children:"Tipo de Material"}),R.jsx("select",{value:O,onChange:te=>z(te.target.value),className:"w-full bg-surface border border-border rounded-none py-1.5 px-2.5 text-xs text-text focus:outline-none focus:border-orange uppercase font-semibold cursor-pointer",children:Ox.map(te=>R.jsx("option",{value:te.value,className:"bg-surface text-text",children:te.name},te.value))})]}),R.jsxs("div",{className:"grid grid-cols-2 gap-2.5",children:[R.jsxs("div",{children:[R.jsx("label",{className:"text-[9px] font-bold uppercase tracking-widest text-muted block mb-1 font-semibold",children:"Precio Bobina (€)"}),R.jsx("input",{type:"number",min:"5",max:"200",value:H,onChange:te=>T(Math.max(1,parseFloat(te.target.value)||0)),className:"w-full bg-surface border border-border rounded-none py-1 px-2.5 text-xs text-text focus:outline-none focus:border-orange font-bold"})]}),R.jsxs("div",{children:[R.jsx("label",{className:"text-[9px] font-bold uppercase tracking-widest text-muted block mb-1 font-semibold",children:"Peso Bobina (g)"}),R.jsx("input",{type:"number",min:"100",max:"5000",value:I,onChange:te=>Z(Math.max(1,parseInt(te.target.value)||0)),className:"w-full bg-surface border border-border rounded-none py-1 px-2.5 text-xs text-text focus:outline-none focus:border-orange font-bold"})]})]}),R.jsxs("div",{children:[R.jsxs("div",{className:"flex justify-between text-[9px] uppercase font-bold text-muted tracking-wider mb-1",children:[R.jsx("span",{children:"Relleno Interno (Infill)"}),R.jsxs("span",{className:"text-orange font-bold",children:[G,"%"]})]}),R.jsx("input",{type:"range",min:"10",max:"100",step:"5",value:G,onChange:te=>K(parseInt(te.target.value)),className:"w-full accent-orange h-1 bg-surface2 border border-border/10 rounded-none cursor-pointer"}),R.jsx("span",{className:"text-[8px] text-muted uppercase",children:"Decorativo ~15%. Sólidos el 100%."})]}),R.jsxs("div",{children:[R.jsx("label",{className:"text-[9px] font-bold uppercase tracking-widest text-muted block mb-1",children:"Altura de Capa (mm)"}),R.jsxs("select",{value:F,onChange:te=>D(parseFloat(te.target.value)),className:"w-full bg-surface border border-border rounded-none py-1 px-2 text-xs text-text focus:outline-none focus:border-orange uppercase font-semibold cursor-pointer",children:[R.jsx("option",{value:"0.12",className:"bg-surface text-text",children:"0.12 mm (Extra-Fina)"}),R.jsx("option",{value:"0.16",className:"bg-surface text-text",children:"0.16 mm (Fina)"}),R.jsx("option",{value:"0.2",className:"bg-surface text-text",children:"0.20 mm (Estándar)"}),R.jsx("option",{value:"0.28",className:"bg-surface text-text",children:"0.28 mm (Borrador)"})]})]}),R.jsxs("div",{className:"bg-surface2 border border-border rounded-none p-3 space-y-2 mt-2",children:[R.jsxs("h4",{className:"text-[10px] font-bold text-text uppercase tracking-widest flex items-center gap-1.5 border-b border-border/60 pb-1.5",children:[R.jsx(T2,{className:"w-3.5 h-3.5 text-orange"})," RESULTADOS SIMULADOR"]}),A?R.jsxs("div",{className:"space-y-1.5 text-[10.5px]",children:[R.jsxs("div",{className:"flex justify-between border-b border-border/40 pb-1",children:[R.jsx("span",{className:"text-muted uppercase tracking-wider text-[9px]",children:"Peso Neto:"}),R.jsxs("strong",{className:"text-text",children:[dt.toFixed(1)," g"]})]}),R.jsxs("div",{className:"flex justify-between border-b border-border/40 pb-1",children:[R.jsx("span",{className:"text-muted uppercase tracking-wider text-[9px]",children:"Longitud Fil.:"}),R.jsxs("strong",{className:"text-text",children:[ct.toFixed(2)," m"]})]}),R.jsxs("div",{className:"flex justify-between border-b border-border/40 pb-1",children:[R.jsx("span",{className:"text-muted uppercase tracking-wider text-[9px]",children:"Capas Z:"}),R.jsxs("strong",{className:"text-orange font-bold",children:[ue," capas"]})]}),R.jsxs("div",{className:"flex justify-between border-b border-border/40 pb-1",children:[R.jsx("span",{className:"text-muted uppercase tracking-wider text-[9px]",children:"Costo:"}),R.jsx("strong",{className:"text-orange font-bold",children:St.toLocaleString(void 0,{style:"currency",currency:"EUR"})})]}),R.jsxs("div",{className:"flex justify-between pt-0.5",children:[R.jsx("span",{className:"text-muted uppercase tracking-wider text-[9px]",children:"Tiempo:"}),R.jsxs("strong",{className:"text-orange font-bold",children:["~ ",Math.max(1,Math.round(dt*1.5))," min"]})]})]}):R.jsx("p",{className:"text-[8px] text-muted uppercase tracking-wide text-center py-1",children:"Selecciona un modelo para simular costos."})]})]}),P==="elegoo"&&R.jsxs("div",{className:"space-y-3.5 text-left font-mono",children:[R.jsxs("div",{className:"bg-orange/5 border border-orange/15 p-3 rounded-none flex gap-2 items-start",children:[R.jsx($2,{className:"w-3.5 h-3.5 text-orange shrink-0 mt-0.5"}),R.jsxs("div",{children:[R.jsx("h4",{className:"text-[9.5px] font-bold text-text uppercase tracking-wider",children:"CONSEJOS ELEGOO CENTURI CARBON"}),R.jsxs("p",{className:"text-[8.5px] text-muted leading-relaxed mt-0.5",children:["Optimizador para filamentos cargados con fibra de carbono. Cama: ",R.jsx("strong",{children:"250 × 250 mm"}),"."]})]})]}),R.jsxs("div",{className:"bg-surface2 border border-border p-3 space-y-1.5",children:[R.jsxs("h5",{className:"text-[9px] font-bold text-muted uppercase tracking-wider flex items-center gap-1.5",children:[R.jsx(O2,{className:"w-3.5 h-3.5 text-orange"})," ESTADO DE LA CAMA (250x250)"]}),A?nt?R.jsxs("div",{className:"text-[9px] border border-red-200 bg-red-50/70 p-2 text-red-700 flex flex-col gap-0.5",children:[R.jsxs("span",{className:"font-bold uppercase tracking-wider flex items-center gap-1",children:[R.jsx(rp,{className:"w-3.5 h-3.5 shrink-0 text-red-650"})," ¡FUERA DE LÍMITES!"]}),R.jsx("span",{children:"Supera las dimensiones permitidas. Reduce el tamaño con el slider."})]}):R.jsxs("div",{className:"text-[9px] border border-emerald-250 bg-emerald-50/70 p-2 text-emerald-800 flex flex-col gap-0.5",children:[R.jsxs("span",{className:"font-bold uppercase tracking-wider flex items-center gap-1",children:[R.jsx(Y2,{className:"w-3.5 h-3.5 shrink-0 text-emerald-600"})," COMPATIBLE (OK)"]}),R.jsxs("span",{children:["Ocupa el ",(Me/250*100).toFixed(0),"% X y el ",(Ze/250*100).toFixed(0),"% Z. Cabe perfectamente."]})]}):R.jsx("p",{className:"text-[8.5px] text-muted uppercase",children:"Sube un archivo para analizar su ocupación."})]}),R.jsxs("div",{className:"space-y-2",children:[R.jsx("label",{className:"text-[8.5px] font-bold uppercase tracking-widest text-muted block font-mono",children:"PREAJUSTES CARBONO (AUTO-CONFIG)"}),R.jsxs("div",{className:"grid grid-cols-1 gap-1.5",children:[R.jsxs("button",{onClick:()=>ae("placf"),className:`p-2.5 border text-left rounded-none transition-all flex justify-between items-center cursor-pointer hover:bg-surface2/80 ${O==="PLA-CF"?"bg-surface border-orange shadow-sm":"bg-surface border-border"}`,children:[R.jsxs("div",{className:"space-y-0.5",children:[R.jsx("span",{className:"text-[9.5px] uppercase font-bold text-text block",children:"🧬 AUTO: PLA-CF Carbono"}),R.jsx("span",{className:"text-[8px] text-muted block font-sans",children:"Boquilla: 220°C | Cama: 60°C | Capa: 0.20mm"})]}),R.jsx("span",{className:`h-2 w-2 rounded-full ${O==="PLA-CF"?"bg-orange animate-pulse":"bg-border"}`})]}),R.jsxs("button",{onClick:()=>ae("petgcf"),className:`p-2.5 border text-left rounded-none transition-all flex justify-between items-center cursor-pointer hover:bg-surface2/80 ${O==="PETG-CF"?"bg-surface border-orange shadow-sm":"bg-surface border-border"}`,children:[R.jsxs("div",{className:"space-y-0.5",children:[R.jsx("span",{className:"text-[9.5px] uppercase font-bold text-text block",children:"🛡️ AUTO: PETG-CF Resistencia"}),R.jsx("span",{className:"text-[8px] text-muted block font-sans",children:"Boquilla: 245°C | Cama: 80°C | Capa: 0.16mm"})]}),R.jsx("span",{className:`h-2 w-2 rounded-full ${O==="PETG-CF"?"bg-orange animate-pulse":"bg-border"}`})]}),R.jsxs("button",{onClick:()=>ae("pacf"),className:`p-2.5 border text-left rounded-none transition-all flex justify-between items-center cursor-pointer hover:bg-surface2/80 ${O==="PA-CF"?"bg-surface border-orange shadow-sm":"bg-surface border-border"}`,children:[R.jsxs("div",{className:"space-y-0.5",children:[R.jsx("span",{className:"text-[9.5px] uppercase font-bold text-text block",children:"⚙️ AUTO: PA-CF Nylon Industrial"}),R.jsx("span",{className:"text-[8px] text-muted block font-sans",children:"Boquilla: 280°C | Cama: 95°C | Capa: 0.12mm (Fina)"})]}),R.jsx("span",{className:`h-2 w-2 rounded-full ${O==="PA-CF"?"bg-orange":"bg-border"}`})]})]})]}),R.jsxs("details",{className:"group bg-surface2 border border-border p-2.5 transition-all text-left text-[9px]",children:[R.jsxs("summary",{className:"list-none flex items-center justify-between text-[9px] font-bold text-text uppercase tracking-widest cursor-pointer select-none",children:[R.jsxs("span",{className:"flex items-center gap-1.5",children:[R.jsx(K2,{className:"w-3 h-3 text-orange animate-pulse"}),"REGLAS DE ORO HARDWARE"]}),R.jsx(tl,{className:"w-3.5 h-3.5 text-muted group-open:rotate-90 transition-transform duration-250"})]}),R.jsxs("ul",{className:"space-y-2 leading-relaxed text-muted list-none pl-0 border-t border-border/40 mt-2 pt-2",children:[R.jsxs("li",{className:"flex gap-1.5",children:[R.jsx("span",{className:"text-orange select-none font-bold",children:"1."}),R.jsxs("span",{children:[R.jsx("strong",{className:"text-text",children:"Boquilla Endurecida:"})," Instala una boquilla de ",R.jsx("strong",{children:"Acero Templado"})," o ",R.jsx("strong",{children:"Rubí"}),". El latón se deformará en minutos con filamento CF abrasivo."]})]}),R.jsxs("li",{className:"flex gap-1.5",children:[R.jsx("span",{className:"text-orange select-none font-bold",children:"2."}),R.jsxs("span",{children:[R.jsx("strong",{className:"text-text",children:"Ventilación reducida:"})," Mantén el ventilador de capa al 0-35% para prevenir contracciones térmicas (",R.jsx("em",{children:"warping"}),")."]})]}),R.jsxs("li",{className:"flex gap-1.5",children:[R.jsx("span",{className:"text-orange select-none font-bold",children:"3."}),R.jsxs("span",{children:[R.jsx("strong",{className:"text-text",children:"PEI y Adhesión:"})," Limpia con alcohol isopropílico al 99%. Para Nylon/PA-CF, aplica pegamento sólido especializado."]})]}),R.jsxs("li",{className:"flex gap-1.5",children:[R.jsx("span",{className:"text-orange select-none font-bold",children:"4."}),R.jsxs("span",{children:[R.jsx("strong",{className:"text-text",children:"Secado previo:"})," Seca el filamento a 55°C (PLA) o 80°C (Nylon/PETG) durante 6 horas para evitar ",R.jsx("em",{children:"stringing"}),"."]})]})]})]})]})]})]})]})]}),R.jsxs("footer",{className:"border-t border-border bg-surface px-6 py-4 flex flex-col sm:flex-row items-center justify-between text-[10px] text-muted gap-2 mt-auto font-mono uppercase tracking-wider relative z-10 font-bold",children:[R.jsx("p",{children:"© 2026 Roberto Garcia Sanz — Visor:STL"}),R.jsx("div",{className:"flex items-center gap-4",children:R.jsx("a",{href:"mailto:Excavacionesart@gmail.com",className:"hover:text-orange tracking-widest transition-colors flex items-center gap-1.5 cursor-pointer",children:"Excavacionesart@gmail.com"})})]})]})}Uy.createRoot(document.getElementById("root")).render(R.jsx(tt.StrictMode,{children:R.jsx(m3,{})}));
